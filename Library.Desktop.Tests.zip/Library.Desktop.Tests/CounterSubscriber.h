#pragma once
#include "EventSubscriber.h"
#include "Event.h"
#include "GameState.h"

namespace UnitTests
{
	class CounterSubscriber : public FieaGameEngine::EventSubscriber
	{
	public:
		CounterSubscriber();
		virtual ~CounterSubscriber();

		virtual void Notify(const FieaGameEngine::EventPublisher* eventPublisher) override;
		size_t SizeCalls  = 0;
		size_t FloatCalls = 0;
		size_t TotalCalls = 0;
	};
}

