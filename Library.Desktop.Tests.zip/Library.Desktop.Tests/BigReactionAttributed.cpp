#include "pch.h"
#include "BigReactionAttributed.h"
using namespace FieaGameEngine;

using namespace std;
using namespace std::string_literals;

namespace UnitTests
{
	RTTI_DEFINITIONS(BigReactionAttributed);

	BigReactionAttributed::BigReactionAttributed() :
		ReactionAttributed(TypeIdClass())
	{
	}

	Vector<Signature> BigReactionAttributed::Signatures()
	{
		Vector<Signature> signatureArray = ReactionAttributed::Signatures();
		signatureArray.PushBack(Signature{ "Apples", Datum::DatumTypes::Integer, 1, offsetof(BigReactionAttributed, Apples) });
		signatureArray.PushBack(Signature{ "Grapes", Datum::DatumTypes::Integer, 1, offsetof(BigReactionAttributed, Grapes) });
		signatureArray.PushBack(Signature{ "Pears", Datum::DatumTypes::Integer, 1, offsetof(BigReactionAttributed, Pears) });
		signatureArray.PushBack(Signature{ "Bananas", Datum::DatumTypes::Integer, 1, offsetof(BigReactionAttributed, Bananas) });
		return signatureArray;
	}
}