#include "pch.h"
#include "CppUnitTest.h"
#include "Foo.h"
#include "ToStringSpecializations.h"
#include "Datum.h"
/// <summary>
/// The file specifying the tests needed to ensure proper functionality of the Datum class.
/// </summary>
using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace UnitTests;
using namespace std;
using namespace std::string_literals;


namespace Microsoft::VisualStudio::CppUnitTestFramework
{
	template<>
	std::wstring ToString<Datum::DatumTypes>(const Datum::DatumTypes& type)
	{
		std::wstring value;
		try
		{
			int32_t dataIndex{};
			dataIndex = static_cast<int32_t>(type);
			return std::to_wstring(dataIndex);;
		}
		catch (const std::exception&)
		{
			value = L"end()"s;
		}
		return value;
	}

	template<>
	std::wstring ToString<RTTI>(RTTI* data)
	{
		RETURN_WIDE_STRING(data);
	}
}

namespace FieaGameEngine
{
	TEST_CLASS(DatumTests)
	{
	public:

		TEST_METHOD_INITIALIZE(Initialize) //Initial setup of memory state variables to allow memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&_startMemState);
			#endif
		}

		TEST_METHOD_CLEANUP(Cleanup) //Setup for memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &_startMemState,
				&endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
			#endif
		}
		TEST_METHOD(DefaultConstructor)
		{
			Datum default;
			Assert::AreEqual(default.Size(), size_t(0));
			Assert::AreEqual(default.Capacity(), size_t(0));
			Assert::AreEqual(default.Type(), Datum::DatumTypes::Unknown);
		}

		TEST_METHOD(TypeConstructors)
		{
			{
				Datum basicInt(Datum::DatumTypes::Integer);
				Assert::AreEqual(basicInt.Size(), size_t(0));
				Assert::AreEqual(basicInt.Capacity(), size_t(0));
				Assert::AreEqual(basicInt.Type(), Datum::DatumTypes::Integer);
			}

			{
				Datum basicFloat(Datum::DatumTypes::Float);
				Assert::AreEqual(basicFloat.Size(), size_t(0));
				Assert::AreEqual(basicFloat.Capacity(), size_t(0));
				Assert::AreEqual(basicFloat.Type(), Datum::DatumTypes::Float);
			}

			{
				Datum basicString(Datum::DatumTypes::String);
				Assert::AreEqual(basicString.Size(), size_t(0));
				Assert::AreEqual(basicString.Capacity(), size_t(0));
				Assert::AreEqual(basicString.Type(), Datum::DatumTypes::String);
			}

			{
				Datum basicVector(Datum::DatumTypes::Vector);
				Assert::AreEqual(basicVector.Size(), size_t(0));
				Assert::AreEqual(basicVector.Capacity(), size_t(0));
				Assert::AreEqual(basicVector.Type(), Datum::DatumTypes::Vector);
			}

			{
				Datum basicMatrix(Datum::DatumTypes::Matrix);
				Assert::AreEqual(basicMatrix.Size(), size_t(0));
				Assert::AreEqual(basicMatrix.Capacity(), size_t(0));
				Assert::AreEqual(basicMatrix.Type(), Datum::DatumTypes::Matrix);
			}

			{
				Datum basicFoo(Datum::DatumTypes::Pointer);
				Assert::AreEqual(basicFoo.Size(), size_t(0));
				Assert::AreEqual(basicFoo.Capacity(), size_t(0));
				Assert::AreEqual(basicFoo.Type(), Datum::DatumTypes::Pointer);
			}
		}

		TEST_METHOD(TypeSizeConstructors)
		{
			{
				Datum basicInt(Datum::DatumTypes::Integer, 2);
				Assert::AreEqual(basicInt.Size(), size_t(0));
				Assert::AreEqual(basicInt.Capacity(), size_t(2));
				Assert::AreEqual(basicInt.Type(), Datum::DatumTypes::Integer);
			}

			{
				Datum basicFloat(Datum::DatumTypes::Float, 2);
				Assert::AreEqual(basicFloat.Size(), size_t(0));
				Assert::AreEqual(basicFloat.Capacity(), size_t(2));
				Assert::AreEqual(basicFloat.Type(), Datum::DatumTypes::Float);
			}

			{
				Datum basicString(Datum::DatumTypes::String, 2);
				Assert::AreEqual(basicString.Size(), size_t(0));
				Assert::AreEqual(basicString.Capacity(), size_t(2));
				Assert::AreEqual(basicString.Type(), Datum::DatumTypes::String);
			}

			{
				Datum basicVector(Datum::DatumTypes::Vector, 2);
				Assert::AreEqual(basicVector.Size(), size_t(0));
				Assert::AreEqual(basicVector.Capacity(), size_t(2));
				Assert::AreEqual(basicVector.Type(), Datum::DatumTypes::Vector);
			}

			{
				Datum basicMatrix(Datum::DatumTypes::Matrix, 2);
				Assert::AreEqual(basicMatrix.Size(), size_t(0));
				Assert::AreEqual(basicMatrix.Capacity(), size_t(2));
				Assert::AreEqual(basicMatrix.Type(), Datum::DatumTypes::Matrix);
			}

			{
				Datum basicFoo(Datum::DatumTypes::Pointer, 2);
				Assert::AreEqual(basicFoo.Size(), size_t(0));
				Assert::AreEqual(basicFoo.Capacity(), size_t(2));
				Assert::AreEqual(basicFoo.Type(), Datum::DatumTypes::Pointer);
			}
		}

		TEST_METHOD(TypeCastConstructors)
		{
			{
				size_t basicIntValue(4);
				Datum basicInt(basicIntValue);
				Assert::AreEqual(basicInt.Size(), size_t(1));
				Assert::AreEqual(basicInt.Capacity(), size_t(1));
				Assert::AreEqual(basicInt.Type(), Datum::DatumTypes::Integer);
				Assert::AreEqual(basicInt.FrontInt(), basicIntValue);
				Assert::AreEqual(basicInt.BackInt(), basicIntValue);
			}

			{
				float basicFloatValue = 4.5;
				Datum basicFloat(basicFloatValue);
				Assert::AreEqual(basicFloat.Size(), size_t(1));
				Assert::AreEqual(basicFloat.Capacity(), size_t(1));
				Assert::AreEqual(basicFloat.Type(), Datum::DatumTypes::Float);
				Assert::AreEqual(basicFloat.FrontFloat(), 4.5f);
				Assert::AreEqual(basicFloat.BackFloat(), 4.5f);
			}

			{
				std::string basicStringValue = "Butterscotch";
				Datum basicString(basicStringValue);
				Assert::AreEqual(basicString.Size(), size_t(1));
				Assert::AreEqual(basicString.Capacity(), size_t(1));
				Assert::AreEqual(basicString.Type(), Datum::DatumTypes::String);
				Assert::AreEqual(basicString.FrontString(), basicStringValue);
				Assert::AreEqual(basicString.BackString(), basicStringValue);
			}

			{
				glm::vec4 basicVectorValue(1, 2, 4, 5);
				Datum basicVector(basicVectorValue);
				Assert::AreEqual(basicVector.Size(), size_t(1));
				Assert::AreEqual(basicVector.Capacity(), size_t(1));
				Assert::AreEqual(basicVector.Type(), Datum::DatumTypes::Vector);
				Assert::IsTrue(basicVector.FrontVector() == basicVectorValue);
				Assert::IsTrue(basicVector.BackVector() == basicVectorValue);
			}

			{
				glm::mat4 basicMatrixValue {1, 2, 4, 5,
											1, 2, 4, 5,
											1, 2, 4, 5,
											1, 2, 4, 5 };
				Datum basicMatrix(basicMatrixValue);
				Assert::AreEqual(basicMatrix.Size(), size_t(1));
				Assert::AreEqual(basicMatrix.Capacity(), size_t(1));
				Assert::AreEqual(basicMatrix.Type(), Datum::DatumTypes::Matrix);
				Assert::IsTrue(basicMatrix.FrontMatrix() == basicMatrixValue);
				Assert::IsTrue(basicMatrix.BackMatrix() == basicMatrixValue);
			}

			{
				Foo basicFooValue(1);
				RTTI* fooReference = &basicFooValue;
				Datum basicFoo(fooReference);
				Assert::AreEqual(basicFoo.Size(), size_t(1));
				Assert::AreEqual(basicFoo.Capacity(), size_t(1));
				Assert::AreEqual(basicFoo.Type(), Datum::DatumTypes::Pointer);
				Assert::AreEqual(basicFoo.FrontRTTI(), fooReference);
				Assert::AreEqual(basicFoo.BackRTTI(), fooReference);
			}
		}

		TEST_METHOD(DatumToValueAssignment)
		{
			{
				Datum basicDatum;
				Datum wrongTypeDatum(Datum::DatumTypes::Float);
				Datum externalStorage(Datum::DatumTypes::Integer);

				size_t firstValue(12);
				size_t secondValue(1);
				size_t thirdValue(8);

				size_t baseArray[] = { firstValue, secondValue, thirdValue };
				externalStorage.SetStorage(baseArray, 3);

				Assert::ExpectException<std::runtime_error>([&externalStorage, &firstValue]() { externalStorage = firstValue; }); //External storage cant be set this way
				Assert::ExpectException<std::runtime_error>([&wrongTypeDatum, &firstValue]() { wrongTypeDatum = firstValue; }); //Nor can one of the wrong type

				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Unknown);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(0));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(0));
				Assert::ExpectException<std::runtime_error>([&basicDatum]() { basicDatum.FrontInt(); });
				Assert::ExpectException<std::runtime_error>([&basicDatum]() { basicDatum.BackInt(); });

				basicDatum = firstValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Integer);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(basicDatum.FrontInt() == firstValue);
				Assert::IsTrue(basicDatum.BackInt() == firstValue);
				Assert::IsTrue(basicDatum == firstValue);

				basicDatum.PushBack(size_t(2));
				basicDatum = secondValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Integer);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(2));
				Assert::IsTrue(basicDatum.FrontInt() == secondValue);
				Assert::IsTrue(basicDatum.BackInt() == secondValue);
				Assert::IsTrue(basicDatum == secondValue);

				basicDatum = thirdValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Integer);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(2));
				Assert::IsTrue(basicDatum.FrontInt() == thirdValue);
				Assert::IsTrue(basicDatum.BackInt() == thirdValue);
				Assert::IsTrue(basicDatum == thirdValue);
			}

			{
				Datum basicDatum;
				Datum wrongTypeDatum(Datum::DatumTypes::Integer);
				Datum externalStorage(Datum::DatumTypes::Float);

				float firstValue = 12.5f;
				float secondValue = 1.2f;
				float thirdValue = 8.3f;

				float baseArray[] = { firstValue, secondValue, thirdValue };
				externalStorage.SetStorage(baseArray, 3);

				Assert::ExpectException<std::runtime_error>([&externalStorage, &firstValue]() { externalStorage = firstValue; }); //External storage cant be set this way
				Assert::ExpectException<std::runtime_error>([&wrongTypeDatum, &firstValue]() { wrongTypeDatum = firstValue; }); //Nor can one of the wrong type

				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Unknown);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(0));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(0));
				Assert::ExpectException<std::runtime_error>([&basicDatum]() { basicDatum.FrontFloat(); });
				Assert::ExpectException<std::runtime_error>([&basicDatum]() { basicDatum.BackFloat(); });

				basicDatum = firstValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Float);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(basicDatum.FrontFloat() == firstValue);
				Assert::IsTrue(basicDatum.BackFloat() == firstValue);
				Assert::IsTrue(basicDatum == firstValue);

				basicDatum.PushBack(secondValue);
				basicDatum = secondValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Float);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(2));
				Assert::IsTrue(basicDatum.FrontFloat() == secondValue);
				Assert::IsTrue(basicDatum.BackFloat() == secondValue);
				Assert::IsTrue(basicDatum == secondValue);

				basicDatum = thirdValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Float);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(2));
				Assert::IsTrue(basicDatum.FrontFloat() == thirdValue);
				Assert::IsTrue(basicDatum.BackFloat() == thirdValue);
				Assert::IsTrue(basicDatum == thirdValue);
			}

			{
				Datum basicDatum;
				Datum wrongTypeDatum(Datum::DatumTypes::Integer);
				Datum externalStorage(Datum::DatumTypes::String);

				std::string firstValue = "Apple";
				std::string secondValue = "Pear";
				std::string thirdValue = "Pineapple";

				std::string baseArray[] = { firstValue, secondValue, thirdValue };
				externalStorage.SetStorage(baseArray, 3);

				Assert::ExpectException<std::runtime_error>([&externalStorage, &firstValue]() { externalStorage = firstValue; }); //External storage cant be set this way
				Assert::ExpectException<std::runtime_error>([&wrongTypeDatum, &firstValue]() { wrongTypeDatum = firstValue; }); //Nor can one of the wrong type

				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Unknown);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(0));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(0));
				Assert::ExpectException<std::runtime_error>([&basicDatum]() { basicDatum.FrontString(); });
				Assert::ExpectException<std::runtime_error>([&basicDatum]() { basicDatum.BackString(); });

				basicDatum = firstValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::String);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(basicDatum.FrontString() == firstValue);
				Assert::IsTrue(basicDatum.BackString() == firstValue);
				Assert::IsTrue(basicDatum == firstValue);

				basicDatum.PushBack(secondValue);
				basicDatum = secondValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::String);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(2));
				Assert::IsTrue(basicDatum.FrontString() == secondValue);
				Assert::IsTrue(basicDatum.BackString() == secondValue);
				Assert::IsTrue(basicDatum == secondValue);

				basicDatum = thirdValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::String);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(2));
				Assert::IsTrue(basicDatum.FrontString() == thirdValue);
				Assert::IsTrue(basicDatum.BackString() == thirdValue);
				Assert::IsTrue(basicDatum == thirdValue);
			}

			{
				Datum basicDatum;
				Datum wrongTypeDatum(Datum::DatumTypes::Integer);
				Datum externalStorage(Datum::DatumTypes::Vector);

				glm::vec4 firstValue = {0, 1, 2, 3};
				glm::vec4 secondValue = {2, 4, 6, 8};
				glm::vec4 thirdValue = { 3, 6, 9, 12 };

				glm::vec4 baseArray[] = { firstValue, secondValue, thirdValue };
				externalStorage.SetStorage(baseArray, 3);

				Assert::ExpectException<std::runtime_error>([&externalStorage, &firstValue]() { externalStorage = firstValue; }); //External storage cant be set this way
				Assert::ExpectException<std::runtime_error>([&wrongTypeDatum, &firstValue]() { wrongTypeDatum = firstValue; }); //Nor can one of the wrong type

				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Unknown);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(0));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(0));
				Assert::ExpectException<std::runtime_error>([&basicDatum]() { basicDatum.FrontVector(); });
				Assert::ExpectException<std::runtime_error>([&basicDatum]() { basicDatum.BackVector(); });

				basicDatum = firstValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Vector);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(basicDatum.FrontVector() == firstValue);
				Assert::IsTrue(basicDatum.BackVector() == firstValue);
				Assert::IsTrue(basicDatum == firstValue);

				basicDatum.PushBack(secondValue);
				basicDatum = secondValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Vector);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(2));
				Assert::IsTrue(basicDatum.FrontVector() == secondValue);
				Assert::IsTrue(basicDatum.BackVector() == secondValue);
				Assert::IsTrue(basicDatum == secondValue);

				basicDatum = thirdValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Vector);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(2));
				Assert::IsTrue(basicDatum.FrontVector() == thirdValue);
				Assert::IsTrue(basicDatum.BackVector() == thirdValue);
				Assert::IsTrue(basicDatum == thirdValue);
			}

			{
				Datum basicDatum;
				Datum wrongTypeDatum(Datum::DatumTypes::Integer);
				Datum externalStorage(Datum::DatumTypes::Matrix);

				glm::mat4 firstValue = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 secondValue = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32 };
				glm::mat4 thirdValue = { 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 39, 42, 45, 48 };

				glm::mat4 baseArray[] = { firstValue, secondValue, thirdValue };
				externalStorage.SetStorage(baseArray, 3);

				Assert::ExpectException<std::runtime_error>([&externalStorage, &firstValue]() { externalStorage = firstValue; }); //External storage cant be set this way
				Assert::ExpectException<std::runtime_error>([&wrongTypeDatum, &firstValue]() { wrongTypeDatum = firstValue; }); //Nor can one of the wrong type

				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Unknown);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(0));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(0));
				Assert::ExpectException<std::runtime_error>([&basicDatum]() { basicDatum.FrontMatrix(); });
				Assert::ExpectException<std::runtime_error>([&basicDatum]() { basicDatum.BackMatrix(); });

				basicDatum = firstValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Matrix);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(basicDatum.FrontMatrix() == firstValue);
				Assert::IsTrue(basicDatum.BackMatrix() == firstValue);
				Assert::IsTrue(basicDatum == firstValue);

				basicDatum.PushBack(secondValue);
				basicDatum = secondValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Matrix);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(2));
				Assert::IsTrue(basicDatum.FrontMatrix() == secondValue);
				Assert::IsTrue(basicDatum.BackMatrix() == secondValue);
				Assert::IsTrue(basicDatum == secondValue);

				basicDatum = thirdValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Matrix);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(2));
				Assert::IsTrue(basicDatum.FrontMatrix() == thirdValue);
				Assert::IsTrue(basicDatum.BackMatrix() == thirdValue);
				Assert::IsTrue(basicDatum == thirdValue);
			}

			{
				Datum basicDatum;
				Datum wrongTypeDatum(Datum::DatumTypes::Integer);
				Datum externalStorage(Datum::DatumTypes::Pointer);

				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);

				RTTI* firstValue = &firstFoo;
				RTTI* secondValue = &secondFoo;
				RTTI* thirdValue = &thirdFoo;

				RTTI* baseArray[] = { firstValue, secondValue, thirdValue };
				externalStorage.SetStorage(baseArray, 3);

				Assert::ExpectException<std::runtime_error>([&externalStorage, &firstValue]() { externalStorage = firstValue; }); //External storage cant be set this way
				Assert::ExpectException<std::runtime_error>([&wrongTypeDatum, &firstValue]() { wrongTypeDatum = firstValue; }); //Nor can one of the wrong type

				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Unknown);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(0));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(0));
				Assert::ExpectException<std::runtime_error>([&basicDatum]() { basicDatum.FrontRTTI(); });
				Assert::ExpectException<std::runtime_error>([&basicDatum]() { basicDatum.BackRTTI(); });

				basicDatum = firstValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Pointer);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(basicDatum.FrontRTTI() == firstValue);
				Assert::IsTrue(basicDatum.BackRTTI() == firstValue);
				Assert::IsTrue(basicDatum == firstValue);

				basicDatum.PushBack(secondValue);
				basicDatum = secondValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Pointer);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(2));
				Assert::IsTrue(basicDatum.FrontRTTI() == secondValue);
				Assert::IsTrue(basicDatum.BackRTTI() == secondValue);
				Assert::IsTrue(basicDatum == secondValue);

				basicDatum = thirdValue;
				Assert::AreEqual(basicDatum.Type(), Datum::DatumTypes::Pointer);
				Assert::AreEqual(basicDatum.Size(), static_cast<size_t>(1));
				Assert::AreEqual(basicDatum.Capacity(), static_cast<size_t>(2));
				Assert::IsTrue(basicDatum.FrontRTTI() == thirdValue);
				Assert::IsTrue(basicDatum.BackRTTI() == thirdValue);
				Assert::IsTrue(basicDatum == thirdValue);
			}
		}

		TEST_METHOD(CopyConstructor)
		{
			{
				size_t basicIntValue(4);
				Datum basicInt(basicIntValue);
				basicInt.Reserve(5);

				Datum emptyDatum;
				Datum emptyIntDatum(Datum::DatumTypes::Integer);
				basicInt.PushBack(size_t(9));
				basicInt.PushBack(size_t(25));

				Assert::AreEqual(basicInt.FrontInt(), basicIntValue);
				Assert::AreEqual(basicInt.BackInt(), static_cast<size_t>(25));
				Assert::AreEqual(basicInt.Size(), static_cast<size_t>(3));
				Assert::AreEqual(basicInt.Capacity(), static_cast<size_t>(5));
				Assert::AreEqual(basicInt.Type(), Datum::DatumTypes::Integer);

				Datum copiedInt = basicInt; //All values are copied here.
				Assert::AreEqual(copiedInt.FrontInt(), static_cast<size_t>(4));
				Assert::AreEqual(copiedInt.BackInt(), static_cast<size_t>(25));
				Assert::AreEqual(copiedInt.Size(), static_cast<size_t>(3));
				Assert::AreEqual(copiedInt.Capacity(), static_cast<size_t>(3)); //Capacity doesnt need to be copied
				Assert::AreEqual(copiedInt.Type(), Datum::DatumTypes::Integer);

				Datum emptyIntCopy = emptyIntDatum;
				Assert::AreEqual(emptyIntCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyIntCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyIntCopy.Type(), Datum::DatumTypes::Integer);
				Assert::ExpectException<std::runtime_error>([&emptyIntCopy]() { emptyIntCopy.FrontInt(); });
				Assert::ExpectException<std::runtime_error>([&emptyIntCopy]() { emptyIntCopy.BackInt(); });

				Datum emptyCopy = emptyDatum;
				Assert::AreEqual(emptyCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Type(), Datum::DatumTypes::Unknown);
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.FrontInt(); });
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.BackInt(); });
			}

			{
				float basicFloatValue = 4.9f;
				Datum basicFloat(basicFloatValue);
				basicFloat.Reserve(5);

				Datum emptyDatum;
				Datum emptyFloatDatum(Datum::DatumTypes::Float);
				basicFloat.PushBack(9.4f);
				basicFloat.PushBack(25.2f);

				Assert::AreEqual(basicFloat.FrontFloat(), 4.9f);
				Assert::AreEqual(basicFloat.BackFloat(), 25.2f);
				Assert::AreEqual(basicFloat.Size(), static_cast<size_t>(3));
				Assert::AreEqual(basicFloat.Capacity(), static_cast<size_t>(5));
				Assert::AreEqual(basicFloat.Type(), Datum::DatumTypes::Float);

				Datum copiedFloat = basicFloat; //All values are copied here.
				Assert::AreEqual(copiedFloat.FrontFloat(), 4.9f);
				Assert::AreEqual(copiedFloat.BackFloat(), 25.2f);
				Assert::AreEqual(copiedFloat.Size(), static_cast<size_t>(3));
				Assert::AreEqual(copiedFloat.Capacity(), static_cast<size_t>(3)); //Capacity doesnt need to be copied
				Assert::AreEqual(copiedFloat.Type(), Datum::DatumTypes::Float);

				Datum emptyFloatCopy = emptyFloatDatum;
				Assert::AreEqual(emptyFloatCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyFloatCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyFloatCopy.Type(), Datum::DatumTypes::Float);
				Assert::ExpectException<std::runtime_error>([&emptyFloatCopy]() { emptyFloatCopy.FrontFloat(); });
				Assert::ExpectException<std::runtime_error>([&emptyFloatCopy]() { emptyFloatCopy.BackFloat(); });

				Datum emptyCopy = emptyDatum;
				Assert::AreEqual(emptyCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Type(), Datum::DatumTypes::Unknown);
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.FrontFloat(); });
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.BackFloat(); });
			}

			{
				std::string basicStringValue = "Apples";
				std::string oranges = "Oranges";
				std::string pears = "Pears";
				Datum basicString(basicStringValue);
				basicString.Reserve(5);

				Datum emptyDatum;
				Datum emptyStringDatum(Datum::DatumTypes::String);
				basicString.PushBack(oranges);
				basicString.PushBack(pears);

				Assert::AreEqual(basicString.FrontString(), static_cast<std::string>("Apples"));
				Assert::AreEqual(basicString.BackString(), static_cast<std::string>("Pears"));
				Assert::AreEqual(basicString.Size(), static_cast<size_t>(3));
				Assert::AreEqual(basicString.Capacity(), static_cast<size_t>(5));
				Assert::AreEqual(basicString.Type(), Datum::DatumTypes::String);

				Datum copiedString = basicString; //All values are copied here.
				Assert::AreEqual(copiedString.FrontString(), static_cast<std::string>("Apples"));
				Assert::AreEqual(copiedString.BackString(), static_cast<std::string>("Pears"));
				Assert::AreEqual(copiedString.Size(), static_cast<size_t>(3));
				Assert::AreEqual(copiedString.Capacity(), static_cast<size_t>(3)); //Capacity doesnt need to be copied
				Assert::AreEqual(copiedString.Type(), Datum::DatumTypes::String);

				Datum emptyStringCopy = emptyStringDatum;
				Assert::AreEqual(emptyStringCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyStringCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyStringCopy.Type(), Datum::DatumTypes::String);
				Assert::ExpectException<std::runtime_error>([&emptyStringCopy]() { emptyStringCopy.FrontString(); });
				Assert::ExpectException<std::runtime_error>([&emptyStringCopy]() { emptyStringCopy.BackString(); });

				Datum emptyCopy = emptyDatum;
				Assert::AreEqual(emptyCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Type(), Datum::DatumTypes::Unknown);
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.FrontString(); });
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.BackString(); });
			}

			{
				glm::vec4 basicVectorValue = { 0, 1, 2, 3};
				Datum basicVector(basicVectorValue);
				basicVector.Reserve(5);

				Datum emptyDatum;
				Datum emptyVectorDatum(Datum::DatumTypes::Vector);
				basicVector.PushBack(glm::vec4{4, 5, 6, 7});
				basicVector.PushBack(glm::vec4{8, 9, 10, 11});

				Assert::IsTrue(basicVector.FrontVector() == basicVectorValue);
				Assert::IsTrue(basicVector.BackVector() == glm::vec4{ 8, 9, 10, 11 });
				Assert::AreEqual(basicVector.Size(), static_cast<size_t>(3));
				Assert::AreEqual(basicVector.Capacity(), static_cast<size_t>(5));
				Assert::AreEqual(basicVector.Type(), Datum::DatumTypes::Vector);

				Datum copiedVector = basicVector; //All values are copied here.
				Assert::IsTrue(copiedVector.FrontVector() == basicVectorValue);
				Assert::IsTrue(copiedVector.BackVector() == glm::vec4{ 8, 9, 10, 11 });
				Assert::AreEqual(copiedVector.Size(), static_cast<size_t>(3));
				Assert::AreEqual(copiedVector.Capacity(), static_cast<size_t>(3)); //Capacity doesnt need to be copied
				Assert::AreEqual(copiedVector.Type(), Datum::DatumTypes::Vector);

				Datum emptyVectorCopy = emptyVectorDatum;
				Assert::AreEqual(emptyVectorCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyVectorCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyVectorCopy.Type(), Datum::DatumTypes::Vector);
				Assert::ExpectException<std::runtime_error>([&emptyVectorCopy]() { emptyVectorCopy.FrontVector(); });
				Assert::ExpectException<std::runtime_error>([&emptyVectorCopy]() { emptyVectorCopy.BackVector(); });

				Datum emptyCopy = emptyDatum;
				Assert::AreEqual(emptyCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Type(), Datum::DatumTypes::Unknown);
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.FrontVector(); });
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.BackVector(); });
			}

			{
				glm::mat4 basicMatrixValue{ 1, 2, 4, 5,
											1, 2, 4, 5,
											1, 2, 4, 5,
											1, 2, 4, 5 };

				glm::mat4 basicMatrixValue2{ 5, 6, 77, 15,
											11, 12, 14, 15,
											11, 12, 14, 15,
											11, 12, 14, 15 };

				glm::mat4 basicMatrixValue3{ 21, 22, 24, 25,
											21, 22, 24, 25,
											21, 22, 24, 25,
											21, 22, 24, 25 };

				Datum basicMatrix(basicMatrixValue);
				basicMatrix.Reserve(5);

				Datum emptyDatum;
				Datum emptyMatrixDatum(Datum::DatumTypes::Matrix);
				basicMatrix.PushBack(basicMatrixValue2);
				basicMatrix.PushBack(basicMatrixValue3);

				Assert::IsTrue(basicMatrix.FrontMatrix() == basicMatrixValue);
				Assert::IsTrue(basicMatrix.BackMatrix() == basicMatrixValue3);
				Assert::AreEqual(basicMatrix.Size(), static_cast<size_t>(3));
				Assert::AreEqual(basicMatrix.Capacity(), static_cast<size_t>(5));
				Assert::AreEqual(basicMatrix.Type(), Datum::DatumTypes::Matrix);

				Datum copiedMatrix = basicMatrix; //All values are copied here.
				Assert::IsTrue(copiedMatrix.FrontMatrix() == basicMatrixValue);
				Assert::IsTrue(copiedMatrix.BackMatrix() == basicMatrixValue3);
				Assert::AreEqual(copiedMatrix.Size(), static_cast<size_t>(3));
				Assert::AreEqual(copiedMatrix.Capacity(), static_cast<size_t>(3));
				Assert::AreEqual(copiedMatrix.Type(), Datum::DatumTypes::Matrix);

				Datum emptyMatrixCopy = emptyMatrixDatum;
				Assert::AreEqual(emptyMatrixCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyMatrixCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyMatrixCopy.Type(), Datum::DatumTypes::Matrix);
				Assert::ExpectException<std::runtime_error>([&emptyMatrixCopy]() { emptyMatrixCopy.FrontMatrix(); });
				Assert::ExpectException<std::runtime_error>([&emptyMatrixCopy]() { emptyMatrixCopy.BackMatrix(); });

				Datum emptyCopy = emptyDatum;
				Assert::AreEqual(emptyCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Type(), Datum::DatumTypes::Unknown);
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.FrontMatrix(); });
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.BackMatrix(); });
			}

			{
				Foo basicFooValue(4);
				RTTI* fooReference = &basicFooValue;
				Foo basicFooValue2(10);
				RTTI* fooReference2 = &basicFooValue2;
				Foo basicFooValue3(25);
				RTTI* fooReference3 = &basicFooValue3;

				Datum basicFoo(fooReference);
				basicFoo.Reserve(5);

				basicFoo.PushBack(fooReference2);
				basicFoo.PushBack(fooReference3);

				Datum emptyDatum;
				Datum emptyFooDatum(Datum::DatumTypes::Pointer);

				Assert::AreEqual(basicFoo.FrontRTTI(), fooReference);
				Assert::AreEqual(basicFoo.BackRTTI(), fooReference3);
				Assert::AreEqual(basicFoo.Size(), static_cast<size_t>(3));
				Assert::AreEqual(basicFoo.Capacity(), static_cast<size_t>(5));
				Assert::AreEqual(basicFoo.Type(), Datum::DatumTypes::Pointer);

				Datum copiedFoo = basicFoo; //All values are copied here.
				Assert::AreEqual(copiedFoo.FrontRTTI(), fooReference);
				Assert::AreEqual(copiedFoo.BackRTTI(), fooReference3);
				Assert::AreEqual(copiedFoo.Size(), static_cast<size_t>(3));
				Assert::AreEqual(copiedFoo.Capacity(), static_cast<size_t>(3)); //Capacity doesnt need to be copied
				Assert::AreEqual(copiedFoo.Type(), Datum::DatumTypes::Pointer);

				Datum emptyFooCopy = emptyFooDatum;
				Assert::AreEqual(emptyFooCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyFooCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyFooCopy.Type(), Datum::DatumTypes::Pointer);
				Assert::ExpectException<std::runtime_error>([&emptyFooCopy]() { emptyFooCopy.FrontRTTI(); });
				Assert::ExpectException<std::runtime_error>([&emptyFooCopy]() { emptyFooCopy.BackRTTI(); });

				Datum emptyCopy = emptyDatum;
				Assert::AreEqual(emptyCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Type(), Datum::DatumTypes::Unknown);
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.FrontRTTI(); });
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.BackRTTI(); });
			}

		}

		TEST_METHOD(MoveConstructor)
		{
			{
				size_t basicIntValue(4);
				Datum basicInt(basicIntValue);
				basicInt.Reserve(5);

				Datum emptyDatum;
				Datum emptyIntDatum(Datum::DatumTypes::Integer);
				basicInt.PushBack(static_cast<size_t>(9));
				basicInt.PushBack(static_cast<size_t>(25));

				Assert::AreEqual(basicInt.FrontInt(), static_cast<size_t>(4));
				Assert::AreEqual(basicInt.BackInt(), static_cast<size_t>(25));
				Assert::AreEqual(basicInt.Size(), static_cast<size_t>(3));
				Assert::AreEqual(basicInt.Capacity(), static_cast<size_t>(5));
				Assert::AreEqual(basicInt.Type(), Datum::DatumTypes::Integer);

				Datum copiedInt = move(basicInt); //All values are copied here.
				Assert::AreEqual(copiedInt.FrontInt(), static_cast<size_t>(4));
				Assert::AreEqual(copiedInt.BackInt(), static_cast<size_t>(25));
				Assert::AreEqual(copiedInt.Size(), static_cast<size_t>(3));
				Assert::AreEqual(copiedInt.Capacity(), static_cast<size_t>(5)); //Capacity is copied
				Assert::AreEqual(copiedInt.Type(), Datum::DatumTypes::Integer);

				Datum emptyIntCopy = move(emptyIntDatum);
				Assert::AreEqual(emptyIntCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyIntCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyIntCopy.Type(), Datum::DatumTypes::Integer);
				Assert::ExpectException<std::runtime_error>([&emptyIntCopy]() { emptyIntCopy.FrontInt(); });
				Assert::ExpectException<std::runtime_error>([&emptyIntCopy]() { emptyIntCopy.BackInt(); });

				Datum emptyCopy = move(emptyDatum);
				Assert::AreEqual(emptyCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Type(), Datum::DatumTypes::Unknown);
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.FrontInt(); });
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.BackInt(); });
			}

			{
				float basicFloatValue = 4.9f;
				Datum basicFloat(basicFloatValue);
				basicFloat.Reserve(5);

				Datum emptyDatum;
				Datum emptyFloatDatum(Datum::DatumTypes::Float);
				basicFloat.PushBack(9.4f);
				basicFloat.PushBack(25.2f);

				Assert::AreEqual(basicFloat.FrontFloat(), 4.9f);
				Assert::AreEqual(basicFloat.BackFloat(), 25.2f);
				Assert::AreEqual(basicFloat.Size(), static_cast<size_t>(3));
				Assert::AreEqual(basicFloat.Capacity(), static_cast<size_t>(5));
				Assert::AreEqual(basicFloat.Type(), Datum::DatumTypes::Float);

				Datum copiedFloat = move(basicFloat); //All values are copied here.
				Assert::AreEqual(copiedFloat.FrontFloat(), 4.9f);
				Assert::AreEqual(copiedFloat.BackFloat(), 25.2f);
				Assert::AreEqual(copiedFloat.Size(), static_cast<size_t>(3));
				Assert::AreEqual(copiedFloat.Capacity(), static_cast<size_t>(5)); //Capacity is copied
				Assert::AreEqual(copiedFloat.Type(), Datum::DatumTypes::Float);

				Datum emptyFloatCopy = move(emptyFloatDatum);
				Assert::AreEqual(emptyFloatCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyFloatCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyFloatCopy.Type(), Datum::DatumTypes::Float);
				Assert::ExpectException<std::runtime_error>([&emptyFloatCopy]() { emptyFloatCopy.FrontFloat(); });
				Assert::ExpectException<std::runtime_error>([&emptyFloatCopy]() { emptyFloatCopy.BackFloat(); });

				Datum emptyCopy = move(emptyDatum);
				Assert::AreEqual(emptyCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Type(), Datum::DatumTypes::Unknown);
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.FrontFloat(); });
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.BackFloat(); });
			}

			{
				std::string basicStringValue = "Apples";
				std::string oranges = "Oranges";
				std::string pears = "Pears";
				Datum basicString(basicStringValue);
				basicString.Reserve(5);

				Datum emptyDatum;
				Datum emptyStringDatum(Datum::DatumTypes::String);
				basicString.PushBack(oranges);
				basicString.PushBack(pears);

				Assert::AreEqual(basicString.FrontString(), static_cast<std::string>("Apples"));
				Assert::AreEqual(basicString.BackString(), static_cast<std::string>("Pears"));
				Assert::AreEqual(basicString.Size(), static_cast<size_t>(3));
				Assert::AreEqual(basicString.Capacity(), static_cast<size_t>(5));
				Assert::AreEqual(basicString.Type(), Datum::DatumTypes::String);

				Datum copiedString = move(basicString); //All values are copied here.
				Assert::AreEqual(copiedString.FrontString(), static_cast<std::string>("Apples"));
				Assert::AreEqual(copiedString.BackString(), static_cast<std::string>("Pears"));
				Assert::AreEqual(copiedString.Size(), static_cast<size_t>(3));
				Assert::AreEqual(copiedString.Capacity(), static_cast<size_t>(5)); //Capacity is copied
				Assert::AreEqual(copiedString.Type(), Datum::DatumTypes::String);

				Datum emptyStringCopy = move(emptyStringDatum);
				Assert::AreEqual(emptyStringCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyStringCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyStringCopy.Type(), Datum::DatumTypes::String);
				Assert::ExpectException<std::runtime_error>([&emptyStringCopy]() { emptyStringCopy.FrontString(); });
				Assert::ExpectException<std::runtime_error>([&emptyStringCopy]() { emptyStringCopy.BackString(); });

				Datum emptyCopy = move(emptyDatum);
				Assert::AreEqual(emptyCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Type(), Datum::DatumTypes::Unknown);
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.FrontString(); });
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.BackString(); });
			}

			{
				glm::vec4 basicVectorValue = { 0, 1, 2, 3 };
				Datum basicVector(basicVectorValue);
				basicVector.Reserve(5);

				Datum emptyDatum;
				Datum emptyVectorDatum(Datum::DatumTypes::Vector);
				basicVector.PushBack(glm::vec4{ 4, 5, 6, 7 });
				basicVector.PushBack(glm::vec4{ 8, 9, 10, 11 });

				Assert::IsTrue(basicVector.FrontVector() == basicVectorValue);
				Assert::IsTrue(basicVector.BackVector() == glm::vec4{ 8, 9, 10, 11 });
				Assert::AreEqual(basicVector.Size(), static_cast<size_t>(3));
				Assert::AreEqual(basicVector.Capacity(), static_cast<size_t>(5));
				Assert::AreEqual(basicVector.Type(), Datum::DatumTypes::Vector);

				Datum copiedVector = move(basicVector); //All values are copied here.
				Assert::IsTrue(copiedVector.FrontVector() == basicVectorValue);
				Assert::IsTrue(copiedVector.BackVector() == glm::vec4{ 8, 9, 10, 11 });
				Assert::AreEqual(copiedVector.Size(), static_cast<size_t>(3));
				Assert::AreEqual(copiedVector.Capacity(), static_cast<size_t>(5)); //Capacity is copied
				Assert::AreEqual(copiedVector.Type(), Datum::DatumTypes::Vector);

				Datum emptyVectorCopy = move(emptyVectorDatum);
				Assert::AreEqual(emptyVectorCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyVectorCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyVectorCopy.Type(), Datum::DatumTypes::Vector);
				Assert::ExpectException<std::runtime_error>([&emptyVectorCopy]() { emptyVectorCopy.FrontVector(); });
				Assert::ExpectException<std::runtime_error>([&emptyVectorCopy]() { emptyVectorCopy.BackVector(); });

				Datum emptyCopy = move(emptyDatum);
				Assert::AreEqual(emptyCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Type(), Datum::DatumTypes::Unknown);
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.FrontVector(); });
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.BackVector(); });
			}

			{
				glm::mat4 basicMatrixValue{ 1, 2, 4, 5,
											1, 2, 4, 5,
											1, 2, 4, 5,
											1, 2, 4, 5 };

				glm::mat4 basicMatrixValue2{ 5, 6, 77, 15,
											11, 12, 14, 15,
											11, 12, 14, 15,
											11, 12, 14, 15 };

				glm::mat4 basicMatrixValue3{ 21, 22, 24, 25,
											21, 22, 24, 25,
											21, 22, 24, 25,
											21, 22, 24, 25 };

				Datum basicMatrix(basicMatrixValue);
				basicMatrix.Reserve(5);

				Datum emptyDatum;
				Datum emptyMatrixDatum(Datum::DatumTypes::Matrix);
				basicMatrix.PushBack(basicMatrixValue2);
				basicMatrix.PushBack(basicMatrixValue3);

				Assert::IsTrue(basicMatrix.FrontMatrix() == basicMatrixValue);
				Assert::IsTrue(basicMatrix.BackMatrix() == basicMatrixValue3);
				Assert::AreEqual(basicMatrix.Size(), static_cast<size_t>(3));
				Assert::AreEqual(basicMatrix.Capacity(), static_cast<size_t>(5));
				Assert::AreEqual(basicMatrix.Type(), Datum::DatumTypes::Matrix);

				Datum copiedMatrix = move(basicMatrix); //All values are copied here.
				Assert::IsTrue(copiedMatrix.FrontMatrix() == basicMatrixValue);
				Assert::IsTrue(copiedMatrix.BackMatrix() == basicMatrixValue3);
				Assert::AreEqual(copiedMatrix.Size(), static_cast<size_t>(3));
				Assert::AreEqual(copiedMatrix.Capacity(), static_cast<size_t>(5));
				Assert::AreEqual(copiedMatrix.Type(), Datum::DatumTypes::Matrix);

				Datum emptyMatrixCopy = move(emptyMatrixDatum);
				Assert::AreEqual(emptyMatrixCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyMatrixCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyMatrixCopy.Type(), Datum::DatumTypes::Matrix);
				Assert::ExpectException<std::runtime_error>([&emptyMatrixCopy]() { emptyMatrixCopy.FrontMatrix(); });
				Assert::ExpectException<std::runtime_error>([&emptyMatrixCopy]() { emptyMatrixCopy.BackMatrix(); });

				Datum emptyCopy = move(emptyDatum);
				Assert::AreEqual(emptyCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Type(), Datum::DatumTypes::Unknown);
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.FrontMatrix(); });
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.BackMatrix(); });
			}

			{
				Foo basicFooValue(4);
				RTTI* fooReference = &basicFooValue;
				Foo basicFooValue2(10);
				RTTI* fooReference2 = &basicFooValue2;
				Foo basicFooValue3(25);
				RTTI* fooReference3 = &basicFooValue3;

				Datum basicFoo(fooReference);
				basicFoo.Reserve(5);

				basicFoo.PushBack(fooReference2);
				basicFoo.PushBack(fooReference3);

				Datum emptyDatum;
				Datum emptyFooDatum(Datum::DatumTypes::Pointer);

				Assert::AreEqual(basicFoo.FrontRTTI(), fooReference);
				Assert::AreEqual(basicFoo.BackRTTI(), fooReference3);
				Assert::AreEqual(basicFoo.Size(), static_cast<size_t>(3));
				Assert::AreEqual(basicFoo.Capacity(), static_cast<size_t>(5));
				Assert::AreEqual(basicFoo.Type(), Datum::DatumTypes::Pointer);

				Datum copiedFoo = move(basicFoo); //All values are copied here.
				Assert::AreEqual(copiedFoo.FrontRTTI(), fooReference);
				Assert::AreEqual(copiedFoo.BackRTTI(), fooReference3);
				Assert::AreEqual(copiedFoo.Size(), static_cast<size_t>(3));
				Assert::AreEqual(copiedFoo.Capacity(), static_cast<size_t>(5)); //Capacity is copied
				Assert::AreEqual(copiedFoo.Type(), Datum::DatumTypes::Pointer);

				Datum emptyFooCopy = move(emptyFooDatum);
				Assert::AreEqual(emptyFooCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyFooCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyFooCopy.Type(), Datum::DatumTypes::Pointer);
				Assert::ExpectException<std::runtime_error>([&emptyFooCopy]() { emptyFooCopy.FrontRTTI(); });
				Assert::ExpectException<std::runtime_error>([&emptyFooCopy]() { emptyFooCopy.BackRTTI(); });

				Datum emptyCopy = move(emptyDatum);
				Assert::AreEqual(emptyCopy.Size(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(emptyCopy.Type(), Datum::DatumTypes::Unknown);
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.FrontRTTI(); });
				Assert::ExpectException<std::runtime_error>([&emptyCopy]() { emptyCopy.BackRTTI(); });
			}
		}

		TEST_METHOD(DatumInequality)
		{
			{
				size_t firstElement(0);
				size_t secondElement(1);
				size_t thirdElement(2);

				Datum a(static_cast<size_t>(0));
				a.PushBack(static_cast<size_t>(1));
				a.PushBack(static_cast<size_t>(2));

				Datum b;

				Assert::IsTrue(a != b);
				Assert::IsTrue(b != a);

				b.PushBack(firstElement);
				b.PushBack(secondElement);
				b.PushBack(thirdElement);

				Assert::IsFalse(a != b);
				Assert::IsFalse(b != a);

				b.SetInt(3, 2);
				Assert::IsTrue(a != b);
				Assert::IsTrue(b != a);
			}

			{
				float firstElement = 0.1f;
				float secondElement = 1.2f;
				float thirdElement = 2.3f;

				Datum a(0.1f);
				a.PushBack(1.2f);
				a.PushBack(2.3f);

				Datum b;

				Assert::IsTrue(a != b);
				Assert::IsTrue(b != a);

				b.PushBack(firstElement);
				b.PushBack(secondElement);
				b.PushBack(thirdElement);

				Assert::IsFalse(a != b);
				Assert::IsFalse(b != a);

				b.SetFloat(3.3f, 2);
				Assert::IsTrue(a != b);
				Assert::IsTrue(b != a);
			}

			{
				std::string firstElement = "C";
				std::string secondElement = "Plus";
				std::string thirdElement = "++";

				std::string baseElement;
				std::string secondBaseElement;
				std::string thirdBaseElement;

				baseElement = "C";
				secondBaseElement = "Plus";
				thirdBaseElement = "++";

				std::string unusualString = "--";

				Datum a(baseElement);
				a.PushBack(secondBaseElement);
				a.PushBack(thirdBaseElement);

				Datum b;

				Assert::IsTrue(a != b);
				Assert::IsTrue(b != a);

				b.PushBack(firstElement);
				b.PushBack(secondElement);
				b.PushBack(thirdElement);

				Assert::IsFalse(a != b);
				Assert::IsFalse(b != a);

				b.SetString(unusualString, 2);
				Assert::IsTrue(a != b);
				Assert::IsTrue(b != a);
			}

			{
				glm::vec4 firstElement = { 0, 1, 2, 3 };
				glm::vec4 secondElement = { 2, 4, 6, 8 };
				glm::vec4 thirdElement = { 0, 3, 6, 9 };

				Datum a(glm::vec4{ 0, 1, 2, 3 });
				a.PushBack(glm::vec4{ 2, 4, 6, 8 });
				a.PushBack(glm::vec4{ 0, 3, 6, 9 });

				Datum b;

				Assert::IsTrue(a != b);
				Assert::IsTrue(b != a);

				b.PushBack(firstElement);
				b.PushBack(secondElement);
				b.PushBack(thirdElement);

				Assert::IsFalse(a != b);
				Assert::IsFalse(b != a);

				b.SetVector(glm::vec4{ 0, 0, 0, 0 }, 2);
				Assert::IsTrue(a != b);
				Assert::IsTrue(b != a);
			}

			{
				glm::mat4 firstElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 secondElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
				glm::mat4 thirdElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17 };

				glm::mat4 firstElementAlt;
				firstElementAlt = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 secondElementAlt;
				secondElementAlt = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
				glm::mat4 thirdElementAlt;
				thirdElementAlt = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17 };

				Datum a(firstElementAlt);
				a.PushBack(secondElementAlt);
				a.PushBack(thirdElementAlt);

				Datum b;

				Assert::IsTrue(a != b);
				Assert::IsTrue(b != a);

				b.PushBack(firstElement);
				b.PushBack(secondElement);
				b.PushBack(thirdElement);

				Assert::IsFalse(a != b);
				Assert::IsFalse(b != a);

				b.SetMatrix(firstElementAlt, 2);
				Assert::IsTrue(a != b);
				Assert::IsTrue(b != a);
			}

			{
				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);

				Foo fourthFoo(1);
				Foo fifthFoo(2);
				Foo sixthFoo(3);


				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;
				RTTI* thirdElement = &thirdFoo;
				RTTI* fourthElement = &fourthFoo;
				RTTI* fifthElement = &fifthFoo;
				RTTI* sixthElement = &sixthFoo;

				Datum a(fourthElement);
				a.PushBack(fifthElement);
				a.PushBack(sixthElement);

				Datum b;

				Assert::IsTrue(a != b);
				Assert::IsTrue(b != a);

				b.PushBack(firstElement);
				b.PushBack(secondElement);
				b.PushBack(thirdElement);

				Assert::IsFalse(a != b);
				Assert::IsFalse(b != a);

				b.SetRTTI(firstElement, 2);
				Assert::IsTrue(a != b);
				Assert::IsTrue(b != a);
			}
		}

		TEST_METHOD(ScalarEquality)
		{
			{
				size_t firstElement(0);
				size_t secondElement(1);
				size_t thirdElement(2);
				size_t basicArray[] = { firstElement, secondElement, thirdElement };

				Datum a(firstElement);
				Datum empty(Datum::DatumTypes::Integer);
				Datum wrongType(Datum::DatumTypes::Float);

				Assert::ExpectException<std::runtime_error>([&wrongType, &firstElement]() { wrongType == firstElement; }); //Doesnt work for wrong type of data
				Assert::ExpectException<std::runtime_error>([&empty, &firstElement]() { empty == firstElement; }); //Doesnt work for wrong type of data

				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Integer);
				Assert::IsTrue(a == static_cast<size_t>(0));
				Assert::IsFalse(a == static_cast<size_t>(1));
				Assert::IsFalse(a == static_cast<size_t>(2));

				a = secondElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Integer);
				Assert::IsFalse(a == static_cast<size_t>(0));
				Assert::IsTrue(a == static_cast<size_t>(1));
				Assert::IsFalse(a == static_cast<size_t>(2));

				a = thirdElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Integer);
				Assert::IsFalse(a == static_cast<size_t>(0));
				Assert::IsFalse(a == static_cast<size_t>(1));
				Assert::IsTrue(a == static_cast<size_t>(2));
			}

			{
				float firstElement = 0.1f;
				float secondElement = 1.2f;
				float thirdElement = 2.3f;
				float basicArray[] = { firstElement, secondElement, thirdElement };

				Datum a(firstElement);
				Datum empty(Datum::DatumTypes::Float);
				Datum wrongType(Datum::DatumTypes::Integer);

				Assert::ExpectException<std::runtime_error>([&wrongType, &firstElement]() { wrongType == firstElement; }); //Doesnt work for wrong type of data
				Assert::ExpectException<std::runtime_error>([&empty, &firstElement]() { empty == firstElement; }); //Doesnt work for wrong type of data

				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Float);
				Assert::IsTrue(a == 0.1f);
				Assert::IsFalse(a == 1.2f);
				Assert::IsFalse(a == 2.3f);

				a = secondElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Float);
				Assert::IsFalse(a == 0.1f);
				Assert::IsTrue(a == 1.2f);
				Assert::IsFalse(a == 2.3f);

				a = thirdElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Float);
				Assert::IsFalse(a == 0.1f);
				Assert::IsFalse(a == 1.2f);
				Assert::IsTrue(a == 2.3f);
			}

			{
				std::string firstElement = "Apple";
				std::string secondElement = "Orange";
				std::string thirdElement = "Pear";

				std::string firstElementCopy;
				std::string secondElementCopy;
				std::string thirdElementCopy;

				firstElementCopy = "Apple";
				secondElementCopy = "Orange";
				thirdElementCopy = "Pear";

				std::string basicArray[] = { firstElement, secondElement, thirdElement };

				Datum a(firstElement);
				Datum empty(Datum::DatumTypes::String);
				Datum wrongType(Datum::DatumTypes::Integer);

				Assert::ExpectException<std::runtime_error>([&wrongType, &firstElement]() { wrongType == firstElement; }); //Doesnt work for wrong type of data
				Assert::ExpectException<std::runtime_error>([&empty, &firstElement]() { empty == firstElement; }); //Doesnt work for wrong type of data

				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::String);
				Assert::IsTrue(a == firstElementCopy);
				Assert::IsFalse(a == secondElementCopy);
				Assert::IsFalse(a == thirdElementCopy);

				a = secondElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::String);
				Assert::IsFalse(a == firstElementCopy);
				Assert::IsTrue(a == secondElementCopy);
				Assert::IsFalse(a == thirdElementCopy);

				a = thirdElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::String);
				Assert::IsFalse(a == firstElementCopy);
				Assert::IsFalse(a == secondElementCopy);
				Assert::IsTrue(a == thirdElementCopy);
			}

			{
				glm::vec4 firstElement = {0, 1, 2, 3};
				glm::vec4 secondElement = {2, 4, 6, 8};
				glm::vec4 thirdElement = { 3, 6, 9, 12 };

				glm::vec4 firstElementCopy;
				glm::vec4 secondElementCopy;
				glm::vec4 thirdElementCopy;

				firstElementCopy = {0, 1, 2, 3};
				secondElementCopy = {2, 4, 6, 8};
				thirdElementCopy = {3, 6, 9, 12};

				glm::vec4 basicArray[] = { firstElement, secondElement, thirdElement };

				Datum a(firstElement);
				Datum empty(Datum::DatumTypes::Vector);
				Datum wrongType(Datum::DatumTypes::Integer);

				Assert::ExpectException<std::runtime_error>([&wrongType, &firstElement]() { wrongType == firstElement; }); //Doesnt work for wrong type of data
				Assert::ExpectException<std::runtime_error>([&empty, &firstElement]() { empty == firstElement; }); //Doesnt work for wrong type of data

				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Vector);
				Assert::IsTrue(a == firstElementCopy);
				Assert::IsFalse(a == secondElementCopy);
				Assert::IsFalse(a == thirdElementCopy);

				a = secondElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Vector);
				Assert::IsFalse(a == firstElementCopy);
				Assert::IsTrue(a == secondElementCopy);
				Assert::IsFalse(a == thirdElementCopy);

				a = thirdElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Vector);
				Assert::IsFalse(a == firstElementCopy);
				Assert::IsFalse(a == secondElementCopy);
				Assert::IsTrue(a == thirdElementCopy);
			}

			{
				glm::mat4 firstElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 secondElement = { 0, 1, 2, 33, 4, 5, 6, 7, 8, 9, 10, 11, 12, 100, 11, 19 };
				glm::mat4 thirdElement = { 0, 1, 2, 33, 4, 5, 6, 7, 8, 9, 10, 11, 12, 100, 11, 20 };

				glm::mat4 firstElementCopy;
				glm::mat4 secondElementCopy;
				glm::mat4 thirdElementCopy;

				firstElementCopy = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				secondElementCopy = { 0, 1, 2, 33, 4, 5, 6, 7, 8, 9, 10, 11, 12, 100, 11, 19 };
				thirdElementCopy = { 0, 1, 2, 33, 4, 5, 6, 7, 8, 9, 10, 11, 12, 100, 11, 20 };

				glm::mat4 basicArray[] = { firstElement, secondElement, thirdElement };

				Datum a(firstElement);
				Datum empty(Datum::DatumTypes::Matrix);
				Datum wrongType(Datum::DatumTypes::Integer);

				Assert::ExpectException<std::runtime_error>([&wrongType, &firstElement]() { wrongType == firstElement; }); //Doesnt work for wrong type of data
				Assert::ExpectException<std::runtime_error>([&empty, &firstElement]() { empty == firstElement; }); //Doesnt work for wrong type of data

				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Matrix);
				Assert::IsTrue(a == firstElementCopy);
				Assert::IsFalse(a == secondElementCopy);
				Assert::IsFalse(a == thirdElementCopy);

				a = secondElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Matrix);
				Assert::IsFalse(a == firstElementCopy);
				Assert::IsTrue(a == secondElementCopy);
				Assert::IsFalse(a == thirdElementCopy);

				a = thirdElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Matrix);
				Assert::IsFalse(a == firstElementCopy);
				Assert::IsFalse(a == secondElementCopy);
				Assert::IsTrue(a == thirdElementCopy);
			}

			{
				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);

				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;
				RTTI* thirdElement = &thirdFoo;

				Foo firstFooCopy(1);
				Foo secondFooCopy(2);
				Foo thirdFooCopy(3);

				RTTI* firstElementCopy;
				RTTI* secondElementCopy;
				RTTI* thirdElementCopy;

				firstElementCopy = &firstFooCopy;
				secondElementCopy = &secondFooCopy;
				thirdElementCopy = &thirdFooCopy;

				RTTI* basicArray[] = { firstElement, secondElement, thirdElement };

				Datum a(firstElement);
				Datum empty(Datum::DatumTypes::Pointer);
				Datum wrongType(Datum::DatumTypes::Integer);

				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Pointer);
				Assert::IsTrue(a == firstElementCopy);
				Assert::IsFalse(a == secondElementCopy);
				Assert::IsFalse(a == thirdElementCopy);

				a = secondElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Pointer);
				Assert::IsFalse(a == firstElementCopy);
				Assert::IsTrue(a == secondElementCopy);
				Assert::IsFalse(a == thirdElementCopy);

				a = thirdElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Pointer);
				Assert::IsFalse(a == firstElementCopy);
				Assert::IsFalse(a == secondElementCopy);
				Assert::IsTrue(a == thirdElementCopy);
			}
		}

		TEST_METHOD(ScalarInequality)
		{
			{
				size_t firstElement(0);
				size_t secondElement(1);
				size_t thirdElement(2);
				size_t basicArray[] = { firstElement, secondElement, thirdElement };

				Datum a(firstElement);
				Datum empty(Datum::DatumTypes::Integer);
				Datum wrongType(Datum::DatumTypes::Float);

				Assert::ExpectException<std::runtime_error>([&wrongType, &firstElement]() { wrongType != firstElement; }); //Doesnt work for wrong type of data
				Assert::ExpectException<std::runtime_error>([&empty, &firstElement]() { empty != firstElement; }); //Doesnt work for wrong type of data

				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Integer);
				Assert::IsFalse(a != static_cast<size_t>(0));
				Assert::IsTrue(a != static_cast<size_t>(1));
				Assert::IsTrue(a != static_cast<size_t>(2));

				a = secondElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Integer);
				Assert::IsTrue(a != static_cast<size_t>(0));
				Assert::IsFalse(a != static_cast<size_t>(1));
				Assert::IsTrue(a != static_cast<size_t>(2));

				a = thirdElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Integer);
				Assert::IsTrue(a != static_cast<size_t>(0));
				Assert::IsTrue(a != static_cast<size_t>(1));
				Assert::IsFalse(a != static_cast<size_t>(2));
			}

			{
				float firstElement = 0.1f;
				float secondElement = 1.2f;
				float thirdElement = 2.3f;
				float basicArray[] = { firstElement, secondElement, thirdElement };

				Datum a(firstElement);
				Datum empty(Datum::DatumTypes::Float);
				Datum wrongType(Datum::DatumTypes::Integer);

				Assert::ExpectException<std::runtime_error>([&wrongType, &firstElement]() { wrongType != firstElement; }); //Doesnt work for wrong type of data
				Assert::ExpectException<std::runtime_error>([&empty, &firstElement]() { empty != firstElement; }); //Doesnt work for wrong type of data

				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Float);
				Assert::IsFalse(a != 0.1f);
				Assert::IsTrue(a != 1.2f);
				Assert::IsTrue(a != 2.3f);

				a = secondElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Float);
				Assert::IsTrue(a != 0.1f);
				Assert::IsFalse(a != 1.2f);
				Assert::IsTrue(a != 2.3f);

				a = thirdElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Float);
				Assert::IsTrue(a != 0.1f);
				Assert::IsTrue(a != 1.2f);
				Assert::IsFalse(a != 2.3f);
			}

			{
				std::string firstElement = "Apple";
				std::string secondElement = "Orange";
				std::string thirdElement = "Pear";

				std::string firstElementCopy;
				std::string secondElementCopy;
				std::string thirdElementCopy;

				firstElementCopy = "Apple";
				secondElementCopy = "Orange";
				thirdElementCopy = "Pear";

				std::string basicArray[] = { firstElement, secondElement, thirdElement };

				Datum a(firstElement);
				Datum empty(Datum::DatumTypes::String);
				Datum wrongType(Datum::DatumTypes::Integer);

				Assert::ExpectException<std::runtime_error>([&wrongType, &firstElement]() { wrongType != firstElement; }); //Doesnt work for wrong type of data
				Assert::ExpectException<std::runtime_error>([&empty, &firstElement]() { empty != firstElement; }); //Doesnt work for wrong type of data

				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::String);
				Assert::IsFalse(a != firstElementCopy);
				Assert::IsTrue(a != secondElementCopy);
				Assert::IsTrue(a != thirdElementCopy);

				a = secondElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::String);
				Assert::IsTrue(a != firstElementCopy);
				Assert::IsFalse(a != secondElementCopy);
				Assert::IsTrue(a != thirdElementCopy);

				a = thirdElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::String);
				Assert::IsTrue(a != firstElementCopy);
				Assert::IsTrue(a != secondElementCopy);
				Assert::IsFalse(a != thirdElementCopy);
			}

			{
				glm::vec4 firstElement = { 0, 1, 2, 3 };
				glm::vec4 secondElement = { 2, 4, 6, 8 };
				glm::vec4 thirdElement = { 3, 6, 9, 12 };

				glm::vec4 firstElementCopy;
				glm::vec4 secondElementCopy;
				glm::vec4 thirdElementCopy;

				firstElementCopy = { 0, 1, 2, 3 };
				secondElementCopy = { 2, 4, 6, 8 };
				thirdElementCopy = { 3, 6, 9, 12 };

				glm::vec4 basicArray[] = { firstElement, secondElement, thirdElement };

				Datum a(firstElement);
				Datum empty(Datum::DatumTypes::Vector);
				Datum wrongType(Datum::DatumTypes::Integer);

				Assert::ExpectException<std::runtime_error>([&wrongType, &firstElement]() { wrongType != firstElement; }); //Doesnt work for wrong type of data
				Assert::ExpectException<std::runtime_error>([&empty, &firstElement]() { empty != firstElement; }); //Doesnt work for wrong type of data

				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Vector);
				Assert::IsFalse(a != firstElementCopy);
				Assert::IsTrue(a != secondElementCopy);
				Assert::IsTrue(a != thirdElementCopy);

				a = secondElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Vector);
				Assert::IsTrue(a != firstElementCopy);
				Assert::IsFalse(a != secondElementCopy);
				Assert::IsTrue(a != thirdElementCopy);

				a = thirdElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Vector);
				Assert::IsTrue(a != firstElementCopy);
				Assert::IsTrue(a != secondElementCopy);
				Assert::IsFalse(a != thirdElementCopy);
			}

			{
				glm::mat4 firstElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 secondElement = { 0, 1, 2, 33, 4, 5, 6, 7, 8, 9, 10, 11, 12, 100, 11, 19 };
				glm::mat4 thirdElement = { 0, 1, 2, 33, 4, 5, 6, 7, 8, 9, 10, 11, 12, 100, 11, 20 };

				glm::mat4 firstElementCopy;
				glm::mat4 secondElementCopy;
				glm::mat4 thirdElementCopy;

				firstElementCopy = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				secondElementCopy = { 0, 1, 2, 33, 4, 5, 6, 7, 8, 9, 10, 11, 12, 100, 11, 19 };
				thirdElementCopy = { 0, 1, 2, 33, 4, 5, 6, 7, 8, 9, 10, 11, 12, 100, 11, 20 };

				glm::mat4 basicArray[] = { firstElement, secondElement, thirdElement };

				Datum a(firstElement);
				Datum empty(Datum::DatumTypes::Matrix);
				Datum wrongType(Datum::DatumTypes::Integer);

				Assert::ExpectException<std::runtime_error>([&wrongType, &firstElement]() { wrongType != firstElement; }); //Doesnt work for wrong type of data
				Assert::ExpectException<std::runtime_error>([&empty, &firstElement]() { empty != firstElement; }); //Doesnt work for wrong type of data

				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Matrix);
				Assert::IsFalse(a != firstElementCopy);
				Assert::IsTrue(a != secondElementCopy);
				Assert::IsTrue(a != thirdElementCopy);

				a = secondElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Matrix);
				Assert::IsTrue(a != firstElementCopy);
				Assert::IsFalse(a != secondElementCopy);
				Assert::IsTrue(a != thirdElementCopy);

				a = thirdElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Matrix);
				Assert::IsTrue(a != firstElementCopy);
				Assert::IsTrue(a != secondElementCopy);
				Assert::IsFalse(a != thirdElementCopy);
			}

			{
				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);

				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;
				RTTI* thirdElement = &thirdFoo;

				Foo firstFooCopy(1);
				Foo secondFooCopy(2);
				Foo thirdFooCopy(3);

				RTTI* firstElementCopy;
				RTTI* secondElementCopy;
				RTTI* thirdElementCopy;

				firstElementCopy = &firstFooCopy;
				secondElementCopy = &secondFooCopy;
				thirdElementCopy = &thirdFooCopy;

				RTTI* basicArray[] = { firstElement, secondElement, thirdElement };

				Datum a(firstElement);
				Datum empty(Datum::DatumTypes::Pointer);
				Datum wrongType(Datum::DatumTypes::Integer);

				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Pointer);
				Assert::IsFalse(a != firstElementCopy);
				Assert::IsTrue(a != secondElementCopy);
				Assert::IsTrue(a != thirdElementCopy);

				a = secondElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Pointer);
				Assert::IsTrue(a != firstElementCopy);
				Assert::IsFalse(a != secondElementCopy);
				Assert::IsTrue(a != thirdElementCopy);

				a = thirdElement;
				Assert::AreEqual(a.Size(), static_cast<size_t>(1));
				Assert::AreEqual(a.Capacity(), static_cast<size_t>(1));
				Assert::IsTrue(a.Type() == Datum::DatumTypes::Pointer);
				Assert::IsTrue(a != firstElementCopy);
				Assert::IsTrue(a != secondElementCopy);
				Assert::IsFalse(a != thirdElementCopy);
			}
		}

		TEST_METHOD(DatumEquality)
		{
			{
				size_t firstElement = 0;
				size_t secondElement = 1;
				size_t thirdElement = 2;

				Datum a(static_cast<size_t>(0));
				a.PushBack(static_cast<size_t>(1));
				a.PushBack(static_cast<size_t>(2));

				Datum b;

				Assert::IsFalse(a == b);
				Assert::IsFalse(b == a);
				
				b.PushBack(firstElement);
				b.PushBack(secondElement);
				b.PushBack(thirdElement);

				Assert::IsTrue(a == b);
				Assert::IsTrue(b == a);

				b.SetInt(3, 2);
				Assert::IsFalse(a == b);
				Assert::IsFalse(b == a);
			}

			{
				float firstElement = 0.1f;
				float secondElement = 1.2f;
				float thirdElement = 2.3f;

				Datum a(0.1f);
				a.PushBack(1.2f);
				a.PushBack(2.3f);

				Datum b;

				Assert::IsFalse(a == b);
				Assert::IsFalse(b == a);

				b.PushBack(firstElement);
				b.PushBack(secondElement);
				b.PushBack(thirdElement);

				Assert::IsTrue(a == b);
				Assert::IsTrue(b == a);

				b.SetFloat(3.3f, 2);
				Assert::IsFalse(a == b);
				Assert::IsFalse(b == a);
			}

			{
				std::string firstElement = "C";
				std::string secondElement = "Plus";
				std::string thirdElement = "++";

				std::string baseElement;
				std::string secondBaseElement;
				std::string thirdBaseElement;

				baseElement = "C";
				secondBaseElement = "Plus";
				thirdBaseElement = "++";

				std::string unusualString = "--";

				Datum a(baseElement);
				a.PushBack(secondBaseElement);
				a.PushBack(thirdBaseElement);

				Datum b;

				Assert::IsFalse(a == b);
				Assert::IsFalse(b == a);

				b.PushBack(firstElement);
				b.PushBack(secondElement);
				b.PushBack(thirdElement);

				Assert::IsTrue(a == b);
				Assert::IsTrue(b == a);

				b.SetString(unusualString, 2);
				Assert::IsFalse(a == b);
				Assert::IsFalse(b == a);
			}

			{
				glm::vec4 firstElement = {0, 1, 2, 3};
				glm::vec4 secondElement = {2, 4, 6, 8};
				glm::vec4 thirdElement = {0, 3, 6, 9};

				Datum a(glm::vec4 { 0, 1, 2, 3 });
				a.PushBack(glm::vec4 { 2, 4, 6, 8 });
				a.PushBack(glm::vec4{0, 3, 6, 9});

				Datum b;

				Assert::IsFalse(a == b);
				Assert::IsFalse(b == a);

				b.PushBack(firstElement);
				b.PushBack(secondElement);
				b.PushBack(thirdElement);

				Assert::IsTrue(a == b);
				Assert::IsTrue(b == a);

				b.SetVector(glm::vec4{0, 0, 0, 0}, 2);
				Assert::IsFalse(a == b);
				Assert::IsFalse(b == a);
			}

			{
				glm::mat4 firstElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 secondElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
				glm::mat4 thirdElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17 };

				glm::mat4 firstElementAlt; 
				firstElementAlt = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 secondElementAlt; 
				secondElementAlt = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
				glm::mat4 thirdElementAlt;
				thirdElementAlt = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17 };

				Datum a(firstElementAlt);
				a.PushBack(secondElementAlt);
				a.PushBack(thirdElementAlt);

				Datum b;

				Assert::IsFalse(a == b);
				Assert::IsFalse(b == a);

				b.PushBack(firstElement);
				b.PushBack(secondElement);
				b.PushBack(thirdElement);

				Assert::IsTrue(a == b);
				Assert::IsTrue(b == a);

				b.SetMatrix(firstElementAlt, 2);
				Assert::IsFalse(a == b);
				Assert::IsFalse(b == a);
			}

			{
				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);

				Foo fourthFoo(1);
				Foo fifthFoo(2);
				Foo sixthFoo(3);


				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;
				RTTI* thirdElement = &thirdFoo;
				RTTI* fourthElement = &fourthFoo;
				RTTI* fifthElement = &fifthFoo;
				RTTI* sixthElement = &sixthFoo;

				Datum a(fourthElement);
				a.PushBack(fifthElement);
				a.PushBack(sixthElement);

				Datum b;

				Assert::IsFalse(a == b);
				Assert::IsFalse(b == a);

				b.PushBack(firstElement);
				b.PushBack(secondElement);
				b.PushBack(thirdElement);

				Assert::IsTrue(a == b);
				Assert::IsTrue(b == a);

				b.SetRTTI(firstElement, 2);
				Assert::IsFalse(a == b);
				Assert::IsFalse(b == a);
			}
		}

		
		TEST_METHOD(SetType)
		{
			{
				Datum defaultDatum;
				defaultDatum.SetType(Datum::DatumTypes::Integer);
				Assert::AreEqual(defaultDatum.Type(), Datum::DatumTypes::Integer);

				defaultDatum.SetType(Datum::DatumTypes::Integer); //Nothing happens, already specified as size_t
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Float); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Matrix); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Vector); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() {defaultDatum.SetType(Datum::DatumTypes::String); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Pointer); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Unknown); });
			}

			{
				Datum defaultDatum;
				defaultDatum.SetType(Datum::DatumTypes::Float);
				Assert::AreEqual(defaultDatum.Type(), Datum::DatumTypes::Float);

				defaultDatum.SetType(Datum::DatumTypes::Float); //Nothing happens, already specified as size_t
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Integer); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Matrix); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Vector); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::String); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Pointer); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Unknown); });
			}

			{
				Datum defaultDatum;
				defaultDatum.SetType(Datum::DatumTypes::Matrix);
				Assert::AreEqual(defaultDatum.Type(), Datum::DatumTypes::Matrix);

				defaultDatum.SetType(Datum::DatumTypes::Matrix); //Nothing happens, already specified as size_t
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Float); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Integer); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Vector); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::String); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Pointer); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Unknown); });
			}

			{
				Datum defaultDatum;
				defaultDatum.SetType(Datum::DatumTypes::Vector);
				Assert::AreEqual(defaultDatum.Type(), Datum::DatumTypes::Vector);

				defaultDatum.SetType(Datum::DatumTypes::Vector); //Nothing happens, already specified as size_t
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Float); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Matrix); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Integer); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::String); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Pointer); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Unknown); });
			}

			{
				Datum defaultDatum;
				defaultDatum.SetType(Datum::DatumTypes::String);
				Assert::AreEqual(defaultDatum.Type(), Datum::DatumTypes::String);

				defaultDatum.SetType(Datum::DatumTypes::String); //Nothing happens, already specified as size_t
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Float); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Matrix); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Vector); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Integer); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Pointer); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Unknown); });
			}

			{
				Datum defaultDatum;
				defaultDatum.SetType(Datum::DatumTypes::Pointer);
				Assert::AreEqual(defaultDatum.Type(), Datum::DatumTypes::Pointer);

				defaultDatum.SetType(Datum::DatumTypes::Pointer); //Nothing happens, already specified as size_t
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Float); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Matrix); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Vector); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::String); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Integer); });
				Assert::ExpectException<std::runtime_error>([&defaultDatum]() { defaultDatum.SetType(Datum::DatumTypes::Unknown); });
			}
		}

		TEST_METHOD(Type)
		{
			{
				Datum defaultDatum;
				defaultDatum.SetType(Datum::DatumTypes::Integer);
				Datum typeSpecified(Datum::DatumTypes::Integer);
				Datum elementSpecified(static_cast<size_t>(4));

				Assert::AreEqual(defaultDatum.Type(), Datum::DatumTypes::Integer);
				Assert::AreEqual(typeSpecified.Type(), Datum::DatumTypes::Integer);
				Assert::AreEqual(elementSpecified.Type(), Datum::DatumTypes::Integer);
			}

			{
				Datum defaultDatum;
				defaultDatum.SetType(Datum::DatumTypes::Float);
				Datum typeSpecified(Datum::DatumTypes::Float);
				Datum elementSpecified(4.5f);

				Assert::AreEqual(defaultDatum.Type(), Datum::DatumTypes::Float);
				Assert::AreEqual(typeSpecified.Type(), Datum::DatumTypes::Float);
				Assert::AreEqual(elementSpecified.Type(), Datum::DatumTypes::Float);
			}

			{
				std::string element = "Cake";
				Datum defaultDatum;
				defaultDatum.SetType(Datum::DatumTypes::String);
				Datum typeSpecified(Datum::DatumTypes::String);
				Datum elementSpecified(element);

				Assert::AreEqual(defaultDatum.Type(), Datum::DatumTypes::String);
				Assert::AreEqual(typeSpecified.Type(), Datum::DatumTypes::String);
				Assert::AreEqual(elementSpecified.Type(), Datum::DatumTypes::String);
			}

			{
				Datum defaultDatum;
				defaultDatum.SetType(Datum::DatumTypes::Vector);
				Datum typeSpecified(Datum::DatumTypes::Vector);
				Datum elementSpecified(glm::vec4(0, 1, 2, 4));

				Assert::AreEqual(defaultDatum.Type(), Datum::DatumTypes::Vector);
				Assert::AreEqual(typeSpecified.Type(), Datum::DatumTypes::Vector);
				Assert::AreEqual(elementSpecified.Type(), Datum::DatumTypes::Vector);
			}

			{
				Datum defaultDatum;
				glm::mat4 element = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
				defaultDatum.SetType(Datum::DatumTypes::Matrix);
				Datum typeSpecified(Datum::DatumTypes::Matrix);
				Datum elementSpecified(element);

				Assert::AreEqual(defaultDatum.Type(), Datum::DatumTypes::Matrix);
				Assert::AreEqual(typeSpecified.Type(), Datum::DatumTypes::Matrix);
				Assert::AreEqual(elementSpecified.Type(), Datum::DatumTypes::Matrix);
			}

			{
				Foo basicFoo(1);
				RTTI* basicFooPointer = &basicFoo;

				Datum defaultDatum;
				defaultDatum.SetType(Datum::DatumTypes::Pointer);
				Datum typeSpecified(Datum::DatumTypes::Pointer);
				Datum elementSpecified(basicFooPointer);

				Assert::AreEqual(defaultDatum.Type(), Datum::DatumTypes::Pointer);
				Assert::AreEqual(typeSpecified.Type(), Datum::DatumTypes::Pointer);
				Assert::AreEqual(elementSpecified.Type(), Datum::DatumTypes::Pointer);
			}
		}

		TEST_METHOD(Size)
		{
			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Integer);
				Datum elementSpecified(static_cast<size_t>(4));

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(1));

				elementSpecified.PushBack(static_cast<size_t>(5));
				elementSpecified.PushBack(static_cast<size_t>(5));
				elementSpecified.PushBack(static_cast<size_t>(5));
				elementSpecified.PushBack(static_cast<size_t>(5));
				elementSpecified.PushBack(static_cast<size_t>(5));

				typeSpecified = elementSpecified;
				defaultData = elementSpecified;

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(6));

				defaultData.PopBack();
				defaultData.PopBack();
				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(4));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(6));

				defaultData.Clear();
				typeSpecified.Clear();
				elementSpecified.Clear();

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(0));
			}

			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Float);
				Datum elementSpecified(4.1f);

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(1));

				elementSpecified.PushBack(5.2f);
				elementSpecified.PushBack(5.2f);
				elementSpecified.PushBack(5.2f);
				elementSpecified.PushBack(5.2f);
				elementSpecified.PushBack(5.2f);

				typeSpecified = elementSpecified;
				defaultData = elementSpecified;

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(6));

				defaultData.PopBack();
				defaultData.PopBack();
				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(4));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(6));

				defaultData.Clear();
				typeSpecified.Clear();
				elementSpecified.Clear();

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(0));
			}

			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::String);
				std::string cake = "Cake";
				std::string chocolate = "Chocolate";
				std::string cookies = "Cookies";
				std::string marshmallow = "Marshmallow";
				std::string tea = "Tea";
				std::string tarts = "Tarts";

				Datum elementSpecified(cake);

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(1));

				elementSpecified.PushBack(chocolate);
				elementSpecified.PushBack(cookies);
				elementSpecified.PushBack(marshmallow);
				elementSpecified.PushBack(tea);
				elementSpecified.PushBack(tarts);

				typeSpecified = elementSpecified;
				defaultData = elementSpecified;

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(6));

				defaultData.PopBack();
				defaultData.PopBack();
				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(4));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(6));

				defaultData.Clear();
				typeSpecified.Clear();
				elementSpecified.Clear();

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(0));
			}

			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Vector);
				Datum elementSpecified(glm::vec4{1, 2, 3, 5});

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(1));

				elementSpecified.PushBack(glm::vec4{ 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::vec4{ 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::vec4{ 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::vec4{ 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::vec4{ 1, 2, 3, 5 });

				typeSpecified = elementSpecified;
				defaultData = elementSpecified;

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(6));

				defaultData.PopBack();
				defaultData.PopBack();
				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(4));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(6));

				defaultData.Clear();
				typeSpecified.Clear();
				elementSpecified.Clear();

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(0));
			}

			{
				glm::mat4 element = { 1, 2, 3, 5, 1, 2, 3, 5, 1, 2, 3, 4, 1, 2, 3, 5 };
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Matrix);
				Datum elementSpecified(element);

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(1));

				elementSpecified.PushBack(glm::mat4{ 1, 2, 3, 5, 1, 2, 3, 5, 1, 2, 3, 4, 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::mat4{ 1, 2, 3, 5, 1, 2, 3, 5, 1, 2, 3, 4, 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::mat4{ 1, 2, 3, 5, 1, 2, 3, 5, 1, 2, 3, 4, 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::mat4{ 1, 2, 3, 5, 1, 2, 3, 5, 1, 2, 3, 4, 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::mat4{ 1, 2, 3, 5, 1, 2, 3, 5, 1, 2, 3, 4, 1, 2, 3, 5 });

				typeSpecified = elementSpecified;
				defaultData = elementSpecified;

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(6));

				defaultData.PopBack();
				defaultData.PopBack();
				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(4));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(6));

				defaultData.Clear();
				typeSpecified.Clear();
				elementSpecified.Clear();

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(0));
			}

			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Pointer);
				Foo basicFoo(1);
				RTTI* basicPointer = &basicFoo;
				Datum elementSpecified(basicPointer);

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(1));

				elementSpecified.PushBack(basicPointer);
				elementSpecified.PushBack(basicPointer);
				elementSpecified.PushBack(basicPointer);
				elementSpecified.PushBack(basicPointer);
				elementSpecified.PushBack(basicPointer);

				typeSpecified = elementSpecified;
				defaultData = elementSpecified;

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(6));

				defaultData.PopBack();
				defaultData.PopBack();
				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(4));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(6));

				defaultData.Clear();
				typeSpecified.Clear();
				elementSpecified.Clear();

				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Size(), static_cast<size_t>(0));
			}
		}

		TEST_METHOD(Capacity)
		{
			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Integer);
				Datum elementSpecified(static_cast<size_t>(4));

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(1));

				elementSpecified.PushBack(static_cast<size_t>(5));
				elementSpecified.PushBack(static_cast<size_t>(5));
				elementSpecified.PushBack(static_cast<size_t>(5));
				elementSpecified.PushBack(static_cast<size_t>(5));
				elementSpecified.PushBack(static_cast<size_t>(5));

				typeSpecified = elementSpecified;
				defaultData = elementSpecified;

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.PopBack();
				defaultData.PopBack();
				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.Clear();
				typeSpecified.Clear();
				elementSpecified.Clear();

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.ShrinkToFit();
				typeSpecified.ShrinkToFit();
				elementSpecified.ShrinkToFit();

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(0));
			}

			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Float);
				Datum elementSpecified(4.1f);

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(1));

				elementSpecified.PushBack(5.2f);
				elementSpecified.PushBack(5.2f);
				elementSpecified.PushBack(5.2f);
				elementSpecified.PushBack(5.2f);
				elementSpecified.PushBack(5.2f);

				typeSpecified = elementSpecified;
				defaultData = elementSpecified;

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.PopBack();
				defaultData.PopBack();
				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.Clear();
				typeSpecified.Clear();
				elementSpecified.Clear();

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.ShrinkToFit();
				typeSpecified.ShrinkToFit();
				elementSpecified.ShrinkToFit();

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(0));
			}

			{
				std::string cake = "Cake";
				std::string chocolate = "Chocolate";
				std::string cookies = "Cookies";
				std::string marshmallow = "Marshmallow";
				std::string tea = "Tea";
				std::string tarts = "Tarts";

				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::String);
				Datum elementSpecified(cake);

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(1));

				elementSpecified.PushBack(chocolate);
				elementSpecified.PushBack(cookies);
				elementSpecified.PushBack(marshmallow);
				elementSpecified.PushBack(tea);
				elementSpecified.PushBack(tarts);

				typeSpecified = elementSpecified;
				defaultData = elementSpecified;

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.PopBack();
				defaultData.PopBack();
				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.Clear();
				typeSpecified.Clear();
				elementSpecified.Clear();

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.ShrinkToFit();
				typeSpecified.ShrinkToFit();
				elementSpecified.ShrinkToFit();

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(0));
			}

			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Vector);
				Datum elementSpecified(glm::vec4{ 1, 2, 3, 5 });

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(1));

				elementSpecified.PushBack(glm::vec4{ 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::vec4{ 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::vec4{ 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::vec4{ 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::vec4{ 1, 2, 3, 5 });

				typeSpecified = elementSpecified;
				defaultData = elementSpecified;

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.PopBack();
				defaultData.PopBack();
				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.Clear();
				typeSpecified.Clear();
				elementSpecified.Clear();

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));
			
				defaultData.ShrinkToFit();
				typeSpecified.ShrinkToFit();
				elementSpecified.ShrinkToFit();

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(0));
			}

			{
				glm::mat4 element = { 1, 2, 3, 5, 1, 2, 3, 5, 1, 2, 3, 4, 1, 2, 3, 5 };
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Matrix);
				Datum elementSpecified(element);

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(1));

				elementSpecified.PushBack(glm::mat4{ 1, 2, 3, 5, 1, 2, 3, 5, 1, 2, 3, 4, 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::mat4{ 1, 2, 3, 5, 1, 2, 3, 5, 1, 2, 3, 4, 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::mat4{ 1, 2, 3, 5, 1, 2, 3, 5, 1, 2, 3, 4, 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::mat4{ 1, 2, 3, 5, 1, 2, 3, 5, 1, 2, 3, 4, 1, 2, 3, 5 });
				elementSpecified.PushBack(glm::mat4{ 1, 2, 3, 5, 1, 2, 3, 5, 1, 2, 3, 4, 1, 2, 3, 5 });

				typeSpecified = elementSpecified;
				defaultData = elementSpecified;

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.PopBack();
				defaultData.PopBack();
				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.Clear();
				typeSpecified.Clear();
				elementSpecified.Clear();

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.ShrinkToFit();
				typeSpecified.ShrinkToFit();
				elementSpecified.ShrinkToFit();

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(0));
			}

 {
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Pointer);
				Foo basicFoo(1);
				RTTI* basicPointer = &basicFoo;
				Datum elementSpecified(basicPointer);

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(1));

				elementSpecified.PushBack(basicPointer);
				elementSpecified.PushBack(basicPointer);
				elementSpecified.PushBack(basicPointer);
				elementSpecified.PushBack(basicPointer);
				elementSpecified.PushBack(basicPointer);

				typeSpecified = elementSpecified;
				defaultData = elementSpecified;

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.PopBack();
				defaultData.PopBack();
				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.Clear();
				typeSpecified.Clear();
				elementSpecified.Clear();

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(6));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(6));

				defaultData.ShrinkToFit();
				typeSpecified.ShrinkToFit();
				elementSpecified.ShrinkToFit();

				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(0));
				Assert::AreEqual(elementSpecified.Capacity(), static_cast<size_t>(0));
			}
		}

		TEST_METHOD(SetStorage)
		{
			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Integer);
				Datum elementSpecified(static_cast<size_t>(1));
				size_t basicArray[]{ 1, 2, 3, 4, 5 };
				float wrongTypeArray[]{ 2.1f, 1.1f, 5.1f };

				Assert::ExpectException<std::runtime_error>([&elementSpecified, &basicArray]() { elementSpecified.SetStorage(basicArray, 5); }); //If set to internal data with values assigned, can not be set to external.
				Assert::ExpectException<std::runtime_error>([&typeSpecified, &wrongTypeArray]() { typeSpecified.SetStorage(wrongTypeArray, 5); }); //Cannot reassign type value if set initially

				typeSpecified.SetStorage(basicArray, 5);

				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(5));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(5));
				Assert::IsTrue(typeSpecified.Type() == Datum::DatumTypes::Integer);

				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.PushBack(static_cast<size_t>(5)); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.PopBack(); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.Resize(static_cast<size_t>(10)); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.Clear(); });

				typeSpecified.SetInt(5, 0);
				Assert::AreEqual(typeSpecified.GetInt(0), static_cast<size_t>(5));

				//Internal = external storage assignment.
				defaultData = typeSpecified;
				Assert::AreEqual(typeSpecified.GetInt(0), static_cast<size_t>(5));
				Assert::AreEqual(defaultData.GetInt(0), static_cast<size_t>(5));
				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(5));
				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(5));


				//External = internal storage assignment
				typeSpecified = defaultData;
				Assert::AreEqual(typeSpecified.GetInt(0), static_cast<size_t>(5));
				Assert::AreEqual(defaultData.GetInt(0), static_cast<size_t>(5));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(5));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(5));
			}

			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::String);
				std::string basicArray[]{ "Oolong", "Black", "Green", "Herbal", "White"};
				Datum elementSpecified(basicArray[0]);
				std::string alternateString = "Chai";
				size_t wrongTypeArray[]{ 2, 1, 5 };

				Assert::ExpectException<std::runtime_error>([&elementSpecified, &basicArray]() { elementSpecified.SetStorage(basicArray, 5); }); //If set to internal data with values assigned, can not be set to external.
				Assert::ExpectException<std::runtime_error>([&typeSpecified, &wrongTypeArray]() { typeSpecified.SetStorage(wrongTypeArray, 5); }); //Cannot reassign type value if set initially

				typeSpecified.SetStorage(basicArray, 5);

				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(5));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(5));
				Assert::IsTrue(typeSpecified.Type() == Datum::DatumTypes::String);

				Assert::ExpectException<std::runtime_error>([&typeSpecified,&alternateString]() { typeSpecified.PushBack(alternateString); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.PopBack(); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.Resize(static_cast<size_t>(10)); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.Clear(); });

				typeSpecified.SetString(alternateString, 0);
				Assert::AreEqual(typeSpecified.GetString(0), alternateString);

				//Internal = external storage assignment.
				defaultData = typeSpecified;
				Assert::AreEqual(typeSpecified.GetString(0),alternateString);
				Assert::AreEqual(defaultData.GetString(0), alternateString);
				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(5));
				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(5));


				//External = internal storage assignment
				typeSpecified = defaultData;
				Assert::AreEqual(typeSpecified.GetString(0), alternateString);
				Assert::AreEqual(defaultData.GetString(0), alternateString);
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(5));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(5));
			}

			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Float);
				Datum elementSpecified(1.1f);
				float basicArray[]{ 1.1f, 2.2f, 3.3f, 4.4f, 5.5f };
				size_t wrongTypeArray[]{ 2, 1, 5 };

				Assert::ExpectException<std::runtime_error>([&elementSpecified, &basicArray]() { elementSpecified.SetStorage(basicArray, 5); }); //If set to internal data with values assigned, can not be set to external.
				Assert::ExpectException<std::runtime_error>([&typeSpecified, &wrongTypeArray]() { typeSpecified.SetStorage(wrongTypeArray, 5); }); //Cannot reassign type value if set initially

				typeSpecified.SetStorage(basicArray, 5);

				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(5));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(5));
				Assert::IsTrue(typeSpecified.Type() == Datum::DatumTypes::Float);

				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.PushBack(5.4f); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.PopBack(); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.Resize(static_cast<size_t>(10)); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.Clear(); });

				typeSpecified.SetFloat(9.9f, 0);
				Assert::AreEqual(typeSpecified.GetFloat(0), 9.9f);

				//Internal = external storage assignment.
				defaultData = typeSpecified;
				Assert::AreEqual(typeSpecified.GetFloat(0), 9.9f);
				Assert::AreEqual(defaultData.GetFloat(0), 9.9f);
				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(5));
				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(5));


				//External = internal storage assignment
				typeSpecified = defaultData;
				Assert::AreEqual(typeSpecified.GetFloat(0), 9.9f);
				Assert::AreEqual(defaultData.GetFloat(0), 9.9f);
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(5));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(5));
			}

			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Vector);
				Datum elementSpecified(glm::vec4(1, 2, 3, 4));
				glm::vec4 basicArray[]{ glm::vec4(1, 2, 3, 4), glm::vec4(1, 2, 3, 4), glm::vec4(1, 2, 3, 4), glm::vec4(1, 2, 3, 4), glm::vec4(1, 2, 3, 4) };
				size_t wrongTypeArray[]{ 2, 1, 5 };

				Assert::ExpectException<std::runtime_error>([&elementSpecified, &basicArray]() { elementSpecified.SetStorage(basicArray, 5); }); //If set to internal data with values assigned, can not be set to external.
				Assert::ExpectException<std::runtime_error>([&typeSpecified, &wrongTypeArray]() { typeSpecified.SetStorage(wrongTypeArray, 5); }); //Cannot reassign type value if set initially

				typeSpecified.SetStorage(basicArray, 5);

				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(5));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(5));
				Assert::IsTrue(typeSpecified.Type() == Datum::DatumTypes::Vector);

				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.PushBack(glm::vec4(2, 3, 4, 5)); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.PopBack(); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.Resize(static_cast<size_t>(10)); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.Clear(); });

				typeSpecified.SetVector(glm::vec4(2, 3, 4, 5), 0);
				Assert::IsTrue(typeSpecified.GetVector(0) == glm::vec4(2, 3, 4, 5));

				//Internal = external storage assignment.
				defaultData = typeSpecified;
				Assert::IsTrue(typeSpecified.GetVector(0) == glm::vec4(2, 3, 4, 5));
				Assert::IsTrue(defaultData.GetVector(0) == glm::vec4(2, 3, 4, 5));
				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(5));
				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(5));


				//External = internal storage assignment
				typeSpecified = defaultData;
				Assert::IsTrue(typeSpecified.GetVector(0) == glm::vec4(2, 3, 4, 5));
				Assert::IsTrue(defaultData.GetVector(0) == glm::vec4(2, 3, 4, 5));
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(5));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(5));
			}

			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Matrix);
				glm::mat4 basicMatrix = glm::mat4(1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8);
				glm::mat4 alternateMatrix = glm::mat4(1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 9);
				Datum elementSpecified(basicMatrix);
				glm::mat4 basicArray[]{ basicMatrix, basicMatrix, basicMatrix, basicMatrix, basicMatrix };
				size_t wrongTypeArray[]{ 2, 1, 5 };

				Assert::ExpectException<std::runtime_error>([&elementSpecified, &basicArray]() { elementSpecified.SetStorage(basicArray, 5); }); //If set to internal data with values assigned, can not be set to external.
				Assert::ExpectException<std::runtime_error>([&typeSpecified, &wrongTypeArray]() { typeSpecified.SetStorage(wrongTypeArray, 5); }); //Cannot reassign type value if set initially

				typeSpecified.SetStorage(basicArray, 5);

				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(5));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(5));
				Assert::IsTrue(typeSpecified.Type() == Datum::DatumTypes::Matrix);

				Assert::ExpectException<std::runtime_error>([&typeSpecified, &alternateMatrix]() { typeSpecified.PushBack(alternateMatrix); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.PopBack(); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.Resize(static_cast<size_t>(10)); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.Clear(); });

				typeSpecified.SetMatrix(alternateMatrix, 0);
				Assert::IsTrue(typeSpecified.GetMatrix(0) == alternateMatrix);

				//Internal = external storage assignment.
				defaultData = typeSpecified;
				Assert::IsTrue(typeSpecified.GetMatrix(0) == alternateMatrix);
				Assert::IsTrue(defaultData.GetMatrix(0) == alternateMatrix);
				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(5));
				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(5));


				//External = internal storage assignment
				typeSpecified = defaultData;
				Assert::IsTrue(typeSpecified.GetMatrix(0) == alternateMatrix);
				Assert::IsTrue(defaultData.GetMatrix(0) == alternateMatrix);
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(5));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(5));
			}

			{
				Datum defaultData;
				Datum typeSpecified(Datum::DatumTypes::Pointer);

				Foo basicFoo(1);
				Foo alternateFoo(2);
				
				RTTI* basicFooPointer = &basicFoo;
				RTTI* alternateFooPointer = &alternateFoo;

				Datum elementSpecified(basicFooPointer);
				RTTI* basicArray[]{ basicFooPointer, basicFooPointer, basicFooPointer, basicFooPointer, basicFooPointer};
				size_t wrongTypeArray[]{ 2, 1, 5 };

				Assert::ExpectException<std::runtime_error>([&elementSpecified, &basicArray]() { elementSpecified.SetStorage(basicArray, 5); }); //If set to internal data with values assigned, can not be set to external.
				Assert::ExpectException<std::runtime_error>([&typeSpecified, &wrongTypeArray]() { typeSpecified.SetStorage(wrongTypeArray, 5); }); //Cannot reassign type value if set initially

				typeSpecified.SetStorage(basicArray, 5);

				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(5));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(5));
				Assert::IsTrue(typeSpecified.Type() == Datum::DatumTypes::Pointer);

				Assert::ExpectException<std::runtime_error>([&typeSpecified, &alternateFooPointer]() { typeSpecified.PushBack(alternateFooPointer); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.PopBack(); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.Resize(static_cast<size_t>(10)); });
				Assert::ExpectException<std::runtime_error>([&typeSpecified]() { typeSpecified.Clear(); });

				typeSpecified.SetRTTI(alternateFooPointer, 0);
				Assert::IsTrue(typeSpecified.GetRTTI(0) == alternateFooPointer);

				//Internal = external storage assignment.
				defaultData = typeSpecified;
				Assert::IsTrue(typeSpecified.GetRTTI(0) == alternateFooPointer);
				Assert::IsTrue(defaultData.GetRTTI(0) == alternateFooPointer);
				Assert::AreEqual(defaultData.Size(), static_cast<size_t>(5));
				Assert::AreEqual(defaultData.Capacity(), static_cast<size_t>(5));


				//External = internal storage assignment
				typeSpecified = defaultData;
				Assert::IsTrue(typeSpecified.GetRTTI(0) == alternateFooPointer);
				Assert::IsTrue(defaultData.GetRTTI(0) == alternateFooPointer);
				Assert::AreEqual(typeSpecified.Size(), static_cast<size_t>(5));
				Assert::AreEqual(typeSpecified.Capacity(), static_cast<size_t>(5));
			}
		}

		TEST_METHOD(DatumToDatumAssignment)
		{
			{
				Datum internalData;
				Datum alternateInternalData;
				Datum externalData(static_cast<size_t>(6));
				Datum alternateExternalData(static_cast<size_t>(2));

				Datum differentType(1.0f);
				size_t basicArray[]{ 1, 2, 3, 4, 5 };
				size_t alternateArray[]{ 5, 4, 3, 2, 1 };

//				Assert::ExpectException<std::runtime_error>([&externalData, &differentType]() { externalData = differentType; });//Does not allow assignment between separate types.

				internalData.SetStorage(basicArray, 5);
				alternateInternalData.SetStorage(alternateArray, 5);

				Assert::AreEqual(externalData.FrontInt(), static_cast<size_t>(6));
				Assert::AreEqual(alternateExternalData.FrontInt(), static_cast<size_t>(2));
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				Assert::AreEqual(internalData.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(alternateInternalData.FrontInt(), static_cast<size_t>(5));
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//External = External
				externalData = alternateExternalData;
				Assert::AreEqual(externalData.FrontInt(), static_cast<size_t>(2));
				Assert::AreEqual(alternateExternalData.FrontInt(), static_cast<size_t>(2));
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				//External = Internal
				externalData = internalData;
				Assert::AreEqual(internalData.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(externalData.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(externalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(externalData.Capacity(), size_t(5));

				//Internal = External
				internalData = alternateExternalData;
				Assert::AreEqual(internalData.FrontInt(), static_cast<size_t>(2));
				Assert::AreEqual(alternateExternalData.FrontInt(), static_cast<size_t>(2));
				Assert::AreEqual(internalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(internalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				//Internal = Internal
				internalData = alternateInternalData;
				Assert::AreEqual(internalData.FrontInt(), static_cast<size_t>(5));
				Assert::AreEqual(alternateInternalData.FrontInt(), static_cast<size_t>(5));
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));
			}

			{
				Datum internalData;
				Datum alternateInternalData;
				Datum externalData(6.0f);
				Datum alternateExternalData(2.0f);

				Datum differentType(static_cast<size_t>(1));
				float basicArray[]{ 1.0, 2.0, 3.0, 4.0, 5.0 };
				float alternateArray[]{ 5.0, 4.0, 3.0, 2.0, 1.0 };

//				Assert::ExpectException<std::runtime_error>([&externalData, &differentType]() { externalData = differentType; });//Does not allow assignment between separate types.

				internalData.SetStorage(basicArray, 5);
				alternateInternalData.SetStorage(alternateArray, 5);

				Assert::AreEqual(externalData.FrontFloat(), 6.0f);
				Assert::AreEqual(alternateExternalData.FrontFloat(), 2.0f);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				Assert::AreEqual(internalData.FrontFloat(), 1.0f);
				Assert::AreEqual(alternateInternalData.FrontFloat(), 5.0f);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//External = External
				externalData = alternateExternalData;
				Assert::AreEqual(externalData.FrontFloat(), 2.0f);
				Assert::AreEqual(alternateExternalData.FrontFloat(), 2.0f);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				//External = Internal
				externalData = internalData;
				Assert::AreEqual(internalData.FrontFloat(), 1.0f);
				Assert::AreEqual(externalData.FrontFloat(), 1.0f);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(externalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(externalData.Capacity(), size_t(5));

				//Internal = External
				internalData = alternateExternalData;
				Assert::AreEqual(internalData.FrontFloat(), 2.0f);
				Assert::AreEqual(alternateExternalData.FrontFloat(), 2.0f);
				Assert::AreEqual(internalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(internalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				//Internal = Internal
				internalData = alternateInternalData;
				Assert::AreEqual(internalData.FrontFloat(), 5.0f);
				Assert::AreEqual(alternateInternalData.FrontFloat(), 5.0f);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));
			}

			{
				std::string oolong = "Oolong";
				std::string green = "Green";
				Datum internalData;
				Datum alternateInternalData;
				Datum externalData(oolong);
				Datum alternateExternalData(green);

				Datum differentType(static_cast<size_t>(1));
				std::string basicArray[]{ "Chai", "Black", "Chamomile", "Apple", "Royal milk"};
				std::string alternateArray[]{ "White", "Herbal", "Peach", "Lemon ginger", "Boba"};

//				Assert::ExpectException<std::runtime_error>([&externalData, &differentType]() { externalData = differentType; });//Does not allow assignment between separate types.

				internalData.SetStorage(basicArray, 5);
				alternateInternalData.SetStorage(alternateArray, 5);

				Assert::AreEqual(externalData.FrontString(), std::string("Oolong"));
				Assert::AreEqual(alternateExternalData.FrontString(), std::string("Green"));
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				Assert::AreEqual(internalData.FrontString(), basicArray[0]);
				Assert::AreEqual(alternateInternalData.FrontString(), alternateArray[0]);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//External = External
				externalData = alternateExternalData;
				Assert::AreEqual(externalData.FrontString(), std::string("Green"));
				Assert::AreEqual(alternateExternalData.FrontString(), std::string("Green"));
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				//External = Internal
				externalData = internalData;
				Assert::AreEqual(internalData.FrontString(), std::string("Chai"));
				Assert::AreEqual(externalData.FrontString(), std::string("Chai"));
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(externalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(externalData.Capacity(), size_t(5));

				//Internal = External
				internalData = alternateExternalData;
				Assert::AreEqual(internalData.FrontString(), std::string("Green"));
				Assert::AreEqual(alternateExternalData.FrontString(), std::string("Green"));
				Assert::AreEqual(internalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(internalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				//Internal = Internal
				internalData = alternateInternalData;
				Assert::AreEqual(internalData.FrontString(), std::string("White"));
				Assert::AreEqual(alternateInternalData.FrontString(), std::string("White"));
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));
			}

			{
				glm::vec4 basicInternalVector = {1, 2, 3, 4};
				glm::vec4 alternateInternalVector = {4, 3, 2, 1};

				glm::vec4 basicExternalVector = { 2, 4, 6, 8 };
				glm::vec4 alternateExternalVector = { 1, 3, 5, 7 };

				glm::vec4 basicArray[] = {basicInternalVector, basicInternalVector, basicInternalVector, basicInternalVector, basicInternalVector};
				glm::vec4 alternateArray[] = {alternateInternalVector, alternateInternalVector, alternateInternalVector, alternateInternalVector, alternateInternalVector};

				Datum internalData;
				Datum alternateInternalData;
				Datum externalData(basicExternalVector);
				Datum alternateExternalData(alternateExternalVector);

				Datum differentType(1.0f);

//				Assert::ExpectException<std::runtime_error>([&externalData, &differentType]() { externalData = differentType; });//Does not allow assignment between separate types.

				internalData.SetStorage(basicArray, 5);
				alternateInternalData.SetStorage(alternateArray, 5);

				Assert::IsTrue(externalData.FrontVector() == basicExternalVector);
				Assert::IsTrue(alternateExternalData.FrontVector() == alternateExternalVector);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				Assert::IsTrue(internalData.FrontVector() == basicInternalVector);
				Assert::IsTrue(alternateInternalData.FrontVector() == alternateInternalVector);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//External = External
				externalData = alternateExternalData;
				Assert::IsTrue(externalData.FrontVector() == alternateExternalVector);
				Assert::IsTrue(alternateExternalData.FrontVector() == alternateExternalVector);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				//External = Internal
				externalData = internalData;
				Assert::IsTrue(internalData.FrontVector() == basicInternalVector);
				Assert::IsTrue(externalData.FrontVector() == basicInternalVector);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(externalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(externalData.Capacity(), size_t(5));

				//Internal = External
				internalData = alternateExternalData;
				Assert::IsTrue(internalData.FrontVector() == alternateExternalVector);
				Assert::IsTrue(alternateExternalData.FrontVector() == alternateExternalVector);
				Assert::AreEqual(internalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(internalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				//Internal = Internal
				internalData = alternateInternalData;
				Assert::IsTrue(internalData.FrontVector() == alternateInternalVector);
				Assert::IsTrue(alternateInternalData.FrontVector() == alternateInternalVector);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));
			}

			{
				glm::mat4 basicInternalMatrix = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
				glm::mat4 alternateInternalMatrix = { 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };

				glm::mat4 basicExternalMatrix = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32};
				glm::mat4 alternateExternalMatrix = { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31 };

				glm::mat4 basicArray[] = { basicInternalMatrix, basicInternalMatrix, basicInternalMatrix, basicInternalMatrix, basicInternalMatrix };
				glm::mat4 alternateArray[] = { alternateInternalMatrix, alternateInternalMatrix, alternateInternalMatrix, alternateInternalMatrix, alternateInternalMatrix };

				Datum internalData;
				Datum alternateInternalData;
				Datum externalData(basicExternalMatrix);
				Datum alternateExternalData(alternateExternalMatrix);

				Datum differentType(1.0f);

//				Assert::ExpectException<std::runtime_error>([&externalData, &differentType]() { externalData = differentType; });//Does not allow assignment between separate types.

				internalData.SetStorage(basicArray, 5);
				alternateInternalData.SetStorage(alternateArray, 5);

				Assert::IsTrue(externalData.FrontMatrix() == basicExternalMatrix);
				Assert::IsTrue(alternateExternalData.FrontMatrix() == alternateExternalMatrix);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				Assert::IsTrue(internalData.FrontMatrix() == basicInternalMatrix);
				Assert::IsTrue(alternateInternalData.FrontMatrix() == alternateInternalMatrix);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//External = External
				externalData = alternateExternalData;
				Assert::IsTrue(externalData.FrontMatrix() == alternateExternalMatrix);
				Assert::IsTrue(alternateExternalData.FrontMatrix() == alternateExternalMatrix);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				//External = Internal
				externalData = internalData;
				Assert::IsTrue(internalData.FrontMatrix() == basicInternalMatrix);
				Assert::IsTrue(externalData.FrontMatrix() == basicInternalMatrix);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(externalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(externalData.Capacity(), size_t(5));

				//Internal = External
				internalData = alternateExternalData;
				Assert::IsTrue(internalData.FrontMatrix() == alternateExternalMatrix);
				Assert::IsTrue(alternateExternalData.FrontMatrix() == alternateExternalMatrix);
				Assert::AreEqual(internalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(internalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				//Internal = Internal
				internalData = alternateInternalData;
				Assert::IsTrue(internalData.FrontMatrix() == alternateInternalMatrix);
				Assert::IsTrue(alternateInternalData.FrontMatrix() == alternateInternalMatrix);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));
			}

			{
				Foo firstInternalFoo(1);
				Foo secondInternalFoo(2);

				RTTI* basicInternalFoo = &firstInternalFoo;
				RTTI* alternateInternalFoo = &secondInternalFoo;

				Foo firstExternalFoo(3);
				Foo secondExternalFoo(4);

				RTTI* basicExternalFoo = &firstExternalFoo;
				RTTI* alternateExternalFoo = &secondExternalFoo;

				RTTI* basicArray[] = { basicInternalFoo, basicInternalFoo, basicInternalFoo, basicInternalFoo, basicInternalFoo };
				RTTI* alternateArray[] = { alternateInternalFoo, alternateInternalFoo, alternateInternalFoo, alternateInternalFoo, alternateInternalFoo };

				Datum internalData;
				Datum alternateInternalData;
				Datum externalData(basicExternalFoo);
				Datum alternateExternalData(alternateExternalFoo);

				Datum differentType(1.0f);

//				Assert::ExpectException<std::runtime_error>([&externalData, &differentType]() { externalData = differentType; });//Does not allow assignment between separate types.

				internalData.SetStorage(basicArray, 5);
				alternateInternalData.SetStorage(alternateArray, 5);

				Assert::IsTrue(externalData.FrontRTTI() == basicExternalFoo);
				Assert::IsTrue(alternateExternalData.FrontRTTI() == alternateExternalFoo);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				Assert::IsTrue(internalData.FrontRTTI() == basicInternalFoo);
				Assert::IsTrue(alternateInternalData.FrontRTTI() == alternateInternalFoo);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//External = External
				externalData = alternateExternalData;
				Assert::IsTrue(externalData.FrontRTTI() == alternateExternalFoo);
				Assert::IsTrue(alternateExternalData.FrontRTTI() == alternateExternalFoo);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				//External = Internal
				externalData = internalData;
				Assert::IsTrue(internalData.FrontRTTI() == basicInternalFoo);
				Assert::IsTrue(externalData.FrontRTTI() == basicInternalFoo);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(externalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(externalData.Capacity(), size_t(5));

				//Internal = External
				internalData = alternateExternalData;
				Assert::IsTrue(internalData.FrontRTTI() == alternateExternalFoo);
				Assert::IsTrue(alternateExternalData.FrontRTTI() == alternateExternalFoo);
				Assert::AreEqual(internalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(internalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				//Internal = Internal
				internalData = alternateInternalData;
				Assert::IsTrue(internalData.FrontRTTI() == alternateInternalFoo);
				Assert::IsTrue(alternateInternalData.FrontRTTI() == alternateInternalFoo);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));
			}
		}

		TEST_METHOD(MoveAssignment)
		{
			{
				Datum internalData;
				Datum internalDataCopy;
				Datum alternateInternalData;
				Datum externalData(static_cast<size_t>(6));
				Datum alternateExternalData(static_cast<size_t>(2));

				Datum differentType(1.0f);
				size_t basicArray[]{ 1, 2, 3, 4, 5 };
				size_t alternateArray[]{ 5, 4, 3, 2, 1 };

				//Assert::ExpectException<std::runtime_error>([&externalData, &differentType]() { externalData = differentType; });//Does not allow assignment between separate types.

				internalData.SetStorage(basicArray, 5);
				alternateInternalData.SetStorage(alternateArray, 5);

				internalDataCopy = internalData;

				Assert::AreEqual(externalData.FrontInt(), static_cast<size_t>(6));
				Assert::AreEqual(alternateExternalData.FrontInt(), static_cast<size_t>(2));
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				Assert::AreEqual(internalData.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(alternateInternalData.FrontInt(), static_cast<size_t>(5));
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//External = External
				externalData = move(alternateExternalData);
				Assert::AreEqual(externalData.FrontInt(), static_cast<size_t>(2));
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));

				//External = Internal
				externalData = move(internalData);
				Assert::AreEqual(externalData.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(externalData.Size(), size_t(5));
				Assert::AreEqual(externalData.Capacity(), size_t(5));

				//Internal = External
				alternateInternalData = move(externalData);
				Assert::AreEqual(alternateInternalData.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//Internal = Internal
				alternateInternalData = move(internalDataCopy);
				Assert::AreEqual(alternateInternalData.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));
			}

			{
				Datum internalData;
				Datum alternateInternalData;
				Datum externalData(6.0f);
				Datum alternateExternalData(2.0f);
				Datum internalDataCopy;

				Datum differentType(static_cast<size_t>(1));
				float basicArray[]{ 1.0, 2.0, 3.0, 4.0, 5.0 };
				float alternateArray[]{ 5.0, 4.0, 3.0, 2.0, 1.0 };

				//Assert::ExpectException<std::runtime_error>([&externalData, &differentType]() { externalData = differentType; });//Does not allow assignment between separate types.

				internalData.SetStorage(basicArray, 5);
				alternateInternalData.SetStorage(alternateArray, 5);
				internalDataCopy = internalData;

				Assert::AreEqual(externalData.FrontFloat(), 6.0f);
				Assert::AreEqual(alternateExternalData.FrontFloat(), 2.0f);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				Assert::AreEqual(internalData.FrontFloat(), 1.0f);
				Assert::AreEqual(alternateInternalData.FrontFloat(), 5.0f);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//External = External
				externalData = alternateExternalData;
				Assert::AreEqual(externalData.FrontFloat(), 2.0f);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));

				//External = Internal
				externalData = internalData;
				Assert::AreEqual(externalData.FrontFloat(), 1.0f);
				Assert::AreEqual(externalData.Size(), size_t(5));
				Assert::AreEqual(externalData.Capacity(), size_t(5));

				//Internal = External
				alternateInternalData = move(externalData);
				Assert::AreEqual(alternateInternalData.FrontFloat(), 1.0f);
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//Internal = Internal
				alternateInternalData = move(internalDataCopy);
				Assert::AreEqual(alternateInternalData.FrontFloat(), 1.0f);
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));
			}

			{
				std::string oolong = "Oolong";
				std::string green = "Green";
				Datum internalData;
				Datum alternateInternalData;
				Datum externalData(oolong);
				Datum alternateExternalData(green);
				Datum internalDataCopy;

				Datum differentType(static_cast<size_t>(1));
				std::string basicArray[]{ "Chai", "Black", "Chamomile", "Apple", "Royal milk" };
				std::string alternateArray[]{ "White", "Herbal", "Peach", "Lemon ginger", "Boba" };

				//Assert::ExpectException<std::runtime_error>([&externalData, &differentType]() { externalData = differentType; });//Does not allow assignment between separate types.

				internalData.SetStorage(basicArray, 5);
				alternateInternalData.SetStorage(alternateArray, 5);

				internalDataCopy = internalData;

				Assert::AreEqual(externalData.FrontString(), std::string("Oolong"));
				Assert::AreEqual(alternateExternalData.FrontString(), std::string("Green"));
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				Assert::AreEqual(internalData.FrontString(), basicArray[0]);
				Assert::AreEqual(alternateInternalData.FrontString(), alternateArray[0]);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//External = External
				externalData = move(alternateExternalData);
				Assert::AreEqual(externalData.FrontString(), std::string("Green"));
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));

				//External = Internal
				externalData = move(internalData);
				Assert::AreEqual(externalData.FrontString(), std::string("Chai"));
				Assert::AreEqual(externalData.Size(), size_t(5));
				Assert::AreEqual(externalData.Capacity(), size_t(5));

				//Internal = External
				alternateInternalData = move(externalData);
				Assert::AreEqual(alternateInternalData.FrontString(),std::string("Chai"));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//Internal = Internal
				alternateInternalData = move(internalDataCopy);
				Assert::AreEqual(alternateInternalData.FrontString(), std::string("Chai"));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));
			}

			{
				glm::vec4 basicInternalVector = { 1, 2, 3, 4 };
				glm::vec4 alternateInternalVector = { 4, 3, 2, 1 };

				glm::vec4 basicExternalVector = { 2, 4, 6, 8 };
				glm::vec4 alternateExternalVector = { 1, 3, 5, 7 };

				glm::vec4 basicArray[] = { basicInternalVector, basicInternalVector, basicInternalVector, basicInternalVector, basicInternalVector };
				glm::vec4 alternateArray[] = { alternateInternalVector, alternateInternalVector, alternateInternalVector, alternateInternalVector, alternateInternalVector };

				Datum internalData;
				Datum alternateInternalData;
				Datum externalData(basicExternalVector);
				Datum alternateExternalData(alternateExternalVector);
				Datum internalDataCopy;

				Datum differentType(1.0f);

				//Assert::ExpectException<std::runtime_error>([&externalData, &differentType]() { externalData = differentType; });//Does not allow assignment between separate types.

				internalData.SetStorage(basicArray, 5);
				alternateInternalData.SetStorage(alternateArray, 5);
				internalDataCopy = internalData;

				Assert::IsTrue(externalData.FrontVector() == basicExternalVector);
				Assert::IsTrue(alternateExternalData.FrontVector() == alternateExternalVector);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				Assert::IsTrue(internalData.FrontVector() == basicInternalVector);
				Assert::IsTrue(alternateInternalData.FrontVector() == alternateInternalVector);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//External = External
				externalData = move(alternateExternalData);
				Assert::IsTrue(externalData.FrontVector() == alternateExternalVector);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));

				//External = Internal
				externalData = move(internalData);
				Assert::IsTrue(externalData.FrontVector() == basicInternalVector);
				Assert::AreEqual(externalData.Size(), size_t(5));
				Assert::AreEqual(externalData.Capacity(), size_t(5));

				//Internal = External
				alternateInternalData = move(externalData);
				Assert::IsTrue(alternateInternalData.FrontVector() == basicInternalVector);
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//Internal = Internal
				alternateInternalData = move(internalDataCopy);
				Assert::IsTrue(alternateInternalData.FrontVector() == basicInternalVector);
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));
			}

			{
				glm::mat4 basicInternalMatrix = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
				glm::mat4 alternateInternalMatrix = { 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };

				glm::mat4 basicExternalMatrix = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32 };
				glm::mat4 alternateExternalMatrix = { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31 };

				glm::mat4 basicArray[] = { basicInternalMatrix, basicInternalMatrix, basicInternalMatrix, basicInternalMatrix, basicInternalMatrix };
				glm::mat4 alternateArray[] = { alternateInternalMatrix, alternateInternalMatrix, alternateInternalMatrix, alternateInternalMatrix, alternateInternalMatrix };

				Datum internalData;
				Datum alternateInternalData;
				Datum externalData(basicExternalMatrix);
				Datum alternateExternalData(alternateExternalMatrix);
				Datum internalDataCopy;

				Datum differentType(1.0f);

//				Assert::ExpectException<std::runtime_error>([&externalData, &differentType]() { externalData = differentType; });//Does not allow assignment between separate types.

				internalData.SetStorage(basicArray, 5);
				alternateInternalData.SetStorage(alternateArray, 5);
				internalDataCopy = internalData;

				Assert::IsTrue(externalData.FrontMatrix() == basicExternalMatrix);
				Assert::IsTrue(alternateExternalData.FrontMatrix() == alternateExternalMatrix);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				Assert::IsTrue(internalData.FrontMatrix() == basicInternalMatrix);
				Assert::IsTrue(alternateInternalData.FrontMatrix() == alternateInternalMatrix);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));


				//External = External
				externalData = move(alternateExternalData);
				Assert::IsTrue(externalData.FrontMatrix() == alternateExternalMatrix);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));

				//External = Internal
				externalData = move(internalData);
				Assert::IsTrue(externalData.FrontMatrix() == basicInternalMatrix);
				Assert::AreEqual(externalData.Size(), size_t(5));
				Assert::AreEqual(externalData.Capacity(), size_t(5));

				//Internal = External
				alternateInternalData = move(externalData);
				Assert::IsTrue(alternateInternalData.FrontMatrix() == basicInternalMatrix);
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//Internal = Internal
				alternateInternalData = move(internalDataCopy);
				Assert::IsTrue(alternateInternalData.FrontMatrix() == basicInternalMatrix);
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));
			}

			{
				Foo firstInternalFoo(1);
				Foo secondInternalFoo(2);

				RTTI* basicInternalFoo = &firstInternalFoo;
				RTTI* alternateInternalFoo = &secondInternalFoo;

				Foo firstExternalFoo(3);
				Foo secondExternalFoo(4);

				RTTI* basicExternalFoo = &firstExternalFoo;
				RTTI* alternateExternalFoo = &secondExternalFoo;

				RTTI* basicArray[] = { basicInternalFoo, basicInternalFoo, basicInternalFoo, basicInternalFoo, basicInternalFoo };
				RTTI* alternateArray[] = { alternateInternalFoo, alternateInternalFoo, alternateInternalFoo, alternateInternalFoo, alternateInternalFoo };

				Datum internalData;
				Datum alternateInternalData;
				Datum externalData(basicExternalFoo);
				Datum alternateExternalData(alternateExternalFoo);
				Datum internalDataCopy;

				Datum differentType(1.0f);

	//			Assert::ExpectException<std::runtime_error>([&externalData, &differentType]() { externalData = differentType; });//Does not allow assignment between separate types.

				internalData.SetStorage(basicArray, 5);
				alternateInternalData.SetStorage(alternateArray, 5);
				internalDataCopy = internalData;

				Assert::IsTrue(externalData.FrontRTTI() == basicExternalFoo);
				Assert::IsTrue(alternateExternalData.FrontRTTI() == alternateExternalFoo);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(alternateExternalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));
				Assert::AreEqual(alternateExternalData.Capacity(), size_t(1));

				Assert::IsTrue(internalData.FrontRTTI() == basicInternalFoo);
				Assert::IsTrue(alternateInternalData.FrontRTTI() == alternateInternalFoo);
				Assert::AreEqual(internalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(internalData.Capacity(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//External = External
				externalData = move(alternateExternalData);
				Assert::IsTrue(externalData.FrontRTTI() == alternateExternalFoo);
				Assert::AreEqual(externalData.Size(), size_t(1));
				Assert::AreEqual(externalData.Capacity(), size_t(1));

				//External = Internal
				externalData = move(internalData);
				Assert::IsTrue(externalData.FrontRTTI() == basicInternalFoo);
				Assert::AreEqual(externalData.Size(), size_t(5));
				Assert::AreEqual(externalData.Capacity(), size_t(5));

				//Internal = External
				alternateInternalData = move(externalData);
				Assert::IsTrue(alternateInternalData.FrontRTTI() == basicInternalFoo);
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));

				//Internal = Internal
				alternateInternalData = move(internalDataCopy);
				Assert::IsTrue(alternateInternalData.FrontRTTI() == basicInternalFoo);
				Assert::AreEqual(alternateInternalData.Size(), size_t(5));
				Assert::AreEqual(alternateInternalData.Capacity(), size_t(5));
			}
		}

		TEST_METHOD(PushBack)
		{
			{
				Datum dataList(Datum::DatumTypes::Integer, static_cast<size_t>(5));
				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.FrontInt(); });
				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.BackInt(); });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(0));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(static_cast<size_t>(1));
				Assert::AreEqual(dataList.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.BackInt(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(static_cast<size_t>(2));
				Assert::AreEqual(dataList.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.BackInt(), static_cast<size_t>(2));
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(2));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(static_cast<size_t>(3));
				Assert::AreEqual(dataList.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.BackInt(), static_cast<size_t>(3));
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(3));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(static_cast<size_t>(4));
				Assert::AreEqual(dataList.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.BackInt(), static_cast<size_t>(4));
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(4));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(static_cast<size_t>(5));
				Assert::AreEqual(dataList.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.BackInt(), static_cast<size_t>(5));
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(5));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(static_cast<size_t>(6));
				Assert::AreEqual(dataList.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.BackInt(), static_cast<size_t>(6));
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(6));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(6));

				dataList.PushBack(static_cast<size_t>(7));
				Assert::AreEqual(dataList.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.BackInt(), static_cast<size_t>(7));
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(7));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(7));

				dataList.PushBack(static_cast<size_t>(8));
				Assert::AreEqual(dataList.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.BackInt(), static_cast<size_t>(8));
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(8));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(8));

				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.PushBack(2.0f); });
			}

			{
				Datum dataList(Datum::DatumTypes::Float, static_cast<size_t>(5));
				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.FrontFloat(); });
				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.BackFloat(); });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(0));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(1.1f);
				Assert::AreEqual(dataList.FrontFloat(), 1.1f);
				Assert::AreEqual(dataList.BackFloat(), 1.1f);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(2.2f);
				Assert::AreEqual(dataList.FrontFloat(), 1.1f);
				Assert::AreEqual(dataList.BackFloat(), 2.2f);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(2));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(3.3f);
				Assert::AreEqual(dataList.FrontFloat(), 1.1f);
				Assert::AreEqual(dataList.BackFloat(), 3.3f);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(3));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(4.4f);
				Assert::AreEqual(dataList.FrontFloat(), 1.1f);
				Assert::AreEqual(dataList.BackFloat(), 4.4f);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(4));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(5.5f);
				Assert::AreEqual(dataList.FrontFloat(), 1.1f);
				Assert::AreEqual(dataList.BackFloat(), 5.5f);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(5));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(6.6f);
				Assert::AreEqual(dataList.FrontFloat(), 1.1f);
				Assert::AreEqual(dataList.BackFloat(), 6.6f);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(6));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(6));

				dataList.PushBack(7.7f);
				Assert::AreEqual(dataList.FrontFloat(), 1.1f);
				Assert::AreEqual(dataList.BackFloat(), 7.7f);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(7));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(7));

				dataList.PushBack(8.8f);
				Assert::AreEqual(dataList.FrontFloat(), 1.1f);
				Assert::AreEqual(dataList.BackFloat(), 8.8f);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(8));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(8));

				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.PushBack(static_cast<size_t>(1)); });
			}

			{
				std::string apple = "Apple";
				std::string pear = "Pear";
				std::string orange = "Orange";
				std::string pineapple = "Pineapple";
				std::string plum = "Plum";
				std::string cranberry = "Cranberry";
				std::string peach = "Peach";
				std::string strawberry = "Strawberry";

				Datum dataList(Datum::DatumTypes::String, static_cast<size_t>(5));
				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.FrontString(); });
				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.BackString(); });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(0));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(apple);
				Assert::AreEqual(dataList.FrontString(), apple);
				Assert::AreEqual(dataList.BackString(), apple);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(pear);
				Assert::AreEqual(dataList.FrontString(), apple);
				Assert::AreEqual(dataList.BackString(), pear);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(2));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(peach);
				Assert::AreEqual(dataList.FrontString(), apple);
				Assert::AreEqual(dataList.BackString(), peach);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(3));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(orange);
				Assert::AreEqual(dataList.FrontString(),apple);
				Assert::AreEqual(dataList.BackString(), orange);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(4));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(strawberry);
				Assert::AreEqual(dataList.FrontString(), apple);
				Assert::AreEqual(dataList.BackString(), strawberry);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(5));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(pineapple);
				Assert::AreEqual(dataList.FrontString(), apple);
				Assert::AreEqual(dataList.BackString(), pineapple);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(6));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(6));

				dataList.PushBack(plum);
				Assert::AreEqual(dataList.FrontString(), apple);
				Assert::AreEqual(dataList.BackString(), plum);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(7));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(7));

				dataList.PushBack(cranberry);
				Assert::AreEqual(dataList.FrontString(), apple);
				Assert::AreEqual(dataList.BackString(), cranberry);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(8));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(8));

				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.PushBack(static_cast<size_t>(1)); });
			}

			{
				Datum dataList(Datum::DatumTypes::Vector, static_cast<size_t>(5));
				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.FrontVector(); });
				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.BackVector(); });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(0));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(glm::vec4{0, 1, 2, 3});
				Assert::IsTrue(dataList.FrontVector() == glm::vec4{ 0, 1, 2, 3 });
				Assert::IsTrue(dataList.BackVector() == glm::vec4{ 0, 1, 2, 3 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(glm::vec4{ 0, 1, 2, 4 });
				Assert::IsTrue(dataList.FrontVector() == glm::vec4{ 0, 1, 2, 3 });
				Assert::IsTrue(dataList.BackVector() == glm::vec4{ 0, 1, 2, 4 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(2));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(glm::vec4{ 0, 1, 2, 5 });
				Assert::IsTrue(dataList.FrontVector() == glm::vec4{ 0, 1, 2, 3 });
				Assert::IsTrue(dataList.BackVector() == glm::vec4{ 0, 1, 2, 5 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(3));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(glm::vec4{ 0, 1, 2, 6 });
				Assert::IsTrue(dataList.FrontVector() == glm::vec4{ 0, 1, 2, 3 });
				Assert::IsTrue(dataList.BackVector() == glm::vec4{ 0, 1, 2, 6 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(4));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(glm::vec4{ 0, 1, 2, 7 });
				Assert::IsTrue(dataList.FrontVector() == glm::vec4{0, 1, 2, 3});
				Assert::IsTrue(dataList.BackVector() == glm::vec4{ 0, 1, 2, 7 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(5));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(glm::vec4{ 0, 1, 2, 8 });
				Assert::IsTrue(dataList.FrontVector() == glm::vec4{ 0, 1, 2, 3 });
				Assert::IsTrue(dataList.BackVector() == glm::vec4{ 0, 1, 2, 8 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(6));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(6));

				dataList.PushBack(glm::vec4{ 0, 1, 2, 9 });
				Assert::IsTrue(dataList.FrontVector() == glm::vec4{ 0, 1, 2, 3 });
				Assert::IsTrue(dataList.BackVector() == glm::vec4{ 0, 1, 2, 9 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(7));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(7));

				dataList.PushBack(glm::vec4{ 0, 1, 2, 10 });
				Assert::IsTrue(dataList.FrontVector() == glm::vec4{ 0, 1, 2, 3 });
				Assert::IsTrue(dataList.BackVector() == glm::vec4{ 0, 1, 2, 10 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(8));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(8));

				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.PushBack(static_cast<size_t>(1)); });
			}

			{
				Datum dataList(Datum::DatumTypes::Matrix, static_cast<size_t>(5));
				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.FrontMatrix(); });
				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.BackMatrix(); });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(0));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
				Assert::IsTrue(dataList.FrontMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
				Assert::IsTrue(dataList.BackMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 });
				Assert::IsTrue(dataList.FrontMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
				Assert::IsTrue(dataList.BackMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(2));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17 });
				Assert::IsTrue(dataList.FrontMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
				Assert::IsTrue(dataList.BackMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(3));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 18 });
				Assert::IsTrue(dataList.FrontMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
				Assert::IsTrue(dataList.BackMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 18 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(4));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 19 });
				Assert::IsTrue(dataList.FrontMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
				Assert::IsTrue(dataList.BackMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 19 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(5));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 20 });
				Assert::IsTrue(dataList.FrontMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
				Assert::IsTrue(dataList.BackMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 20 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(6));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(6));

				dataList.PushBack(glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 21 });
				Assert::IsTrue(dataList.FrontMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
				Assert::IsTrue(dataList.BackMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 21 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(7));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(7));

				dataList.PushBack(glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 22 });
				Assert::IsTrue(dataList.FrontMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
				Assert::IsTrue(dataList.BackMatrix() == glm::mat4{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 22 });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(8));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(8));

				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.PushBack(static_cast<size_t>(1)); });
			}

			{
				Datum dataList(Datum::DatumTypes::Pointer, static_cast<size_t>(5));
				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.FrontRTTI(); });
				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.BackRTTI(); });
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(0));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);
				Foo fourthFoo(4);
				Foo fifthFoo(5);
				Foo sixthFoo(6);
				Foo seventhFoo(7);
				Foo eigthFoo(9);

				RTTI* firstRef = &firstFoo;
				RTTI* secondRef = &secondFoo;
				RTTI* thirdRef = &thirdFoo;
				RTTI* fourthRef = &fourthFoo;
				RTTI* fifthRef = &fifthFoo;
				RTTI* sixthRef = &sixthFoo;
				RTTI* seventhRef = &seventhFoo;
				RTTI* eigthRef = &eigthFoo;

				dataList.PushBack(firstRef);
				Assert::AreEqual(dataList.FrontRTTI(), firstRef);
				Assert::AreEqual(dataList.BackRTTI(), firstRef);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(1));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(secondRef);
				Assert::AreEqual(dataList.FrontRTTI(), firstRef);
				Assert::AreEqual(dataList.BackRTTI(), secondRef);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(2));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(thirdRef);
				Assert::AreEqual(dataList.FrontRTTI(), firstRef);
				Assert::AreEqual(dataList.BackRTTI(), thirdRef);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(3));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(fourthRef);
				Assert::AreEqual(dataList.FrontRTTI(), firstRef);
				Assert::AreEqual(dataList.BackRTTI(), fourthRef);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(4));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(fifthRef);
				Assert::AreEqual(dataList.FrontRTTI(), firstRef);
				Assert::AreEqual(dataList.BackRTTI(), fifthRef);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(5));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(5));

				dataList.PushBack(sixthRef);
				Assert::AreEqual(dataList.FrontRTTI(), firstRef);
				Assert::AreEqual(dataList.BackRTTI(), sixthRef);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(6));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(6));

				dataList.PushBack(seventhRef);
				Assert::AreEqual(dataList.FrontRTTI(), firstRef);
				Assert::AreEqual(dataList.BackRTTI(), seventhRef);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(7));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(7));

				dataList.PushBack(eigthRef);
				Assert::AreEqual(dataList.FrontRTTI(), firstRef);
				Assert::AreEqual(dataList.BackRTTI(), eigthRef);
				Assert::AreEqual(dataList.Size(), static_cast<size_t>(8));
				Assert::AreEqual(dataList.Capacity(), static_cast<size_t>(8));

				Assert::ExpectException<std::runtime_error>([&dataList]() { dataList.PushBack(static_cast<size_t>(1)); });
			}
		}

		TEST_METHOD(PopBack)
		{
			{
				Datum data;
				Assert::ExpectException<std::runtime_error>([&data]() { data.PopBack(); }); //Cannot pop back from list with no elements

				data.PushBack(static_cast<size_t>(1));
				data.PushBack(static_cast<size_t>(2));
				data.PushBack(static_cast<size_t>(3));
				Assert::AreEqual(data.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(data.GetInt(1), static_cast<size_t>(2));
				Assert::AreEqual(data.BackInt(), static_cast<size_t>(3));
				Assert::AreEqual(data.Size(), static_cast<size_t>(3));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::AreEqual(data.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(data.BackInt(), static_cast<size_t>(2));
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::AreEqual(data.FrontInt(), static_cast<size_t>(1));
				Assert::AreEqual(data.BackInt(), static_cast<size_t>(1));
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackInt(); });
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));
			}

			{
				Datum data;
				Assert::ExpectException<std::runtime_error>([&data]() { data.PopBack(); }); //Cannot pop back from list with no elements

				data.PushBack(1.0f);
				data.PushBack(2.0f);
				data.PushBack(3.0f);
				Assert::AreEqual(data.FrontFloat(), 1.0f);
				Assert::AreEqual(data.GetFloat(1), 2.0f);
				Assert::AreEqual(data.BackFloat(), 3.0f);
				Assert::AreEqual(data.Size(), static_cast<size_t>(3));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::AreEqual(data.FrontFloat(), 1.0f);
				Assert::AreEqual(data.BackFloat(), 2.0f);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::AreEqual(data.FrontFloat(), 1.0f);
				Assert::AreEqual(data.BackFloat(), 1.0f);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackFloat(); });
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));
			}

			{
				Datum data;
				Assert::ExpectException<std::runtime_error>([&data]() { data.PopBack(); }); //Cannot pop back from list with no elements

				std::string apple = "Apple";
				std::string pear = "Pear";
				std::string orange = "Orange";

				data.PushBack(apple);
				data.PushBack(pear);
				data.PushBack(orange);
				Assert::AreEqual(data.FrontString(), apple);
				Assert::AreEqual(data.GetString(1), pear);
				Assert::AreEqual(data.BackString(), orange);
				Assert::AreEqual(data.Size(), static_cast<size_t>(3));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::AreEqual(data.FrontString(), apple);
				Assert::AreEqual(data.BackString(), pear);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::AreEqual(data.FrontString(), apple);
				Assert::AreEqual(data.BackString(), apple);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackString(); });
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));
			}

			{
				Datum data;
				Assert::ExpectException<std::runtime_error>([&data]() { data.PopBack(); }); //Cannot pop back from list with no elements

				glm::vec4 firstElement{ 1, 2, 3, 4 };
				glm::vec4 secondElement{ 2, 4, 6, 8 };
				glm::vec4 thirdElement{ 3, 6, 8, 12 };

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::IsTrue(data.FrontVector() == firstElement);
				Assert::IsTrue(data.GetVector(1) == secondElement);
				Assert::IsTrue(data.BackVector() == thirdElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(3));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::IsTrue(data.FrontVector() == firstElement);
				Assert::IsTrue(data.BackVector() == secondElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::IsTrue(data.FrontVector() == firstElement);
				Assert::IsTrue(data.BackVector() == firstElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackVector(); });
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));
			}

			{
				Datum data;
				Assert::ExpectException<std::runtime_error>([&data]() { data.PopBack(); }); //Cannot pop back from list with no elements

				glm::mat4 firstElement{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
				glm::mat4 secondElement{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17 };
				glm::mat4 thirdElement{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 18 };

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::IsTrue(data.FrontMatrix() == firstElement);
				Assert::IsTrue(data.GetMatrix(1) == secondElement);
				Assert::IsTrue(data.BackMatrix() == thirdElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(3));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::IsTrue(data.FrontMatrix() == firstElement);
				Assert::IsTrue(data.BackMatrix() == secondElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::IsTrue(data.FrontMatrix() == firstElement);
				Assert::IsTrue(data.BackMatrix() == firstElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackMatrix(); });
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));
			}

			{
				Datum data;
				Assert::ExpectException<std::runtime_error>([&data]() { data.PopBack(); }); //Cannot pop back from list with no elements

				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);
				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;
				RTTI* thirdElement = &thirdFoo;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::IsTrue(data.FrontRTTI() == firstElement);
				Assert::IsTrue(data.GetRTTI(1) == secondElement);
				Assert::IsTrue(data.BackRTTI() == thirdElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(3));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::IsTrue(data.FrontRTTI() == firstElement);
				Assert::IsTrue(data.BackRTTI() == secondElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::IsTrue(data.FrontRTTI() == firstElement);
				Assert::IsTrue(data.BackRTTI() == firstElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));

				data.PopBack();
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontRTTI(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackRTTI(); });
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(3));
			}
		}

		TEST_METHOD(GetConst)
		{
			{
				Datum data(Datum::DatumTypes::Integer, 4);
				const size_t firstElement = 9;
				const size_t secondElement = 8;
				const size_t thirdElement = 7;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(data.GetConstInt(), firstElement);
				Assert::AreEqual(data.GetConstInt(1), secondElement);
				Assert::AreEqual(data.GetConstInt(2), thirdElement);

				const size_t intArray[] = {data.GetConstInt(), data.GetConstInt(1), data.GetConstInt(2)};
				Assert::AreEqual(intArray[0], firstElement);
				Assert::AreEqual(intArray[1], secondElement);
				Assert::AreEqual(intArray[2], thirdElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.GetConstFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetConstInt(3); });
			}

			{
				Datum data(Datum::DatumTypes::Float, 4);
				const float firstElement = 9.9f;
				const float secondElement = 8.8f;
				const float thirdElement = 7.7f;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(data.GetConstFloat(), firstElement);
				Assert::AreEqual(data.GetConstFloat(1), secondElement);
				Assert::AreEqual(data.GetConstFloat(2), thirdElement);

				const float floatArray[] = { data.GetConstFloat(), data.GetConstFloat(1), data.GetConstFloat(2) };
				Assert::AreEqual(floatArray[0], firstElement);
				Assert::AreEqual(floatArray[1], secondElement);
				Assert::AreEqual(floatArray[2], thirdElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetFloat(3); });
			}

			{
				Datum data(Datum::DatumTypes::String, 4);
				std::string firstElement = "Apple";
				std::string secondElement = "Pear";
				std::string thirdElement = "Orange";

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::AreEqual(data.GetString(), firstElement);
				Assert::AreEqual(data.GetString(1), secondElement);
				Assert::AreEqual(data.GetString(2), thirdElement);

				const std::string stringArray[] = { data.GetConstString(), data.GetConstString(1), data.GetConstString(2) };
				Assert::AreEqual(stringArray[0], firstElement);
				Assert::AreEqual(stringArray[1], secondElement);
				Assert::AreEqual(stringArray[2], thirdElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetString(3); });
			}

			{
				Datum data(Datum::DatumTypes::Vector, 4);
				const glm::vec4 firstElement = {0, 1, 2, 3};
				const glm::vec4 secondElement = {1, 2, 3, 4};
				const glm::vec4 thirdElement = {2, 3, 4, 5};

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::IsTrue(data.GetVector() == firstElement);
				Assert::IsTrue(data.GetVector(1) == secondElement);
				Assert::IsTrue(data.GetVector(2) == thirdElement);

				const glm::vec4 vectorArray[] = { data.GetConstVector(), data.GetConstVector(1), data.GetConstVector(2)};
				Assert::IsTrue(vectorArray[0] == firstElement);
				Assert::IsTrue(vectorArray[1] == secondElement);
				Assert::IsTrue(vectorArray[2] == thirdElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetVector(3); });
			}

			{
				Datum data(Datum::DatumTypes::Matrix, 4);
				const glm::mat4 firstElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				const glm::mat4 secondElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
				const glm::mat4 thirdElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17 };

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::IsTrue(data.GetMatrix() == firstElement);
				Assert::IsTrue(data.GetMatrix(1) == secondElement);
				Assert::IsTrue(data.GetMatrix(2) == thirdElement);

				const glm::mat4 matrixArray[] = { data.GetConstMatrix(), data.GetConstMatrix(1), data.GetConstMatrix(2) };
				Assert::IsTrue(matrixArray[0] == firstElement);
				Assert::IsTrue(matrixArray[1] == secondElement);
				Assert::IsTrue(matrixArray[2] == thirdElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetMatrix(3); });
			}

			{
				Datum data(Datum::DatumTypes::Pointer, 4);
				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);

				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;
				RTTI* thirdElement = &thirdFoo;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::IsTrue(data.GetRTTI() == firstElement);
				Assert::IsTrue(data.GetRTTI(1) == secondElement);
				Assert::IsTrue(data.GetRTTI(2) == thirdElement);

				const RTTI* fooArray[] = { data.GetConstRTTI(), data.GetConstRTTI(1), data.GetConstRTTI(2) };
				Assert::IsTrue(fooArray[0] == data.GetConstRTTI());
				Assert::IsTrue(fooArray[1] == data.GetConstRTTI(1));
				Assert::IsTrue(fooArray[2] == data.GetConstRTTI(2));

				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetRTTI(3); });
			}
		}

		TEST_METHOD(Get)
		{
			{
				Datum data(Datum::DatumTypes::Integer, 4);
				size_t firstElement = 9;
				size_t secondElement = 8;
				size_t thirdElement = 7;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::AreEqual(data.GetInt(), firstElement);
				Assert::AreEqual(data.GetInt(1), secondElement);
				Assert::AreEqual(data.GetInt(2), thirdElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.GetFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(3); });
			}

			{
				Datum data(Datum::DatumTypes::Float, 4);
				float firstElement = 9.9f;
				float secondElement = 8.8f;
				float thirdElement = 7.7f;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::AreEqual(data.GetFloat(), firstElement);
				Assert::AreEqual(data.GetFloat(1), secondElement);
				Assert::AreEqual(data.GetFloat(2), thirdElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetFloat(3); });
			}

			{
				Datum data(Datum::DatumTypes::String, 4);
				std::string firstElement = "Apple";
				std::string secondElement = "Pear";
				std::string thirdElement = "Orange";

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::AreEqual(data.GetString(), firstElement);
				Assert::AreEqual(data.GetString(1), secondElement);
				Assert::AreEqual(data.GetString(2), thirdElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetString(3); });
			}

			{
				Datum data(Datum::DatumTypes::Vector, 4);
				glm::vec4 firstElement = { 0, 1, 2, 3 };
				glm::vec4 secondElement = { 1, 2, 3, 4 };
				glm::vec4 thirdElement = { 2, 3, 4, 5 };

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::IsTrue(data.GetVector() == firstElement);
				Assert::IsTrue(data.GetVector(1) == secondElement);
				Assert::IsTrue(data.GetVector(2) == thirdElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetVector(3); });
			}

			{
				Datum data(Datum::DatumTypes::Matrix, 4);
				glm::mat4 firstElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 secondElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
				glm::mat4 thirdElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17 };

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::IsTrue(data.GetMatrix() == firstElement);
				Assert::IsTrue(data.GetMatrix(1) == secondElement);
				Assert::IsTrue(data.GetMatrix(2) == thirdElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetMatrix(3); });
			}

			{
				Datum data(Datum::DatumTypes::Pointer, 4);
				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);

				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;
				RTTI* thirdElement = &thirdFoo;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::IsTrue(data.GetRTTI() == firstElement);
				Assert::IsTrue(data.GetRTTI(1) == secondElement);
				Assert::IsTrue(data.GetRTTI(2) == thirdElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetRTTI(3); });
			}
		}

		TEST_METHOD(Set)
		{
			{
				Datum data(Datum::DatumTypes::Integer, 4);
				size_t firstElement = 9;
				size_t secondElement = 8;
				size_t thirdElement = 7;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.SetInt(1);
				data.SetInt(2, 1);
				data.SetInt(3, 2);

				Assert::AreEqual(data.GetInt(), static_cast<size_t>(1));
				Assert::AreEqual(data.GetInt(1), static_cast<size_t>(2));
				Assert::AreEqual(data.GetInt(2), static_cast<size_t>(3));

				Assert::ExpectException<std::runtime_error>([&data]() { data.SetFloat(1.1f); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.SetInt(4, 3); });
			}

			{
				Datum data(Datum::DatumTypes::Float, 4);
				float firstElement = 9.9f;
				float secondElement = 8.8f;
				float thirdElement = 7.7f;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.SetFloat(1.1f);
				data.SetFloat(2.2f, 1);
				data.SetFloat(3.3f, 2);

				Assert::AreEqual(data.GetFloat(), 1.1f);
				Assert::AreEqual(data.GetFloat(1), 2.2f);
				Assert::AreEqual(data.GetFloat(2), 3.3f);

				Assert::ExpectException<std::runtime_error>([&data]() { data.SetInt(static_cast<size_t>(1)); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.SetFloat(4, 3); });
			}

			{
				Datum data(Datum::DatumTypes::String, 4);
				std::string firstElement = "Apple";
				std::string secondElement = "Pear";
				std::string thirdElement = "Orange";

				std::string fourthElement = "Blueberry";
				std::string fifthElement = "Cherry";
				std::string sixthElement = "Strawberry";
				std::string missingElement = "Peach";

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.SetString(fourthElement);
				data.SetString(fifthElement, 1);
				data.SetString(sixthElement, 2);

				Assert::AreEqual(data.GetString(), std::string("Blueberry"));
				Assert::AreEqual(data.GetString(1), std::string("Cherry"));
				Assert::AreEqual(data.GetString(2), std::string("Strawberry"));

				Assert::ExpectException<std::runtime_error>([&data]() { data.SetInt(static_cast<size_t>(1)); });
				Assert::ExpectException<std::runtime_error>([&data, &missingElement]() { data.SetString(missingElement, 3); });
			}

			{
				Datum data(Datum::DatumTypes::Vector, 4);
				glm::vec4 firstElement = { 0, 1, 2, 3 };
				glm::vec4 secondElement = { 1, 2, 3, 4 };
				glm::vec4 thirdElement = { 2, 3, 4, 5 };
				glm::vec4 fourthElement = { 0, 1, 3, 4 };
				glm::vec4 fifthElement = { 1, 2, 1, 2 };
				glm::vec4 sixthElement = { 2, 2, 2, 2 };

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.SetVector(fourthElement);
				data.SetVector(fifthElement, 1);
				data.SetVector(sixthElement, 2);

				Assert::IsTrue(data.GetVector() == fourthElement);
				Assert::IsTrue(data.GetVector(1) == fifthElement);
				Assert::IsTrue(data.GetVector(2) == sixthElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.SetInt(1); });
				Assert::ExpectException<std::runtime_error>([&data, &sixthElement]() { data.SetVector(sixthElement, 3); });
			}

			{
				Datum data(Datum::DatumTypes::Matrix, 4);
				glm::mat4 firstElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 secondElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
				glm::mat4 thirdElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17 };
				glm::mat4 fourthElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 18 };
				glm::mat4 fifthElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 19 };
				glm::mat4 sixthElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 20 };

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.SetMatrix(fourthElement);
				data.SetMatrix(fifthElement, 1);
				data.SetMatrix(sixthElement, 2);

				Assert::IsTrue(data.GetMatrix() == fourthElement);
				Assert::IsTrue(data.GetMatrix(1) == fifthElement);
				Assert::IsTrue(data.GetMatrix(2) == sixthElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.SetInt(1); });
				Assert::ExpectException<std::runtime_error>([&data, &sixthElement]() { data.SetMatrix(sixthElement, 3); });
			}

			{
				Datum data(Datum::DatumTypes::Pointer, 4);
				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);
				Foo fourthFoo(4);
				Foo fifthFoo(5);
				Foo sixthFoo(6);

				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;
				RTTI* thirdElement = &thirdFoo;
				RTTI* fourthElement = &fourthFoo;
				RTTI* fifthElement = &fifthFoo;
				RTTI* sixthElement = &sixthFoo;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.SetRTTI(fourthElement);
				data.SetRTTI(fifthElement, 1);
				data.SetRTTI(sixthElement, 2);

				Assert::IsTrue(data.GetRTTI() == fourthElement);
				Assert::IsTrue(data.GetRTTI(1) == fifthElement);
				Assert::IsTrue(data.GetRTTI(2) == sixthElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.SetInt(1); });
				Assert::ExpectException<std::runtime_error>([&data, &sixthElement]() { data.SetRTTI(sixthElement, 3); });
			}
		}

		TEST_METHOD(Front)
		{
			{
				Datum data(Datum::DatumTypes::Integer);
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontInt(); }); //Cannot call if datum is empty

				data.PushBack(static_cast<size_t>(1));
				data.PushBack(static_cast<size_t>(2));
				data.PushBack(static_cast<size_t>(3));

				Assert::IsTrue(data.FrontInt() == static_cast<size_t>(1));
				data.Remove(static_cast<size_t>(1));
				Assert::IsTrue(data.FrontInt() == static_cast<size_t>(2));
				data.Remove(static_cast<size_t>(2));
				Assert::IsTrue(data.FrontInt() == static_cast<size_t>(3));
				data.Remove(static_cast<size_t>(3));


				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Float);
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontFloat(); }); //Cannot call if datum is empty

				data.PushBack(1.1f);
				data.PushBack(2.2f);
				data.PushBack(3.3f);

				Assert::IsTrue(data.FrontFloat() == 1.1f);
				data.Remove(1.1f);
				Assert::IsTrue(data.FrontFloat() == 2.2f);
				data.Remove(2.2f);
				Assert::IsTrue(data.FrontFloat() == 3.3f);
				data.Remove(3.3f);


				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::String);
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontString(); }); //Cannot call if datum is empty
					
				std::string frontElement = "Apple";
				std::string middleElement = "Pear";
				std::string endElement = "Orange";

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				Assert::IsTrue(data.FrontString() == frontElement);
				data.Remove(frontElement);
				Assert::IsTrue(data.FrontString() == middleElement);
				data.Remove(middleElement);
				Assert::IsTrue(data.FrontString() == endElement);
				data.Remove(endElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Vector);
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontVector(); }); //Cannot call if datum is empty

				glm::vec4 frontElement = {0, 1, 2, 3};
				glm::vec4 middleElement = {2, 4, 6, 8};
				glm::vec4 endElement = {3, 6, 9, 12};

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				Assert::IsTrue(data.FrontVector() == frontElement);
				data.Remove(frontElement);
				Assert::IsTrue(data.FrontVector() == middleElement);
				data.Remove(middleElement);
				Assert::IsTrue(data.FrontVector() == endElement);
				data.Remove(endElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Matrix);
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontMatrix(); }); //Cannot call if datum is empty

				glm::mat4 frontElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 middleElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
				glm::mat4 endElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17 };

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				Assert::IsTrue(data.FrontMatrix() == frontElement);
				data.Remove(frontElement);
				Assert::IsTrue(data.FrontMatrix() == middleElement);
				data.Remove(middleElement);
				Assert::IsTrue(data.FrontMatrix() == endElement);
				data.Remove(endElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Pointer);
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontRTTI(); }); //Cannot call if datum is empty

				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);

				RTTI* frontElement = &firstFoo;
				RTTI* middleElement = &secondFoo;
				RTTI* endElement = &thirdFoo;

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				Assert::IsTrue(data.FrontRTTI() == frontElement);
				data.Remove(frontElement);
				Assert::IsTrue(data.FrontRTTI() == middleElement);
				data.Remove(middleElement);
				Assert::IsTrue(data.FrontRTTI() == endElement);
				data.Remove(endElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontMatrix(); });
			}
		}

		TEST_METHOD(Back)
		{
			{
				Datum data(Datum::DatumTypes::Integer);
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackInt(); }); //Cannot call if datum is empty

				data.PushBack(static_cast<size_t>(1));
				data.PushBack(static_cast<size_t>(2));
				data.PushBack(static_cast<size_t>(3));

				Assert::IsTrue(data.BackInt() == static_cast<size_t>(3));
				data.PopBack();
				Assert::IsTrue(data.BackInt() == static_cast<size_t>(2));
				data.PopBack();
				Assert::IsTrue(data.BackInt() == static_cast<size_t>(1));
				data.PopBack();


				Assert::ExpectException<std::runtime_error>([&data]() { data.BackFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Float);
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackFloat(); }); //Cannot call if datum is empty

				data.PushBack(1.1f);
				data.PushBack(2.2f);
				data.PushBack(3.3f);

				Assert::IsTrue(data.BackFloat() == 3.3f);
				data.PopBack();
				Assert::IsTrue(data.BackFloat() == 2.2f);
				data.PopBack();
				Assert::IsTrue(data.BackFloat() == 1.1f);
				data.PopBack();


				Assert::ExpectException<std::runtime_error>([&data]() { data.BackInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::String);
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackString(); }); //Cannot call if datum is empty

				std::string frontElement = "Apple";
				std::string middleElement = "Pear";
				std::string endElement = "Orange";

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				Assert::IsTrue(data.BackString() == endElement);
				data.PopBack();
				Assert::IsTrue(data.BackString() == middleElement);
				data.PopBack();
				Assert::IsTrue(data.BackString() == frontElement);
				data.PopBack();

				Assert::ExpectException<std::runtime_error>([&data]() { data.BackInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Vector);
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackVector(); }); //Cannot call if datum is empty

				glm::vec4 frontElement = { 0, 1, 2, 3 };
				glm::vec4 middleElement = { 2, 4, 6, 8 };
				glm::vec4 endElement = { 3, 6, 9, 12 };

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				Assert::IsTrue(data.BackVector() == endElement);
				data.PopBack();
				Assert::IsTrue(data.BackVector() == middleElement);
				data.PopBack();
				Assert::IsTrue(data.BackVector() == frontElement);
				data.PopBack();

				Assert::ExpectException<std::runtime_error>([&data]() { data.BackInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Matrix);
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackMatrix(); }); //Cannot call if datum is empty

				glm::mat4 frontElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 middleElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
				glm::mat4 endElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17 };

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				Assert::IsTrue(data.BackMatrix() == endElement);
				data.PopBack();
				Assert::IsTrue(data.BackMatrix() == middleElement);
				data.PopBack();
				Assert::IsTrue(data.BackMatrix() == frontElement);
				data.PopBack();

				Assert::ExpectException<std::runtime_error>([&data]() { data.BackInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Pointer);
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackRTTI(); }); //Cannot call if datum is empty

				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);

				RTTI* frontElement = &firstFoo;
				RTTI* middleElement = &secondFoo;
				RTTI* endElement = &thirdFoo;

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				Assert::IsTrue(data.BackRTTI() == endElement);
				data.PopBack();
				Assert::IsTrue(data.BackRTTI() == middleElement);
				data.PopBack();
				Assert::IsTrue(data.BackRTTI() == frontElement);
				data.PopBack();

				Assert::ExpectException<std::runtime_error>([&data]() { data.BackInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackMatrix(); });
			}
		}

		TEST_METHOD(ConstFront)
		{
			{
				Datum data(Datum::DatumTypes::Integer);
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstInt(); }); //Cannot call if datum is empty

				size_t firstElement(1);
				size_t secondElement(2);
				size_t thirdElement(3);

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				const auto firstConstVariable = data.FrontConstInt();
				Assert::IsTrue(data.FrontConstInt() == static_cast<size_t>(1));
				Assert::IsTrue(firstConstVariable == static_cast<size_t>(1));
				data.Remove(static_cast<size_t>(1));

				const auto secondConstVariable = data.FrontConstInt();
				Assert::IsTrue(data.FrontConstInt() == static_cast<size_t>(2));
				Assert::IsTrue(secondConstVariable == static_cast<size_t>(2));
				data.Remove(static_cast<size_t>(2));

				const auto thirdConstVariable = data.FrontConstInt();
				Assert::IsTrue(data.FrontInt() == static_cast<size_t>(3));
				Assert::IsTrue(thirdConstVariable == static_cast<size_t>(3));
				data.Remove(static_cast<size_t>(3));

				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Float);
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstFloat(); }); //Cannot call if datum is empty

				data.PushBack(1.1f);
				data.PushBack(2.2f);
				data.PushBack(3.3f);

				const auto firstConstVariable = data.FrontConstFloat();
				Assert::IsTrue(data.FrontConstFloat() == 1.1f);
				Assert::IsTrue(firstConstVariable == 1.1f);
				data.Remove(1.1f);

				const auto secondConstVariable = data.FrontConstFloat();
				Assert::IsTrue(data.FrontConstFloat() == 2.2f);
				Assert::IsTrue(secondConstVariable == 2.2f);
				data.Remove(2.2f);

				const auto thirdConstVariable = data.FrontConstFloat();
				Assert::IsTrue(data.FrontConstFloat() == 3.3f);
				Assert::IsTrue(thirdConstVariable == 3.3f);
				data.Remove(3.3f);

				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::String);
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstString(); }); //Cannot call if datum is empty

				std::string frontElement = "Apple";
				std::string middleElement = "Pear";
				std::string endElement = "Orange";

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				const auto firstConstVariable = data.FrontConstString();
				Assert::IsTrue(data.FrontConstString() == frontElement);
				Assert::IsTrue(firstConstVariable == frontElement);
				data.Remove(frontElement);

				const auto secondConstVariable = data.FrontConstString();
				Assert::IsTrue(data.FrontConstString() == middleElement);
				Assert::IsTrue(secondConstVariable == middleElement);
				data.Remove(middleElement);

				const auto thirdConstVariable = data.FrontConstString();
				Assert::IsTrue(thirdConstVariable == endElement);
				Assert::IsTrue(data.FrontConstString() == endElement);
				data.Remove(endElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Vector);
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstVector(); }); //Cannot call if datum is empty

				glm::vec4 frontElement = { 0, 1, 2, 3 };
				glm::vec4 middleElement = { 2, 4, 6, 8 };
				glm::vec4 endElement = { 3, 6, 9, 12 };

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				const auto firstValue = data.FrontConstVector();
				Assert::IsTrue(firstValue == frontElement);
				Assert::IsTrue(data.FrontConstVector() == frontElement);
				data.Remove(frontElement);

				const auto secondValue = data.FrontConstVector();
				Assert::IsTrue(secondValue == middleElement);
				Assert::IsTrue(data.FrontConstVector() == middleElement);
				data.Remove(middleElement);

				const auto thirdValue = data.FrontConstVector();
				Assert::IsTrue(thirdValue == endElement);
				Assert::IsTrue(data.FrontConstVector() == endElement);
				data.Remove(endElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Matrix);
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstMatrix(); }); //Cannot call if datum is empty

				glm::mat4 frontElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 middleElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
				glm::mat4 endElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17 };

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				const auto firstElement = data.FrontConstMatrix();
				Assert::IsTrue(firstElement == frontElement);
				Assert::IsTrue(data.FrontConstMatrix() == frontElement);
				data.Remove(frontElement);

				const auto secondElement = data.FrontConstMatrix();
				Assert::IsTrue(secondElement == middleElement);
				Assert::IsTrue(data.FrontConstMatrix() == middleElement);
				data.Remove(middleElement);

				const auto thirdElement = data.FrontConstMatrix();
				Assert::IsTrue(thirdElement == endElement);
				Assert::IsTrue(data.FrontConstMatrix() == endElement);
				data.Remove(endElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Pointer);
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstRTTI(); }); //Cannot call if datum is empty

				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);

				RTTI* frontElement = &firstFoo;
				RTTI* middleElement = &secondFoo;
				RTTI* endElement = &thirdFoo;

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				const auto firstElement = data.FrontConstRTTI();
				Assert::IsTrue(firstElement == frontElement);
				Assert::IsTrue(data.FrontConstRTTI() == frontElement);
				data.Remove(frontElement);

				const auto secondElement = data.FrontConstRTTI();
				Assert::IsTrue(secondElement == middleElement);
				Assert::IsTrue(data.FrontConstRTTI() == middleElement);
				data.Remove(middleElement);

				const auto thirdElement = data.FrontConstRTTI();
				Assert::IsTrue(thirdElement == endElement);
				Assert::IsTrue(data.FrontConstRTTI() == endElement);
				data.Remove(endElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.FrontConstMatrix(); });
			}
		}

		TEST_METHOD(ConstBack)
		{
			{
				Datum data(Datum::DatumTypes::Integer);
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstInt(); }); //Cannot call if datum is empty

				size_t firstElement = 1;
				size_t secondElement = 2;
				size_t thirdElement = 3;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				const auto firstConstVariable = data.BackConstInt();
				Assert::IsTrue(data.BackConstInt() == 3);
				Assert::IsTrue(firstConstVariable == 3);
				data.PopBack();

				const auto secondConstVariable = data.BackConstInt();
				Assert::IsTrue(data.BackConstInt() == 2);
				Assert::IsTrue(secondConstVariable == 2);
				data.PopBack();

				const auto thirdConstVariable = data.BackConstInt();
				Assert::IsTrue(data.BackConstInt() == 1);
				Assert::IsTrue(thirdConstVariable == 1);
				data.PopBack();

				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Float);
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstFloat(); }); //Cannot call if datum is empty

				data.PushBack(1.1f);
				data.PushBack(2.2f);
				data.PushBack(3.3f);

				const auto firstConstVariable = data.BackConstFloat();
				Assert::IsTrue(data.BackConstFloat() == 3.3f);
				Assert::IsTrue(firstConstVariable == 3.3f);
				data.PopBack();

				const auto secondConstVariable = data.BackConstFloat();
				Assert::IsTrue(data.BackConstFloat() == 2.2f);
				Assert::IsTrue(secondConstVariable == 2.2f);
				data.PopBack();

				const auto thirdConstVariable = data.BackConstFloat();
				Assert::IsTrue(data.BackConstFloat() == 1.1f);
				Assert::IsTrue(thirdConstVariable == 1.1f);
				data.PopBack();

				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::String);
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstString(); }); //Cannot call if datum is empty

				std::string frontElement = "Apple";
				std::string middleElement = "Pear";
				std::string endElement = "Orange";

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				const auto firstConstVariable = data.BackConstString();
				Assert::IsTrue(data.BackConstString() == endElement);
				Assert::IsTrue(firstConstVariable == endElement);
				data.PopBack();

				const auto secondConstVariable = data.BackConstString();
				Assert::IsTrue(data.BackConstString() == middleElement);
				Assert::IsTrue(secondConstVariable == middleElement);
				data.PopBack();

				const auto thirdConstVariable = data.BackConstString();
				Assert::IsTrue(thirdConstVariable == frontElement);
				Assert::IsTrue(data.BackConstString() == frontElement);
				data.PopBack();

				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Vector);
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstVector(); }); //Cannot call if datum is empty

				glm::vec4 frontElement = { 0, 1, 2, 3 };
				glm::vec4 middleElement = { 2, 4, 6, 8 };
				glm::vec4 endElement = { 3, 6, 9, 12 };

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				const auto firstValue = data.BackConstVector();
				Assert::IsTrue(firstValue == endElement);
				Assert::IsTrue(data.BackConstVector() == endElement);
				data.PopBack();

				const auto secondValue = data.BackConstVector();
				Assert::IsTrue(secondValue == middleElement);
				Assert::IsTrue(data.BackConstVector() == middleElement);
				data.PopBack();

				const auto thirdValue = data.BackConstVector();
				Assert::IsTrue(thirdValue == frontElement);
				Assert::IsTrue(data.BackConstVector() == frontElement);
				data.PopBack();

				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstMatrix(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Matrix);
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstMatrix(); }); //Cannot call if datum is empty

				glm::mat4 frontElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 middleElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
				glm::mat4 endElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17 };

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				const auto firstElement = data.BackConstMatrix();
				Assert::IsTrue(firstElement == endElement);
				Assert::IsTrue(data.BackConstMatrix() == endElement);
				data.PopBack();

				const auto secondElement = data.BackConstMatrix();
				Assert::IsTrue(secondElement == middleElement);
				Assert::IsTrue(data.BackConstMatrix() == middleElement);
				data.PopBack();

				const auto thirdElement = data.BackConstMatrix();
				Assert::IsTrue(thirdElement == frontElement);
				Assert::IsTrue(data.BackConstMatrix() == frontElement);
				data.Remove(endElement);

				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstRTTI(); });
			}

			{
				Datum data(Datum::DatumTypes::Pointer);
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstRTTI(); }); //Cannot call if datum is empty

				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);

				RTTI* frontElement = &firstFoo;
				RTTI* middleElement = &secondFoo;
				RTTI* endElement = &thirdFoo;

				data.PushBack(frontElement);
				data.PushBack(middleElement);
				data.PushBack(endElement);

				const auto firstElement = data.BackConstRTTI();
				Assert::IsTrue(firstElement == endElement);
				Assert::IsTrue(data.BackConstRTTI() == endElement);
				data.PopBack();

				const auto secondElement = data.BackConstRTTI();
				Assert::IsTrue(secondElement == middleElement);
				Assert::IsTrue(data.BackConstRTTI() == middleElement);
				data.PopBack();

				const auto thirdElement = data.BackConstRTTI();
				Assert::IsTrue(thirdElement == frontElement);
				Assert::IsTrue(data.BackConstRTTI() == frontElement);
				data.PopBack();

				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstInt(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstFloat(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstString(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstVector(); });
				Assert::ExpectException<std::runtime_error>([&data]() { data.BackConstMatrix(); });
			}
		}
		TEST_METHOD(Remove)
		{
			{
				Datum data(Datum::DatumTypes::Integer, 3);
				size_t firstElement = 9;
				size_t secondElement = 8;
				size_t thirdElement = 7;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::AreEqual(static_cast<size_t>(5), data.Size());

				Assert::ExpectException<std::runtime_error>([&data]() { data.Remove(3.0f); });

				data.Remove(secondElement);
				Assert::IsTrue(data.GetInt() == firstElement);
				Assert::IsTrue(data.GetInt(1) == thirdElement);
				Assert::IsTrue(data.GetInt(2) == secondElement);
				Assert::IsTrue(data.GetInt(3) == thirdElement);

				data.Remove(thirdElement);
				Assert::IsTrue(data.GetInt() == firstElement);
				Assert::IsTrue(data.GetInt(1) == secondElement);
				Assert::IsTrue(data.GetInt(2) == thirdElement);

				data.Remove(secondElement);
				Assert::IsTrue(data.GetInt() == firstElement);
				Assert::IsTrue(data.GetInt(1) == thirdElement);

				data.Remove(thirdElement);
				Assert::IsTrue(data.GetInt() == firstElement);

				data.Remove(firstElement);
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(); });
			}

			 {
				Datum data(Datum::DatumTypes::Float, 3);
				float firstElement = 9.1f;
				float secondElement = 8.2f;
				float thirdElement = 7.3f;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::AreEqual(static_cast<size_t>(5), data.Size());

				Assert::ExpectException<std::runtime_error>([&data]() { data.Remove(static_cast<size_t>(3)); });

				data.Remove(secondElement);
				Assert::IsTrue(data.GetFloat() == firstElement);
				Assert::IsTrue(data.GetFloat(1) == thirdElement);
				Assert::IsTrue(data.GetFloat(2) == secondElement);
				Assert::IsTrue(data.GetFloat(3) == thirdElement);

				data.Remove(thirdElement);
				Assert::IsTrue(data.GetFloat() == firstElement);
				Assert::IsTrue(data.GetFloat(1) == secondElement);
				Assert::IsTrue(data.GetFloat(2) == thirdElement);

				data.Remove(secondElement);
				Assert::IsTrue(data.GetFloat() == firstElement);
				Assert::IsTrue(data.GetFloat(1) == thirdElement);

				data.Remove(thirdElement);
				Assert::IsTrue(data.GetFloat() == firstElement);

				data.Remove(firstElement);
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetFloat(); });
			 }

			 {
				 Datum data(Datum::DatumTypes::String, 3);
				 std::string firstElement = "Apple";
				 std::string secondElement = "Orange";
				 std::string thirdElement = "Pear";

				 data.PushBack(firstElement);
				 data.PushBack(secondElement);
				 data.PushBack(thirdElement);
				 data.PushBack(secondElement);
				 data.PushBack(thirdElement);
				 Assert::AreEqual(static_cast<size_t>(5), data.Size());

				 Assert::ExpectException<std::runtime_error>([&data]() { data.Remove(static_cast<size_t>(3)); });

				 data.Remove(secondElement);
				 Assert::IsTrue(data.GetString() == firstElement);
				 Assert::IsTrue(data.GetString(1) == thirdElement);
				 Assert::IsTrue(data.GetString(2) == secondElement);
				 Assert::IsTrue(data.GetString(3) == thirdElement);

				 data.Remove(thirdElement);
				 Assert::IsTrue(data.GetString() == firstElement);
				 Assert::IsTrue(data.GetString(1) == secondElement);
				 Assert::IsTrue(data.GetString(2) == thirdElement);

				 data.Remove(secondElement);
				 Assert::IsTrue(data.GetString() == firstElement);
				 Assert::IsTrue(data.GetString(1) == thirdElement);

				 data.Remove(thirdElement);
				 Assert::IsTrue(data.GetString() == firstElement);

				 data.Remove(firstElement);
				 Assert::ExpectException<std::runtime_error>([&data]() { data.GetString(); });
			 }
			
			 {
				 Datum data(Datum::DatumTypes::Vector, 3);
				 glm::vec4 firstElement = {1, 2, 3, 4};
				 glm::vec4 secondElement = {2, 3, 4, 5};
				 glm::vec4 thirdElement = {4, 5, 6, 7};

				 data.PushBack(firstElement);
				 data.PushBack(secondElement);
				 data.PushBack(thirdElement);
				 data.PushBack(secondElement);
				 data.PushBack(thirdElement);
				 Assert::AreEqual(static_cast<size_t>(5), data.Size());

				 Assert::ExpectException<std::runtime_error>([&data]() { data.Remove(static_cast<size_t>(3)); });

				 data.Remove(secondElement);
				 Assert::IsTrue(data.GetVector() == firstElement);
				 Assert::IsTrue(data.GetVector(1) == thirdElement);
				 Assert::IsTrue(data.GetVector(2) == secondElement);
				 Assert::IsTrue(data.GetVector(3) == thirdElement);

				 data.Remove(thirdElement);
				 Assert::IsTrue(data.GetVector() == firstElement);
				 Assert::IsTrue(data.GetVector(1) == secondElement);
				 Assert::IsTrue(data.GetVector(2) == thirdElement);

				 data.Remove(secondElement);
				 Assert::IsTrue(data.GetVector() == firstElement);
				 Assert::IsTrue(data.GetVector(1) == thirdElement);

				 data.Remove(thirdElement);
				 Assert::IsTrue(data.GetVector() == firstElement);

				 data.Remove(firstElement);
				 Assert::ExpectException<std::runtime_error>([&data]() { data.GetVector(); });
			 }

			 {
				 Datum data(Datum::DatumTypes::Matrix, 3);
				 glm::mat4 firstElement = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
				 glm::mat4 secondElement = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 19 };
				 glm::mat4 thirdElement = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 245 };

				 data.PushBack(firstElement);
				 data.PushBack(secondElement);
				 data.PushBack(thirdElement);
				 data.PushBack(secondElement);
				 data.PushBack(thirdElement);
				 Assert::AreEqual(static_cast<size_t>(5), data.Size());

				 Assert::ExpectException<std::runtime_error>([&data]() { data.Remove(static_cast<size_t>(3)); });

				 data.Remove(secondElement);
				 Assert::IsTrue(data.GetMatrix() == firstElement);
				 Assert::IsTrue(data.GetMatrix(1) == thirdElement);
				 Assert::IsTrue(data.GetMatrix(2) == secondElement);
				 Assert::IsTrue(data.GetMatrix(3) == thirdElement);

				 data.Remove(thirdElement);
				 Assert::IsTrue(data.GetMatrix() == firstElement);
				 Assert::IsTrue(data.GetMatrix(1) == secondElement);
				 Assert::IsTrue(data.GetMatrix(2) == thirdElement);

				 data.Remove(secondElement);
				 Assert::IsTrue(data.GetMatrix() == firstElement);
				 Assert::IsTrue(data.GetMatrix(1) == thirdElement);

				 data.Remove(thirdElement);
				 Assert::IsTrue(data.GetMatrix() == firstElement);

				 data.Remove(firstElement);
				 Assert::ExpectException<std::runtime_error>([&data]() { data.GetMatrix(); });
			 }

			 {
				 Datum data(Datum::DatumTypes::Pointer, 3);

				 Foo firstFoo(1);
				 Foo secondFoo(2);
				 Foo thirdFoo(3);

				 RTTI* firstElement = &firstFoo;
				 RTTI* secondElement = &secondFoo;
				 RTTI* thirdElement = &thirdFoo;

				 data.PushBack(firstElement);
				 data.PushBack(secondElement);
				 data.PushBack(thirdElement);
				 data.PushBack(secondElement);
				 data.PushBack(thirdElement);
				 Assert::AreEqual(static_cast<size_t>(5), data.Size());

				 Assert::ExpectException<std::runtime_error>([&data]() { data.Remove(static_cast<size_t>(3)); });

				 data.Remove(secondElement);
				 Assert::IsTrue(data.GetRTTI() == firstElement);
				 Assert::IsTrue(data.GetRTTI(1) == thirdElement);
				 Assert::IsTrue(data.GetRTTI(2) == secondElement);
				 Assert::IsTrue(data.GetRTTI(3) == thirdElement);

				 data.Remove(thirdElement);
				 Assert::IsTrue(data.GetRTTI() == firstElement);
				 Assert::IsTrue(data.GetRTTI(1) == secondElement);
				 Assert::IsTrue(data.GetRTTI(2) == thirdElement);

				 data.Remove(secondElement);
				 Assert::IsTrue(data.GetRTTI() == firstElement);
				 Assert::IsTrue(data.GetRTTI(1) == thirdElement);

				 data.Remove(thirdElement);
				 Assert::IsTrue(data.GetRTTI() == firstElement);

				 data.Remove(firstElement);
				 Assert::ExpectException<std::runtime_error>([&data]() { data.GetRTTI(); });
			 }
		}

		TEST_METHOD(RemoveAt)
		{
			{
				Datum data(Datum::DatumTypes::Integer, 3);
				size_t firstElement = 9;
				size_t secondElement = 8;
				size_t thirdElement = 7;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::AreEqual(static_cast<size_t>(5), data.Size());

				Assert::IsFalse(data.RemoveAt(6));

				data.RemoveAt(1);
				Assert::IsTrue(data.GetInt() == firstElement);
				Assert::IsTrue(data.GetInt(1) == thirdElement);
				Assert::IsTrue(data.GetInt(2) == secondElement);
				Assert::IsTrue(data.GetInt(3) == thirdElement);

				data.RemoveAt(3);
				Assert::IsTrue(data.GetInt() == firstElement);
				Assert::IsTrue(data.GetInt(1) == thirdElement);
				Assert::IsTrue(data.GetInt(2) == secondElement);

				data.RemoveAt(0);
				Assert::IsTrue(data.GetInt() == thirdElement);
				Assert::IsTrue(data.GetInt(1) == secondElement);

				data.RemoveAt(1);
				Assert::IsTrue(data.GetInt() == thirdElement);

				data.RemoveAt(0);
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(); });
			}

			{
				Datum data(Datum::DatumTypes::Float, 3);
				float firstElement = 9.9f;
				float secondElement = 8.8f;
				float thirdElement = 7.7f;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::AreEqual(static_cast<size_t>(5), data.Size());

				Assert::IsFalse(data.RemoveAt(6));

				data.RemoveAt(1);
				Assert::IsTrue(data.GetFloat() == firstElement);
				Assert::IsTrue(data.GetFloat(1) == thirdElement);
				Assert::IsTrue(data.GetFloat(2) == secondElement);
				Assert::IsTrue(data.GetFloat(3) == thirdElement);

				data.RemoveAt(3);
				Assert::IsTrue(data.GetFloat() == firstElement);
				Assert::IsTrue(data.GetFloat(1) == thirdElement);
				Assert::IsTrue(data.GetFloat(2) == secondElement);

				data.RemoveAt(0);
				Assert::IsTrue(data.GetFloat() == thirdElement);
				Assert::IsTrue(data.GetFloat(1) == secondElement);

				data.RemoveAt(1);
				Assert::IsTrue(data.GetFloat() == thirdElement);

				data.RemoveAt(0);
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetFloat(); });
			}

			{
				Datum data(Datum::DatumTypes::String, 3);
				std::string firstElement = "Apple";
				std::string secondElement = "Orange";
				std::string thirdElement = "Pear";

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::AreEqual(static_cast<size_t>(5), data.Size());

				Assert::IsFalse(data.RemoveAt(6));

				data.RemoveAt(1);
				Assert::IsTrue(data.GetString() == firstElement);
				Assert::IsTrue(data.GetString(1) == thirdElement);
				Assert::IsTrue(data.GetString(2) == secondElement);
				Assert::IsTrue(data.GetString(3) == thirdElement);

				data.RemoveAt(3);
				Assert::IsTrue(data.GetString() == firstElement);
				Assert::IsTrue(data.GetString(1) == thirdElement);
				Assert::IsTrue(data.GetString(2) == secondElement);

				data.RemoveAt(0);
				Assert::IsTrue(data.GetString() == thirdElement);
				Assert::IsTrue(data.GetString(1) == secondElement);

				data.RemoveAt(1);
				Assert::IsTrue(data.GetString() == thirdElement);

				data.RemoveAt(0);
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetString(); });
			}

			{
				Datum data(Datum::DatumTypes::Vector, 3);
				glm::vec4 firstElement = {0, 1, 2, 3};
				glm::vec4 secondElement = {2, 3, 4, 5};
				glm::vec4 thirdElement = {8, 10, 12, 14};

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::AreEqual(static_cast<size_t>(5), data.Size());

				Assert::IsFalse(data.RemoveAt(6));

				data.RemoveAt(1);
				Assert::IsTrue(data.GetVector() == firstElement);
				Assert::IsTrue(data.GetVector(1) == thirdElement);
				Assert::IsTrue(data.GetVector(2) == secondElement);
				Assert::IsTrue(data.GetVector(3) == thirdElement);

				data.RemoveAt(3);
				Assert::IsTrue(data.GetVector() == firstElement);
				Assert::IsTrue(data.GetVector(1) == thirdElement);
				Assert::IsTrue(data.GetVector(2) == secondElement);

				data.RemoveAt(0);
				Assert::IsTrue(data.GetVector() == thirdElement);
				Assert::IsTrue(data.GetVector(1) == secondElement);

				data.RemoveAt(1);
				Assert::IsTrue(data.GetVector() == thirdElement);

				data.RemoveAt(0);
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetVector(); });
			}

			{
				Datum data(Datum::DatumTypes::Matrix, 3);
				glm::mat4 firstElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 secondElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 19 };
				glm::mat4 thirdElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 22 };

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::AreEqual(static_cast<size_t>(5), data.Size());

				Assert::IsFalse(data.RemoveAt(6));

				data.RemoveAt(1);
				Assert::IsTrue(data.GetMatrix() == firstElement);
				Assert::IsTrue(data.GetMatrix(1) == thirdElement);
				Assert::IsTrue(data.GetMatrix(2) == secondElement);
				Assert::IsTrue(data.GetMatrix(3) == thirdElement);

				data.RemoveAt(3);
				Assert::IsTrue(data.GetMatrix() == firstElement);
				Assert::IsTrue(data.GetMatrix(1) == thirdElement);
				Assert::IsTrue(data.GetMatrix(2) == secondElement);

				data.RemoveAt(0);
				Assert::IsTrue(data.GetMatrix() == thirdElement);
				Assert::IsTrue(data.GetMatrix(1) == secondElement);

				data.RemoveAt(1);
				Assert::IsTrue(data.GetMatrix() == thirdElement);

				data.RemoveAt(0);
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetMatrix(); });
			}

			{
				Datum data(Datum::DatumTypes::Pointer, 3);
				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);

				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;
				RTTI* thirdElement = &thirdFoo;

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);
				Assert::AreEqual(static_cast<size_t>(5), data.Size());

				Assert::IsFalse(data.RemoveAt(6));

				data.RemoveAt(1);
				Assert::IsTrue(data.GetRTTI() == firstElement);
				Assert::IsTrue(data.GetRTTI(1) == thirdElement);
				Assert::IsTrue(data.GetRTTI(2) == secondElement);
				Assert::IsTrue(data.GetRTTI(3) == thirdElement);

				data.RemoveAt(3);
				Assert::IsTrue(data.GetRTTI() == firstElement);
				Assert::IsTrue(data.GetRTTI(1) == thirdElement);
				Assert::IsTrue(data.GetRTTI(2) == secondElement);

				data.RemoveAt(0);
				Assert::IsTrue(data.GetRTTI() == thirdElement);
				Assert::IsTrue(data.GetRTTI(1) == secondElement);

				data.RemoveAt(1);
				Assert::IsTrue(data.GetRTTI() == thirdElement);

				data.RemoveAt(0);
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetRTTI(); });
			}
		}

		TEST_METHOD(Resize)
		{
			{
				Datum data;
				Datum internalData;
				size_t dataArray[] = { 1, 2, 3, 4, 5 };
				internalData.SetStorage(dataArray, 4);

				Assert::ExpectException<std::runtime_error>([&internalData]() { internalData.Resize(1); }); //Not allowed when storage is external

				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				Assert::ExpectException<std::runtime_error>([&data]() { data.Resize(0); }); //Needs type.
				data.SetType(Datum::DatumTypes::Integer);

				data.Resize(0);
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				data.Resize(2);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(2));
				data.PushBack(dataArray[0]);

				data.Resize(4);
				Assert::AreEqual(data.Size(), static_cast<size_t>(4));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(4));

				data.Resize(1);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(1));
			}

 {
				Datum data;
				Datum internalData;
				float dataArray[] = { 1.1f, 2.2f, 3.3f, 4.4f, 5.5f };
				internalData.SetStorage(dataArray, 4);

				Assert::ExpectException<std::runtime_error>([&internalData]() { internalData.Resize(1); }); //Not allowed when storage is external

				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				Assert::ExpectException<std::runtime_error>([&data]() { data.Resize(0); }); //Needs type.
				data.SetType(Datum::DatumTypes::Float);

				data.Resize(0); //No effect if less than or equal to capacity
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				data.Resize(2);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(2));
				data.PushBack(dataArray[0]);

				data.Resize(4);
				Assert::AreEqual(data.Size(), static_cast<size_t>(4));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(4));

				data.Resize(1);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(1));
			}

			 {
				Datum data;
				Datum internalData;
				std::string dataArray[] = { "Apple", "Orange", "Peach", "Strawberry", "Lemon", "Apricot"};
				std::string apple = "Apple";
				internalData.SetStorage(dataArray, 4);

				Assert::ExpectException<std::runtime_error>([&internalData]() { internalData.Resize(1); }); //Not allowed when storage is external

				Assert::ExpectException<std::runtime_error>([&data]() { data.Resize(0); }); //Needs type.
				data.SetType(Datum::DatumTypes::String);

				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				data.Resize(0); //No effect if less than or equal to capacity
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				data.Resize(2);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(2));
				data.PushBack(apple);

				data.Resize(4);
				Assert::AreEqual(data.Size(), static_cast<size_t>(4));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(4));

				data.Resize(1);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(1));
			}

			{
				Datum data;
				Datum internalData;
				glm::vec4 dataArray[] = { {1, 2, 3, 4}, {3, 2, 4, 1}, {2, 4, 6, 8}, {3, 3, 3, 3 }, {4, 4, 5, 6} };
				internalData.SetStorage(dataArray, 4);

				Assert::ExpectException<std::runtime_error>([&internalData]() { internalData.Resize(1); }); //Not allowed when storage is external

				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				Assert::ExpectException<std::runtime_error>([&data]() { data.Resize(0); }); //Needs type.
				data.SetType(Datum::DatumTypes::Vector);

				data.Resize(0); //No effect if less than or equal to capacity
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				data.Resize(2);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(2));
				data.PushBack(dataArray[0]);

				data.Resize(4);
				Assert::AreEqual(data.Size(), static_cast<size_t>(4));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(4));

				data.Resize(1);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(1));
			}

			{
				Datum data;
				Datum internalData;
				glm::mat4 firstMatrix = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
				glm::mat4 dataArray[] = { firstMatrix,  };
				internalData.SetStorage(dataArray, 4);

				Assert::ExpectException<std::runtime_error>([&internalData]() { internalData.Resize(1); }); //Not allowed when storage is external

				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				Assert::ExpectException<std::runtime_error>([&data]() { data.Resize(0); }); //Needs type.
				data.SetType(Datum::DatumTypes::Matrix);

				data.Resize(0); //No effect if less than or equal to capacity
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				data.Resize(2);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(2));
				data.PushBack(dataArray[0]);

				data.Resize(4);
				Assert::AreEqual(data.Size(), static_cast<size_t>(4));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(4));
			
				data.Resize(1);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(1));
			}

			{
				Datum data;
				Datum internalData;

				Foo firstFoo(1);
				Foo secondFoo(2);
				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;

				RTTI* dataArray[] = { firstElement, secondElement, firstElement, secondElement, firstElement, secondElement};
				internalData.SetStorage(dataArray, 4);

				Assert::ExpectException<std::runtime_error>([&internalData]() { internalData.Resize(1); }); //Not allowed when storage is external

				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				Assert::ExpectException<std::runtime_error>([&data]() { data.Resize(0); }); //Needs type.
				data.SetType(Datum::DatumTypes::Pointer);

				data.Resize(0); //No effect if less than or equal to capacity
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				data.Resize(2);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(2));
				data.PushBack(dataArray[0]);

				data.Resize(4);
				Assert::AreEqual(data.Size(), static_cast<size_t>(4));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(4));

				data.Resize(1);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(1));
			}

		}

		TEST_METHOD(Clear)
		{
			{
				Datum data(static_cast<size_t>(1));
				Datum externalData(Datum::DatumTypes::Integer);
				size_t valueArray[] = {0, 1, 2, 3};
				externalData.SetStorage(valueArray, 4);

				Assert::ExpectException<std::runtime_error>([&externalData]() { externalData.Clear(); }); //External datum cannot clear

				data.Resize(20);
				Assert::AreEqual(data.Size(), static_cast<size_t>(20));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.PushBack(static_cast<size_t>(1));
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
				Assert::AreEqual(data.GetInt(0), static_cast<size_t>(1));

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetInt(0); });

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
			}

			{
				Datum data(1.1f);
				Datum externalData(Datum::DatumTypes::Float);
				float valueArray[] = { 0.5f, 1.1f, 2.2f, 3.3f };
				externalData.SetStorage(valueArray, 4);

				Assert::ExpectException<std::runtime_error>([&externalData]() { externalData.Clear(); }); //External datum cannot clear

				data.Resize(20);
				Assert::AreEqual(data.Size(), static_cast<size_t>(20));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.PushBack(1.1f);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
				Assert::AreEqual(data.GetFloat(0), 1.1f);

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetFloat(0); });

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
			}

			{
				std::string firstElement = "Chai";
				std::string secondElement = "Green";
				std::string thirdElement = "Black";
				std::string fourthElement = "Herbal";

				Datum data(firstElement);
				Datum externalData(Datum::DatumTypes::String);
				std::string valueArray[] = { firstElement, secondElement, thirdElement, fourthElement };
				externalData.SetStorage(valueArray, 4);

				Assert::ExpectException<std::runtime_error>([&externalData]() { externalData.Clear(); }); //External datum cannot clear

				data.Resize(20);
				Assert::AreEqual(data.Size(), static_cast<size_t>(20));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.PushBack(thirdElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
				Assert::AreEqual(data.GetString(0), thirdElement);

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetString(0); });

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
			}

			{
				glm::vec4 firstElement = {0, 1, 2, 3};
				glm::vec4 secondElement = {2, 4, 6, 8};
				glm::vec4 thirdElement = {1, 3, 5, 8};
				glm::vec4 fourthElement = {1, 2, 2, 1};

				Datum data(firstElement);
				Datum externalData(Datum::DatumTypes::Vector);
				glm::vec4 valueArray[] = { firstElement, secondElement, thirdElement, fourthElement };
				externalData.SetStorage(valueArray, 4);

				Assert::ExpectException<std::runtime_error>([&externalData]() { externalData.Clear(); }); //External datum cannot clear

				data.Resize(20);
				Assert::AreEqual(data.Size(), static_cast<size_t>(20));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.PushBack(thirdElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
				Assert::IsTrue(data.GetVector(0) == thirdElement);

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetVector(0); });

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
			}

			{
				glm::mat4 firstElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 secondElement = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32 };
				glm::mat4 thirdElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 53, 34, 24 };
				glm::mat4 fourthElement = { 20, 21, 32, 43, 4, 5, 6, 7, 8, 9, 10, 11, 12, 53, 34, 24 };

				Datum data(firstElement);
				Datum externalData(Datum::DatumTypes::Matrix);
				glm::mat4 valueArray[] = { firstElement, secondElement, thirdElement, fourthElement };
				externalData.SetStorage(valueArray, 4);

				Assert::ExpectException<std::runtime_error>([&externalData]() { externalData.Clear(); }); //External datum cannot clear

				data.Resize(20);
				Assert::AreEqual(data.Size(), static_cast<size_t>(20));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.PushBack(thirdElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
				Assert::IsTrue(data.GetMatrix(0) == thirdElement);

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetMatrix(0); });

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
			}

			{
				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);
				Foo fourthFoo(4);

				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;
				RTTI* thirdElement = &thirdFoo;
				RTTI* fourthElement = &fourthFoo;

				Datum data(firstElement);
				Datum externalData(Datum::DatumTypes::Pointer);
				RTTI* valueArray[] = { firstElement, secondElement, thirdElement, fourthElement };
				externalData.SetStorage(valueArray, 4);

				Assert::ExpectException<std::runtime_error>([&externalData]() { externalData.Clear(); }); //External datum cannot clear

				data.Resize(20);
				Assert::AreEqual(data.Size(), static_cast<size_t>(20));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.PushBack(thirdElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(1));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
				Assert::IsTrue(data.GetRTTI(0) == thirdElement);

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
				Assert::ExpectException<std::runtime_error>([&data]() { data.GetRTTI(0); });

				data.Clear();
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
			}
		};

		TEST_METHOD(Reserve)
		{
			{
				size_t firstElement = 0;
				size_t secondElement = 1;
				size_t thirdElement = 2;
				size_t fourthElement = 3;

				Datum data;
				Datum externalData(Datum::DatumTypes::Integer);

				size_t valueArray[] = { firstElement, secondElement, thirdElement, fourthElement };
				externalData.SetStorage(valueArray, 4);

				Assert::ExpectException<std::runtime_error>([&externalData]() { externalData.Reserve(9); }); //External datum cannot reserve greater than current storage

				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				Assert::ExpectException<std::runtime_error>([&data]() { data.Reserve(2); }); //Cannot reserve with no designated type
				data.SetType(Datum::DatumTypes::Integer);

				data.Reserve(20);
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.Reserve(19);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
			}

			{
				float firstElement = 0.1f;
				float secondElement = 1.2f;
				float thirdElement = 2.3f;
				float fourthElement = 3.5f;

				Datum data;
				Datum externalData(Datum::DatumTypes::Float);

				float valueArray[] = { firstElement, secondElement, thirdElement, fourthElement };
				externalData.SetStorage(valueArray, 4);

				Assert::ExpectException<std::runtime_error>([&externalData]() { externalData.Reserve(9); }); //External datum cannot reserve

				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				Assert::ExpectException<std::runtime_error>([&data]() { data.Reserve(2); }); //Cannot reserve with no designated type
				data.SetType(Datum::DatumTypes::Float);

				data.Reserve(20);
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.Reserve(19);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
			}

			{
				std::string firstElement = "Chai";
				std::string secondElement = "Black";
				std::string thirdElement = "Green";
				std::string fourthElement = "White";

				Datum data;
				Datum externalData(Datum::DatumTypes::String);

				std::string valueArray[] = { firstElement, secondElement, thirdElement, fourthElement };
				externalData.SetStorage(valueArray, 4);

				Assert::ExpectException<std::runtime_error>([&externalData]() { externalData.Reserve(9); }); //External datum cannot reserve

				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				Assert::ExpectException<std::runtime_error>([&data]() { data.Reserve(2); }); //Cannot reserve with no designated type
				data.SetType(Datum::DatumTypes::String);

				data.Reserve(20);
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.Reserve(19);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
			}

			{
				glm::vec4 firstElement = {0, 1, 2, 3};
				glm::vec4 secondElement = {2, 4, 6, 8};
				glm::vec4 thirdElement = {3, 6, 9, 12};
				glm::vec4 fourthElement = {4, 3, 2, 1};

				Datum data;
				Datum externalData(Datum::DatumTypes::Vector);

				glm::vec4 valueArray[] = { firstElement, secondElement, thirdElement, fourthElement };
				externalData.SetStorage(valueArray, 4);

				Assert::ExpectException<std::runtime_error>([&externalData]() { externalData.Reserve(9); }); //External datum cannot reserve

				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				Assert::ExpectException<std::runtime_error>([&data]() { data.Reserve(2); }); //Cannot reserve with no designated type
				data.SetType(Datum::DatumTypes::Vector);

				data.Reserve(20);
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.Reserve(19);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
			}

			{
				glm::mat4 firstElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				glm::mat4 secondElement = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32};
				glm::mat4 thirdElement = { 3, 6, 9, 12, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32 };
				glm::mat4 fourthElement = { 4, 3, 2, 1, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32 };

				Datum data;
				Datum externalData(Datum::DatumTypes::Matrix);

				glm::mat4 valueArray[] = { firstElement, secondElement, thirdElement, fourthElement };
				externalData.SetStorage(valueArray, 4);

				Assert::ExpectException<std::runtime_error>([&externalData]() { externalData.Reserve(9); }); //External datum cannot reserve

				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				Assert::ExpectException<std::runtime_error>([&data]() { data.Reserve(2); }); //Cannot reserve with no designated type
				data.SetType(Datum::DatumTypes::Matrix);

				data.Reserve(20);
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.Reserve(19);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
			}

			{
				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);
				Foo fourthFoo(4);

				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;
				RTTI* thirdElement = &thirdFoo;
				RTTI* fourthElement = &fourthFoo;

				Datum data;
				Datum externalData(Datum::DatumTypes::Pointer);

				RTTI* valueArray[] = { firstElement, secondElement, thirdElement, fourthElement };
				externalData.SetStorage(valueArray, 4);

				Assert::ExpectException<std::runtime_error>([&externalData]() { externalData.Reserve(9); }); //External datum cannot reserve

				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(0));

				Assert::ExpectException<std::runtime_error>([&data]() { data.Reserve(2); }); //Cannot reserve with no designated type
				data.SetType(Datum::DatumTypes::Pointer);

				data.Reserve(20);
				Assert::AreEqual(data.Size(), static_cast<size_t>(0));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.PushBack(firstElement);
				data.PushBack(secondElement);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));

				data.Reserve(19);
				Assert::AreEqual(data.Size(), static_cast<size_t>(2));
				Assert::AreEqual(data.Capacity(), static_cast<size_t>(20));
			}
		}

		TEST_METHOD(Find)
		{
			{
				Foo wrongElement(1);
				RTTI* wrongElementPtr = &wrongElement;
				std::string wrongString = "Apple";
				glm::mat4 wrongMatrix = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };

				size_t firstElement(1);
				size_t secondElement(2);
				size_t thirdElement(3);

				Datum data(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(data.Find(firstElement), static_cast<size_t>(0));
				Assert::AreEqual(data.Find(secondElement), static_cast<size_t>(1));
				Assert::AreEqual(data.Find(thirdElement), static_cast<size_t>(2));
				Assert::AreEqual(data.Find(static_cast<size_t>(10)), static_cast<size_t>(3)); //If not found, it will return an end of datum index

				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(2.1f); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongString]() { data.Find(wrongString); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(glm::vec4{0, 1, 2, 3}); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongMatrix]() { data.Find(wrongMatrix); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongElementPtr]() { data.Find(wrongElementPtr); }); //Cannot search for type that doesn't match datum
			}

			{
				Foo wrongElement(1);
				RTTI* wrongElementPtr = &wrongElement;
				std::string wrongString = "Apple";
				glm::mat4 wrongMatrix = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };

				float firstElement = 1.1f;
				float secondElement = 2.2f;
				float thirdElement = 3.3f;

				Datum data(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(data.Find(firstElement), static_cast<size_t>(0));
				Assert::AreEqual(data.Find(secondElement), static_cast<size_t>(1));
				Assert::AreEqual(data.Find(thirdElement), static_cast<size_t>(2));
				Assert::AreEqual(data.Find(10.3f), static_cast<size_t>(3)); //If not found, it will return an end of datum index

				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(static_cast<size_t>(1)); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongString]() { data.Find(wrongString); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(glm::vec4{ 0, 1, 2, 3 }); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongMatrix]() { data.Find(wrongMatrix); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongElementPtr]() { data.Find(wrongElementPtr); }); //Cannot search for type that doesn't match datum
			}

			{
				Foo wrongElement(1);
				RTTI* wrongElementPtr = &wrongElement;
				std::string wrongString = "Apple";
				glm::mat4 wrongMatrix = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };

				std::string firstElement = "Chai";
				std::string secondElement = "Green";
				std::string thirdElement = "Black";

				Datum data(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(data.Find(firstElement), static_cast<size_t>(0));
				Assert::AreEqual(data.Find(secondElement), static_cast<size_t>(1));
				Assert::AreEqual(data.Find(thirdElement), static_cast<size_t>(2));
				Assert::AreEqual(data.Find(wrongString), static_cast<size_t>(3)); //If not found, it will return an end of datum index

				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(static_cast<size_t>(1)); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(1.1f); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(glm::vec4{ 0, 1, 2, 3 }); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongMatrix]() { data.Find(wrongMatrix); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongElementPtr]() { data.Find(wrongElementPtr); }); //Cannot search for type that doesn't match datum
			}

			{
				Foo wrongElement(1);
				RTTI* wrongElementPtr = &wrongElement;
				std::string wrongString = "Apple";
				glm::mat4 wrongMatrix = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };

				glm::vec4 firstElement = {0, 1, 2, 3};
				glm::vec4 secondElement = {2, 4, 6, 8};
				glm::vec4 thirdElement = {3, 6, 9, 12};

				Datum data(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(data.Find(firstElement), static_cast<size_t>(0));
				Assert::AreEqual(data.Find(secondElement), static_cast<size_t>(1));
				Assert::AreEqual(data.Find(thirdElement), static_cast<size_t>(2));
				Assert::AreEqual(data.Find(glm::vec4{0, 0, 0, 0}), static_cast<size_t>(3)); //If not found, it will return an end of datum index

				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(static_cast<size_t>(1)); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(1.1f); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongString]() { data.Find(wrongString); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongMatrix]() { data.Find(wrongMatrix); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongElementPtr]() { data.Find(wrongElementPtr); }); //Cannot search for type that doesn't match datum
			}

			{
				Foo wrongElement(1);
				RTTI* wrongElementPtr = &wrongElement;
				std::string wrongString = "Apple";
				glm::mat4 wrongMatrix = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 20 };

				glm::mat4 firstElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
				glm::mat4 secondElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
				glm::mat4 thirdElement = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 21 };

				Datum data(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(data.Find(firstElement), static_cast<size_t>(0));
				Assert::AreEqual(data.Find(secondElement), static_cast<size_t>(1));
				Assert::AreEqual(data.Find(thirdElement), static_cast<size_t>(2));
				Assert::AreEqual(data.Find(wrongMatrix), static_cast<size_t>(3)); //If not found, it will return an end of datum index

				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(static_cast<size_t>(1)); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(1.1f); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongString]() { data.Find(wrongString); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(glm::vec4{0, 1, 2, 3}); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongElementPtr]() { data.Find(wrongElementPtr); }); //Cannot search for type that doesn't match datum
			}

			{
				Foo wrongElement(1);
				RTTI* wrongElementPtr = &wrongElement;
				std::string wrongString = "Apple";
				glm::mat4 wrongMatrix = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 20 };

				Foo firstFoo(2);
				Foo secondFoo(3);
				Foo thirdFoo(4);

				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;
				RTTI* thirdElement = &thirdFoo;

				Datum data(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(data.Find(firstElement), static_cast<size_t>(0));
				Assert::AreEqual(data.Find(secondElement), static_cast<size_t>(1));
				Assert::AreEqual(data.Find(thirdElement), static_cast<size_t>(2));
				Assert::AreEqual(data.Find(wrongElementPtr), static_cast<size_t>(3)); //If not found, it will return an end of datum index

				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(static_cast<size_t>(1)); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(1.1f); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongString]() { data.Find(wrongString); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data]() { data.Find(glm::vec4{ 0, 1, 2, 3 }); }); //Cannot search for type that doesn't match datum
				Assert::ExpectException<std::runtime_error>([&data, &wrongMatrix]() { data.Find(wrongMatrix); }); //Cannot search for type that doesn't match datum
			}
		}

		TEST_METHOD(ToString)
		{
			{
				Datum data;
				size_t firstElement = 1;
				size_t secondElement = 2;
				size_t thirdElement = 3;

				std::string firstString = "1";
				std::string secondString = "2";
				std::string thirdString = "3";
				std::string emptyString = "";

				Assert::ExpectException<std::runtime_error>([&data]() { data.ToString(); }); //Cannot get string from datum with no type.
				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(firstString, data.ToString());
				Assert::AreNotEqual(secondString, data.ToString());
				Assert::AreNotEqual(thirdString, data.ToString());

				Assert::AreNotEqual(firstString, data.ToString(1));
				Assert::AreEqual(secondString, data.ToString(1));
				Assert::AreNotEqual(thirdString, data.ToString(1));

				Assert::AreNotEqual(firstString, data.ToString(2));
				Assert::AreNotEqual(secondString, data.ToString(2));
				Assert::AreEqual(thirdString, data.ToString(2));

				Assert::AreEqual(emptyString, data.ToString(3));
			}

			{
				Datum data;
				float firstElement = 1.0f;
				float secondElement = 2.0f;
				float thirdElement = 3.0f;

				std::string firstString = "1.000000";
				std::string secondString = "2.000000";
				std::string thirdString = "3.000000";
				std::string emptyString = "";

				Assert::ExpectException<std::runtime_error>([&data]() { data.ToString(); }); //Cannot get string from datum with no type.
				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(firstString, data.ToString());
				Assert::AreNotEqual(secondString, data.ToString());
				Assert::AreNotEqual(thirdString, data.ToString());

				Assert::AreNotEqual(firstString, data.ToString(1));
				Assert::AreEqual(secondString, data.ToString(1));
				Assert::AreNotEqual(thirdString, data.ToString(1));

				Assert::AreNotEqual(firstString, data.ToString(2));
				Assert::AreNotEqual(secondString, data.ToString(2));
				Assert::AreEqual(thirdString, data.ToString(2));

				Assert::AreEqual(emptyString, data.ToString(3));
			}

			{
				Datum data;
				std::string firstElement = "Apple";
				std::string secondElement = "Pear";
				std::string thirdElement = "Orange";

				std::string firstString = "Apple";
				std::string secondString = "Pear";
				std::string thirdString = "Orange";
				std::string emptyString = "";

				Assert::ExpectException<std::runtime_error>([&data]() { data.ToString(); }); //Cannot get string from datum with no type.
				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(firstString, data.ToString());
				Assert::AreNotEqual(secondString, data.ToString());
				Assert::AreNotEqual(thirdString, data.ToString());

				Assert::AreNotEqual(firstString, data.ToString(1));
				Assert::AreEqual(secondString, data.ToString(1));
				Assert::AreNotEqual(thirdString, data.ToString(1));

				Assert::AreNotEqual(firstString, data.ToString(2));
				Assert::AreNotEqual(secondString, data.ToString(2));
				Assert::AreEqual(thirdString, data.ToString(2));

				Assert::AreEqual(emptyString, data.ToString(3));
			}

			{
				Datum data;
				glm::vec4 firstElement = {0, 0, 0, 0};
				glm::vec4 secondElement = { 1, 1, 1, 1 };
				glm::vec4 thirdElement = {2, 2, 2, 2};

				std::string firstString = "vec4(0.000000, 0.000000, 0.000000, 0.000000)";
				std::string secondString = "vec4(1.000000, 1.000000, 1.000000, 1.000000)";
				std::string thirdString = "vec4(2.000000, 2.000000, 2.000000, 2.000000)";
				std::string emptyString = "";

				Assert::ExpectException<std::runtime_error>([&data]() { data.ToString(); }); //Cannot get string from datum with no type.
				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(firstString, data.ToString());
				Assert::AreNotEqual(secondString, data.ToString());
				Assert::AreNotEqual(thirdString, data.ToString());

				Assert::AreNotEqual(firstString, data.ToString(1));
				Assert::AreEqual(secondString, data.ToString(1));
				Assert::AreNotEqual(thirdString, data.ToString(1));

				Assert::AreNotEqual(firstString, data.ToString(2));
				Assert::AreNotEqual(secondString, data.ToString(2));
				Assert::AreEqual(thirdString, data.ToString(2));

				Assert::AreEqual(emptyString, data.ToString(3));
			}

			{
				Datum data;
				glm::mat4 firstElement = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
				glm::mat4 secondElement = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
				glm::mat4 thirdElement = { 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2};

				std::string firstString = "mat4x4((0.000000, 0.000000, 0.000000, 0.000000), (0.000000, 0.000000, 0.000000, 0.000000), (0.000000, 0.000000, 0.000000, 0.000000), (0.000000, 0.000000, 0.000000, 0.000000))";
				std::string secondString = "mat4x4((1.000000, 1.000000, 1.000000, 1.000000), (1.000000, 1.000000, 1.000000, 1.000000), (1.000000, 1.000000, 1.000000, 1.000000), (1.000000, 1.000000, 1.000000, 1.000000))";
				std::string thirdString = "mat4x4((2.000000, 2.000000, 2.000000, 2.000000), (2.000000, 2.000000, 2.000000, 2.000000), (2.000000, 2.000000, 2.000000, 2.000000), (2.000000, 2.000000, 2.000000, 2.000000))";
				std::string emptyString = "";

				Assert::ExpectException<std::runtime_error>([&data]() { data.ToString(); }); //Cannot get string from datum with no type.
				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(firstString, data.ToString());
				Assert::AreNotEqual(secondString, data.ToString());
				Assert::AreNotEqual(thirdString, data.ToString());

				Assert::AreNotEqual(firstString, data.ToString(1));
				Assert::AreEqual(secondString, data.ToString(1));
				Assert::AreNotEqual(thirdString, data.ToString(1));

				Assert::AreNotEqual(firstString, data.ToString(2));
				Assert::AreNotEqual(secondString, data.ToString(2));
				Assert::AreEqual(thirdString, data.ToString(2));

				Assert::AreEqual(emptyString, data.ToString(3));
			}

			{
				Datum data;
				Foo firstFoo(1);
				Foo secondFoo(2);
				Foo thirdFoo(3);

				RTTI* firstElement = &firstFoo;
				RTTI* secondElement = &secondFoo;
				RTTI* thirdElement = &thirdFoo;

				std::string firstString = "Foo(1)";
				std::string secondString = "Foo(2)";
				std::string thirdString = "Foo(3)";
				std::string emptyString = "";

				Assert::ExpectException<std::runtime_error>([&data]() { data.ToString(); }); //Cannot get string from datum with no type.
				data.PushBack(firstElement);
				data.PushBack(secondElement);
				data.PushBack(thirdElement);

				Assert::AreEqual(firstString, data.ToString());
				Assert::AreNotEqual(secondString, data.ToString());
				Assert::AreNotEqual(thirdString, data.ToString());

				Assert::AreNotEqual(firstString, data.ToString(1));
				Assert::AreEqual(secondString, data.ToString(1));
				Assert::AreNotEqual(thirdString, data.ToString(1));

				Assert::AreNotEqual(firstString, data.ToString(2));
				Assert::AreNotEqual(secondString, data.ToString(2));
				Assert::AreEqual(thirdString, data.ToString(2));

				Assert::AreEqual(emptyString, data.ToString(3));
			}
		}

		TEST_METHOD(SetFromString)
		{
			{
				Datum data;
				size_t firstElement = 1;
				size_t secondElement = 2;
				size_t thirdElement = 3;

				const char* firstString = "1";
				const char* secondString = "2";
				const char* thirdString = "3";
				const char* emptyString = "";

				Assert::ExpectException<std::runtime_error>([&data, &firstString]() { data.SetFromString(firstString); }); //Cannot get string from datum with no type.
				data.SetType(Datum::DatumTypes::Integer);

				data.PushBack(secondElement);
				Assert::IsTrue(data.SetFromString(firstString));

				Assert::AreEqual(firstElement, data.GetInt(0));
				Assert::AreNotEqual(secondElement, data.GetInt(0));
				Assert::AreNotEqual(thirdElement, data.GetInt(0));

				Assert::IsTrue(data.SetFromString(secondString));
				Assert::AreNotEqual(firstElement, data.GetInt(0));
				Assert::AreEqual(secondElement, data.GetInt(0));
				Assert::AreNotEqual(thirdElement, data.GetInt(0));

				Assert::IsTrue(data.SetFromString(thirdString));
				Assert::AreNotEqual(firstElement, data.GetInt(0));
				Assert::AreNotEqual(secondElement, data.GetInt(0));
				Assert::AreEqual(thirdElement, data.GetInt(0));

				Assert::IsFalse(data.SetFromString(emptyString));
			}

 {
				Datum data;
				float firstElement = 1.0f;
				float secondElement = 2.0f;
				float thirdElement = 3.0f;

				char* firstString = "1.000000";
				char* secondString = "2.000000";
				char* thirdString = "3.000000";
				char* emptyString = "";

				Assert::ExpectException<std::runtime_error>([&data, &firstString]() { data.SetFromString(firstString); }); //Cannot get string from datum with no type.
				data.SetType(Datum::DatumTypes::Float);

				data.PushBack(secondElement);
				Assert::IsTrue(data.SetFromString(firstString));

				Assert::AreEqual(firstElement, data.GetFloat(0));
				Assert::AreNotEqual(secondElement, data.GetFloat(0));
				Assert::AreNotEqual(thirdElement, data.GetFloat(0));

				Assert::IsTrue(data.SetFromString(secondString));
				Assert::AreNotEqual(firstElement, data.GetFloat(0));
				Assert::AreEqual(secondElement, data.GetFloat(0));
				Assert::AreNotEqual(thirdElement, data.GetFloat(0));

				Assert::IsTrue(data.SetFromString(thirdString));
				Assert::AreNotEqual(firstElement, data.GetFloat(0));
				Assert::AreNotEqual(secondElement, data.GetFloat(0));
				Assert::AreEqual(thirdElement, data.GetFloat(0));

				Assert::IsFalse(data.SetFromString(emptyString));
			}

			{
				Datum data;
				std::string firstElement = "Apple";
				std::string secondElement = "Pear";
				std::string thirdElement = "Orange";

				char* firstString = "Apple";
				char* secondString = "Pear";
				char* thirdString = "Orange";

				Assert::ExpectException<std::runtime_error>([&data, &firstString]() { data.SetFromString(firstString); }); //Cannot get string from datum with no type.
				data.SetType(Datum::DatumTypes::String);

				data.PushBack(secondElement);
				Assert::IsTrue(data.SetFromString(firstString));

				Assert::AreEqual(firstElement, data.GetString(0));
				Assert::AreNotEqual(secondElement, data.GetString(0));
				Assert::AreNotEqual(thirdElement, data.GetString(0));

				Assert::IsTrue(data.SetFromString(secondString));
				Assert::AreNotEqual(firstElement, data.GetString(0));
				Assert::AreEqual(secondElement, data.GetString(0));
				Assert::AreNotEqual(thirdElement, data.GetString(0));

				Assert::IsTrue(data.SetFromString(thirdString));
				Assert::AreNotEqual(firstElement, data.GetString(0));
				Assert::AreNotEqual(secondElement, data.GetString(0));
				Assert::AreEqual(thirdElement, data.GetString(0));
			}

			{
				Datum data;
				glm::vec4 firstElement = { 0, 0, 0, 0 };
				glm::vec4 secondElement = { 1, 1, 1, 1 };
				glm::vec4 thirdElement = { 2, 2, 2, 2 };

				char* firstString = "vec4(0.000000, 0.000000, 0.000000, 0.000000)";
				char* secondString = "vec4(1.000000, 1.000000, 1.000000, 1.000000)";
				char* thirdString = "vec4(2.000000, 2.000000, 2.000000, 2.000000)";
				char* emptyString = "";

				Assert::ExpectException<std::runtime_error>([&data, &firstString]() { data.SetFromString(firstString); }); //Cannot get string from datum with no type.
				data.SetType(Datum::DatumTypes::Vector);

				data.PushBack(secondElement);
				Assert::IsTrue(data.SetFromString(firstString));

				Assert::IsTrue(firstElement == data.GetVector(0));
				Assert::IsFalse(secondElement == data.GetVector(0));
				Assert::IsFalse(thirdElement == data.GetVector(0));

				Assert::IsTrue(data.SetFromString(secondString));
				Assert::IsFalse(firstElement == data.GetVector(0));
				Assert::IsTrue(secondElement == data.GetVector(0));
				Assert::IsFalse(thirdElement == data.GetVector(0));

				Assert::IsTrue(data.SetFromString(thirdString));
				Assert::IsFalse(firstElement == data.GetVector(0));
				Assert::IsFalse(secondElement == data.GetVector(0));
				Assert::IsTrue(thirdElement == data.GetVector(0));

				Assert::IsFalse(data.SetFromString(emptyString));
			}

			{
				Datum data;
				glm::mat4 firstElement = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
				glm::mat4 secondElement = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
				glm::mat4 thirdElement = { 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2 };

				char* firstString = "mat4x4((0.000000, 0.000000, 0.000000, 0.000000), (0.000000, 0.000000, 0.000000, 0.000000), (0.000000, 0.000000, 0.000000, 0.000000), (0.000000, 0.000000, 0.000000, 0.000000))";
				char* secondString = "mat4x4((1.000000, 1.000000, 1.000000, 1.000000), (1.000000, 1.000000, 1.000000, 1.000000), (1.000000, 1.000000, 1.000000, 1.000000), (1.000000, 1.000000, 1.000000, 1.000000))";
				char* thirdString = "mat4x4((2.000000, 2.000000, 2.000000, 2.000000), (2.000000, 2.000000, 2.000000, 2.000000), (2.000000, 2.000000, 2.000000, 2.000000), (2.000000, 2.000000, 2.000000, 2.000000))";
				char* emptyString = "";

				Assert::ExpectException<std::runtime_error>([&data, &firstString]() { data.SetFromString(firstString); }); //Cannot get string from datum with no type.
				data.SetType(Datum::DatumTypes::Matrix);

				data.PushBack(secondElement);
				Assert::IsTrue(data.SetFromString(firstString));

				Assert::IsTrue(firstElement == data.GetMatrix(0));
				Assert::IsFalse(secondElement == data.GetMatrix(0));
				Assert::IsFalse(thirdElement == data.GetMatrix(0));

				Assert::IsTrue(data.SetFromString(secondString));
				Assert::IsFalse(firstElement == data.GetMatrix(0));
				Assert::IsTrue(secondElement == data.GetMatrix(0));
				Assert::IsFalse(thirdElement == data.GetMatrix(0));

				Assert::IsTrue(data.SetFromString(thirdString));
				Assert::IsFalse(firstElement == data.GetMatrix(0));
				Assert::IsFalse(secondElement == data.GetMatrix(0));
				Assert::IsTrue(thirdElement == data.GetMatrix(0));

				Assert::IsFalse(data.SetFromString(emptyString));
			}
		}

private: //Creates memory state screenshots to ensure no memory leaks in any test
	inline static _CrtMemState _startMemState;
};
}