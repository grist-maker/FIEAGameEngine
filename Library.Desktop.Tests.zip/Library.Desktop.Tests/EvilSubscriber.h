#pragma once
#include "EventSubscriber.h"
#include "Event.h"
#include "GameState.h"

namespace UnitTests
{
	class EvilSubscriber : public FieaGameEngine::EventSubscriber
	{
	public:
		virtual void Notify(const FieaGameEngine::EventPublisher* eventPublisher) override;
		float MyFloat = 0.0f;
	};
}

