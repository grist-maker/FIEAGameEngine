#include "pch.h"
#include "CounterSubscriber.h"

using namespace FieaGameEngine;
namespace UnitTests
{
	CounterSubscriber::CounterSubscriber()
	{
		Event<size_t>::Subscribe(this);
		Event<float>::Subscribe(this);
	}

	CounterSubscriber::~CounterSubscriber()
	{
		Event<float>::Unsubscribe(this);
		Event<size_t>::Unsubscribe(this);
	}

	void CounterSubscriber::Notify(const EventPublisher* eventPublisher)
	{
		if (eventPublisher->Is(Event<size_t>::TypeIdClass()))
		{
			SizeCalls += static_cast<const Event<size_t>*>(eventPublisher)->Message();
			TotalCalls += 1;

			std::shared_ptr<EventPublisher> newEventPublisher(new Event<size_t>(1));
			GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime());

			std::shared_ptr<EventPublisher> anotherEventPublisher(new Event<float>(1.1f));

			GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime());
			GameState::Queue.Enqueue(anotherEventPublisher, GameState::CurrentTime.CurrentTime());
		}
		if (eventPublisher->Is(Event<float>::TypeIdClass()))
		{
			TotalCalls += 1;
			FloatCalls += static_cast<size_t>(floor(static_cast<const Event<float>*>(eventPublisher)->Message()));
		}
	}
}