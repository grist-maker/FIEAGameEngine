#include "pch.h"
#include "CppUnitTest.h"
#include "GameState.h"
#include "Foo.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace UnitTests;
using namespace std;
using namespace std::string_literals;
using namespace chrono;

namespace UnitTests
{
	TEST_CLASS(GameTimeTests)
	{
		TEST_METHOD_INITIALIZE(Initialize) //Initial setup of memory state variables to allow memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&_startMemState);
			#endif
		}

		TEST_METHOD_CLEANUP(Cleanup) //Setup for memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);

			if (_CrtMemDifference(&diffMemState, &_startMemState,
				&endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
			#endif
		}

		TEST_METHOD(Constructor)
		{
			const GameTime gameTime;
			
			Assert::IsTrue(0ms == gameTime.TotalGameTime());
			Assert::IsTrue(0ms == gameTime.ElapsedGameTime());
			Assert::IsTrue(0.0f == gameTime.TotalGameTimeSeconds().count());
			Assert::IsTrue(0.0f == gameTime.ElapsedGameTimeSeconds().count());
		}

		TEST_METHOD(GetSetCurrentTime)
		{
			GameTime gameTime;
			Assert::IsTrue(high_resolution_clock::time_point() == gameTime.CurrentTime());

			auto now = high_resolution_clock::now();
			gameTime.SetCurrentTime(now);
			Assert::IsTrue(now == gameTime.CurrentTime());
		}

		TEST_METHOD(GetSetTotalGameTime)
		{
			GameTime gameTime;
			Assert::IsTrue(0ms == gameTime.TotalGameTime());
			Assert::IsTrue(0.0f == gameTime.TotalGameTimeSeconds().count());

			gameTime.SetTotalGameTime(1s);
			Assert::IsTrue(1000ms == gameTime.TotalGameTime());
			Assert::IsTrue(1.0f == gameTime.TotalGameTimeSeconds().count());
		}

		TEST_METHOD(GetSetTotalElapsedTime)
		{
			GameTime gameTime;
			Assert::IsTrue(0ms == gameTime.ElapsedGameTime());
			Assert::IsTrue(0.0f == gameTime.ElapsedGameTimeSeconds().count());

			gameTime.SetElapsedGameTime(1s);
			Assert::IsTrue(1000ms == gameTime.ElapsedGameTime());
			Assert::IsTrue(1.0f == gameTime.ElapsedGameTimeSeconds().count());
		}

		TEST_METHOD(GameClockConstructor)
		{
			GameClock clock;
			Assert::IsTrue(clock.CurrentTime() == clock.StartTime());
			Assert::IsTrue(clock.CurrentTime() == clock.LastTime());
		}

		TEST_METHOD(UpdateGameTime)
		{
			GameClock clock;
			GameTime gameTime;

			const auto lastTime = clock.LastTime();
			clock.UpdateGameTime(gameTime);
			Assert::IsTrue(clock.CurrentTime() == gameTime.CurrentTime());
			Assert::IsTrue(duration_cast<milliseconds>(clock.CurrentTime() - clock.StartTime()) == gameTime.TotalGameTime());
			Assert::IsTrue(duration_cast<milliseconds>(clock.CurrentTime() - lastTime) == gameTime.ElapsedGameTime());
			Assert::IsTrue(clock.LastTime() == gameTime.CurrentTime());
		}
	private: //Creates memory state screenshots to ensure no memory leaks in any test
		inline static _CrtMemState _startMemState;
	};
}