#pragma once
#include <cstdint>
#include "IJsonParseHelper.h"

namespace UnitTests
{
	class JsonTestParseHelper final : public FieaGameEngine::IJsonParseHelper
	{
	RTTI_DECLARATIONS(JsonTestParseHelper, FieaGameEngine::IJsonParseHelper);
	public:
		class Wrapper : public FieaGameEngine::JsonParseCoordinator::Wrapper
		{
			RTTI_DECLARATIONS(Wrapper, FieaGameEngine::JsonParseCoordinator::Wrapper);
		public:
			std::shared_ptr<FieaGameEngine::JsonParseCoordinator::Wrapper> Create() const override;
			virtual ~Wrapper() override;
			size_t TotalDepth = 0;
			FieaGameEngine::Vector<size_t> Data;
		};

		std::shared_ptr<IJsonParseHelper> Create() const override;
		void Initialize() override;
		bool StartHandler(FieaGameEngine::JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>&  value, bool& isArray) override;
		void EndHandler(FieaGameEngine::JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray) override;
		void Cleanup() override;

		bool InitializeCalled = false;
		bool CleanupCalled = false;
		size_t StartHandlerCount = 0;
		size_t EndHandlerCount = 0;

	private:
		inline static const std::string IntegerKey{ "Integer" };
		bool ParsingData = false;
	};
}