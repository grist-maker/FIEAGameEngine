#include "pch.h"
#include "CppUnitTest.h"
#include "EvilSubscriber.h"
#include "MultiEventSubscriber.h"
#include "EventArgs.h"
#include "CounterSubscriber.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;
using namespace std::string_literals;
using namespace chrono;

namespace UnitTests
{
	TEST_CLASS(EventTests)
	{
		TEST_METHOD_INITIALIZE(Initialize) //Initial setup of memory state variables to allow memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&_startMemState);
			#endif
		}

		TEST_METHOD_CLEANUP(Cleanup) //Setup for memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);

			if (_CrtMemDifference(&diffMemState, &_startMemState,
				&endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
			#endif
		}

		TEST_METHOD(Constructor)
		{
			const float newFloat = 2.4f;
			std::shared_ptr<EventPublisher> newEventPublisher(new Event<float>(newFloat));

			Assert::IsTrue(GameState::Queue.IsEmpty());
			GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime());
			Assert::IsTrue(GameState::Queue.IsEmpty());

			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsFalse(GameState::Queue.IsEmpty());

			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsTrue(GameState::Queue.IsEmpty());

			GameState::Queue.TestClear();
		}

		TEST_METHOD(EdgeCaseTest)
		{
			{ 
				//This notify method uses EvilSubscriber, who naughtily tries to call update on the EventQueue recursively. This does not work as an atomic bool guards the update
				//function from reentry to prevent recursion. The EvilSubscriber also enqueues a new Event<float> with the value 8.5f.
				std::shared_ptr<EvilSubscriber> evil(new EvilSubscriber);

				std::shared_ptr<EventPublisher> newEventPublisher(new Event<float>(9.9f));
				Event<float>::Subscribe(evil.get());

				Assert::IsTrue(GameState::Queue.IsEmpty());
				GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime()); //An event, once enqueued, will not allow a new enqueue to take place for the same event.
				Assert::IsTrue(GameState::Queue.IsEmpty());
				Assert::IsTrue(GameState::Queue.Size() == 0);

				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsFalse(GameState::Queue.IsEmpty());
				Assert::IsTrue(GameState::Queue.Size() == 1);

				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsFalse(GameState::Queue.IsEmpty());
				Assert::IsTrue(GameState::Queue.Size() == 1);
				Assert::IsTrue(evil->MyFloat == 9.9f);

				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsFalse(GameState::Queue.IsEmpty());
				Assert::IsTrue(GameState::Queue.Size() == 1);
				Assert::IsTrue(evil->MyFloat == 8.5f);
				
				Event<float>::Unsubscribe(evil.get());
				GameState::Queue.TestClear();
			}

			{
				std::shared_ptr<EvilSubscriber> evil(new EvilSubscriber);
				std::shared_ptr<EventPublisher> newEventPublisher(new Event<float>(9.9f));
				Event<float>::Subscribe(evil.get());

				std::shared_ptr<EventPublisher> newEventInt(new Event<int>(4));

				Assert::IsTrue(GameState::Queue.IsEmpty());
				GameState::Queue.Enqueue(newEventInt, GameState::CurrentTime.CurrentTime());
				Assert::IsTrue(GameState::Queue.IsEmpty());
				Assert::IsTrue(GameState::Queue.Size() == 0);

				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsFalse(GameState::Queue.IsEmpty());
				Assert::IsTrue(GameState::Queue.Size() == 1);

				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsTrue(GameState::Queue.IsEmpty());
				Assert::IsTrue(GameState::Queue.Size() == 0);
				Assert::IsTrue(evil->MyFloat == 0.0f); //The float subscriber does NOT get updated by integer events.

				Event<float>::Unsubscribe(evil.get());
				Event<float>::TestClear();
				GameState::Queue.TestClear();
			}
		}

		TEST_METHOD(SubscriptionToAllEvents)
		{
			{
				std::shared_ptr<EvilSubscriber> evil(new EvilSubscriber);

				std::shared_ptr<EventPublisher> newEventPublisher(new Event<float>(9.9f));
				Event<float>::Subscribe(evil.get());

				std::shared_ptr<EventPublisher> newEventFloat(new Event<float>(4.6f));

				Assert::IsTrue(GameState::Queue.IsEmpty());
				GameState::Queue.Enqueue(newEventFloat, GameState::CurrentTime.CurrentTime());
				Assert::IsTrue(GameState::Queue.IsEmpty());
				Assert::IsTrue(GameState::Queue.Size() == 0);

				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsFalse(GameState::Queue.IsEmpty());
				Assert::IsTrue(GameState::Queue.Size() == 1);

				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsFalse(GameState::Queue.IsEmpty());
				Assert::IsTrue(GameState::Queue.Size() == 1);
				Assert::IsTrue(evil->MyFloat == 4.6f); //It will receive updates  from all events of type float, including those it doesn't explicitly subscribe to.
				
				Event<float>::Unsubscribe(evil.get());
				Event<float>::TestClear();
				GameState::Queue.TestClear();
			}
		}

		TEST_METHOD(DelayedEventSend)
		{
			std::shared_ptr<EvilSubscriber> evil(new EvilSubscriber);

			std::shared_ptr<EventPublisher> newEventPublisher(new Event<float>(9.9f));
			Event<float>::Subscribe(evil.get());

			Assert::IsTrue(GameState::Queue.IsEmpty());
			GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime(), 1000ms);
			Assert::IsTrue(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 0);

			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsFalse(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 1);
			Assert::IsTrue(evil->MyFloat == 0.0f);

			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsFalse(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 1);
			Assert::IsTrue(evil->MyFloat == 0.0f);

			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsFalse(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 1);
			Assert::IsTrue(evil->MyFloat == 0.0f); //The float hasn't been changed, so we know the event has not been fired yet.

			GameState::CurrentTime.SetCurrentTime(GameState::CurrentTime.CurrentTime()+1000ms);
			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsFalse(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 1);
			Assert::IsTrue(evil->MyFloat == 9.9f); //Now, the event has been fired!

			Event<float>::Unsubscribe(evil.get());
			Event<float>::TestClear();
			GameState::Queue.TestClear();
		}

		TEST_METHOD(EventQueueClear)
		{
			std::shared_ptr<EvilSubscriber> evil(new EvilSubscriber);
			std::shared_ptr<EventPublisher> newEventPublisher(new Event<float>(9.9f));
			Event<float>::Subscribe(evil.get());

			Assert::IsTrue(GameState::Queue.IsEmpty());
			GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime(), 10ms);
			Assert::IsTrue(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 0);

			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsFalse(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 1);

			std::shared_ptr<EventPublisher> anotherEventPublisher(new Event<float>(9.9f));
			GameState::Queue.Enqueue(anotherEventPublisher, GameState::CurrentTime.CurrentTime());

			GameState::Queue.Clear();
			Assert::IsFalse(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 1); //The clear will be executed on update, after the firing of expired events.
			
			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsTrue(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 0);

			Event<float>::Unsubscribe(evil.get());
			Event<float>::TestClear();
			GameState::Queue.TestClear();
		}

		TEST_METHOD(EventQueueSize)
		{
			std::shared_ptr<EventPublisher> newEventPublisher(new Event<float>(9.9f));
			std::shared_ptr<EventPublisher> newEventPublisher2(new Event<float>(4.2f));
			std::shared_ptr<EventPublisher> newEventPublisher3(new Event<int>(2));
			std::shared_ptr<EventPublisher> newEventPublisher4(new Event<std::string>("Hi"));

			Assert::IsTrue(GameState::Queue.IsEmpty());
			GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime(), 10ms);
			GameState::Queue.Enqueue(newEventPublisher2, GameState::CurrentTime.CurrentTime(), 10ms);
			GameState::Queue.Enqueue(newEventPublisher3, GameState::CurrentTime.CurrentTime(), 10ms);
			GameState::Queue.Enqueue(newEventPublisher4, GameState::CurrentTime.CurrentTime(), 10ms);
			
			Assert::IsTrue(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 0);

			GameState::Queue.Update(GameState::CurrentTime);

			Assert::IsFalse(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 4);

			GameState::CurrentTime.SetCurrentTime(GameState::CurrentTime.CurrentTime() + 10ms);
			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);

			Assert::IsTrue(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 0);

			Event<float>::TestClear();
			Event<int>::TestClear();
			Event<std::string>::TestClear();
			GameState::Queue.TestClear();
		}

		TEST_METHOD(Unsubscribe)
		{
			std::shared_ptr<MultiEventSubscriber>subscriber(new MultiEventSubscriber);

			std::shared_ptr<EventPublisher> newEventFloat(new Event<float>(9.9f));
			std::shared_ptr<EventPublisher> newEventString(new Event<std::string>("Cake"));

			Assert::IsTrue(GameState::Queue.IsEmpty());
			GameState::Queue.Enqueue(newEventFloat, GameState::CurrentTime.CurrentTime());
			GameState::Queue.Enqueue(newEventString, GameState::CurrentTime.CurrentTime());
			Assert::IsTrue(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 0);

			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsFalse(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 2);

			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsTrue(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 0);

			Assert::IsTrue(subscriber->MyFloat == 9.9f);
			Assert::IsTrue(subscriber->MyString == ("Cake"s));

			Event<float>::Unsubscribe(subscriber.get());

			std::shared_ptr<EventPublisher> anotherEventFloat(new Event<float>(11.11f));
			std::shared_ptr<EventPublisher> anotherEventString(new Event<std::string>("Pie"));

			GameState::Queue.Enqueue(anotherEventFloat, GameState::CurrentTime.CurrentTime());
			GameState::Queue.Enqueue(anotherEventString, GameState::CurrentTime.CurrentTime());

			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);

			Assert::IsTrue(subscriber->MyFloat == 9.9f); //The float did not get updated because subscriber unsubscribed from it prior to its update.
			Assert::IsTrue(subscriber->MyString == ("Pie"s));

			Event<float>::TestClear();
			Event<std::string>::TestClear();
			GameState::Queue.TestClear();
		}

		TEST_METHOD(UnsubscribeAll)
		{
			std::shared_ptr<MultiEventSubscriber>subscriber(new MultiEventSubscriber);
			std::shared_ptr<MultiEventSubscriber>subscriber1(new MultiEventSubscriber);
			std::shared_ptr<MultiEventSubscriber>subscriber2(new MultiEventSubscriber);
			std::shared_ptr<MultiEventSubscriber>subscriber3(new MultiEventSubscriber);

			std::shared_ptr<EventPublisher> newEventFloat(new Event<float>(9.9f));
			std::shared_ptr<EventPublisher> newEventString(new Event<std::string>("Cake"));

			Assert::IsTrue(GameState::Queue.IsEmpty());
			GameState::Queue.Enqueue(newEventFloat, GameState::CurrentTime.CurrentTime());
			GameState::Queue.Enqueue(newEventString, GameState::CurrentTime.CurrentTime());
			Assert::IsTrue(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 0);

			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsFalse(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 2);

			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsTrue(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 0);

			Assert::IsTrue(subscriber->MyFloat == 9.9f);
			Assert::IsTrue(subscriber->MyString == ("Cake"s));
			Assert::IsTrue(subscriber1->MyFloat == 9.9f);
			Assert::IsTrue(subscriber1->MyString == ("Cake"s));
			Assert::IsTrue(subscriber2->MyFloat == 9.9f);
			Assert::IsTrue(subscriber2->MyString == ("Cake"s));
			Assert::IsTrue(subscriber3->MyFloat == 9.9f);
			Assert::IsTrue(subscriber3->MyString == ("Cake"s));

			std::shared_ptr<MultiEventSubscriber>subscriber4(new MultiEventSubscriber);
			Event<float>::Subscribe(subscriber4.get());
			Event<std::string>::Subscribe(subscriber4.get());

			Event<float>::UnsubscribeAll();

			std::shared_ptr<EventPublisher> anotherEventFloat(new Event<float>(11.11f));
			std::shared_ptr<EventPublisher> anotherEventString(new Event<std::string>("Pie"));

			GameState::Queue.Enqueue(anotherEventFloat, GameState::CurrentTime.CurrentTime());
			GameState::Queue.Enqueue(anotherEventString, GameState::CurrentTime.CurrentTime());

			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);

			Assert::IsTrue(subscriber->MyFloat == 9.9f); //The float did not get updated because subscriber unsubscribed from it prior to its update.
			Assert::IsTrue(subscriber->MyString == ("Pie"s));
			Assert::IsTrue(subscriber1->MyFloat == 9.9f); //The float did not get updated because subscriber unsubscribed from it prior to its update.
			Assert::IsTrue(subscriber1->MyString == ("Pie"s));
			Assert::IsTrue(subscriber2->MyFloat == 9.9f); //The float did not get updated because subscriber unsubscribed from it prior to its update.
			Assert::IsTrue(subscriber2->MyString == ("Pie"s));
			Assert::IsTrue(subscriber3->MyFloat == 9.9f); //The float did not get updated because subscriber unsubscribed from it prior to its update.
			Assert::IsTrue(subscriber3->MyString == ("Pie"s));
			Assert::IsTrue(subscriber4->MyFloat == 0.0f); //The float did not get updated because subscriber unsubscribed from it prior to its update.
			Assert::IsTrue(subscriber4->MyString == ("Pie"s));

			Event<float>::TestClear();
			Event<std::string>::TestClear();
			GameState::Queue.TestClear();
		}

		TEST_METHOD(MultipleEventSubscription)
		{
			std::shared_ptr<MultiEventSubscriber>subscriber(new MultiEventSubscriber);

			std::shared_ptr<EventPublisher> newEventFloat(new Event<float>(9.9f));
			std::shared_ptr<EventPublisher> newEventString(new Event<std::string>("Cake"));

			Assert::IsTrue(GameState::Queue.IsEmpty());
			GameState::Queue.Enqueue(newEventFloat, GameState::CurrentTime.CurrentTime());
			GameState::Queue.Enqueue(newEventString, GameState::CurrentTime.CurrentTime());
			Assert::IsTrue(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 0);

			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsFalse(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 2);

			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsTrue(GameState::Queue.IsEmpty());
			Assert::IsTrue(GameState::Queue.Size() == 0);

			Assert::IsTrue(subscriber->MyFloat == 9.9f);
			Assert::IsTrue(subscriber->MyString == ("Cake"s));

			Event<float>::TestClear();
			Event<std::string>::TestClear();
			GameState::Queue.TestClear();
		}

		TEST_METHOD(SubscribeUnsubscribeInNotify)
		{
			{ 
				//This tests subscribe, when badguy > goodguy
				std::shared_ptr<MultiEventSubscriber>subscriber(new MultiEventSubscriber);
				std::shared_ptr<EventPublisher> newEventFloat(new Event<float>(9.9f));
				GameState::Queue.Enqueue(newEventFloat, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsTrue(subscriber->MyFloat == 9.9f); //The subscriber is added on initialization, as shown.

				Event<float>::Unsubscribe(subscriber.get());
				std::shared_ptr<EventPublisher> anotherNewEventFloat(new Event<float>(4.6f));
				GameState::Queue.Enqueue(anotherNewEventFloat, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsTrue(GameState::Queue.Size() == 1);
				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsTrue(GameState::Queue.IsEmpty());
				Assert::IsTrue(subscriber->MyFloat == 9.9f); //The subscriber is now removed.

				Event<EventArgs>::Subscribe(subscriber.get()); //The subscriber responds to an alert from Event<EventArgs> where BadGuy > GoodGuy by subscribing to Event<float>. After that, the subscribe request goes through when the next 
				//Event<float> fires, adding it and changing the float.
				std::shared_ptr<EventPublisher> newEventArgs(new Event<EventArgs>(EventArgs(2, 1)));
				GameState::Queue.Enqueue(newEventArgs, GameState::CurrentTime.CurrentTime());
				std::shared_ptr<EventPublisher> anotherAnotherEventFloat(new Event<float>(8.2f));
				GameState::Queue.Enqueue(anotherAnotherEventFloat, GameState::CurrentTime.CurrentTime(),1ms);
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::CurrentTime.SetCurrentTime(GameState::CurrentTime.CurrentTime() + 1ms);
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsTrue(GameState::Queue.Size() == 0);
				Assert::IsTrue(subscriber->MyFloat == 8.2f);

				Event<EventArgs>::TestClear();
				Event<float>::TestClear();
				Event<std::string>::TestClear();
				GameState::Queue.TestClear();
			}

			{
				//This tests unsubscribe, when goodguy > badguy
				std::shared_ptr<MultiEventSubscriber>subscriber(new MultiEventSubscriber);
				std::shared_ptr<MultiEventSubscriber>subscriber1(new MultiEventSubscriber);
				std::shared_ptr<MultiEventSubscriber>subscriber2(new MultiEventSubscriber);
				std::shared_ptr<MultiEventSubscriber>subscriber3(new MultiEventSubscriber);

				std::shared_ptr<EventPublisher> newEventFloat(new Event<float>(9.9f));

				GameState::Queue.Enqueue(newEventFloat, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				Assert::IsTrue(subscriber->MyFloat == 9.9f); //The subscriber is added on initialization, as shown.
				Assert::IsTrue(subscriber1->MyFloat == 9.9f);
				Assert::IsTrue(subscriber2->MyFloat == 9.9f);
				Assert::IsTrue(subscriber3->MyFloat == 9.9f);

				Event<EventArgs>::Subscribe(subscriber.get());
				std::shared_ptr<EventPublisher> newEventArgs(new Event<EventArgs>(EventArgs(1, 2)));  //When we enqueue a new event of type EventArgs where GoodGuy > BadGuy, it will unsubscribe from Event<float>, meaning its float will not be updated.
				std::shared_ptr<EventPublisher> anotherEventFloat(new Event<float>(8.2f));
				GameState::Queue.Enqueue(newEventArgs, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Enqueue(anotherEventFloat, GameState::CurrentTime.CurrentTime(), 1ms);
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				GameState::CurrentTime.SetCurrentTime(GameState::CurrentTime.CurrentTime() + 10ms);
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				Assert::IsTrue(subscriber->MyFloat == 9.9f);
				Assert::IsTrue(subscriber1->MyFloat == 8.2f);
				Assert::IsTrue(subscriber2->MyFloat == 8.2f);
				Assert::IsTrue(subscriber3->MyFloat == 8.2f);

				Event<EventArgs>::TestClear();
				Event<float>::TestClear();
				Event<std::string>::TestClear();
				GameState::Queue.TestClear();
			}

			{
				//This tests UnsubscribeAll, when goodguy == badguy.
				std::shared_ptr<MultiEventSubscriber>subscriber(new MultiEventSubscriber);
				std::shared_ptr<MultiEventSubscriber>subscriber1(new MultiEventSubscriber);
				std::shared_ptr<MultiEventSubscriber>subscriber2(new MultiEventSubscriber);
				std::shared_ptr<MultiEventSubscriber>subscriber3(new MultiEventSubscriber);

				std::shared_ptr<EventPublisher> newEventFloat(new Event<float>(9.9f));
				GameState::Queue.Enqueue(newEventFloat, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsTrue(subscriber->MyFloat == 9.9f); //The subscriber is added on initialization, as shown.
				Assert::IsTrue(subscriber1->MyFloat == 9.9f);
				Assert::IsTrue(subscriber2->MyFloat == 9.9f);
				Assert::IsTrue(subscriber3->MyFloat == 9.9f);

				Event<EventArgs>::Subscribe(subscriber.get()); //Only one subscriber is subscribing to EventArgs, only IT is getting the update, but UnsubscribeAll
				std::shared_ptr<EventPublisher> newEventArgs(new Event<EventArgs>(EventArgs(2, 2)));  //When we enqueue a new event of type EventArgs where GoodGuy = BadGuy, it will unsubscribe everything from Event<float>.
				std::shared_ptr<EventPublisher> anotherEventFloat(new Event<float>(8.2f));
				GameState::Queue.Enqueue(newEventArgs, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsTrue(GameState::Queue.Size() == 0);

				GameState::Queue.Enqueue(anotherEventFloat, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				Assert::IsTrue(subscriber->MyFloat == 9.9f); //NOTHING is updated here.
				Assert::IsTrue(subscriber1->MyFloat == 9.9f);
				Assert::IsTrue(subscriber2->MyFloat == 9.9f);
				Assert::IsTrue(subscriber3->MyFloat == 9.9f);

				Event<EventArgs>::TestClear();
				Event<float>::TestClear();
				Event<std::string>::TestClear();
				GameState::Queue.TestClear();
			}
		}

		TEST_METHOD(EventDequeueOnUpdate)
		{
			//This tests subscribe, when badguy > goodguy
			std::shared_ptr<MultiEventSubscriber>subscriber(new MultiEventSubscriber);

			std::shared_ptr<EventPublisher> newEventFloat(new Event<float>(9.9f));
			std::shared_ptr<EventPublisher> hatedEvent(new Event<float>(13.13f));
			std::shared_ptr<EventPublisher> newEventArgs(new Event<EventArgs>(EventArgs(13, 13)));

			subscriber->HatedEvent = hatedEvent.get();

			GameState::Queue.Enqueue(newEventFloat, GameState::CurrentTime.CurrentTime());
			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsTrue(subscriber->MyFloat == 9.9f); //The subscriber is added on initialization, as shown.

			Event<EventArgs>::Subscribe(subscriber.get()); //The subscriber responds to an alert from Event<EventArgs> where BadGuy > GoodGuy by subscribing to Event<float>. After that, the subscribe request goes through when the next 
			//Event<float> fires, adding it and changing the float.
			GameState::Queue.Enqueue(newEventArgs, GameState::CurrentTime.CurrentTime());
			GameState::Queue.Enqueue(hatedEvent, GameState::CurrentTime.CurrentTime(), 10ms);
			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);
			Assert::IsTrue(GameState::Queue.Size() == 0);
			Assert::IsTrue(subscriber->MyFloat == 9.9f);

			Event<EventArgs>::TestClear();
			Event<float>::TestClear();
			Event<std::string>::TestClear();
			GameState::Queue.TestClear();
		}


		TEST_METHOD(EventCopy)
		{
			{ //Copy construction of Event<T>
				std::shared_ptr<MultiEventSubscriber>subscriber(new MultiEventSubscriber);
				std::shared_ptr<EventPublisher> newEventFloat(new Event<float>(9.9f));
				std::shared_ptr<EventPublisher>copiedFloat = newEventFloat;
				Assert::IsTrue(static_cast<Event<float>*>(copiedFloat.get())->Message() == 9.9f);

				GameState::Queue.Enqueue(copiedFloat, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				Assert::IsTrue(subscriber->MyFloat == 9.9f);

				Event<float>::TestClear();
				Event<std::string>::TestClear();
				GameState::Queue.TestClear();
			}
			{ //Copy assignment of Event<T>
				std::shared_ptr<MultiEventSubscriber>subscriber(new MultiEventSubscriber);
				std::shared_ptr<EventPublisher> newEventFloat(new Event<float>(9.9f));
				std::shared_ptr<EventPublisher>copiedFloat;
				copiedFloat = newEventFloat;
				Assert::IsTrue(static_cast<Event<float>*>(copiedFloat.get())->Message() == 9.9f);

				GameState::Queue.Enqueue(copiedFloat, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				Assert::IsTrue(subscriber->MyFloat == 9.9f);

				Event<float>::TestClear();
				Event<std::string>::TestClear();
				GameState::Queue.TestClear();
			}
		}

		TEST_METHOD(EventMove)
		{
			{ //Move construction of Event<T>
				std::shared_ptr<MultiEventSubscriber>subscriber(new MultiEventSubscriber);

				std::shared_ptr<EventPublisher> newEventFloat(new Event<float>(9.9f));
				std::shared_ptr<EventPublisher>copiedFloat = std::move(newEventFloat);
				Assert::IsTrue(static_cast<Event<float>*>(copiedFloat.get())->Message() == 9.9f);

				GameState::Queue.Enqueue(copiedFloat, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				Assert::IsTrue(subscriber->MyFloat == 9.9f);

				Event<float>::TestClear();
				Event<std::string>::TestClear();
				GameState::Queue.TestClear();
			}
			{ //Move assignment of Event<T>
				std::shared_ptr<MultiEventSubscriber>subscriber(new MultiEventSubscriber);
				std::shared_ptr<EventPublisher> newEventFloat(new Event<float>(9.9f));
				std::shared_ptr<EventPublisher>copiedFloat;
				copiedFloat = std::move(newEventFloat);
				Assert::IsTrue(static_cast<Event<float>*>(copiedFloat.get())->Message() == 9.9f);

				GameState::Queue.Enqueue(copiedFloat, GameState::CurrentTime.CurrentTime());
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				Assert::IsTrue(subscriber->MyFloat == 9.9f);

				Event<float>::TestClear();
				Event<std::string>::TestClear();
				GameState::Queue.TestClear();
			}
		}

		TEST_METHOD(LotsOfEvents)
		{
			std::shared_ptr<CounterSubscriber>subscriber(new CounterSubscriber);
			std::shared_ptr<EventPublisher> newEventSizet(new Event<size_t>(1));
			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);

			GameState::Queue.Enqueue(newEventSizet, GameState::CurrentTime.CurrentTime());
			GameState::Queue.Update(GameState::CurrentTime);

			for (size_t i = 0; i < 10000; i++)
			{
				GameState::Queue.Update(GameState::CurrentTime);
				Assert::IsTrue(subscriber->SizeCalls == i+1);
				Assert::IsTrue(subscriber->TotalCalls == 2*(i)+1);
				Assert::IsTrue(subscriber->FloatCalls == i);
				Assert::IsTrue(GameState::Queue.Size() == 2);
			}

			Event<size_t>::TestClear();
			Event<float>::TestClear();
			GameState::Queue.TestClear();
		}

	private: //Creates memory state screenshots to ensure no memory leaks in any test
		inline static _CrtMemState _startMemState;
	};
}