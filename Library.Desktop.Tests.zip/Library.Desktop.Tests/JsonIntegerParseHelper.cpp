#include "JsonIntegerParseHelper.h"

namespace UnitTests
{
	RTTI_DEFINITIONS(JsonIntegerParseHelper::Wrapper);
	RTTI_DEFINITIONS(JsonIntegerParseHelper);

	std::shared_ptr<FieaGameEngine::JsonParseCoordinator::Wrapper> JsonIntegerParseHelper::Wrapper::Create() const
	{
		std::shared_ptr<FieaGameEngine::JsonParseCoordinator::Wrapper> newWrapper(new Wrapper);
		return newWrapper;
	}

	JsonIntegerParseHelper::Wrapper::~Wrapper()
	{
		Data.~Vector();
		TotalDepth = 0;
	}

	void JsonIntegerParseHelper::Initialize()
	{

	}

	bool JsonIntegerParseHelper::StartHandler(FieaGameEngine::JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray)
	{
		if (value.second["Type"] == "Integer" && coordinator.Is(JsonIntegerParseHelper::Wrapper().TypeIdClass()) && value.second["Value"].isInt())
		{
			isArray = false;
			return true;
		}
		else if (value.second["Type"] == "Integer" && coordinator.Is(JsonIntegerParseHelper::Wrapper().TypeIdClass()) && value.second["Value"].isArray())
		{
			if (value.second["Value"].get(Json::ArrayIndex(0), -999.9f).isInt())
			{
				isArray = true;
				return true;
			}
		}
		return false;
	}

	void JsonIntegerParseHelper::EndHandler(FieaGameEngine::JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray)
	{
		reinterpret_cast<JsonIntegerParseHelper::Wrapper*>(dynamic_cast<FieaGameEngine::RTTI*>(&coordinator))->TotalDepth = coordinator.Depth();
		if (isArray)
		{
			for (size_t i = 0; value.second["Value"].get(Json::ArrayIndex(i), -999.9f).isInt(); i++)
			{
				reinterpret_cast<JsonIntegerParseHelper::Wrapper*>(dynamic_cast<FieaGameEngine::RTTI*>(&coordinator))->Data.PushBack(value.second["Value"].get(Json::ArrayIndex(i), -999.9f).asInt());
			}
		}
		else
		{
			reinterpret_cast<JsonIntegerParseHelper::Wrapper*>(dynamic_cast<FieaGameEngine::RTTI*>(&coordinator))->Data.PushBack(value.second["Value"].asInt());
		}
	}

	void JsonIntegerParseHelper::Cleanup()
	{
		
	}

	std::shared_ptr<FieaGameEngine::IJsonParseHelper> JsonIntegerParseHelper::Create() const
	{
		std::shared_ptr<FieaGameEngine::IJsonParseHelper> newHelp(new JsonIntegerParseHelper);
		return newHelp;
	}
}