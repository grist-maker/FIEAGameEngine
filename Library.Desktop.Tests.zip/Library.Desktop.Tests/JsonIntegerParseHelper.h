#pragma once
#include "Vector.h"
#include "IJsonParseHelper.h"

namespace UnitTests
{
	class JsonIntegerParseHelper final : public FieaGameEngine::IJsonParseHelper
	{
		RTTI_DECLARATIONS(JsonIntegerParseHelper, FieaGameEngine::IJsonParseHelper);
	public:
		class Wrapper final : public FieaGameEngine::JsonParseCoordinator::Wrapper
		{
			RTTI_DECLARATIONS(Wrapper, FieaGameEngine::JsonParseCoordinator::Wrapper);
		public:
			std::shared_ptr<FieaGameEngine::JsonParseCoordinator::Wrapper> Create() const override;
			virtual ~Wrapper() override;
			FieaGameEngine::Vector<size_t> Data;
			size_t TotalDepth = 0;
		};

		std::shared_ptr<IJsonParseHelper> Create() const override;

		void Initialize() override;
		bool StartHandler(FieaGameEngine::JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray) override;
		void EndHandler(FieaGameEngine::JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray) override;
		void Cleanup() override;

	private:
		inline static const std::string IntegerKey{ "Integer" };
		bool ParsingData = false;
	};
}