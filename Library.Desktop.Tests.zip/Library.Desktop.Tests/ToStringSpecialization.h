#pragma once
#include "Foo.h"
#include "CppUnitTest.h"
/// <summary>
/// The file specifying ToString methods to be used with new defined classes. Allows conversion of Foo class objects to strings to be compared with greater ease.
/// </summary>
namespace Microsoft::VisualStudio::CppUnitTestFramework
{

//	template <typename Q> static std::wstring ToString(const Q* q) { static_assert(dependent_false<Q>, "Test writer must define specialization of ToString<const Q* q> for "); }
	template<>
	inline std::wstring ToString<UnitTests::Foo>(const UnitTests::Foo& t)
	{
		std::wstringstream _s;
		_s << t.Data();
		return _s.str();
		//RETURN_WIDE_STRING(t.Data());
	}

	template<>
	inline std::wstring ToString<UnitTests::Foo>(const UnitTests::Foo* t)
	{
		std::wstringstream _s;
		_s << t->Data();
		return _s.str();
		//RETURN_WIDE_STRING(t);
	}
	template<>
	inline std::wstring ToString<UnitTests::Foo>(UnitTests::Foo* t)
	{
		std::wstringstream _s;
		_s << t->Data();
		return _s.str();
		//RETURN_WIDE_STRING(t.Data());
	}

	template<>
	inline std::wstring ToString<const UnitTests::Foo>(const UnitTests::Foo& t)
	{
		std::wstringstream _s;
		_s << t.Data();
		return _s.str();
	}

}