#include "pch.h"
#include "CppUnitTest.h"
#include "EventArgs.h"
#include "OperateReactionAttributed.h"
#include "ActionEvent.h"
#include "ActionIncrement.h"
#include "ActionDecrement.h"
#include "ActionMultiply.h"
#include "ActionDivide.h"
#include "JsonTableParseHelper.h"
#include "BigReactionAttributed.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;
using namespace std::string_literals;
using namespace chrono;

namespace UnitTests
{
	TEST_CLASS(ReactionTests)
	{
		TEST_METHOD_INITIALIZE(Initialize) //Initial setup of memory state variables to allow memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&_startMemState);
			#endif
		}

		TEST_METHOD_CLEANUP(Cleanup) //Setup for memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);

			if (_CrtMemDifference(&diffMemState, &_startMemState,
				&endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
			#endif
		}

		TEST_METHOD(BasicUpdateLoop)
		{
			//EventMessageAttributed - Used as base event type reactionAttributed subscribe to, holds arguments as auxiliary attributes.
			//Reaction - Basic class inheriting from EventSubscriber and ActionList, with a protected update method. Used to prevent access to on-tick updates, instead being triggered on notify.
			//ReactionAttributed - Subscriber to Event<EventMessageAttributed>, only Updates on receipt of this event with matching Subtype variable, performs nested actions on Update calls.
			//ActionEvent - Raises new events of type EventMessageAttributed, enqueueing them onto the Event queue with specified delay and subtype variable. Similarly copies its own auxiliary
			//attributes into each EventMessageAttributed object for arguments.

			ActionEvent EventCreator;
			ReactionAttributed EventSub;
			std::string base = "BaseSubtype";
			std::string A = "A";

			EventSub.Find("Subtype")->SetString(base);
			auto& IntTable = EventSub.AppendAuxiliaryAttribute("A");
			IntTable.SetType(Datum::DatumTypes::Integer);
			IntTable.PushBack(size_t(0));
			IntTable.PushBack(size_t(0));
			IntTable.PushBack(size_t(0));
			
			auto& children = EventSub.At("Actions")->GetScope();
			children->Adopt(new ActionIncrement(), "Child");
			auto& childEvent = children->Find("Child")->GetScope();
			childEvent->Find("Index")->SetInt(1);
			childEvent->Find("Step")->SetInt(4);
			childEvent->Find("Target")->SetString(A);

			std::shared_ptr<EventPublisher> MainEvent(new Event<EventMessageAttributed>(EventMessageAttributed("BaseSubtype")));
			GameState::Queue.Enqueue(MainEvent, GameState::CurrentTime.CurrentTime());

			EventCreator.Find("Subtype")->SetString(base);
			EventCreator.Find("Delay")->SetInt(1);
			EventCreator.Update(GameState::CurrentTime);

			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);

			GameState::CurrentTime.SetCurrentTime(GameState::CurrentTime.CurrentTime() + 10ms);
			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);

			Assert::IsTrue(IntTable.GetInt() == 0);
			Assert::IsTrue(IntTable.GetInt(1) == 8);
			Assert::IsTrue(IntTable.GetInt(2) == 0);

			Event<EventMessageAttributed>::TestClear();
			GameState::Queue.TestClear();
		}

		TEST_METHOD(SubtypeImportance)
		{
			ActionEvent EventCreator;
			ReactionAttributed EventSub;
			std::string base = "BaseSubtype";
			std::string wrongBase = "Wrong";
			std::string A = "A";

			EventSub.Find("Subtype")->SetString(base);
			auto& IntTable = EventSub.AppendAuxiliaryAttribute("A");
			IntTable.SetType(Datum::DatumTypes::Integer);
			IntTable.PushBack(size_t(0));
			IntTable.PushBack(size_t(0));
			IntTable.PushBack(size_t(0));

			auto& children = EventSub.At("Actions")->GetScope();
			children->Adopt(new ActionIncrement(), "Child");
			auto& childEvent = children->Find("Child")->GetScope();
			childEvent->Find("Index")->SetInt(1);
			childEvent->Find("Step")->SetInt(4);
			childEvent->Find("Target")->SetString(A);

			std::shared_ptr<EventPublisher> MainEvent(new Event<EventMessageAttributed>(EventMessageAttributed("IncorrectSubtype")));
			GameState::Queue.Enqueue(MainEvent, GameState::CurrentTime.CurrentTime());

			EventCreator.Find("Subtype")->SetString(wrongBase);
			EventCreator.Find("Delay")->SetInt(0);
			EventCreator.Update(GameState::CurrentTime);

			Assert::IsTrue(EventCreator.Find("Subtype")->GetString(0) != EventSub.Find("Subtype")->GetString());

			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);

			Assert::IsTrue(IntTable.GetInt() == 0);
			Assert::IsTrue(IntTable.GetInt(1) == 0);
			Assert::IsTrue(IntTable.GetInt(2) == 0);

			EventSub.Find("Subtype")->SetString(wrongBase, 1);
			EventCreator.Update(GameState::CurrentTime);
			std::shared_ptr<EventPublisher> SecondEvent(new Event<EventMessageAttributed>(EventMessageAttributed("BaseSubtype")));
			GameState::Queue.Enqueue(SecondEvent, GameState::CurrentTime.CurrentTime());
			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);

			Assert::IsTrue(IntTable.GetInt() == 0);
			Assert::IsTrue(IntTable.GetInt(1) == 8);
			Assert::IsTrue(IntTable.GetInt(2) == 0);

			ActionEvent AnotherCreator;
			AnotherCreator.Find("Subtype")->SetString(base);
			AnotherCreator.Find("Delay")->SetInt(0);
			AnotherCreator.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);

			Assert::IsTrue(IntTable.GetInt() == 0);
			Assert::IsTrue(IntTable.GetInt(1) == 12);
			Assert::IsTrue(IntTable.GetInt(2) == 0);

			Event<EventMessageAttributed>::TestClear();
			GameState::Queue.TestClear();
		}

		TEST_METHOD(ReactionAttributedFunctionParameters)
		{
			ActionEvent EventCreator;
			OperateReactionAttributed EventSub;
			std::string operate = "Operate";
			std::string A = "A";
			std::string empty = "";

			auto& children = EventSub.At("Actions")->GetScope();
			children->Adopt(new ActionIncrement(), "Child");
			auto& childEvent = children->Find("Child")->GetScope();
			childEvent->Find("Index")->SetInt(0);
			childEvent->Find("Step")->SetInt(0);
			childEvent->Find("Target")->SetString(empty);

			children->Adopt(new ActionIncrement(), "AnotherChild");
			auto childEvent2 = children->Find("AnotherChild")->GetScope();
			childEvent2->Find("Index")->SetInt(0);
			childEvent2->Find("Step")->SetInt(0);
			childEvent2->Find("Target")->SetString(empty);

			children->Adopt(new ActionIncrement(), "ThirdChild");
			auto childEvent3 = children->Find("ThirdChild")->GetScope();
			childEvent3->Find("Index")->SetInt(0);
			childEvent3->Find("Step")->SetInt(0);
			childEvent3->Find("Target")->SetString(empty);

			EventCreator.Find("Subtype")->SetString(operate);
			EventCreator.Find("Delay")->SetInt(0);

			EventCreator.AppendAuxiliaryAttribute("ArrayPosition").PushBack(size_t(1));
			EventCreator.AppendAuxiliaryAttribute("Change").PushBack(size_t(5));
			EventCreator.AppendAuxiliaryAttribute("Focus").PushBack(A);

			auto& newAttribute3 = EventCreator.AppendAuxiliaryAttribute("A");
			newAttribute3.PushBack(size_t(4));
			newAttribute3.PushBack(size_t(3));
			newAttribute3.PushBack(size_t(2));

			EventCreator.Update(GameState::CurrentTime);

			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);

			Assert::IsTrue(EventSub.Find(A)->GetInt(1) == 18);

			Event<EventMessageAttributed>::Unsubscribe(&EventSub);
			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);

			Event<EventMessageAttributed>::TestClear();
			GameState::Queue.TestClear();
		}

		TEST_METHOD(Parse)
		{
			//ReactionAttributed objec parsing
			{
				std::string base = "BaseSubtype";
				std::string A = "A";

				std::string ScopeTag = "Scope";
				std::string ActionListTag = "ActionList";
				std::string ActionIncrementTag = "ActionIncrement";
				std::string ActionEventTag = "ActionEvent";
				std::string ReactionAttributedTag = "ReactionAttributed";

				Factory<Scope>::Add(std::make_unique<ScopeFactory>());
				Factory<Scope>::Add(std::make_unique<ActionListFactory>());
				Factory<Scope>::Add(std::make_unique<ActionIncrementFactory>());
				Factory<Scope>::Add(std::make_unique<ActionEventFactory>());
				Factory<Scope>::Add(std::make_unique<ReactionAttributedFactory>());

				std::string fullPath = R"(Content\ReactionAttributedParsing.json)";
				shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<ReactionAttributed>()));
				JsonParseCoordinator parseCoordinator(wrapper);
				auto testParseHelper = make_shared<JsonTableParseHelper>();
				parseCoordinator.AddHelper(testParseHelper);

				parseCoordinator.Initialize();
				JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
				parseCoordinator.DeserializeObjectFromFile(fullPath);

				rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
				auto EventSub = static_cast<ReactionAttributed*>(rawWrapper->Data.get());

				fullPath = R"(Content\ActionEventParsing.json)";
				parseCoordinator.Initialize();
				parseCoordinator.DeserializeObjectFromFile(fullPath);

				rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
				auto EventCreator = static_cast<ActionEvent*>(rawWrapper->Data.get());

				EventCreator->Update(GameState::CurrentTime);

				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				auto IntTable = *EventSub->Find("A");
				Assert::IsTrue(IntTable.GetInt() == 0);
				Assert::IsTrue(IntTable.GetInt(1) == 4);
				Assert::IsTrue(IntTable.GetInt(2) == 0);

				EventCreator->Update(GameState::CurrentTime);

				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				IntTable = *EventSub->Find("A");
				Assert::IsTrue(IntTable.GetInt() == 0);
				Assert::IsTrue(IntTable.GetInt(1) == 8);
				Assert::IsTrue(IntTable.GetInt(2) == 0);

				Factory<Scope>::Remove(ScopeTag);
				Factory<Scope>::Remove(ActionListTag);
				Factory<Scope>::Remove(ActionIncrementTag);
				Factory<Scope>::Remove(ActionEventTag);
				Factory<Scope>::Remove(ReactionAttributedTag);

				Event<EventMessageAttributed>::TestClear();
				GameState::Queue.TestClear();
			}

			//OperateReactionAttributedParsing with increment
			{
				std::string A = "A";
				std::string Operate = "Operate";

				std::string ScopeTag = "Scope";
				std::string ActionListTag = "ActionList";
				std::string ActionIncrementTag = "ActionIncrement";
				std::string ActionEventTag = "ActionEvent";
				std::string ReactionAttributedTag = "ReactionAttributed";
				std::string OperateReactionAttributedTag = "OperateReactionAttributed";

				Factory<Scope>::Add(std::make_unique<ScopeFactory>());
				Factory<Scope>::Add(std::make_unique<ActionListFactory>());
				Factory<Scope>::Add(std::make_unique<ActionIncrementFactory>());
				Factory<Scope>::Add(std::make_unique<ActionEventFactory>());
				Factory<Scope>::Add(std::make_unique<ReactionAttributedFactory>());
				Factory<Scope>::Add(std::make_unique<OperateReactionAttributedFactory>());

				std::string fullPath = R"(Content\OperateReactionAttributedAdd.json)";
				shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<OperateReactionAttributed>()));
				JsonParseCoordinator parseCoordinator(wrapper);
				auto testParseHelper = make_shared<JsonTableParseHelper>();
				parseCoordinator.AddHelper(testParseHelper);

				parseCoordinator.Initialize();
				JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
				parseCoordinator.DeserializeObjectFromFile(fullPath);

				rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
				auto EventSub = static_cast<OperateReactionAttributed*>(rawWrapper->Data.get());

				shared_ptr<JsonParseCoordinator::Wrapper> newwrapper(new JsonTableParseHelper::Wrapper(std::make_shared<ActionEvent>()));
				JsonParseCoordinator newparseCoordinator(newwrapper);
				auto newtestParseHelper = make_shared<JsonTableParseHelper>();
				newparseCoordinator.AddHelper(newtestParseHelper);

				fullPath = R"(Content\ActionEventOperateParsing.json)";
				newparseCoordinator.Initialize();
				newparseCoordinator.DeserializeObjectFromFile(fullPath);

				auto newrawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(newwrapper.get());
				auto EventCreator = static_cast<ActionEvent*>(newrawWrapper->Data.get());

				EventCreator->Find("Subtype")->SetString(Operate);
				EventCreator->Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				auto& IntTable = *EventSub->Find("A");
				Assert::IsTrue(IntTable.GetInt() == 4);
				Assert::IsTrue(IntTable.GetInt(1) == 13);
				Assert::IsTrue(IntTable.GetInt(2) == 2);

				EventCreator->Update(GameState::CurrentTime);

				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				IntTable = *EventSub->Find("A");
				Assert::IsTrue(IntTable.GetInt() == 4);
				Assert::IsTrue(IntTable.GetInt(1) == 23);
				Assert::IsTrue(IntTable.GetInt(2) == 2);

				Factory<Scope>::Remove(ScopeTag);
				Factory<Scope>::Remove(ActionListTag);
				Factory<Scope>::Remove(ActionIncrementTag);
				Factory<Scope>::Remove(ActionEventTag);
				Factory<Scope>::Remove(ReactionAttributedTag);
				Factory<Scope>::Remove(OperateReactionAttributedTag);

				Event<EventMessageAttributed>::TestClear();
				GameState::Queue.TestClear();
			}

			//OperateReactionAttributedParsing with decrement
			{
				std::string A = "A";
				std::string Operate = "Operate";

				std::string ScopeTag = "Scope";
				std::string ActionListTag = "ActionList";
				std::string ActionDecrementTag = "ActionDecrement";
				std::string ActionEventTag = "ActionEvent";
				std::string ReactionAttributedTag = "ReactionAttributed";
				std::string OperateReactionAttributedTag = "OperateReactionAttributed";

				Factory<Scope>::Add(std::make_unique<ScopeFactory>());
				Factory<Scope>::Add(std::make_unique<ActionListFactory>());
				Factory<Scope>::Add(std::make_unique<ActionDecrementFactory>());
				Factory<Scope>::Add(std::make_unique<ActionEventFactory>());
				Factory<Scope>::Add(std::make_unique<ReactionAttributedFactory>());
				Factory<Scope>::Add(std::make_unique<OperateReactionAttributedFactory>());

				std::string fullPath = R"(Content\OperateReactionAttributedSubtract.json)";
				shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<OperateReactionAttributed>()));
				JsonParseCoordinator parseCoordinator(wrapper);
				auto testParseHelper = make_shared<JsonTableParseHelper>();
				parseCoordinator.AddHelper(testParseHelper);

				parseCoordinator.Initialize();
				JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
				parseCoordinator.DeserializeObjectFromFile(fullPath);

				rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
				auto EventSub = static_cast<OperateReactionAttributed*>(rawWrapper->Data.get());

				shared_ptr<JsonParseCoordinator::Wrapper> newwrapper(new JsonTableParseHelper::Wrapper(std::make_shared<ActionEvent>()));
				JsonParseCoordinator newparseCoordinator(newwrapper);
				auto newtestParseHelper = make_shared<JsonTableParseHelper>();
				newparseCoordinator.AddHelper(newtestParseHelper);

				fullPath = R"(Content\ActionEventOperateParsing.json)";
				newparseCoordinator.Initialize();
				newparseCoordinator.DeserializeObjectFromFile(fullPath);

				auto newrawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(newwrapper.get());
				auto EventCreator = static_cast<ActionEvent*>(newrawWrapper->Data.get());

				EventCreator->Find("Subtype")->SetString(Operate);
				EventCreator->Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				auto& IntTable = *EventSub->Find("A");
				Assert::IsTrue(IntTable.GetInt() == 10);
				Assert::IsTrue(IntTable.GetInt(1) == 8);
				Assert::IsTrue(IntTable.GetInt(2) == 16);

				EventCreator->Update(GameState::CurrentTime);

				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				IntTable = *EventSub->Find("A");
				Assert::IsTrue(IntTable.GetInt() == 10);
				Assert::IsTrue(IntTable.GetInt(1) == 3);
				Assert::IsTrue(IntTable.GetInt(2) == 16);

				Factory<Scope>::Remove(ScopeTag);
				Factory<Scope>::Remove(ActionListTag);
				Factory<Scope>::Remove(ActionDecrementTag);
				Factory<Scope>::Remove(ActionEventTag);
				Factory<Scope>::Remove(ReactionAttributedTag);
				Factory<Scope>::Remove(OperateReactionAttributedTag);

				Event<EventMessageAttributed>::TestClear();
				GameState::Queue.TestClear();
			}

			//OperateReactionAttributedParsing with Multiply
			{
				std::string A = "A";
				std::string Operate = "Operate";

				std::string ScopeTag = "Scope";
				std::string ActionListTag = "ActionList";
				std::string ActionMultiplyTag = "ActionMultiply";
				std::string ActionEventTag = "ActionEvent";
				std::string ReactionAttributedTag = "ReactionAttributed";
				std::string OperateReactionAttributedTag = "OperateReactionAttributed";

				Factory<Scope>::Add(std::make_unique<ScopeFactory>());
				Factory<Scope>::Add(std::make_unique<ActionListFactory>());
				Factory<Scope>::Add(std::make_unique<ActionMultiplyFactory>());
				Factory<Scope>::Add(std::make_unique<ActionEventFactory>());
				Factory<Scope>::Add(std::make_unique<ReactionAttributedFactory>());
				Factory<Scope>::Add(std::make_unique<OperateReactionAttributedFactory>());

				std::string fullPath = R"(Content\OperateReactionAttributedMultiply.json)";
				shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<OperateReactionAttributed>()));
				JsonParseCoordinator parseCoordinator(wrapper);
				auto testParseHelper = make_shared<JsonTableParseHelper>();
				parseCoordinator.AddHelper(testParseHelper);

				parseCoordinator.Initialize();
				JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
				parseCoordinator.DeserializeObjectFromFile(fullPath);

				rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
				auto EventSub = static_cast<OperateReactionAttributed*>(rawWrapper->Data.get());

				shared_ptr<JsonParseCoordinator::Wrapper> newwrapper(new JsonTableParseHelper::Wrapper(std::make_shared<ActionEvent>()));
				JsonParseCoordinator newparseCoordinator(newwrapper);
				auto newtestParseHelper = make_shared<JsonTableParseHelper>();
				newparseCoordinator.AddHelper(newtestParseHelper);

				fullPath = R"(Content\ActionEventOperateParsing.json)";
				newparseCoordinator.Initialize();
				newparseCoordinator.DeserializeObjectFromFile(fullPath);

				auto newrawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(newwrapper.get());
				auto EventCreator = static_cast<ActionEvent*>(newrawWrapper->Data.get());

				EventCreator->Find("Subtype")->SetString(Operate);
				EventCreator->Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				auto& IntTable = *EventSub->Find("A");
				Assert::IsTrue(IntTable.GetInt() == 3);
				Assert::IsTrue(IntTable.GetInt(1) == 20);
				Assert::IsTrue(IntTable.GetInt(2) == 5);

				EventCreator->Update(GameState::CurrentTime);

				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				IntTable = *EventSub->Find("A");
				Assert::IsTrue(IntTable.GetInt() == 3);
				Assert::IsTrue(IntTable.GetInt(1) == 100);
				Assert::IsTrue(IntTable.GetInt(2) == 5);

				Factory<Scope>::Remove(ScopeTag);
				Factory<Scope>::Remove(ActionListTag);
				Factory<Scope>::Remove(ActionMultiplyTag);
				Factory<Scope>::Remove(ActionEventTag);
				Factory<Scope>::Remove(ReactionAttributedTag);
				Factory<Scope>::Remove(OperateReactionAttributedTag);

				Event<EventMessageAttributed>::TestClear();
				GameState::Queue.TestClear();
			}
			//OperateReactionAttributedParsing with Divide
			{
				std::string A = "A";
				std::string Operate = "Operate";

				std::string ScopeTag = "Scope";
				std::string ActionListTag = "ActionList";
				std::string ActionDivideTag = "ActionDivide";
				std::string ActionEventTag = "ActionEvent";
				std::string ReactionAttributedTag = "ReactionAttributed";
				std::string OperateReactionAttributedTag = "OperateReactionAttributed";

				Factory<Scope>::Add(std::make_unique<ScopeFactory>());
				Factory<Scope>::Add(std::make_unique<ActionListFactory>());
				Factory<Scope>::Add(std::make_unique<ActionDivideFactory>());
				Factory<Scope>::Add(std::make_unique<ActionEventFactory>());
				Factory<Scope>::Add(std::make_unique<ReactionAttributedFactory>());
				Factory<Scope>::Add(std::make_unique<OperateReactionAttributedFactory>());

				std::string fullPath = R"(Content\OperateReactionAttributedDivide.json)";
				shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<OperateReactionAttributed>()));
				JsonParseCoordinator parseCoordinator(wrapper);
				auto testParseHelper = make_shared<JsonTableParseHelper>();
				parseCoordinator.AddHelper(testParseHelper);

				parseCoordinator.Initialize();
				JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
				parseCoordinator.DeserializeObjectFromFile(fullPath);

				rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
				auto EventSub = static_cast<OperateReactionAttributed*>(rawWrapper->Data.get());

				shared_ptr<JsonParseCoordinator::Wrapper> newwrapper(new JsonTableParseHelper::Wrapper(std::make_shared<ActionEvent>()));
				JsonParseCoordinator newparseCoordinator(newwrapper);
				auto newtestParseHelper = make_shared<JsonTableParseHelper>();
				newparseCoordinator.AddHelper(newtestParseHelper);

				fullPath = R"(Content\ActionEventOperateParsing.json)";
				newparseCoordinator.Initialize();
				newparseCoordinator.DeserializeObjectFromFile(fullPath);

				auto newrawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(newwrapper.get());
				auto EventCreator = static_cast<ActionEvent*>(newrawWrapper->Data.get());

				EventCreator->Find("Subtype")->SetString(Operate);
				EventCreator->Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				auto& IntTable = *EventSub->Find("A");
				Assert::IsTrue(IntTable.GetInt() == 75);
				Assert::IsTrue(IntTable.GetInt(1) == 20);
				Assert::IsTrue(IntTable.GetInt(2) == 125);

				EventCreator->Update(GameState::CurrentTime);

				GameState::Queue.Update(GameState::CurrentTime);
				GameState::Queue.Update(GameState::CurrentTime);

				IntTable = *EventSub->Find("A");
				Assert::IsTrue(IntTable.GetInt() == 75);
				Assert::IsTrue(IntTable.GetInt(1) == 4);
				Assert::IsTrue(IntTable.GetInt(2) == 125);

				Factory<Scope>::Remove(ScopeTag);
				Factory<Scope>::Remove(ActionListTag);
				Factory<Scope>::Remove(ActionDivideTag);
				Factory<Scope>::Remove(ActionEventTag);
				Factory<Scope>::Remove(ReactionAttributedTag);
				Factory<Scope>::Remove(OperateReactionAttributedTag);

				Event<EventMessageAttributed>::TestClear();
				GameState::Queue.TestClear();
			}
		}

		TEST_METHOD(PrescribedAttributeOverwrite)
		{
			ActionEvent EventCreator;
			BigReactionAttributed EventSub;
			std::string basic = "Base";

			std::string apple = "Apples";
			std::string pear = "Pears";
			std::string grape = "Grapes";
			std::string banana = "Bananas";

			EventSub.Find("Subtype")->SetString(basic);
			EventCreator.Find("Subtype")->SetString(basic);
			EventCreator.Find("Delay")->SetInt(0);

			Assert::IsTrue(EventSub.Find(apple)!= nullptr);
			Assert::IsTrue(EventSub.Find(grape)!= nullptr);
			Assert::IsTrue(EventSub.Find(pear) != nullptr);
			Assert::IsTrue(EventSub.Find(banana) != nullptr);

			EventCreator.AppendAuxiliaryAttribute("Apples").PushBack(float(1.1f));
			EventCreator.AppendAuxiliaryAttribute("Grapes").PushBack(static_cast<size_t>(2));
			EventCreator.AppendAuxiliaryAttribute("Pears").PushBack(grape);
			EventCreator.AppendAuxiliaryAttribute("Bananas").PushBack(static_cast<size_t>(4));

			EventCreator.Update(GameState::CurrentTime);

			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);

			Assert::IsTrue(EventSub.Find(apple)->GetInt() == 0); //Assignment does not happen if they are not the same type. I think some protection is necessary for prescribed attributes, so changing the datum type is not allowed here.
			Assert::IsTrue(EventSub.Find(grape)->GetInt() == 2);
			Assert::IsTrue(EventSub.Find(pear)->GetInt() == 0);
			Assert::IsTrue(EventSub.Find(banana)->GetInt() == 4);

			Event<EventMessageAttributed>::Unsubscribe(&EventSub);
			GameState::Queue.Update(GameState::CurrentTime);
			GameState::Queue.Update(GameState::CurrentTime);

			Event<EventMessageAttributed>::TestClear();
			GameState::Queue.TestClear();
		}

	private: //Creates memory state screenshots to ensure no memory leaks in any test
		inline static _CrtMemState _startMemState;
	};
}