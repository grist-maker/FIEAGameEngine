#pragma once
#include "GameObject.h"
#include "RTTI.h"

namespace UnitTests
{
	class Pancake : public FieaGameEngine::GameObject
	{
		RTTI_DECLARATIONS(Pancake, FieaGameEngine::GameObject);
	public:
		Pancake();
		Pancake(const Pancake&) = default;
		Pancake(Pancake&&) = default;
		Pancake& operator=(const Pancake&) = default;
		Pancake& operator=(Pancake&&) = default;
		~Pancake() = default;
		static FieaGameEngine::Vector<FieaGameEngine::Signature> Signatures();

		void Update(const FieaGameEngine::GameTime& currentTime) override;
		float Stack;

	protected:
		std::string Berry = "Blueberry";
	};
	ConcreteFactory(Pancake, FieaGameEngine::Scope);
}