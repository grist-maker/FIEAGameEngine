#pragma once
#include "IJsonParseHelper.h"
#include "Scope.h"
#include "Stack.h"
#include "Factory.h"
#include <assert.h>

namespace FieaGameEngine
{
	/// <summary>
	/// A Table Parse Helper class that extends that provided from the IJsonParseHelper, with additional functionality and data members to allow it to parse a full
	/// JSON stream with any valid attribute in the proper grammar.
	/// </summary>
	class JsonTableParseHelper final : public IJsonParseHelper
	{
		RTTI_DECLARATIONS(JsonTableParseHelper, IJsonParseHelper);
	public:
		/// <summary>
		/// A master wrapper class that extends that provided from the JsonParseCoordinator, with additional functionality and data members to allow it to store a full
		/// JSON stream with any valid attribute in the proper grammar in a workable Scope form.
		/// </summary>
		class Wrapper : public JsonParseCoordinator::Wrapper
		{
			RTTI_DECLARATIONS(Wrapper, JsonParseCoordinator::Wrapper);
		public:
			Wrapper(std::shared_ptr<Scope> wrapperType);
			Wrapper() = default;
			/// <summary>
			/// Used to create a new, but uninitialized, wrapper of the same type as the caller. It will not have the same data as the caller, but allows simple and fast creation of a
			/// similar wrapper to more readily implement multithreading.
			/// </summary>
			/// <returns>A shared pointer to the newly created wrapper copy.</returns>
			std::shared_ptr<JsonParseCoordinator::Wrapper> Create() const override;
			/// <summary>
			/// Used to destroy the wrapper, freeing all of its allocated memory and unassociating it from the Coordinator that contained it. 
			/// </summary>
			virtual ~Wrapper() override;

			/// <summary>
			/// A shared pointer to a Scope. This will hold all attributes that are parsed from the Json source, with the specified keys and values as documented. This is a way to relay
			/// the relevant information to the user through a single, complete data structure that they can traverse via key searching for object data.
			/// </summary>
			std::shared_ptr<Scope> Data;
			/// <summary>
			/// The depth of the wrapper, that is, how many layers deep it is in the JSON data. Every internally nested attribute introduces a new layer of depth. After parsing all data,
			/// the depth is 0, as the wrapper is not inside of the Json content anymore.
			/// </summary>
			size_t TotalDepth = 0;
			/// <summary>
			/// A stack listing all Context Frames for the JSON data traversal. These frames represent positions, more specifically states, within the file as parsing proceeds. This allows
			/// the management of nested Scopes, a reliable method of keeping track of which area of the Data member and JSON file is being adjusted at any given time. Frames are pushed onto
			/// and popped off of the front of the stack, since whenever a nested scope is found, all of its members must be added before leaving its context. To do this, the Stack stores a pair
			/// including a pointer to the current scope, as well as the string key for the current attribute.
			/// </summary>
			Stack<std::pair<Scope*, const std::string*>> ContextFrame; //It has the current key value pair and Scope for context
		};

		virtual ~JsonTableParseHelper() override;
		/// <summary>
		/// A virtual function that is used to effectively "Clone" the calling helper. This actually creates an entirely new Helper object, ensuring that its also a JSONTableParseHelper
		/// wth the same capabilities, but without any helper stored data. This lets the original helper and its clone, now separate, be used in tandem by two concurrent parsing operations with a
		/// single function call.
		/// </summary>
		/// <returns>A shared_ptr to the newly constructed helper, ready for use by the new owner.</returns>
		std::shared_ptr<IJsonParseHelper> Create() const override;

		/// <summary>
		/// Initializes the Helper to prepare it for parsing a fresh JSON stream of data, which may include any number of primitives or scopes.
		/// </summary>
		void Initialize() override;
		/// <summary>
		/// The StartHandler function, called when a Helper attempts to parse JSON data. After performing necessary logical checks and attempting a parse if successful, it returns a boolean indicating whether or not
		/// the parse succeeded. If successful, the EndHandler function should be called by the Parse Coordinator.
		/// </summary>
		/// <param name="targetWrapper">The wrapper that the Helper works with to parse JSON data. If the two are compatible and the parse succeeds, parsed data may be stored inside the wrapper.</param>
		/// <param name="value">The string JSON::value pair that will be checked to be parsed.</param>
		/// <param name="isArray">Whether or not the values are stored in an array format.</param>
		/// <returns>Indicates whether or not the helper was able to parse the target data.</returns>
		bool StartHandler(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray) override;
		/// <summary>
		/// The EndHandler function, called when the helper's checks from StartHandler are complete and successful, its data is added, and the attribute's context may be left. This means there are no more nested
		/// attributes within the calling Json value, and the depth will decrease to match this.
		/// </summary>
		/// <param name="targetWrapper">The wrapper that the Helper will transer parsed JSON data to.</param>
		/// <param name="value">The string JSON::value pair that has been parsed.</param>
		/// <param name="isArray">Whether or not the Json::Value stores an array of values.</param>
		void EndHandler(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray) override;
		/// <summary>
		/// Used to "clean" the TableParseHelper following its use in a parsing operation. This cleans any residual, unnecessary data that may have been set in the Initialize call or subsequent parsing activity.
		/// </summary>
		void Cleanup() override;
		
		/// <summary>
		/// The StartHandler implementation targeted towards parsing Integer values, used for code organization and readability. It parses the JSON data under the assumption that it contains an int, as previous
		/// checks have indicated such. After performing more checks, the result is returned to the user as a success or failure.
		/// </summary>
		/// <param name="coordinator">The wrapper being manipulated by the current helper for data storage.</param>
		/// <param name="value">The JSON key value pair currently being parsed.</param>
		/// <param name="isArray">Whether or not the value stores an array of data to be parsed instead of a single value.</param>
		/// <returns>Whether or not the integer parse was successful.</returns>
		bool StartHandlerInt(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray);
		/// <summary>
		/// The StartHandler implementation targeted towards parsing Float values, used for code organization and readability. It parses the JSON data under the assumption that it contains a float, as previous
		/// checks have indicated such. After performing more checks, the result is returned to the user as a success or failure.
		/// </summary>
		/// <param name="coordinator">The wrapper being manipulated by the current helper for data storage.</param>
		/// <param name="value">The JSON key value pair currently being parsed.</param>
		/// <param name="isArray">Whether or not the value stores an array of data to be parsed instead of a single value.</param>
		/// <returns>Whether or not the float parse was successful.</returns>
		bool StartHandlerFloat(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray);
		/// <summary>
		/// The StartHandler implementation targeted towards parsing String values, used for code organization and readability. It parses the JSON data under the assumption that it contains a string, as previous
		/// checks have indicated such. After performing more checks, the result is returned to the user as a success or failure.
		/// </summary>
		/// <param name="coordinator">The wrapper being manipulated by the current helper for data storage.</param>
		/// <param name="value">The JSON key value pair currently being parsed.</param>
		/// <param name="isArray">Whether or not the value stores an array of data to be parsed instead of a single value.</param>
		/// <returns>Whether or not the string parse was successful.</returns>
		bool StartHandlerString(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray);
		/// <summary>
		/// The StartHandler implementation targeted towards parsing Vector4 values, used for code organization and readability. It parses the JSON data under the assumption that it contains a vector, as previous
		/// checks have indicated such. After performing more checks, the result is returned to the user as a success or failure.
		/// </summary>
		/// <param name="coordinator">The wrapper being manipulated by the current helper for data storage.</param>
		/// <param name="value">The JSON key value pair currently being parsed.</param>
		/// <param name="isArray">Whether or not the value stores an array of data to be parsed instead of a single value.</param>
		/// <returns>Whether or not the Vector4 parse was successful.</returns>
		bool StartHandlerVector(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray);
		/// <summary>
		/// The StartHandler implementation targeted towards parsing Matrix4x4 values, used for code organization and readability. It parses the JSON data under the assumption that it contains a Matrix, as previous
		/// checks have indicated such. After performing more checks, the result is returned to the user as a success or failure.
		/// </summary>
		/// <param name="coordinator">The wrapper being manipulated by the current helper for data storage.</param>
		/// <param name="value">The JSON key value pair currently being parsed.</param>
		/// <param name="isArray">Whether or not the value stores an array of data to be parsed instead of a single value.</param>
		/// <returns>Whether or not the matrix4x4 parse was successful.</returns>
		bool StartHandlerMatrix(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray);
		/// <summary>
		/// The StartHandler implementation targeted towards parsing Scope values, used for code organization and readability. It parses the JSON data under the assumption that it contains a scope, as previous
		/// checks have indicated such. After performing more checks, the result is returned to the user as a success or failure.
		/// </summary>
		/// <param name="coordinator">The wrapper being manipulated by the current helper for data storage.</param>
		/// <param name="value">The JSON key value pair currently being parsed.</param>
		/// <param name="isArray">Whether or not the value stores an array of data to be parsed instead of a single value.</param>
		/// <returns>Whether or not the scope parse was successful.</returns>
		bool StartHandlerTable(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray);

	private:
		/// <summary>
		/// The Type key used to indicate the attribute being parsed is an Integer.
		/// </summary>
		inline static const std::string IntegerKey{ "Integer" };
		/// <summary>
		/// The Type key used to indicate the attribute being parsed is a Float.
		/// </summary>
		inline static const std::string FloatKey{ "Float" };
		/// <summary>
		/// The Type key used to indicate the attribute being parsed is a String.
		/// </summary>
		inline static const std::string StringKey{ "String" };
		/// <summary>
		/// The Type key used to indicate the attribute being parsed is a Vector.
		/// </summary>
		inline static const std::string VectorKey{ "Vector" };
		/// <summary>
		/// The Type key used to indicate the attribute being parsed is a Matrix.
		/// </summary>
		inline static const std::string MatrixKey{ "Matrix" };
		/// <summary>
		/// The Type key used to indicate the attribute being parsed is a Table.
		/// </summary>
		inline static const std::string ScopeKey{ "Table" };
		/// <summary>
		/// Indicates whether or not a parse is in progress inside the helper. Used to prevent the use of the same helper at the same time during a multithreading application.
		/// </summary>
		bool ParsingData = false;
	};
}