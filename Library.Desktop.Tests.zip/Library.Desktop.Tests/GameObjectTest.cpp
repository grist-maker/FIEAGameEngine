#include "pch.h"
#include "CppUnitTest.h"
#include "Pancake.h"
#include "JsonTableParseHelper.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace UnitTests;
using namespace std;
using namespace std::string_literals;
using namespace chrono;

namespace UnitTests
{
	TEST_CLASS(GameObjectTests)
	{
		TEST_METHOD_INITIALIZE(Initialize) //Initial setup of memory state variables to allow memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&_startMemState);
			#endif
		}

		TEST_METHOD_CLEANUP(Cleanup) //Setup for memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);

			if (_CrtMemDifference(&diffMemState, &_startMemState,
				&endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
			#endif
		}

		TEST_METHOD(Constructor)
		{
			GameObject newObject;
			Pancake pancake;
			Pancake secondPancake;
			std::string strawberry = "Strawberry";

			Assert::AreNotEqual(newObject.TypeIdClass(), pancake.TypeIdClass());
			Assert::IsFalse(pancake == newObject);


			Assert::IsTrue(pancake.At("Berry")->Type() == Datum::DatumTypes::String);
			Assert::IsTrue(pancake == secondPancake);

			pancake.At("Berry")->SetString(strawberry);
			Assert::IsFalse(pancake == secondPancake);
		}

		TEST_METHOD(Update)
		{
			GameTime currentTime;
			GameObject newObject;

			newObject.At("Children")->GetScope()->Adopt(new Pancake(), "Child");
			auto pancake = newObject.At("Children")->GetScope()->Find("Child")->GetScope()->As<Pancake>();

			Assert::AreNotEqual(newObject.TypeIdClass(), pancake->TypeIdClass());

			newObject.Update(currentTime);
			Assert::IsTrue(pancake->Stack == 0.0f);

			currentTime.SetElapsedGameTime(100s);

			newObject.Update(currentTime);
			Assert::IsTrue(pancake->Stack == 100.0f);
		}

		TEST_METHOD(Equal)
		{
			GameTime currentTime;
			GameObject newObject;
			GameObject anotherNewObject;
			std::string cherry = "Cherry";

			newObject.At("Children")->GetScope()->Adopt(new Pancake(), "Child");
			auto pancake = newObject.At("Children")->GetScope()->Find("Child")->GetScope()->As<Pancake>();
			pancake->Find("Berry")->SetString(cherry);

			anotherNewObject.At("Children")->GetScope()->Adopt(new Pancake(), "Child");
			auto anotherPancake = anotherNewObject.At("Children")->GetScope()->Find("Child")->GetScope()->As<Pancake>();

			Assert::IsFalse(anotherNewObject == newObject);
			anotherPancake->Find("Berry")->SetString(cherry);
			Assert::IsTrue(anotherNewObject == newObject);

			GameObject finalNewObject;
			finalNewObject.At("Children")->GetScope()->Adopt(new Pancake(), "Child");
			finalNewObject.At("Children")->GetScope()->Adopt(new Pancake(), "SecondChild");
			auto finalPancake = finalNewObject.At("Children")->GetScope()->Find("Child")->GetScope()->As<Pancake>();
			finalPancake->Find("Berry")->SetString(cherry);

			Assert::IsFalse(anotherNewObject == finalNewObject);
			Assert::IsFalse(finalNewObject == newObject);

			anotherPancake->At("Children")->GetScope()->Adopt(new Pancake(), "Child");
			Assert::IsFalse(anotherNewObject == newObject);

			pancake->At("Children")->GetScope()->Adopt(new Pancake(), "Child");
			Assert::IsTrue(anotherNewObject == newObject);
		}

		TEST_METHOD(CopyConstruction)
		{
			GameTime currentTime;
			GameObject newObject;
			std::string cherry = "Cherry";
			std::string name = "NewObject";
			glm::vec4 position = glm::vec4(0, 1, 2, 3);
			glm::vec4 rotation = glm::vec4(1, 2, 3, 4);
			glm::vec4 scale = glm::vec4(2, 3, 4, 5);

			newObject.At("Children")->GetScope()->Adopt(new Pancake(), "Child");
			auto pancake = newObject.At("Children")->GetScope()->Find("Child")->GetScope()->As<Pancake>();
			newObject.At("Name")->SetString(name);
			newObject.At("Position")->SetVector(position);
			newObject.At("Rotation")->SetVector(rotation);
			newObject.At("Scale")->SetVector(scale);
			pancake->Find("Berry")->SetString(cherry);

			GameObject anotherNewObject = newObject;
			Assert::IsTrue(anotherNewObject.At("Name")->GetString() == name);
			Assert::IsTrue(anotherNewObject.At("Position")->GetVector() == position);
			Assert::IsTrue(anotherNewObject.At("Rotation")->GetVector() == rotation);
			Assert::IsTrue(anotherNewObject.At("Scale")->GetVector() == scale);

			Assert::IsTrue(anotherNewObject.At("Children")->GetScope()->Find("Child")->GetScope()->Find("Berry")->GetString() == cherry);
			Assert::IsTrue(newObject == anotherNewObject);
		}

		TEST_METHOD(CopyAssignment)
		{
			GameTime currentTime;
			GameObject newObject;
			GameObject anotherNewObject;
			std::string cherry = "Cherry";
			std::string name = "NewObject";
			glm::vec4 position = glm::vec4(0, 1, 2, 3);
			glm::vec4 rotation = glm::vec4(1, 2, 3, 4);
			glm::vec4 scale = glm::vec4(2, 3, 4, 5);

			newObject.At("Children")->GetScope()->Adopt(new Pancake(), "Child");
			auto pancake = newObject.At("Children")->GetScope()->Find("Child")->GetScope()->As<Pancake>();
			newObject.At("Name")->SetString(name);
			newObject.At("Position")->SetVector(position);
			newObject.At("Rotation")->SetVector(rotation);
			newObject.At("Scale")->SetVector(scale);
			pancake->Find("Berry")->SetString(cherry);

			anotherNewObject = newObject;
			Assert::IsTrue(anotherNewObject.At("Name")->GetString() == name);
			Assert::IsTrue(anotherNewObject.At("Position")->GetVector() == position);
			Assert::IsTrue(anotherNewObject.At("Rotation")->GetVector() == rotation);
			Assert::IsTrue(anotherNewObject.At("Scale")->GetVector() == scale);

			Assert::IsTrue(anotherNewObject.At("Children")->GetScope()->Find("Child")->GetScope()->Find("Berry")->GetString() == cherry);
			Assert::IsTrue(newObject == anotherNewObject);
		}

		TEST_METHOD(MoveConstruction)
		{
			GameTime currentTime;
			GameObject newObject;

			std::string cherry = "Cherry";
			std::string name = "NewObject";
			glm::vec4 position = glm::vec4(0, 1, 2, 3);
			glm::vec4 rotation = glm::vec4(1, 2, 3, 4);
			glm::vec4 scale = glm::vec4(2, 3, 4, 5);

			newObject.At("Children")->GetScope()->Adopt(new Pancake(), "Child");
			newObject.At("Name")->SetString(name);
			newObject.At("Position")->SetVector(position);
			newObject.At("Rotation")->SetVector(rotation);
			newObject.At("Scale")->SetVector(scale);
			auto pancake = newObject.At("Children")->GetScope()->Find("Child")->GetScope()->As<Pancake>();
			pancake->Find("Berry")->SetString(cherry);

			GameObject anotherNewObject = std::move(newObject);
			Assert::IsTrue(anotherNewObject.At("Name")->GetString() == name);
			Assert::IsTrue(anotherNewObject.At("Position")->GetVector() == position);
			Assert::IsTrue(anotherNewObject.At("Rotation")->GetVector() == rotation);
			Assert::IsTrue(anotherNewObject.At("Scale")->GetVector() == scale);

			Assert::IsTrue(anotherNewObject.At("Children")->GetScope()->Find("Child")->GetScope()->Find("Berry")->GetString() == cherry);
		}

		TEST_METHOD(MoveAssignment)
		{
			GameTime currentTime;
			GameObject newObject;
			GameObject anotherNewObject;

			std::string cherry = "Cherry";
			std::string name = "NewObject";
			glm::vec4 position = glm::vec4(0, 1, 2, 3);
			glm::vec4 rotation = glm::vec4(1, 2, 3, 4);
			glm::vec4 scale = glm::vec4(2, 3, 4, 5);

			newObject.At("Children")->GetScope()->Adopt(new Pancake(), "Child");
			newObject.At("Name")->SetString(name);
			newObject.At("Position")->SetVector(position);
			newObject.At("Rotation")->SetVector(rotation);
			newObject.At("Scale")->SetVector(scale);
			auto pancake = newObject.At("Children")->GetScope()->Find("Child")->GetScope()->As<Pancake>();
			pancake->Find("Berry")->SetString(cherry);

			anotherNewObject = std::move(newObject);
			Assert::IsTrue(anotherNewObject.At("Name")->GetString() == name);
			Assert::IsTrue(anotherNewObject.At("Position")->GetVector() == position);
			Assert::IsTrue(anotherNewObject.At("Rotation")->GetVector() == rotation);
			Assert::IsTrue(anotherNewObject.At("Scale")->GetVector() == scale);

			Assert::IsTrue(anotherNewObject.At("Children")->GetScope()->Find("Child")->GetScope()->Find("Berry")->GetString() == cherry);
		}

		TEST_METHOD(Parser)
		{
			std::string ScopeTag = "Scope";
			std::string GameObjectTag = "GameObject";
			std::string PancakeTag = "Pancake";

			Factory<Scope>::Add(std::make_unique<ScopeFactory>());
			Factory<Scope>::Add(std::make_unique<GameObjectFactory>());
			Factory<Scope>::Add(std::make_unique<PancakeFactory>());

			std::string fullPath = R"(Content\TestGameObject.json)";
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<GameObject>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			auto pancakeChild = rawWrapper->Data->Find("Children")->GetScope()->Find("FirstChild");

			Assert::IsNotNull(pancakeChild);
			Assert::IsTrue(pancakeChild->GetScope()->TypeIdInstance() == Pancake::TypeIdClass());
			Assert::IsTrue(pancakeChild->GetScope()->Find("Berry")->GetString() == "Strawberry");

			Assert::IsTrue(rawWrapper->Data->TypeIdInstance() == GameObject::TypeIdClass());
			Assert::IsTrue(rawWrapper->Data->Find("Name")->GetString() == "GameName");
			Assert::IsTrue(rawWrapper->Data->Find("Position")->GetVector() == glm::vec4(0, 1, 2, 3));
			Assert::IsTrue(rawWrapper->Data->Find("Rotation")->GetVector() == glm::vec4(1, 2, 3, 4));
			Assert::IsTrue(rawWrapper->Data->Find("Scale")->GetVector() == glm::vec4(2, 3, 4, 5));

			Factory<Scope>::Remove(ScopeTag);
			Factory<Scope>::Remove(GameObjectTag);
			Factory<Scope>::Remove(PancakeTag);
		}
	private: //Creates memory state screenshots to ensure no memory leaks in any test
		inline static _CrtMemState _startMemState;
	};
}