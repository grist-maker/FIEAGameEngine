#include "pch.h"
#include "CppUnitTest.h"
#include "Foo.h"
#include "ToStringSpecializations.h"
#include "AttributedFoo.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace UnitTests;
using namespace std;
using namespace std::string_literals;

/// <summary>
/// Tests to exercise the Attributed class, via the defined AttributedFoo object type that contains attributes of all datum types.
/// </summary>
namespace FieaGameEngine
{
	TEST_CLASS(AttributedTests)
	{
		TEST_METHOD_INITIALIZE(Initialize) //Initial setup of memory state variables to allow memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&_startMemState);
			#endif
		}

		TEST_METHOD_CLEANUP(Cleanup) //Setup for memory leak testing
		{

			#if defined(DEBUG) || defined(_DEBUG)
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);

			if (_CrtMemDifference(&diffMemState, &_startMemState,
				&endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
			#endif
		}

		TEST_METHOD(Constructor)
		{
			AttributedFoo newFoo;

			Assert::IsTrue(newFoo.At("ExternalInt")->Type() == Datum::DatumTypes::Integer);
			Assert::IsTrue(newFoo.At("ExternalFloat")->Type() == Datum::DatumTypes::Float);
			Assert::IsTrue(newFoo.At("ExternalString")->Type() == Datum::DatumTypes::String);
			Assert::IsTrue(newFoo.At("ExternalVector")->Type() == Datum::DatumTypes::Vector);
			Assert::IsTrue(newFoo.At("ExternalMatrix")->Type() == Datum::DatumTypes::Matrix);
			Assert::IsTrue(newFoo.At("ExternalIntArray")->Type() == Datum::DatumTypes::Integer);
			Assert::IsTrue(newFoo.At("ExternalFloatArray")->Type() == Datum::DatumTypes::Float);
			Assert::IsTrue(newFoo.At("ExternalStringArray")->Type() == Datum::DatumTypes::String);
			Assert::IsTrue(newFoo.At("ExternalVectorArray")->Type() == Datum::DatumTypes::Vector);
			Assert::IsTrue(newFoo.At("ExternalMatrixArray")->Type() == Datum::DatumTypes::Matrix);
			Assert::IsTrue(newFoo.At("NestedScope")->Type() == Datum::DatumTypes::Table);
			Assert::IsTrue(newFoo.At("NestedScopeArray")->Type() == Datum::DatumTypes::Table);

			Assert::IsTrue(newFoo.At("ExternalInt")->Size() == 1);
			Assert::IsTrue(newFoo.At("ExternalFloat")->Size() == 1);
			Assert::IsTrue(newFoo.At("ExternalString")->Size() == 1);
			Assert::IsTrue(newFoo.At("ExternalVector")->Size() == 1);
			Assert::IsTrue(newFoo.At("ExternalMatrix")->Size() == 1);
			Assert::IsTrue(newFoo.At("ExternalIntArray")->Size() == 3);
			Assert::IsTrue(newFoo.At("ExternalFloatArray")->Size() == 3);
			Assert::IsTrue(newFoo.At("ExternalStringArray")->Size() == 3);
			Assert::IsTrue(newFoo.At("ExternalVectorArray")->Size() == 3);
			Assert::IsTrue(newFoo.At("ExternalMatrixArray")->Size() == 3);
			Assert::IsTrue(newFoo.At("NestedScope")->Size() == 1);
			Assert::IsTrue(newFoo.At("NestedScopeArray")->Capacity() == 3);
		}

		TEST_METHOD(CopyConstructor)
		{
			std::string Five = "F";
			glm::vec4 FiveVector = { 5,5,5,5 };
			glm::mat4 FiveMatrix = { 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 };

			AttributedFoo newFoo;
			newFoo.At("ExternalInt")->SetInt(5);
			newFoo.At("ExternalFloat")->SetFloat(5.5f);
			newFoo.At("ExternalString")->SetString(Five);
			newFoo.At("ExternalVector")->SetVector(FiveVector);
			newFoo.At("ExternalMatrix")->SetMatrix(FiveMatrix);

			newFoo.At("ExternalIntArray")->SetInt(5);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f);
			newFoo.At("ExternalStringArray")->SetString(Five);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix);
			
			newFoo.At("ExternalIntArray")->SetInt(5, 1);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f, 1);
			newFoo.At("ExternalStringArray")->SetString(Five, 1);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector, 1);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix, 1);

			newFoo.At("ExternalIntArray")->SetInt(5, 2);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f, 2);
			newFoo.At("ExternalStringArray")->SetString(Five, 2);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector, 2);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix, 2);
			
			newFoo.At("NestedScope")->GetScope()->Append("NewNestedInt");
			newFoo.At("NestedScope")->GetScope()->At(0).PushBack(static_cast<size_t>(5));

			newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedString");
			newFoo.At("NestedScopeArray")->GetScope()->At(0).PushBack(Five);

			auto SecondNestedArray = newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedFloat");
			newFoo.At("NestedScopeArray")->GetScope()->At(1).PushBack(5.5f);

			auto ThirdNestedArray = newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedMatrix");
			newFoo.At("NestedScopeArray")->GetScope()->At(2).PushBack(FiveMatrix);

			AttributedFoo copy = newFoo;

			Assert::IsFalse(copy.At("this")->GetRTTI() == newFoo.At("this")->GetRTTI());
			Assert::IsTrue(copy.At("ExternalInt")->GetInt() == 5);
			Assert::IsTrue(copy.At("ExternalFloat")->GetFloat() == 5.5f);
			Assert::IsTrue(copy.At("ExternalString")->GetString() == Five);
			Assert::IsTrue(copy.At("ExternalVector")->GetVector() == FiveVector);
			Assert::IsTrue(copy.At("ExternalMatrix")->GetMatrix() == FiveMatrix);

			Assert::IsTrue(copy.At("ExternalIntArray")->GetInt() == 5);
			Assert::IsTrue(copy.At("ExternalFloatArray")->GetFloat() == 5.5f);
			Assert::IsTrue(copy.At("ExternalStringArray")->GetString() == Five);
			Assert::IsTrue(copy.At("ExternalVectorArray")->GetVector() == FiveVector);
			Assert::IsTrue(copy.At("ExternalMatrixArray")->GetMatrix() == FiveMatrix);

			Assert::IsTrue(copy.At("ExternalIntArray")->GetInt(1) == 5);
			Assert::IsTrue(copy.At("ExternalFloatArray")->GetFloat(1) == 5.5f);
			Assert::IsTrue(copy.At("ExternalStringArray")->GetString(1) == Five);
			Assert::IsTrue(copy.At("ExternalVectorArray")->GetVector(1) == FiveVector);
			Assert::IsTrue(copy.At("ExternalMatrixArray")->GetMatrix(1) == FiveMatrix);

			Assert::IsTrue(copy.At("ExternalIntArray")->GetInt(2) == 5);
			Assert::IsTrue(copy.At("ExternalFloatArray")->GetFloat(2) == 5.5f);
			Assert::IsTrue(copy.At("ExternalStringArray")->GetString(2) == Five);
			Assert::IsTrue(copy.At("ExternalVectorArray")->GetVector(2) == FiveVector);
			Assert::IsTrue(copy.At("ExternalMatrixArray")->GetMatrix(2) == FiveMatrix);

			Assert::IsTrue(copy.At("NestedScope")->GetScope()->Find("NewNestedInt")->GetInt() == 5);
			Assert::IsTrue(copy.At("NestedScopeArray")->GetScope()->Find("NewNestedString")->GetString() == Five);
			Assert::IsTrue(copy.At("NestedScopeArray")->GetScope()->Find("NewNestedFloat")->GetFloat() == 5.5f);
			Assert::IsTrue(copy.At("NestedScopeArray")->GetScope()->Find("NewNestedMatrix")->GetMatrix() == FiveMatrix);
		}

		TEST_METHOD(CopyAssignment)
		{
			std::string Five = "F";
			glm::vec4 FiveVector = { 5,5,5,5 };
			glm::mat4 FiveMatrix = { 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 };

			AttributedFoo newFoo;
			newFoo.At("ExternalInt")->SetInt(5);
			newFoo.At("ExternalFloat")->SetFloat(5.5f);
			newFoo.At("ExternalString")->SetString(Five);
			newFoo.At("ExternalVector")->SetVector(FiveVector);
			newFoo.At("ExternalMatrix")->SetMatrix(FiveMatrix);

			newFoo.At("ExternalIntArray")->SetInt(5);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f);
			newFoo.At("ExternalStringArray")->SetString(Five);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix);

			newFoo.At("ExternalIntArray")->SetInt(5, 1);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f, 1);
			newFoo.At("ExternalStringArray")->SetString(Five, 1);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector, 1);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix, 1);

			newFoo.At("ExternalIntArray")->SetInt(5, 2);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f, 2);
			newFoo.At("ExternalStringArray")->SetString(Five, 2);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector, 2);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix, 2);

			newFoo.At("NestedScope")->GetScope()->Append("NewNestedInt");
			newFoo.At("NestedScope")->GetScope()->At(0).PushBack(static_cast<size_t>(5));

			newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedString");
			newFoo.At("NestedScopeArray")->GetScope()->At(0).PushBack(Five);

			auto SecondNestedArray = newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedFloat");
			newFoo.At("NestedScopeArray")->GetScope()->At(1).PushBack(5.5f);

			auto ThirdNestedArray = newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedMatrix");
			newFoo.At("NestedScopeArray")->GetScope()->At(2).PushBack(FiveMatrix);

			AttributedFoo copy;
			copy = newFoo;

			Assert::IsFalse(copy.At("this")->GetRTTI() == newFoo.At("this")->GetRTTI());
			Assert::IsTrue(copy.At("ExternalInt")->GetInt() == 5);
			Assert::IsTrue(copy.At("ExternalFloat")->GetFloat() == 5.5f);
			Assert::IsTrue(copy.At("ExternalString")->GetString() == Five);
			Assert::IsTrue(copy.At("ExternalVector")->GetVector() == FiveVector);
			Assert::IsTrue(copy.At("ExternalMatrix")->GetMatrix() == FiveMatrix);

			Assert::IsTrue(copy.At("ExternalIntArray")->GetInt() == 5);
			Assert::IsTrue(copy.At("ExternalFloatArray")->GetFloat() == 5.5f);
			Assert::IsTrue(copy.At("ExternalStringArray")->GetString() == Five);
			Assert::IsTrue(copy.At("ExternalVectorArray")->GetVector() == FiveVector);
			Assert::IsTrue(copy.At("ExternalMatrixArray")->GetMatrix() == FiveMatrix);

			Assert::IsTrue(copy.At("ExternalIntArray")->GetInt(1) == 5);
			Assert::IsTrue(copy.At("ExternalFloatArray")->GetFloat(1) == 5.5f);
			Assert::IsTrue(copy.At("ExternalStringArray")->GetString(1) == Five);
			Assert::IsTrue(copy.At("ExternalVectorArray")->GetVector(1) == FiveVector);
			Assert::IsTrue(copy.At("ExternalMatrixArray")->GetMatrix(1) == FiveMatrix);

			Assert::IsTrue(copy.At("ExternalIntArray")->GetInt(2) == 5);
			Assert::IsTrue(copy.At("ExternalFloatArray")->GetFloat(2) == 5.5f);
			Assert::IsTrue(copy.At("ExternalStringArray")->GetString(2) == Five);
			Assert::IsTrue(copy.At("ExternalVectorArray")->GetVector(2) == FiveVector);
			Assert::IsTrue(copy.At("ExternalMatrixArray")->GetMatrix(2) == FiveMatrix);

			Assert::IsTrue(copy.At("NestedScope")->GetScope()->Find("NewNestedInt")->GetInt() == 5);
			Assert::IsTrue(copy.At("NestedScopeArray")->GetScope()->Find("NewNestedString")->GetString() == Five);
			Assert::IsTrue(copy.At("NestedScopeArray")->GetScope()->Find("NewNestedFloat")->GetFloat() == 5.5f);
			Assert::IsTrue(copy.At("NestedScopeArray")->GetScope()->Find("NewNestedMatrix")->GetMatrix() == FiveMatrix);

			copy.At("ExternalInt")->SetInt(4);
			Assert::IsTrue(copy.At("ExternalInt")->GetInt() == 4);
			Assert::IsTrue(newFoo.At("ExternalInt")->GetInt() == 5);

			copy.At("NestedScope")->GetScope()->Find("NewNestedInt")->SetInt(4);
			Assert::IsTrue(copy.At("NestedScope")->GetScope()->Find("NewNestedInt")->GetInt() == 4);
			Assert::IsTrue(newFoo.At("NestedScope")->GetScope()->Find("NewNestedInt")->GetInt() == 5);

			copy = newFoo;

			Assert::IsTrue(copy.At("ExternalInt")->GetInt() == 5);
			Assert::IsTrue(copy.At("ExternalFloat")->GetFloat() == 5.5f);
			Assert::IsTrue(copy.At("ExternalString")->GetString() == Five);
			Assert::IsTrue(copy.At("ExternalVector")->GetVector() == FiveVector);
			Assert::IsTrue(copy.At("ExternalMatrix")->GetMatrix() == FiveMatrix);

			Assert::IsTrue(copy.At("ExternalIntArray")->GetInt() == 5);
			Assert::IsTrue(copy.At("ExternalFloatArray")->GetFloat() == 5.5f);
			Assert::IsTrue(copy.At("ExternalStringArray")->GetString() == Five);
			Assert::IsTrue(copy.At("ExternalVectorArray")->GetVector() == FiveVector);
			Assert::IsTrue(copy.At("ExternalMatrixArray")->GetMatrix() == FiveMatrix);

			Assert::IsTrue(copy.At("ExternalIntArray")->GetInt(1) == 5);
			Assert::IsTrue(copy.At("ExternalFloatArray")->GetFloat(1) == 5.5f);
			Assert::IsTrue(copy.At("ExternalStringArray")->GetString(1) == Five);
			Assert::IsTrue(copy.At("ExternalVectorArray")->GetVector(1) == FiveVector);
			Assert::IsTrue(copy.At("ExternalMatrixArray")->GetMatrix(1) == FiveMatrix);

			Assert::IsTrue(copy.At("ExternalIntArray")->GetInt(2) == 5);
			Assert::IsTrue(copy.At("ExternalFloatArray")->GetFloat(2) == 5.5f);
			Assert::IsTrue(copy.At("ExternalStringArray")->GetString(2) == Five);
			Assert::IsTrue(copy.At("ExternalVectorArray")->GetVector(2) == FiveVector);
			Assert::IsTrue(copy.At("ExternalMatrixArray")->GetMatrix(2) == FiveMatrix);

			Assert::IsTrue(copy.At("NestedScope")->GetScope()->Find("NewNestedInt")->GetInt() == 5);
			Assert::IsTrue(copy.At("NestedScopeArray")->GetScope()->Find("NewNestedString")->GetString() == Five);
			Assert::IsTrue(copy.At("NestedScopeArray")->GetScope()->Find("NewNestedFloat")->GetFloat() == 5.5f);
			Assert::IsTrue(copy.At("NestedScopeArray")->GetScope()->Find("NewNestedMatrix")->GetMatrix() == FiveMatrix);
		}

		TEST_METHOD(MoveConstructor)
		{
			std::string Five = "F";
			glm::vec4 FiveVector = { 5,5,5,5 };
			glm::mat4 FiveMatrix = { 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 };

			AttributedFoo newFoo;
			newFoo.At("ExternalInt")->SetInt(5);
			newFoo.At("ExternalFloat")->SetFloat(5.5f);
			newFoo.At("ExternalString")->SetString(Five);
			newFoo.At("ExternalVector")->SetVector(FiveVector);
			newFoo.At("ExternalMatrix")->SetMatrix(FiveMatrix);

			newFoo.At("ExternalIntArray")->SetInt(5);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f);
			newFoo.At("ExternalStringArray")->SetString(Five);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix);

			newFoo.At("ExternalIntArray")->SetInt(5, 1);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f, 1);
			newFoo.At("ExternalStringArray")->SetString(Five, 1);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector, 1);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix, 1);

			newFoo.At("ExternalIntArray")->SetInt(5, 2);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f, 2);
			newFoo.At("ExternalStringArray")->SetString(Five, 2);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector, 2);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix, 2);

			newFoo.At("NestedScope")->GetScope()->Append("NewNestedInt");
			newFoo.At("NestedScope")->GetScope()->At(0).PushBack(static_cast<size_t>(5));

			newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedString");
			newFoo.At("NestedScopeArray")->GetScope()->At(0).PushBack(Five);

			auto SecondNestedArray = newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedFloat");
			newFoo.At("NestedScopeArray")->GetScope()->At(1).PushBack(5.5f);

			auto ThirdNestedArray = newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedMatrix");
			newFoo.At("NestedScopeArray")->GetScope()->At(2).PushBack(FiveMatrix);

			AttributedFoo move = std::move(newFoo);
			Assert::IsTrue(move.At("ExternalInt")->GetInt() == static_cast<size_t>(5));
			Assert::IsTrue(move.At("ExternalFloat")->GetFloat() == 5.5f);
			Assert::IsTrue(move.At("ExternalString")->GetString() == Five);
			Assert::IsTrue(move.At("ExternalVector")->GetVector() == FiveVector);
			Assert::IsTrue(move.At("ExternalMatrix")->GetMatrix() == FiveMatrix);

			Assert::IsTrue(move.At("ExternalIntArray")->GetInt() == static_cast<size_t>(5));
			Assert::IsTrue(move.At("ExternalFloatArray")->GetFloat() == 5.5f);
			Assert::IsTrue(move.At("ExternalStringArray")->GetString() == Five);
			Assert::IsTrue(move.At("ExternalVectorArray")->GetVector() == FiveVector);
			Assert::IsTrue(move.At("ExternalMatrixArray")->GetMatrix() == FiveMatrix);

			Assert::IsTrue(move.At("ExternalIntArray")->GetInt(1) == 5);
			Assert::IsTrue(move.At("ExternalFloatArray")->GetFloat(1) == 5.5f);
			Assert::IsTrue(move.At("ExternalStringArray")->GetString(1) == Five);
			Assert::IsTrue(move.At("ExternalVectorArray")->GetVector(1) == FiveVector);
			Assert::IsTrue(move.At("ExternalMatrixArray")->GetMatrix(1) == FiveMatrix);

			Assert::IsTrue(move.At("ExternalIntArray")->GetInt(2) == 5);
			Assert::IsTrue(move.At("ExternalFloatArray")->GetFloat(2) == 5.5f);
			Assert::IsTrue(move.At("ExternalStringArray")->GetString(2) == Five);
			Assert::IsTrue(move.At("ExternalVectorArray")->GetVector(2) == FiveVector);
			Assert::IsTrue(move.At("ExternalMatrixArray")->GetMatrix(2) == FiveMatrix);

			Assert::IsTrue(move.At("NestedScope")->GetScope()->Find("NewNestedInt")->GetInt() == 5);
			Assert::IsTrue(move.At("NestedScopeArray")->GetScope()->Find("NewNestedString")->GetString() == Five);
			Assert::IsTrue(move.At("NestedScopeArray")->GetScope()->Find("NewNestedFloat")->GetFloat() == 5.5f);
			Assert::IsTrue(move.At("NestedScopeArray")->GetScope()->Find("NewNestedMatrix")->GetMatrix() == FiveMatrix);
		}

		TEST_METHOD(MoveAssignment)
		{
			std::string Five = "F";
			glm::vec4 FiveVector = { 5,5,5,5 };
			glm::mat4 FiveMatrix = { 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 };

			AttributedFoo newFoo;
			newFoo.At("ExternalInt")->SetInt(static_cast<size_t>(5));
			newFoo.At("ExternalFloat")->SetFloat(5.5f);
			newFoo.At("ExternalString")->SetString(Five);
			newFoo.At("ExternalVector")->SetVector(FiveVector);
			newFoo.At("ExternalMatrix")->SetMatrix(FiveMatrix);

			newFoo.At("ExternalIntArray")->SetInt(static_cast<size_t>(5));
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f);
			newFoo.At("ExternalStringArray")->SetString(Five);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix);

			newFoo.At("ExternalIntArray")->SetInt(static_cast<size_t>(5), 1);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f, 1);
			newFoo.At("ExternalStringArray")->SetString(Five, 1);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector, 1);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix, 1);

			newFoo.At("ExternalIntArray")->SetInt(static_cast<size_t>(5), 2);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f, 2);
			newFoo.At("ExternalStringArray")->SetString(Five, 2);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector, 2);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix, 2);

			newFoo.At("NestedScope")->GetScope()->Append("NewNestedInt");
			newFoo.At("NestedScope")->GetScope()->At(0).PushBack(static_cast<size_t>(5));

			newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedString");
			newFoo.At("NestedScopeArray")->GetScope()->At(0).PushBack(Five);

			auto SecondNestedArray = newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedFloat");
			newFoo.At("NestedScopeArray")->GetScope()->At(1).PushBack(5.5f);

			auto ThirdNestedArray = newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedMatrix");
			newFoo.At("NestedScopeArray")->GetScope()->At(2).PushBack(FiveMatrix);

			AttributedFoo move;
			move = std::move(newFoo);

			Assert::IsTrue(move.At("ExternalInt")->GetInt() == static_cast<size_t>(5));
			Assert::IsTrue(move.At("ExternalFloat")->GetFloat() == 5.5f);
			Assert::IsTrue(move.At("ExternalString")->GetString() == Five);
			Assert::IsTrue(move.At("ExternalVector")->GetVector() == FiveVector);
			Assert::IsTrue(move.At("ExternalMatrix")->GetMatrix() == FiveMatrix);

			Assert::IsTrue(move.At("ExternalIntArray")->GetInt() == static_cast<size_t>(5));
			Assert::IsTrue(move.At("ExternalFloatArray")->GetFloat() == 5.5f);
			Assert::IsTrue(move.At("ExternalStringArray")->GetString() == Five);
			Assert::IsTrue(move.At("ExternalVectorArray")->GetVector() == FiveVector);
			Assert::IsTrue(move.At("ExternalMatrixArray")->GetMatrix() == FiveMatrix);

			Assert::IsTrue(move.At("ExternalIntArray")->GetInt(1) == static_cast<size_t>(5));
			Assert::IsTrue(move.At("ExternalFloatArray")->GetFloat(1) == 5.5f);
			Assert::IsTrue(move.At("ExternalStringArray")->GetString(1) == Five);
			Assert::IsTrue(move.At("ExternalVectorArray")->GetVector(1) == FiveVector);
			Assert::IsTrue(move.At("ExternalMatrixArray")->GetMatrix(1) == FiveMatrix);

			Assert::IsTrue(move.At("ExternalIntArray")->GetInt(2) == static_cast<size_t>(5));
			Assert::IsTrue(move.At("ExternalFloatArray")->GetFloat(2) == 5.5f);
			Assert::IsTrue(move.At("ExternalStringArray")->GetString(2) == Five);
			Assert::IsTrue(move.At("ExternalVectorArray")->GetVector(2) == FiveVector);
			Assert::IsTrue(move.At("ExternalMatrixArray")->GetMatrix(2) == FiveMatrix);

			Assert::IsTrue(move.At("NestedScope")->GetScope()->Find("NewNestedInt")->GetInt() == static_cast<size_t>(5));
			Assert::IsTrue(move.At("NestedScopeArray")->GetScope()->Find("NewNestedString")->GetString() == Five);
			Assert::IsTrue(move.At("NestedScopeArray")->GetScope()->Find("NewNestedFloat")->GetFloat() == 5.5f);
			Assert::IsTrue(move.At("NestedScopeArray")->GetScope()->Find("NewNestedMatrix")->GetMatrix() == FiveMatrix);
		}
		
		TEST_METHOD(IsAttribute)
		{
			AttributedFoo newFoo;

			newFoo.AppendAuxiliaryAttribute("BrandNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AnotherNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AdditionalNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("WhollyNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("FinalNewAttribute!");

			Assert::IsTrue(newFoo.IsAttribute("ExternalInt"));
			Assert::IsTrue(newFoo.IsAttribute("ExternalFloat"));
			Assert::IsTrue(newFoo.IsAttribute("ExternalString"));
			Assert::IsTrue(newFoo.IsAttribute("ExternalMatrix"));
			Assert::IsTrue(newFoo.IsAttribute("ExternalVector"));

			Assert::IsTrue(newFoo.IsAttribute("ExternalIntArray"));
			Assert::IsTrue(newFoo.IsAttribute("ExternalFloatArray"));
			Assert::IsTrue(newFoo.IsAttribute("ExternalStringArray"));
			Assert::IsTrue(newFoo.IsAttribute("ExternalMatrixArray"));
			Assert::IsTrue(newFoo.IsAttribute("ExternalVectorArray"));

			Assert::IsTrue(newFoo.IsAttribute("NestedScope"));
			Assert::IsTrue(newFoo.IsAttribute("NestedScopeArray"));

			Assert::IsTrue(newFoo.IsAttribute("BrandNewAttribute!"));
			Assert::IsTrue(newFoo.IsAttribute("AnotherNewAttribute!"));
			Assert::IsTrue(newFoo.IsAttribute("AdditionalNewAttribute!"));
			Assert::IsTrue(newFoo.IsAttribute("WhollyNewAttribute!"));
			Assert::IsTrue(newFoo.IsAttribute("FinalNewAttribute!"));

			Assert::IsFalse(newFoo.IsAttribute("AnotherNewAttribute"));
			Assert::IsFalse(newFoo.IsAttribute("NewAttribute"));
			Assert::IsFalse(newFoo.IsAttribute("newishAttribute"));
			Assert::IsFalse(newFoo.IsAttribute("another"));
		}

		TEST_METHOD(IsPrescribedAttribute)
		{
			AttributedFoo newFoo;

			newFoo.AppendAuxiliaryAttribute("BrandNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AnotherNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AdditionalNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("WhollyNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("FinalNewAttribute!");

			Assert::IsTrue(newFoo.IsPrescribedAttribute("ExternalInt"));
			Assert::IsTrue(newFoo.IsPrescribedAttribute("ExternalFloat"));
			Assert::IsTrue(newFoo.IsPrescribedAttribute("ExternalString"));
			Assert::IsTrue(newFoo.IsPrescribedAttribute("ExternalMatrix"));
			Assert::IsTrue(newFoo.IsPrescribedAttribute("ExternalVector"));

			Assert::IsTrue(newFoo.IsPrescribedAttribute("ExternalIntArray"));
			Assert::IsTrue(newFoo.IsPrescribedAttribute("ExternalFloatArray"));
			Assert::IsTrue(newFoo.IsPrescribedAttribute("ExternalStringArray"));
			Assert::IsTrue(newFoo.IsPrescribedAttribute("ExternalMatrixArray"));
			Assert::IsTrue(newFoo.IsPrescribedAttribute("ExternalVectorArray"));

			Assert::IsTrue(newFoo.IsPrescribedAttribute("NestedScope"));
			Assert::IsTrue(newFoo.IsPrescribedAttribute("NestedScopeArray"));

			Assert::IsFalse(newFoo.IsPrescribedAttribute("BrandNewAttribute!"));
			Assert::IsFalse(newFoo.IsPrescribedAttribute("AnotherNewAttribute!"));
			Assert::IsFalse(newFoo.IsPrescribedAttribute("AdditionalNewAttribute!"));
			Assert::IsFalse(newFoo.IsPrescribedAttribute("WhollyNewAttribute!"));
			Assert::IsFalse(newFoo.IsPrescribedAttribute("FinalNewAttribute!"));

			Assert::IsFalse(newFoo.IsPrescribedAttribute("AnotherNewAttribute"));
			Assert::IsFalse(newFoo.IsPrescribedAttribute("NewAttribute"));
			Assert::IsFalse(newFoo.IsPrescribedAttribute("newishAttribute"));
			Assert::IsFalse(newFoo.IsPrescribedAttribute("another"));
		}

		TEST_METHOD(IsAuxiliaryAttribute)
		{
			AttributedFoo newFoo;

			newFoo.AppendAuxiliaryAttribute("BrandNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AnotherNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AdditionalNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("WhollyNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("FinalNewAttribute!");

			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("ExternalInt"));
			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("ExternalFloat"));
			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("ExternalString"));
			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("ExternalMatrix"));
			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("ExternalVector"));

			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("ExternalIntArray"));
			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("ExternalFloatArray"));
			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("ExternalStringArray"));
			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("ExternalMatrixArray"));
			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("ExternalVectorArray"));

			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("NestedScope"));
			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("NestedScopeArray"));

			Assert::IsTrue(newFoo.IsAuxiliaryAttribute("BrandNewAttribute!"));
			Assert::IsTrue(newFoo.IsAuxiliaryAttribute("AnotherNewAttribute!"));
			Assert::IsTrue(newFoo.IsAuxiliaryAttribute("AdditionalNewAttribute!"));
			Assert::IsTrue(newFoo.IsAuxiliaryAttribute("WhollyNewAttribute!"));
			Assert::IsTrue(newFoo.IsAuxiliaryAttribute("FinalNewAttribute!"));

			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("AnotherNewAttribute"));
			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("NewAttribute"));
			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("newishAttribute"));
			Assert::IsFalse(newFoo.IsAuxiliaryAttribute("another"));
		}

		TEST_METHOD(AppendAuxiliaryAttribute)
		{
			AttributedFoo newFoo;

			newFoo.AppendAuxiliaryAttribute("BrandNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AnotherNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AdditionalNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("WhollyNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("FinalNewAttribute!");

			Assert::IsTrue(newFoo.IsAttribute("BrandNewAttribute!"));
			Assert::IsTrue(newFoo.IsAttribute("AnotherNewAttribute!"));
			Assert::IsTrue(newFoo.IsAttribute("AdditionalNewAttribute!"));
			Assert::IsTrue(newFoo.IsAttribute("WhollyNewAttribute!"));
			Assert::IsTrue(newFoo.IsAttribute("FinalNewAttribute!"));

			Assert::IsTrue(newFoo.IsAuxiliaryAttribute("BrandNewAttribute!"));
			Assert::IsTrue(newFoo.IsAuxiliaryAttribute("AnotherNewAttribute!"));
			Assert::IsTrue(newFoo.IsAuxiliaryAttribute("AdditionalNewAttribute!"));
			Assert::IsTrue(newFoo.IsAuxiliaryAttribute("WhollyNewAttribute!"));
			Assert::IsTrue(newFoo.IsAuxiliaryAttribute("FinalNewAttribute!"));

			Assert::ExpectException<std::runtime_error>([&newFoo]() {newFoo.AppendAuxiliaryAttribute("ExternalInt"); });
			Assert::ExpectException<std::runtime_error>([&newFoo]() {newFoo.AppendAuxiliaryAttribute("ExternalFloat"); });
			Assert::ExpectException<std::runtime_error>([&newFoo]() {newFoo.AppendAuxiliaryAttribute("ExternalString"); });
			Assert::ExpectException<std::runtime_error>([&newFoo]() {newFoo.AppendAuxiliaryAttribute("ExternalMatrix"); });
			Assert::ExpectException<std::runtime_error>([&newFoo]() {newFoo.AppendAuxiliaryAttribute("ExternalVector"); });
			Assert::ExpectException<std::runtime_error>([&newFoo]() {newFoo.AppendAuxiliaryAttribute("ExternalIntArray"); });
			Assert::ExpectException<std::runtime_error>([&newFoo]() {newFoo.AppendAuxiliaryAttribute("ExternalFloatArray"); });
			Assert::ExpectException<std::runtime_error>([&newFoo]() {newFoo.AppendAuxiliaryAttribute("ExternalStringArray"); });
			Assert::ExpectException<std::runtime_error>([&newFoo]() {newFoo.AppendAuxiliaryAttribute("ExternalMatrixArray"); });
			Assert::ExpectException<std::runtime_error>([&newFoo]() {newFoo.AppendAuxiliaryAttribute("ExternalVectorArray"); });
			Assert::ExpectException<std::runtime_error>([&newFoo]() {newFoo.AppendAuxiliaryAttribute("NestedScope"); });
			Assert::ExpectException<std::runtime_error>([&newFoo]() {newFoo.AppendAuxiliaryAttribute("NestedScopeArray"); });
		}

		TEST_METHOD(GetAttributes)
		{
			AttributedFoo newFoo;

			newFoo.AppendAuxiliaryAttribute("BrandNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AnotherNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AdditionalNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("WhollyNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("FinalNewAttribute!");

			newFoo.At("FinalNewAttribute!")->PushBack(5.5f);
			newFoo.At("ExternalInt")->SetInt(3);
			auto rangeValues = newFoo.GetAttributes();

			Assert::IsTrue(rangeValues.second == newFoo.Size());
			Assert::IsTrue(rangeValues.first == 1);

			Assert::IsTrue(newFoo.At(rangeValues.first).GetInt() == 3);
			Assert::IsTrue(newFoo.At(rangeValues.second-1).GetFloat() == 5.5f);
		}

		TEST_METHOD(GetPrescribedAttributes)
		{
			AttributedFoo newFoo;

			newFoo.AppendAuxiliaryAttribute("BrandNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AnotherNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AdditionalNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("WhollyNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("FinalNewAttribute!");

			newFoo.At("FinalNewAttribute!")->PushBack(5.5f);

			newFoo.At("NestedScopeArray")->GetScope()->Append("NewestFloat");
			newFoo.At("NestedScopeArray")->GetScope()->At(0).PushBack(4.4f);

			newFoo.At("ExternalInt")->SetInt(3);
			auto rangeValues = newFoo.GetPrescribedAttributes();

			Assert::IsTrue(rangeValues.second == newFoo.Size()-5);
			Assert::IsTrue(rangeValues.first == 1);

			Assert::IsTrue(newFoo.At(rangeValues.first).GetInt() == 3);
			Assert::IsTrue(newFoo.At(rangeValues.second - 1).GetScope()->At(0).GetFloat() == 4.4f);
		}

		TEST_METHOD(GetAuxiliaryAttributes)
		{
			AttributedFoo newFoo;

			newFoo.AppendAuxiliaryAttribute("BrandNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AnotherNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("AdditionalNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("WhollyNewAttribute!");
			newFoo.AppendAuxiliaryAttribute("FinalNewAttribute!");

			newFoo.At("FinalNewAttribute!")->PushBack(4.4f);
			newFoo.At("BrandNewAttribute!")->PushBack(static_cast<size_t>(3));

			auto rangeValues = newFoo.GetAuxiliaryAttributes();

			Assert::IsTrue(rangeValues.second == newFoo.Size());
			Assert::IsTrue(rangeValues.first == newFoo.Size()-5);

			Assert::IsTrue(newFoo.At(rangeValues.first).GetInt() == size_t(3));
			Assert::IsTrue(newFoo.At(rangeValues.second - 1).GetFloat() == 4.4f);
		}

		TEST_METHOD(AtKey)
		{
			std::string Five = "F";
			glm::vec4 FiveVector = { 5,5,5,5 };
			glm::mat4 FiveMatrix = { 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 };

			AttributedFoo newFoo;
			newFoo.At("ExternalInt")->SetInt(5);
			newFoo.At("ExternalFloat")->SetFloat(5.5f);
			newFoo.At("ExternalString")->SetString(Five);
			newFoo.At("ExternalVector")->SetVector(FiveVector);
			newFoo.At("ExternalMatrix")->SetMatrix(FiveMatrix);

			newFoo.At("ExternalIntArray")->SetInt(5);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f);
			newFoo.At("ExternalStringArray")->SetString(Five);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix);

			newFoo.At("ExternalIntArray")->SetInt(5, 1);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f, 1);
			newFoo.At("ExternalStringArray")->SetString(Five, 1);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector, 1);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix, 1);

			newFoo.At("ExternalIntArray")->SetInt(5, 2);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f, 2);
			newFoo.At("ExternalStringArray")->SetString(Five, 2);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector, 2);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix, 2);

			newFoo.At("NestedScope")->GetScope()->Append("NewNestedInt");
			newFoo.At("NestedScope")->GetScope()->At(0).PushBack(static_cast<size_t>(5));

			newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedString");
			newFoo.At("NestedScopeArray")->GetScope()->At(0).PushBack(Five);

			auto SecondNestedArray = newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedFloat");
			newFoo.At("NestedScopeArray")->GetScope()->At(1).PushBack(5.5f);

			auto ThirdNestedArray = newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedMatrix");
			newFoo.At("NestedScopeArray")->GetScope()->At(2).PushBack(FiveMatrix);

			Assert::IsTrue(newFoo.At("ExternalInt")->GetInt() == 5);
			Assert::IsTrue(newFoo.At("ExternalFloat")->GetFloat() == 5.5f);
			Assert::IsTrue(newFoo.At("ExternalString")->GetString() == Five);
			Assert::IsTrue(newFoo.At("ExternalVector")->GetVector() == FiveVector);
			Assert::IsTrue(newFoo.At("ExternalMatrix")->GetMatrix() == FiveMatrix);

			Assert::IsTrue(newFoo.At("ExternalIntArray")->GetInt() == 5);
			Assert::IsTrue(newFoo.At("ExternalFloatArray")->GetFloat() == 5.5f);
			Assert::IsTrue(newFoo.At("ExternalStringArray")->GetString() == Five);
			Assert::IsTrue(newFoo.At("ExternalVectorArray")->GetVector() == FiveVector);
			Assert::IsTrue(newFoo.At("ExternalMatrixArray")->GetMatrix() == FiveMatrix);

			Assert::IsTrue(newFoo.At("ExternalIntArray")->GetInt(1) == 5);
			Assert::IsTrue(newFoo.At("ExternalFloatArray")->GetFloat(1) == 5.5f);
			Assert::IsTrue(newFoo.At("ExternalStringArray")->GetString(1) == Five);
			Assert::IsTrue(newFoo.At("ExternalVectorArray")->GetVector(1) == FiveVector);
			Assert::IsTrue(newFoo.At("ExternalMatrixArray")->GetMatrix(1) == FiveMatrix);

			Assert::IsTrue(newFoo.At("ExternalIntArray")->GetInt(2) == 5);
			Assert::IsTrue(newFoo.At("ExternalFloatArray")->GetFloat(2) == 5.5f);
			Assert::IsTrue(newFoo.At("ExternalStringArray")->GetString(2) == Five);
			Assert::IsTrue(newFoo.At("ExternalVectorArray")->GetVector(2) == FiveVector);
			Assert::IsTrue(newFoo.At("ExternalMatrixArray")->GetMatrix(2) == FiveMatrix);

			Assert::IsTrue(newFoo.At("NestedScope")->GetScope()->At(0).GetInt() == 5);
			Assert::IsTrue(newFoo.At("NestedScopeArray")->GetScope()->At(0).GetString() == Five);
			Assert::IsTrue(newFoo.At("NestedScopeArray")->GetScope()->At(1).GetFloat() == 5.5f);
			Assert::IsTrue(newFoo.At("NestedScopeArray")->GetScope()->At(2).GetMatrix() == FiveMatrix);
		}

		TEST_METHOD(AtIndex)
		{
			std::string Five = "F";
			glm::vec4 FiveVector = { 5,5,5,5 };
			glm::mat4 FiveMatrix = { 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 };

			AttributedFoo newFoo;
			newFoo.At("ExternalInt")->SetInt(5);
			newFoo.At("ExternalFloat")->SetFloat(5.5f);
			newFoo.At("ExternalString")->SetString(Five);
			newFoo.At("ExternalVector")->SetVector(FiveVector);
			newFoo.At("ExternalMatrix")->SetMatrix(FiveMatrix);

			newFoo.At("ExternalIntArray")->SetInt(5);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f);
			newFoo.At("ExternalStringArray")->SetString(Five);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix);

			newFoo.At("ExternalIntArray")->SetInt(5, 1);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f, 1);
			newFoo.At("ExternalStringArray")->SetString(Five, 1);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector, 1);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix, 1);

			newFoo.At("ExternalIntArray")->SetInt(5, 2);
			newFoo.At("ExternalFloatArray")->SetFloat(5.5f, 2);
			newFoo.At("ExternalStringArray")->SetString(Five, 2);
			newFoo.At("ExternalVectorArray")->SetVector(FiveVector, 2);
			newFoo.At("ExternalMatrixArray")->SetMatrix(FiveMatrix, 2);

			newFoo.At("NestedScope")->GetScope()->Append("NewNestedInt");
			newFoo.At("NestedScope")->GetScope()->At(0).PushBack(static_cast<size_t>(5));

			newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedString");
			newFoo.At("NestedScopeArray")->GetScope()->At(0).PushBack(Five);

			auto SecondNestedArray = newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedFloat");
			newFoo.At("NestedScopeArray")->GetScope()->At(1).PushBack(5.5f);

			auto ThirdNestedArray = newFoo.At("NestedScopeArray")->GetScope()->Append("NewNestedMatrix");
			newFoo.At("NestedScopeArray")->GetScope()->At(2).PushBack(FiveMatrix);

			Assert::IsTrue(newFoo.At(1).GetInt() == 5);
			Assert::IsTrue(newFoo.At(2).GetFloat() == 5.5f);
			Assert::IsTrue(newFoo.At(3).GetString() == Five);
			Assert::IsTrue(newFoo.At(4).GetVector() == FiveVector);
			Assert::IsTrue(newFoo.At(5).GetMatrix() == FiveMatrix);

			Assert::IsTrue(newFoo.At(6).GetInt() == 5);
			Assert::IsTrue(newFoo.At(7).GetFloat() == 5.5f);
			Assert::IsTrue(newFoo.At(8).GetString() == Five);
			Assert::IsTrue(newFoo.At(9).GetVector() == FiveVector);
			Assert::IsTrue(newFoo.At(10).GetMatrix() == FiveMatrix);

			Assert::IsTrue(newFoo.At(6).GetInt(1) == 5);
			Assert::IsTrue(newFoo.At(7).GetFloat(1) == 5.5f);
			Assert::IsTrue(newFoo.At(8).GetString(1) == Five);
			Assert::IsTrue(newFoo.At(9).GetVector(1) == FiveVector);
			Assert::IsTrue(newFoo.At(10).GetMatrix(1) == FiveMatrix);

			Assert::IsTrue(newFoo.At(6).GetInt(2) == 5);
			Assert::IsTrue(newFoo.At(7).GetFloat(2) == 5.5f);
			Assert::IsTrue(newFoo.At(8).GetString(2) == Five);
			Assert::IsTrue(newFoo.At(9).GetVector(2) == FiveVector);
			Assert::IsTrue(newFoo.At(10).GetMatrix(2) == FiveMatrix);

			Assert::IsTrue(newFoo.At(11).GetScope()->At(0).GetInt() == 5);
			Assert::IsTrue(newFoo.At(12).GetScope()->At(0).GetString() == Five);
			Assert::IsTrue(newFoo.At(12).GetScope()->At(1).GetFloat() == 5.5f);
			Assert::IsTrue(newFoo.At(12).GetScope()->At(2).GetMatrix() == FiveMatrix);
		}

		TEST_METHOD(Size)
		{
			AttributedFoo newFoo;

			Assert::IsTrue(newFoo.Size() == 13);
			newFoo.AppendAuxiliaryAttribute("BrandNewAttribute!");
			Assert::IsTrue(newFoo.Size() == 14);
			newFoo.AppendAuxiliaryAttribute("AnotherNewAttribute!");
			Assert::IsTrue(newFoo.Size() == 15);
			newFoo.AppendAuxiliaryAttribute("AdditionalNewAttribute!");
			Assert::IsTrue(newFoo.Size() == 16);
			newFoo.AppendAuxiliaryAttribute("WhollyNewAttribute!");
			Assert::IsTrue(newFoo.Size() == 17);
			newFoo.AppendAuxiliaryAttribute("FinalNewAttribute!");
			Assert::IsTrue(newFoo.Size() == 18);

			newFoo.~AttributedFoo();
			Assert::IsTrue(newFoo.Size() == 0);
		}

		private: //Creates memory state screenshots to ensure no memory leaks in any test
		inline static _CrtMemState _startMemState;

	};
}