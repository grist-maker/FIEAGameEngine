#include "pch.h"
#include "AttributedFoo.h"

using namespace FieaGameEngine;
using namespace std;
using namespace std::string_literals;

namespace UnitTests
{
	RTTI_DEFINITIONS(AttributedFoo);

	AttributedFoo::AttributedFoo() :
		Attributed (TypeIdClass())
	{
	}

	FieaGameEngine::Vector<FieaGameEngine::Signature> AttributedFoo::Signatures()
	{
		Vector<Signature> signatureArray;
		signatureArray.PushBack(Signature{ "ExternalInt", Datum::DatumTypes::Integer, 1, offsetof(AttributedFoo, ExternalInt) });
		signatureArray.PushBack(Signature{ "ExternalFloat", Datum::DatumTypes::Float, 1, offsetof(AttributedFoo, ExternalFloat) });
		signatureArray.PushBack(Signature{ "ExternalString", Datum::DatumTypes::String, 1, offsetof(AttributedFoo, ExternalString) });
		signatureArray.PushBack(Signature{ "ExternalVector", Datum::DatumTypes::Vector, 1, offsetof(AttributedFoo, ExternalVector) });
		signatureArray.PushBack(Signature{ "ExternalMatrix", Datum::DatumTypes::Matrix, 1, offsetof(AttributedFoo, ExternalMatrix) });

		signatureArray.PushBack(Signature{ "ExternalIntArray", Datum::DatumTypes::Integer, ArraySize, offsetof(AttributedFoo, ExternalIntArray) });
		signatureArray.PushBack(Signature{ "ExternalFloatArray", Datum::DatumTypes::Float, ArraySize, offsetof(AttributedFoo, ExternalFloatArray) });
		signatureArray.PushBack(Signature{ "ExternalStringArray", Datum::DatumTypes::String, ArraySize, offsetof(AttributedFoo, ExternalStringArray) });
		signatureArray.PushBack(Signature{ "ExternalVectorArray", Datum::DatumTypes::Vector, ArraySize, offsetof(AttributedFoo, ExternalVectorArray) });
		signatureArray.PushBack(Signature{ "ExternalMatrixArray", Datum::DatumTypes::Matrix, ArraySize, offsetof(AttributedFoo, ExternalMatrixArray) });
		signatureArray.PushBack(Signature{ "NestedScope", Datum::DatumTypes::Table, 0, 0 });
		signatureArray.PushBack(Signature{ "NestedScopeArray", Datum::DatumTypes::Table, ArraySize, 0 });

		return signatureArray;
	}

	bool AttributedFoo::Equals(const RTTI* comparedRTTI) const
	{
		const auto comparedFoo = comparedRTTI->As<AttributedFoo>();
		if (comparedFoo == nullptr)
		{
			return false;
		}

		return ExternalInt == comparedFoo->ExternalInt &&
			ExternalFloat == comparedFoo->ExternalFloat &&
			ExternalString == comparedFoo->ExternalString &&
			ExternalVector == comparedFoo->ExternalVector &&
			ExternalMatrix == comparedFoo->ExternalMatrix &&
			std::equal(std::begin(ExternalIntArray), std::end(ExternalIntArray), std::begin(comparedFoo->ExternalIntArray), std::end(comparedFoo->ExternalIntArray)) &&
			std::equal(std::begin(ExternalFloatArray), std::end(ExternalFloatArray), std::begin(comparedFoo->ExternalFloatArray), std::end(comparedFoo->ExternalFloatArray)) &&
			std::equal(std::begin(ExternalStringArray), std::end(ExternalStringArray), std::begin(comparedFoo->ExternalStringArray), std::end(comparedFoo->ExternalStringArray)) &&
			std::equal(std::begin(ExternalVectorArray), std::end(ExternalVectorArray), std::begin(comparedFoo->ExternalVectorArray), std::end(comparedFoo->ExternalVectorArray)) &&
			std::equal(std::begin(ExternalMatrixArray), std::end(ExternalMatrixArray), std::begin(comparedFoo->ExternalMatrixArray), std::end(comparedFoo->ExternalMatrixArray));//&&
			//At("NestedScope"s) == (*comparedFoo).At("NestedScope"s);
	}

	string AttributedFoo::ToString() const
	{
		return "AttributedFoo"s;
	}
}
