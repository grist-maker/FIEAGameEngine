#include "pch.h"
#include "CppUnitTest.h"
#include "ActionIncrement.h"
#include "ActionDecrement.h"
#include "ActionMultiply.h"
#include "ActionDivide.h"
#include "ActionListIf.h"
#include "ActionListWhile.h"
#include "JsonParseCoordinator.h"
#include "JsonTableParseHelper.h"
#include "GameObject.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;
using namespace std::string_literals;
using namespace chrono;

namespace UnitTests
{
	TEST_CLASS(ActionTests)
	{
		TEST_METHOD_INITIALIZE(Initialize) //Initial setup of memory state variables to allow memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&_startMemState);
			#endif
		}

		TEST_METHOD_CLEANUP(Cleanup) //Setup for memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);

			if (_CrtMemDifference(&diffMemState, &_startMemState,
				&endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
			#endif
		}
		TEST_METHOD(Constructor)
		{
			ActionList newObject;
			ActionIncrement firstAction;
			ActionIncrement secondAction;

			Assert::AreNotEqual(newObject.TypeIdClass(), Action::TypeIdClass());

			Assert::IsTrue(firstAction.At("Index")->Type() == Datum::DatumTypes::Integer);
			Assert::IsTrue(firstAction.At("Step")->Type() == Datum::DatumTypes::Integer);
			Assert::IsTrue(firstAction.At("Target")->Type() == Datum::DatumTypes::String);
			Assert::IsTrue(firstAction == secondAction);

			firstAction.At("Index")->SetInt(4);
			Assert::IsFalse(firstAction == secondAction);
			Assert::IsFalse(secondAction == firstAction);
		}

		TEST_METHOD(Update)
		{
			{
				std::string ScopeTag = "Scope";
				std::string ActionListTag = "ActionList";

				Factory<Scope>::Add(std::make_unique<ScopeFactory>());
				Factory<Scope>::Add(std::make_unique<ActionListFactory>());

				GameTime currentTime;
				GameObject gameobject;
				gameobject.CreateAction("ActionList", "newObject");
				ActionList newObject = *static_cast<ActionList*>(gameobject.Actions()->GetScope()->Find("newObject")->GetScope());

				newObject.At("Actions")->GetScope()->Adopt(new ActionIncrement(), "Child");
				auto newAction = newObject.At("Actions")->GetScope()->Find("Child")->GetScope()->As<ActionIncrement>();

				Assert::AreNotEqual(newObject.TypeIdClass(), newAction->TypeIdClass());

				newAction->AppendAuxiliaryAttribute("A");
				newAction->At("A")->PushBack(static_cast<size_t>(0));
				newAction->At("A")->PushBack(static_cast<size_t>(0));

				std::string sample = "A";
				std::string empty = "";
				Assert::IsTrue(newAction->At("Index")->GetInt() == 0);
				Assert::IsTrue(newAction->At("Step")->GetInt() == 0);
				Assert::IsTrue(newAction->At("Target")->GetString() == empty);

				newObject.Update(currentTime);
				Assert::IsTrue(newAction->At("A")->GetInt() == 0);
				Assert::IsTrue(newAction->At("A")->GetInt(1) == 0);

				newAction->At("Target")->SetString(sample);
				newAction->At("Index")->SetInt(1);
				newAction->At("Step")->SetInt(45);

				currentTime.SetElapsedGameTime(100s);
				newObject.Update(currentTime);
				Assert::IsTrue(newAction->At("A")->GetInt(0) == 0);
				Assert::IsTrue(newAction->At("A")->GetInt(1) == 45);

				Factory<Scope>::Remove(ScopeTag);
				Factory<Scope>::Remove(ActionListTag);
			}
		}

		TEST_METHOD(Equal)
		{
			GameTime currentTime;
			ActionList newObject;
			ActionList anotherNewObject;

			auto newObjectActions = newObject.At("Actions")->GetScope();
			newObjectActions->Adopt(new ActionIncrement(), "Child");
			auto firstChild = newObjectActions->Find("Child")->GetScope()->As<ActionIncrement>();
			firstChild->Find("Step")->SetInt(50);

			auto anotherNewObjectActions = anotherNewObject.At("Actions")->GetScope();
			anotherNewObjectActions->Adopt(new ActionIncrement(), "Child");
			auto secondChild = anotherNewObjectActions->Find("Child")->GetScope()->As<ActionIncrement>();

			Assert::IsFalse(anotherNewObject == newObject);
			secondChild->Find("Step")->SetInt(50);
			Assert::IsTrue(anotherNewObject == newObject);

			ActionList finalNewObject;

			auto finalNewObjectActions = finalNewObject.At("Actions")->GetScope();
			finalNewObjectActions->Adopt(new ActionIncrement(), "Child");
			finalNewObjectActions->Adopt(new ActionIncrement(), "SecondChild");
			auto finalChild = finalNewObjectActions->Find("Child")->GetScope()->As<ActionIncrement>();
			finalChild->Find("Step")->SetInt(50);

			Assert::IsFalse(anotherNewObject == finalNewObject);
			Assert::IsFalse(finalNewObject == newObject);
			Assert::IsTrue(anotherNewObject == newObject);

			std::string oldName = "";
			std::string newName = "Child1";
			firstChild->SetName(newName);
			Assert::IsFalse(anotherNewObject == newObject);
			firstChild->SetName(oldName);
			Assert::IsTrue(anotherNewObject == newObject);

			std::string target = "A";

			firstChild->At("Step")->SetInt(50);
			newObject.AppendAuxiliaryAttribute("A");
			auto targetInt = newObject.At("A");

			targetInt->SetType(Datum::DatumTypes::Integer);
			targetInt->PushBack(static_cast<size_t>(0));
			firstChild->At("Target")->SetString(target);

			secondChild->At("Step")->SetInt(50);
			anotherNewObject.AppendAuxiliaryAttribute("A");
			auto anotherTargetInt = anotherNewObject.At("A");

			anotherTargetInt->SetType(Datum::DatumTypes::Integer);
			anotherTargetInt->PushBack(static_cast<size_t>(0));
			secondChild->At("Target")->SetString(target);

			Assert::IsTrue(anotherNewObject == newObject);
			currentTime.SetElapsedGameTime(199s);
			anotherNewObject.Update(currentTime);
			Assert::IsFalse(anotherNewObject == newObject);
			Assert::IsTrue(anotherTargetInt->GetInt() == 50);
		}

		TEST_METHOD(CopyConstruction)
		{
			GameTime currentTime;
			ActionList newObject;
			std::string name = "NewObject";
			
			auto actionScope = newObject.At("Actions")->GetScope();
			actionScope->Adopt(new ActionIncrement(), "Child");
			auto newChild = actionScope->Find("Child")->GetScope()->As<ActionIncrement>();
			newChild->SetName(name);
			newObject.SetName(name);

			ActionList anotherNewObject = newObject;
			Assert::IsTrue(anotherNewObject.GetName() == name);

			auto childScope = anotherNewObject.At("Actions")->GetScope()->Find("Child")->GetScope();

			std::string emptyString = "";
			Assert::IsTrue(childScope->Find("Index")->GetInt() == 0);
			Assert::IsTrue(childScope->Find("Step")->GetInt() == 0);
			Assert::IsTrue(childScope->Find("Target")->GetString() == emptyString);
			Assert::IsTrue(newObject == anotherNewObject);
		}

		TEST_METHOD(CopyAssignment)
		{
			GameTime currentTime;
			ActionList newObject;
			ActionList anotherNewObject;
			std::string name = "NewObject";
			auto newObjectActions = newObject.At("Actions")->GetScope();

			newObjectActions->Adopt(new ActionIncrement(), "Child");
			auto newChild = newObjectActions->Find("Child")->GetScope()->As<ActionIncrement>();
			newChild->SetName(name);
			newObject.SetName(name);

			anotherNewObject = newObject;
			Assert::IsTrue(anotherNewObject.GetName() == name);

			auto childScope = anotherNewObject.At("Actions")->GetScope()->Find("Child")->GetScope();

			std::string emptyString = "";
			Assert::IsTrue(childScope->Find("Index")->GetInt() == 0);
			Assert::IsTrue(childScope->Find("Step")->GetInt() == 0);
			Assert::IsTrue(childScope->Find("Target")->GetString() == emptyString);
			Assert::IsTrue(newObject == anotherNewObject);
		}

		TEST_METHOD(MoveConstruction)
		{
			GameTime currentTime;
			ActionList newObject;

			std::string name = "NewObject";
			auto actionScope = newObject.At("Actions")->GetScope();

			actionScope->Adopt(new ActionIncrement(), "Child");
			newObject.SetName(name);
			auto newChild = actionScope->Find("Child")->GetScope()->As<ActionIncrement>();
			newChild->SetName(name);
			newObject.SetName(name);

			ActionList anotherNewObject = std::move(newObject);
			Assert::IsTrue(anotherNewObject.GetName() == name);

			Assert::IsTrue(anotherNewObject.At("Actions")->GetScope()->Find("Child")->GetScope()->Find("Name")->GetString() == name);
		}

		TEST_METHOD(MoveAssignment)
		{
			GameTime currentTime;
			ActionList newObject;
			ActionList anotherNewObject;

			std::string name = "NewObject";

			auto actionScope = newObject.At("Actions")->GetScope();

			actionScope->Adopt(new ActionIncrement(), "Child");
			newObject.SetName(name);
			auto child = actionScope->Find("Child")->GetScope()->As<ActionIncrement>();
			child->SetName(name);

			anotherNewObject = std::move(newObject);
			Assert::IsTrue(anotherNewObject.GetName() == name);

			Assert::IsTrue(anotherNewObject.At("Actions")->GetScope()->Find("Child")->GetScope()->Find("Name")->GetString() == name);
		}

		TEST_METHOD(ActionDecrement)
		{
			GameTime TimeInstance;

			std::string ScopeTag = "Scope";
			std::string ActionDecrementTag = "ActionDecrement";

			Factory<Scope>::Add(std::make_unique<ScopeFactory>());
			Factory<Scope>::Add(std::make_unique<ActionDecrementFactory>());

			std::string fullPath = R"(Content\ActionDecrementJSONTest.json)";
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<FieaGameEngine::ActionDecrement>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			auto action = static_cast<FieaGameEngine::ActionDecrement*>(rawWrapper->Data.get());

			auto targetInt = action->Find("A");
			Assert::IsTrue(targetInt->GetInt(1) == 10);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 8);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 6);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 4);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 2);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 0);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 0);

			Factory<Scope>::Remove(ScopeTag);
			Factory<Scope>::Remove(ActionDecrementTag);
		}

		TEST_METHOD(ActionMultiply)
		{
			GameTime TimeInstance;

			std::string ScopeTag = "Scope";
			std::string ActionMultiplyTag = "ActionMultiply";

			Factory<Scope>::Add(std::make_unique<ScopeFactory>());
			Factory<Scope>::Add(std::make_unique<ActionMultiplyFactory>());

			std::string fullPath = R"(Content\ActionMultiplyJSONTest.json)";
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<FieaGameEngine::ActionMultiply>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			auto action = static_cast<FieaGameEngine::ActionMultiply*>(rawWrapper->Data.get());

			auto targetInt = action->Find("A");
			Assert::IsTrue(targetInt->GetInt(1) == 2);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 4);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 8);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 16);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 32);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 64);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 128);

			Factory<Scope>::Remove(ScopeTag);
			Factory<Scope>::Remove(ActionMultiplyTag);
		}

		TEST_METHOD(ActionDivide)
		{
			GameTime TimeInstance;

			std::string ScopeTag = "Scope";
			std::string ActionDivideTag = "ActionDivide";

			Factory<Scope>::Add(std::make_unique<ScopeFactory>());
			Factory<Scope>::Add(std::make_unique<ActionDivideFactory>());

			std::string fullPath = R"(Content\ActionDivideJSONTest.json)";
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<FieaGameEngine::ActionDivide>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			auto action = static_cast<FieaGameEngine::ActionDivide*>(rawWrapper->Data.get());

			auto targetInt = action->Find("A");

			Assert::IsTrue(targetInt->GetInt(1) == 64);
			action->Find("Divisor")->SetInt(0);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 64);
			action->Find("Divisor")->SetInt(2);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 32);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 16);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 8);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 4);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 2);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 1);
			action->Update(TimeInstance);
			Assert::IsTrue(targetInt->GetInt(1) == 0);

			Factory<Scope>::Remove(ScopeTag);
			Factory<Scope>::Remove(ActionDivideTag);
		}

		TEST_METHOD(ActionListIfConditionalUpdate)
		{
			GameObject newObject;
			newObject.Actions()->GetScope()->Adopt(new ActionListIf(), "FirstAction");// ->PushBack(conditionalAction);

			GameTime TimeInstance;
			std::string A = "A";
			ActionListIf* conditionalAction = dynamic_cast<ActionListIf*>(newObject.At("Actions")->GetScope()->Find("FirstAction")->GetScope());

			conditionalAction->AppendAuxiliaryAttribute(A);
			conditionalAction->Find(A)->PushBack(static_cast<size_t>(0));
			conditionalAction->Find(A)->PushBack(static_cast<size_t>(0));

			auto trueScope = conditionalAction->Find("TrueBlock")->GetScope();
			trueScope->Adopt(new ActionList(), "TrueActions");
			auto trueActions = trueScope->Find("TrueActions")->GetScope()->Find("Actions")->GetScope();

			trueActions->Adopt(new ActionIncrement(), "FirstTrueAction");
			auto firstTrueAction = trueActions->Find("FirstTrueAction")->GetScope();
			firstTrueAction->Find("Step")->SetInt(static_cast<size_t>(2));
			firstTrueAction->Find("Index")->SetInt(static_cast<size_t>(1));
			firstTrueAction->Find("Target")->SetString(A);

			trueActions->Adopt(new ActionIncrement(), "SecondTrueAction");
			auto secondTrueAction = trueActions->Find("SecondTrueAction")->GetScope();
			secondTrueAction->Find("Step")->SetInt(static_cast<size_t>(3));
			secondTrueAction->Find("Index")->SetInt(static_cast<size_t>(1));
			secondTrueAction->Find("Target")->SetString(A);

			auto falseScope = conditionalAction->Find("FalseBlock")->GetScope();
			falseScope->Adopt(new ActionList(), "FalseActions");
			auto falseActions = falseScope->Find("FalseActions")->GetScope()->Find("Actions")->GetScope();

			falseActions->Adopt(new ActionIncrement(), "FirstFalseAction");
			auto firstFalseAction = falseActions->Find("FirstFalseAction")->GetScope();
			firstFalseAction->Find("Step")->SetInt(static_cast<size_t>(3));
			firstFalseAction->Find("Index")->SetInt(static_cast<size_t>(0));
			firstFalseAction->Find("Target")->SetString(A);

			falseActions->Adopt(new ActionIncrement(), "SecondFalseAction");
			auto secondFalseAction = falseActions->Find("SecondFalseAction")->GetScope();
			secondFalseAction->Find("Step")->SetInt(static_cast<size_t>(7));
			secondFalseAction->Find("Index")->SetInt(static_cast<size_t>(0));
			secondFalseAction->Find("Target")->SetString(A);

			auto Condition = conditionalAction->Find("Condition");
			auto intTarget = conditionalAction->Find(A);

			Condition->SetInt(static_cast<size_t>(0)); //This is false. The false branch should be triggered, but not true.
			newObject.Update(TimeInstance);

			Assert::IsTrue(intTarget->GetInt(0) == 10);
			Assert::IsTrue(intTarget->GetInt(1) == 0);

			Condition->SetInt(static_cast<size_t>(1)); //This is false. The false branch should be triggered, but not true.
			newObject.Update(TimeInstance);

			Assert::IsTrue(intTarget->GetInt(0) == 10);
			Assert::IsTrue(intTarget->GetInt(1) == 5);
		}

		TEST_METHOD(ActionListWhileConditionalUpdate)
		{
			GameTime TimeInstance;

			std::string ScopeTag = "Scope";
			std::string ActionListTag = "ActionList";
			std::string ActionIncrementTag = "ActionIncrement";
			std::string ActionDecrementTag = "ActionDecrement";
			std::string ActionMultiplyTag = "ActionMultiply";
			std::string ActionDivideTag = "ActionDivide";
			std::string ActionListWhileTag = "ActionListWhile";

			Factory<Scope>::Add(std::make_unique<ScopeFactory>());
			Factory<Scope>::Add(std::make_unique<ActionListFactory>());
			Factory<Scope>::Add(std::make_unique<ActionIncrementFactory>());
			Factory<Scope>::Add(std::make_unique<ActionDecrementFactory>());
			Factory<Scope>::Add(std::make_unique<ActionMultiplyFactory>());
			Factory<Scope>::Add(std::make_unique<ActionListWhileFactory>());
			Factory<Scope>::Add(std::make_unique<ActionDivideFactory>());

			std::string fullPath = R"(Content\ActionListWhileJSONTest.json)";
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<ActionListWhile>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			auto action = static_cast<ActionListWhile*>(rawWrapper->Data.get());

			action->Update(TimeInstance);

			Assert::IsTrue(action->Find("Condition")->GetInt() == 0);
			Assert::IsTrue(action->Find("Loops")->GetInt() == 3);

			Factory<Scope>::Remove(ScopeTag);
			Factory<Scope>::Remove(ActionListTag);
			Factory<Scope>::Remove(ActionDecrementTag);
			Factory<Scope>::Remove(ActionMultiplyTag);
			Factory<Scope>::Remove(ActionIncrementTag);
			Factory<Scope>::Remove(ActionListWhileTag);
			Factory<Scope>::Remove(ActionDivideTag);
		}
		TEST_METHOD(ActionParsing)
		{
			GameTime TimeInstance;

			std::string ScopeTag = "Scope";
			std::string ActionListTag = "ActionList";
			std::string ActionIncrementTag = "ActionIncrement";
			std::string ActionListIfTag = "ActionListIf";

			Factory<Scope>::Add(std::make_unique<ScopeFactory>());
			Factory<Scope>::Add(std::make_unique<ActionListFactory>());
			Factory<Scope>::Add(std::make_unique<ActionIncrementFactory>());
			Factory<Scope>::Add(std::make_unique<ActionListIfFactory>());

			std::string fullPath = R"(Content\ActionJSONTest.json)";
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<ActionListIf>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			auto action = static_cast<ActionListIf*>(rawWrapper->Data.get());
			auto intTarget = action->Find("A");

			action->Update(TimeInstance);
			Assert::IsTrue(intTarget->GetInt(0) == 10);

			action->Find("Condition")->SetInt(1);
			action->Update(TimeInstance);
			Assert::IsTrue(intTarget->GetInt(1) == 10);

			Factory<Scope>::Remove(ScopeTag);
			Factory<Scope>::Remove(ActionListTag);
			Factory<Scope>::Remove(ActionListIfTag);
			Factory<Scope>::Remove(ActionIncrementTag);
		}

	private: //Creates memory state screenshots to ensure no memory leaks in any test
		inline static _CrtMemState _startMemState;
	};
}