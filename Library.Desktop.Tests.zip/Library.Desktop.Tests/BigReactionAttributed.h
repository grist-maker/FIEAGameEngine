#pragma once
#include "ReactionAttributed.h"

namespace UnitTests
{
    class BigReactionAttributed final :
        public FieaGameEngine::ReactionAttributed
    {
        RTTI_DECLARATIONS(BigReactionAttributed, FieaGameEngine::ReactionAttributed);

        size_t Apples = 0;
        size_t Grapes = 0;
        size_t Pears = 0;
        size_t Bananas = 0;
    public:

        /// <summary>
        /// Default constructor for the BigReactionAttributed class. This creates a default, base object of the BigReactionAttributed class, not any of its derivatives, and accepts no arguments, with
        /// no return.
        /// </summary>
        BigReactionAttributed();

        /// <summary>
        /// The static Signatures method for the ReactionAttributed class. This specifies the prescribed attribute "Subtype" to denote Event subtypes that the ReactionAttributed is interested in, as well
        /// as those provided within ActionList objects.
        /// </summary>
        /// <returns>A Vector of signatures specifying each prescribed attribute for the ReactionAttributed object.</returns>
        static FieaGameEngine::Vector<FieaGameEngine::Signature> Signatures();
    };
}