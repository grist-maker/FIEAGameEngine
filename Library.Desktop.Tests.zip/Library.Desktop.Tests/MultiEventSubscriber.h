#pragma once
#include "EventSubscriber.h"
#include "Event.h"
#include "GameState.h"
#include "EventArgs.h"

namespace UnitTests
{
	class MultiEventSubscriber : public FieaGameEngine::EventSubscriber
	{
	public:
		MultiEventSubscriber();
		virtual void Notify(const FieaGameEngine::EventPublisher* eventPublisher) override;
		virtual ~MultiEventSubscriber();

		float MyFloat = 0.0f;
		std::string MyString;
		size_t GoodGuy = 0;
		size_t BadGuy = 0;

		FieaGameEngine::EventPublisher* HatedEvent;
	};
}