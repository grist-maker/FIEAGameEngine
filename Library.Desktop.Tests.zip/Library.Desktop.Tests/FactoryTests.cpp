#include "pch.h"
#include "CppUnitTest.h"
#include "Foo.h"
#include "ToStringSpecializations.h"
#include "AttributedFoo.h"
#include "Scope.h"
#include "Monster.h"
#include "json\json.h"
#include <fstream>
#include "JsonTableParseHelper.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace UnitTests;
using namespace std;
using namespace std::string_literals;

namespace UnitTests
{
	TEST_CLASS(FactoryTests)
	{
		TEST_METHOD_INITIALIZE(Initialize) //Initial setup of memory state variables to allow memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&_startMemState);
			#endif
		}

		TEST_METHOD_CLEANUP(Cleanup) //Setup for memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);

			if (_CrtMemDifference(&diffMemState, &_startMemState,
				&endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
			#endif
		}

		TEST_METHOD(Constructor)
		{
			std::string ScopeTag = "Scope";
			std::string AttributedFooTag = "AttributedFoo";
			
			const std::unique_ptr<const Factory<Scope>> scopeFactory = std::make_unique<ScopeFactory>();

			const std::unique_ptr<const Factory<Scope>> FooFactory = std::make_unique<AttributedFooFactory>();
			Assert::AreEqual(FooFactory->ClassName(), AttributedFooTag);
			Assert::AreEqual(scopeFactory->ClassName(), ScopeTag);
		}

		TEST_METHOD(Destructor)
		{

		}

		TEST_METHOD(FindStatic)
		{

		}

		TEST_METHOD(AddRemove)
		{
			std::string ScopeTag = "Scope";
			std::string AttributedFooTag = "AttributedFoo";
			std::string MonsterTag = "Monster";

			Factory<Scope>::Add(std::make_unique<ScopeFactory>());
			Factory<Scope>::Add(std::make_unique<AttributedFooFactory>());
			Factory<Scope>::Add(std::make_unique<MonsterFactory>());

			Assert::IsTrue(Factory<Scope>::Find("Scope") != nullptr);
			Assert::IsTrue(Factory<Scope>::Find("AttributedFoo") != nullptr);
			Assert::IsTrue(Factory<Scope>::Find("Monster") != nullptr);
			Assert::IsTrue(Factory<Scope>::Find("NotReal") == nullptr);

			Factory<Scope>::Remove(ScopeTag);
			Factory<Scope>::Remove(AttributedFooTag);
			Factory<Scope>::Remove(MonsterTag);
		}

		TEST_METHOD(CreateStatic)
		{
			std::string ScopeTag = "Scope";
			std::string AttributedFooTag = "AttributedFoo";

			Factory<Scope>::Add(std::make_unique<ScopeFactory>());
			Factory<Scope>::Add(std::make_unique<AttributedFooFactory>());

			auto attributedFoo = Factory<Scope>::Create(AttributedFooTag);
			Assert::IsTrue(attributedFoo->Size() == 13);
			Assert::IsTrue(attributedFoo->At(1) == *attributedFoo->Find("ExternalInt"));

			Factory<Scope>::Remove(ScopeTag);
			Factory<Scope>::Remove(AttributedFooTag);

			delete(attributedFoo);
		}

		TEST_METHOD(CreateVirtual)
		{
			std::string ScopeTag = "Scope";
			std::string AttributedFooTag = "AttributedFoo";

			const std::unique_ptr<const Factory<Scope>> scopeFactory = std::make_unique<ScopeFactory>();
			const std::unique_ptr<const Factory<Scope>> attributedFactory = std::make_unique<AttributedFooFactory>();

			Scope* myNewScope = scopeFactory->Create();
			Assert::IsTrue(myNewScope->Size() == 0);

			Datum& newDatum = myNewScope->Append("NewDatum");
			newDatum.SetType(Datum::DatumTypes::Integer);
			Assert::IsTrue(myNewScope->At(0).Type() == Datum::DatumTypes::Integer);

			Scope* myNewAttributedFoo = attributedFactory->Create();

			auto attributedFooReference = dynamic_cast<AttributedFoo*>(myNewAttributedFoo);
			Assert::IsTrue(attributedFooReference->Size() == 13);
			Assert::IsTrue(attributedFooReference->At(1) == *attributedFooReference->Find("ExternalInt"));

			delete(myNewAttributedFoo);
			delete(myNewScope);
		}

		TEST_METHOD(ClassName)
		{
			std::string ScopeTag = "Scope";
			std::string AttributedFooTag = "AttributedFoo";

			const std::unique_ptr<const Factory<Scope>> scopeFactory = std::make_unique<ScopeFactory>();
			const std::unique_ptr<const Factory<Scope>> attributedFactory = std::make_unique<AttributedFooFactory>();

			Assert::IsTrue(scopeFactory->ClassName() == ScopeTag);
			Assert::IsTrue(attributedFactory->ClassName() == AttributedFooTag);
		}

		TEST_METHOD(Parsing)
		{
			std::string ScopeTag = "Scope";
			std::string AttributedFooTag = "AttributedFoo";
			std::string MonsterTag = "Monster";

			Factory<Scope>::Add(std::make_unique<ScopeFactory>());
			Factory<Scope>::Add(std::make_unique<AttributedFooFactory>());
			Factory<Scope>::Add(std::make_unique<MonsterFactory>());

			std::string fullPath = R"(Content\FactoryJsonTest.json)";

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());

			Assert::IsTrue(rawWrapper->Data->Size() == 3);

			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt() == 100);
			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(1) == 200);
			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(2) == 300);

			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope()->Find("Cake")->GetString() == "red velvet");

			Assert::IsTrue(rawWrapper->Data->Find("TestFoo")->GetScope()->Size() == 13);
			Assert::IsTrue(rawWrapper->Data->Find("TestFoo")->GetScope()->Find("ExternalInt")->GetInt() == 100);
			Assert::IsTrue(rawWrapper->Data->Find("TestFoo")->GetScope()->Find("ExternalFloat")->Type() == Datum::DatumTypes::Float);
			Assert::IsTrue(rawWrapper->Data->Find("TestFoo")->GetScope()->Find("ExternalString")->Type() == Datum::DatumTypes::String);
			Assert::IsTrue(rawWrapper->Data->Find("TestFoo")->GetScope()->Find("ExternalVector")->Type() == Datum::DatumTypes::Vector);
			Assert::IsTrue(rawWrapper->Data->Find("TestFoo")->GetScope()->Find("ExternalMatrix")->Type() == Datum::DatumTypes::Matrix);
			Assert::IsTrue(rawWrapper->Data->Find("TestFoo")->GetScope()->Find("ExternalIntArray")->Type() == Datum::DatumTypes::Integer);
			Assert::IsTrue(rawWrapper->Data->Find("TestFoo")->GetScope()->Find("ExternalFloatArray")->Type() == Datum::DatumTypes::Float);
			Assert::IsTrue(rawWrapper->Data->Find("TestFoo")->GetScope()->Find("ExternalStringArray")->Type() == Datum::DatumTypes::String);
			Assert::IsTrue(rawWrapper->Data->Find("TestFoo")->GetScope()->Find("ExternalVectorArray")->Type() == Datum::DatumTypes::Vector);
			Assert::IsTrue(rawWrapper->Data->Find("TestFoo")->GetScope()->Find("ExternalMatrixArray")->Type() == Datum::DatumTypes::Matrix);
			Assert::IsTrue(rawWrapper->Data->Find("TestFoo")->GetScope()->Find("NestedScope")->Type() == Datum::DatumTypes::Table);
			Assert::IsTrue(rawWrapper->Data->Find("TestFoo")->GetScope()->Find("NestedScopeArray")->Type() == Datum::DatumTypes::Table);

			Factory<Scope>::Remove(ScopeTag);
			Factory<Scope>::Remove(AttributedFooTag);
			Factory<Scope>::Remove(MonsterTag);
		}

		TEST_METHOD(ParsingInvalidClasses)
		{
			std::string ScopeTag = "Scope";
			std::string AttributedFooTag = "AttributedFoo";
			std::string MonsterTag = "Monster";

			Factory<Scope>::Add(std::make_unique<ScopeFactory>());
			Factory<Scope>::Add(std::make_unique<AttributedFooFactory>());
			Factory<Scope>::Add(std::make_unique<MonsterFactory>());

			std::string fullPath = R"(Content\FactoryJsonInvalidTest.json)";
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());

			Assert::IsTrue(rawWrapper->Data->Size() == 0);

			Factory<Scope>::Remove(ScopeTag);
			Factory<Scope>::Remove(AttributedFooTag);
			Factory<Scope>::Remove(MonsterTag);
		}

	private: //Creates memory state screenshots to ensure no memory leaks in any test
		inline static _CrtMemState _startMemState;
	};
}