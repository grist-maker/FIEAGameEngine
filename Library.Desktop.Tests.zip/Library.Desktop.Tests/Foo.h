#pragma once

#include "RTTI.h"
#include <cstdint>
/// <summary>
/// The file specifying the Foo class that is used to test game engine object functionality more fully.
/// </summary>
namespace UnitTests
{
	class Foo final : public FieaGameEngine::RTTI
	{
		//RTTI_DECLARATIONS(Foo, FieaGameEngine::RTTI);
	public:																													
		static FieaGameEngine::RTTI::IdType TypeIdClass() { return _typeId; }
		FieaGameEngine::RTTI::IdType TypeIdInstance() const override { return TypeIdClass(); }								
		bool Is(FieaGameEngine::RTTI::IdType id) const override { return (id == _typeId ? true : RTTI::Is(id)); }		
	private:																	
		static const FieaGameEngine::RTTI::IdType _typeId;

	public:
		explicit Foo(std::int32_t data = 0);
		Foo(const Foo& rhs);
		Foo(Foo&& rhs) noexcept;
		Foo& operator=(const Foo& rhs);
		Foo& operator=(Foo&& rhs) noexcept;
		virtual ~Foo();

		bool operator==(const Foo& rhs) const;
		bool operator!=(const Foo& rhs) const;

		std::int32_t Data() const;
		void SetData(std::int32_t data);

		bool Equals(const RTTI* rhs) const override;
		std::string Foo::ToString() const override;

	private:
		std::int32_t* _data;
	};
}

