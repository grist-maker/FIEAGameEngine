#include "pch.h"
#include "JsonTableParseHelper.h"

namespace FieaGameEngine
{
	RTTI_DEFINITIONS(JsonTableParseHelper);
	RTTI_DEFINITIONS(JsonTableParseHelper::Wrapper);

	JsonTableParseHelper::Wrapper::~Wrapper()
	{
		if (Data != nullptr)
		{
			Data->~Scope();
		}
		TotalDepth = 0;
	}

	JsonTableParseHelper::Wrapper::Wrapper(std::shared_ptr<Scope> wrapperType)
	{
		static_cast<JsonTableParseHelper::Wrapper*>(this)->Data = wrapperType;
	}

	std::shared_ptr<IJsonParseHelper> JsonTableParseHelper::Create() const
	{
		std::shared_ptr<IJsonParseHelper> newHelp(new JsonTableParseHelper);
		return newHelp;
	}

	std::shared_ptr<JsonParseCoordinator::Wrapper> JsonTableParseHelper::Wrapper::Create() const
	{
		std::shared_ptr<JsonParseCoordinator::Wrapper> newWrapper(new Wrapper(std::make_shared<Scope>()));
		return newWrapper;
	}

	void JsonTableParseHelper::Cleanup()
	{
		ParsingData = false;
	}

	JsonTableParseHelper::~JsonTableParseHelper()
	{
		ParsingData = false;
	}

	void JsonTableParseHelper::Initialize()
	{

	}

	bool JsonTableParseHelper::StartHandler(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray)
	{
		if (ParsingData)
		{
			throw std::runtime_error("Cannot begin parsing new element: parsing is already in progress!");
		}
		ParsingData = true;

		assert(coordinator.Is(JsonTableParseHelper::Wrapper::TypeIdClass()));
		auto& dataWrapper = *static_cast<JsonTableParseHelper::Wrapper*>(&coordinator);

		if (value.second.isObject())
		{
			if (dataWrapper.ContextFrame.IsEmpty())
			{
				dataWrapper.ContextFrame.Push(std::pair(&*static_cast<JsonTableParseHelper::Wrapper*>(&coordinator)->Data, &value.first));
			}
			else
			{
				dataWrapper.ContextFrame.Push(std::pair(dataWrapper.ContextFrame.Top().first, &value.first));
			}
		}
		if (value.second["Type"] == IntegerKey)
		{
			return StartHandlerInt(coordinator, value, isArray);
		}
		else if (value.second["Type"] == FloatKey)
		{
			return StartHandlerFloat(coordinator, value, isArray);
		}
		else if (value.second["Type"] == StringKey)
		{
			return StartHandlerString(coordinator, value, isArray);
		}
		else if (value.second["Type"] == VectorKey)
		{
			return(StartHandlerVector(coordinator, value, isArray));
		}
		else if (value.second["Type"] == MatrixKey)
		{
			return(StartHandlerMatrix(coordinator, value, isArray));
		}
		else if (value.second["Type"] == ScopeKey)
		{
			return(StartHandlerTable(coordinator, value, isArray));
		}
		Cleanup();
		return false;
	}

	bool JsonTableParseHelper::StartHandlerInt(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray)
	{
		assert(coordinator.Is(JsonTableParseHelper::Wrapper::TypeIdClass()));
		auto& dataWrapper = *static_cast<JsonTableParseHelper::Wrapper*>(&coordinator);
		if (value.second["Value"].isInt())
		{
			std::string newKey = *dataWrapper.ContextFrame.Top().second;
			auto& StoredData = dataWrapper.ContextFrame.Top().first->Append(newKey);

			if (StoredData.IsExternalStorage())
			{
				StoredData.SetInt(value.second["Value"].asInt());
			}
			else
			{
				StoredData.PushBack(static_cast<size_t>(value.second["Value"].asInt()));
			}
			isArray = true;
			return true;
		}
		else if (value.second["Value"].isArray())
		{
			if (value.second["Value"].get(Json::ArrayIndex(0), -999.9f).isInt())
			{
				std::string newKey = *dataWrapper.ContextFrame.Top().second;
				auto& NewData = dataWrapper.ContextFrame.Top().first->Append(newKey);

				if (NewData.IsExternalStorage())
				{
					for (size_t i = 0; i < value.second["Value"].size(); i++)
					{
						NewData.SetInt(value.second["Value"][static_cast<Json::Value::ArrayIndex>(i)].asInt(), i);
					}
				}
				else
				{
					for (size_t i = 0; i < value.second["Value"].size(); i++)
					{
						NewData.PushBack(static_cast<size_t>(value.second["Value"][static_cast<Json::Value::ArrayIndex>(i)].asInt()));
					}
				}
				isArray = false;
				return true;
			}
		}
		Cleanup();
		return false;
	}

	bool JsonTableParseHelper::StartHandlerFloat(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray)
	{
		assert(coordinator.Is(JsonTableParseHelper::Wrapper::TypeIdClass()));
		auto& dataWrapper = *static_cast<JsonTableParseHelper::Wrapper*>(&coordinator);
		if (value.second["Value"].isNumeric())
		{
			std::string newKey = *dataWrapper.ContextFrame.Top().second;
			auto& StoredData = dataWrapper.ContextFrame.Top().first->Append(newKey);

			if (StoredData.IsExternalStorage())
			{
				StoredData.SetFloat(value.second["Value"].asFloat());
			}
			else
			{
				StoredData.PushBack(value.second["Value"].asFloat());
			}
			isArray = true;
			return true;
		}
		else if (value.second["Value"].isArray())
		{
			if (value.second["Value"].get(Json::ArrayIndex(0), "NotDouble").isNumeric())
			{
				std::string newKey = *dataWrapper.ContextFrame.Top().second;
				auto& NewData = dataWrapper.ContextFrame.Top().first->Append(newKey);

				if (NewData.IsExternalStorage())
				{
					for (size_t i = 0; i < value.second["Value"].size(); i++)
					{
						NewData.SetFloat(value.second["Value"][static_cast<Json::Value::ArrayIndex>(i)].asFloat(), i);
					}
				}
				else
				{
					for (size_t i = 0; i < value.second["Value"].size(); i++)
					{
						NewData.PushBack(value.second["Value"][static_cast<Json::Value::ArrayIndex>(i)].asFloat());
					}
				}
				isArray = false;
				return true;
			}
		}
		Cleanup();
		return false;
	}

	bool JsonTableParseHelper::StartHandlerString(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray)
	{
		assert(coordinator.Is(JsonTableParseHelper::Wrapper::TypeIdClass()));
		auto& dataWrapper = *static_cast<JsonTableParseHelper::Wrapper*>(&coordinator);
		if (value.second["Value"].isString())
		{
			std::string newKey = *dataWrapper.ContextFrame.Top().second;
			auto& StoredData = dataWrapper.ContextFrame.Top().first->Append(newKey);

			if (StoredData.IsExternalStorage())
			{
				std::string newString = static_cast<std::string>(value.second["Value"].asString());
				StoredData.SetString(newString);
			}
			else
			{
				std::string newString = static_cast<std::string>(value.second["Value"].asString());
				StoredData.PushBack(newString);
			}
			isArray = false;
			return true;
		}
		else if (value.second["Value"].isArray())
		{
			if (value.second["Value"].get(Json::ArrayIndex(0), 1).isString())
			{
				std::string newKey = *dataWrapper.ContextFrame.Top().second;
				auto& NewData = dataWrapper.ContextFrame.Top().first->Append(newKey);

				if (NewData.IsExternalStorage())
				{
					for (size_t i = 0; i < value.second["Value"].size(); i++)
					{
						std::string newString = static_cast<std::string>(value.second["Value"][static_cast<Json::Value::ArrayIndex>(i)].asString());
						NewData.SetString(newString, i);
					}
				}
				else
				{
					for (size_t i = 0; i < value.second["Value"].size(); i++)
					{
						NewData.PushBack(value.second["Value"][Json::Value::ArrayIndex(i)].asString());
					}
				}
				isArray = true;
				return true;
			}
		}
		Cleanup();
		return false;
	}

	bool JsonTableParseHelper::StartHandlerVector(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray)
	{
		assert(coordinator.Is(JsonTableParseHelper::Wrapper::TypeIdClass()));
		auto& dataWrapper = *static_cast<JsonTableParseHelper::Wrapper*>(&coordinator);
		if (value.second["Value"].isString())
		{
			std::string newKey = *dataWrapper.ContextFrame.Top().second;
			auto& StoredData = dataWrapper.ContextFrame.Top().first->Append(newKey);
			bool success = false;

			if (StoredData.IsExternalStorage())
			{
				success = StoredData.SetFromString(value.second["Value"].asString().c_str());
			}
			else
			{
				std::string newString = value.second["Value"].asString();
				StoredData.PushBack(glm::vec4());
				success = StoredData.SetFromString(value.second["Value"].asString().c_str());
			}
			if (success)
			{
				isArray = false;
				return true;
			}
			dataWrapper.Data->Find(newKey)->Clear();
		}
		else if (value.second["Value"].isArray())
		{
			bool success = true;
			if (value.second["Value"].get(Json::ArrayIndex(0), 1).isString())
			{
				std::string newKey = *dataWrapper.ContextFrame.Top().second;
				auto& NewData = dataWrapper.ContextFrame.Top().first->Append(newKey);

				if (NewData.IsExternalStorage())
				{
					for (size_t i = 0; i < value.second["Value"].size(); i++)
					{
						if (success)
						{
							NewData.SetType(Datum::DatumTypes::Vector);
							success = NewData.SetFromString(value.second["Value"][static_cast<Json::Value::ArrayIndex>(i)].asString().c_str(), i);
						}
					}
				}
				else
				{
					for (size_t i = 0; i < value.second["Value"].size(); i++)
					{
						if (success)
						{
							NewData.PushBack(glm::vec4());
							NewData.SetType(Datum::DatumTypes::Vector);
							success = NewData.SetFromString(value.second["Value"][static_cast<Json::Value::ArrayIndex>(i)].asString().c_str(), i);
						}
					}
				}
				if (success)
				{
					isArray = true;
					return true;
				}
				dataWrapper.Data->Find(newKey)->Clear();
			}
		}
		Cleanup();
		return false;
	}

	bool JsonTableParseHelper::StartHandlerMatrix(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray)
	{
		assert(coordinator.Is(JsonTableParseHelper::Wrapper::TypeIdClass()));
		auto& dataWrapper = *static_cast<JsonTableParseHelper::Wrapper*>(&coordinator);
		if (value.second["Value"].isString())
		{
			std::string newKey = *dataWrapper.ContextFrame.Top().second;
			auto& StoredData = dataWrapper.ContextFrame.Top().first->Append(newKey);

			bool success = false;
			if (StoredData.IsExternalStorage())
			{
				success = StoredData.SetFromString(value.second["Value"].asString().c_str());
			}
			else
			{
				std::string newString = value.second["Value"].asString();
				StoredData.PushBack(glm::mat4());
				success = StoredData.SetFromString(value.second["Value"].asString().c_str());
			}
			if (success)
			{
				isArray = false;
				return true;
			}
			dataWrapper.Data->Find(newKey)->Clear();
		}
		else if (value.second["Value"].isArray())
		{
			if (value.second["Value"].get(Json::ArrayIndex(0), 1).isString())
			{
				bool success = true;
				std::string newKey = *dataWrapper.ContextFrame.Top().second;
				auto& NewData = dataWrapper.ContextFrame.Top().first->Append(newKey);

				if (NewData.IsExternalStorage())
				{
					for (size_t i = 0; i < value.second["Value"].size(); i++)
					{
						if (success)
						{
							success = NewData.SetFromString(value.second["Value"][static_cast<Json::Value::ArrayIndex>(i)].asString().c_str(), i);
						}
					}
				}
				else
				{
					for (size_t i = 0; i < value.second["Value"].size(); i++)
					{
						if (success)
						{
							NewData.PushBack(glm::mat4());
							NewData.SetType(Datum::DatumTypes::Matrix);
							success = NewData.SetFromString(value.second["Value"][static_cast<Json::Value::ArrayIndex>(i)].asString().c_str(), i);
						}
					}
				}
				if (success)
				{
					isArray = true;
					return true;
				}
				dataWrapper.Data->Find(newKey)->Clear();
			}
		}
		Cleanup();
		return false;
	}

	bool JsonTableParseHelper::StartHandlerTable(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray)
	{
		assert(coordinator.Is(JsonTableParseHelper::Wrapper::TypeIdClass()));
		auto dataWrapper = static_cast<JsonTableParseHelper::Wrapper*>(&coordinator);
		if (value.second["Value"].isObject())
		{
			isArray = false;
			if (value.second["Class"].isNull()) //Is this a basic Scope?
			{
				auto& newScope = dataWrapper->ContextFrame.Top().first->AppendScope(value.first).Find(value.first)->GetScope();
				dataWrapper->ContextFrame.Top() = (std::pair(newScope, &value.first));
			}
			else //Or is it a class derived from a scope?
			{
				auto newDerived = Factory<Scope>::Create(value.second["Class"].asString());
				if (newDerived == nullptr)
				{
					Cleanup();
					return false;
				}
				dataWrapper->ContextFrame.Top().first->Adopt((newDerived), value.first);
				dataWrapper->ContextFrame.Top() = (std::pair(newDerived, &value.first));
			}
			Cleanup();
			return true;
		}
		else if (value.second["Value"].isArray() && value.second["Value"][0].isObject())
		{
			isArray = true;
			if (value.second["Class"].isNull())
			{
				auto& newScope = dataWrapper->ContextFrame.Top().first->AppendScope(value.first).Find(value.first)->GetScope();
				dataWrapper->ContextFrame.Top() = (std::pair(newScope, &value.first));
			}
			else
			{
				auto newDerived = Factory<Scope>::Create(value.second["Class"].asString());
				if (newDerived == nullptr)
				{
					Cleanup();
					return false;
				}
				dataWrapper->ContextFrame.Top().first->Adopt((newDerived), value.first);
				dataWrapper->ContextFrame.Top() = (std::pair(newDerived, &value.first));
			}

			Cleanup();
			return true;
		}
		Cleanup();
		return false;
	}

	void JsonTableParseHelper::EndHandler(JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray)
	{
		assert(coordinator.Is(JsonTableParseHelper::Wrapper::TypeIdClass()));
		auto& dataWrapper = *static_cast<JsonTableParseHelper::Wrapper*>(&coordinator);
		dataWrapper.TotalDepth = coordinator.Depth();
		isArray;
		value;
		dataWrapper.ContextFrame.Pop();
		Cleanup();
	}
};