#include "pch.h"
#include "CppUnitTest.h"
#include "Vector.h"
#include "Foo.h"
#include <algorithm>
#include <string.h>
#include <iostream>
#include "ToStringSpecializations.h"
/// <summary>
/// The file specifying the Vector class tests. Used to cover all possible code routes and attain full coverage of the class and its variety of methods and allowed operations.
/// </summary>
using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace UnitTests;
using namespace std;
using namespace std::string_literals;

namespace Microsoft::VisualStudio::CppUnitTestFramework
{
	template<>
	std::wstring ToString<Vector<Foo>::Iterator>(const Vector<Foo>::Iterator& iterator)
	{
		wstring value;
		try
		{
			value = ToString(*iterator);
		}
		catch (const std::exception&)
		{
			value = L"end()"s;
		}
		return value;
	}
	template<>
	std::wstring ToString<Vector<Foo>::ConstIterator>(const Vector<Foo>::ConstIterator& iterator)
	{
		wstring value;
		try
		{
			value = ToString(*iterator);
		}
		catch (const std::exception&)
		{
			value = L"end()"s;
		}
		return value;
	}
}

namespace UnitTestLibraryDesktop
{
	TEST_CLASS(VectorTests)
	{

	public:

		TEST_METHOD_INITIALIZE(Initialize) //Initial setup of memory state variables to allow memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&_startMemState);
			#endif
		}

		TEST_METHOD_CLEANUP(Cleanup) //Setup for memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &_startMemState,
				&endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
			#endif
		}

		TEST_METHOD(Constructor)
		{
			Vector<Foo> myVector;
			Assert::ExpectException<std::runtime_error>([&myVector]() {auto& front = myVector.Front(); UNREFERENCED_LOCAL(front); });
			Assert::ExpectException<std::runtime_error>([&myVector]() {auto& back = myVector.Back(); UNREFERENCED_LOCAL(back); });
			Assert::AreEqual(myVector.Size(), size_t(0));
		}

		TEST_METHOD(Size)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Assert::AreEqual(vector.Size(), size_t(0)); //Ensures size is always directly tied to how many elements are currently in the list, regardless of how elements are popped or pushed

			vector.PushBack(frontElement);
			Assert::AreEqual(vector.Size(), size_t(1));

			vector.PushBack(middleElement);
			Assert::AreEqual(vector.Size(), size_t(2));

			vector.PushBack(backElement);
			Assert::AreEqual(vector.Size(), size_t(3));

			Assert::AreEqual(frontElement, vector.Front());
			Assert::AreEqual(backElement, vector.Back());
			
			vector.PopBack();
			Assert::AreEqual(vector.Size(), size_t(2));

			vector.PopBack();
			Assert::AreEqual(vector.Size(), size_t(1));

			vector.PopBack();
			Assert::AreEqual(vector.Size(), size_t(0));
		}

		TEST_METHOD(Begin)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Vector<Foo>::Iterator frontIterator = vector.begin();
			Assert::ExpectException<std::runtime_error>([&frontIterator]() {auto begin = *frontIterator; UNREFERENCED_LOCAL(begin); });

			vector.PushBack(frontElement);
			Assert::AreEqual(*vector.begin(), frontElement);

			vector.PushBack(middleElement);
			Assert::AreEqual(*vector.begin(), frontElement);

			vector.PushBack(backElement);
			Assert::AreEqual(*vector.begin(), frontElement);

			Assert::IsTrue(vector.Remove(frontIterator));

			Assert::AreEqual(*vector.begin(), middleElement);
			Assert::IsTrue(vector.Remove(frontIterator));

			Assert::AreEqual(*vector.begin(), backElement);
			Assert::IsTrue(vector.Remove(frontIterator));

			Assert::AreEqual(vector.begin(), vector.end());
			Assert::ExpectException<std::runtime_error>([&frontIterator]() {auto begin = *frontIterator; UNREFERENCED_LOCAL(begin); });
		}

		TEST_METHOD(CBegin)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Vector<Foo>::ConstIterator frontIterator = vector.cbegin();
			Assert::ExpectException<std::runtime_error>([&frontIterator]() {Foo begin = *frontIterator; UNREFERENCED_LOCAL(begin); });

			vector.PushBack(frontElement);
			Assert::AreEqual(*vector.cbegin(), frontElement);

			vector.PushBack(middleElement);
			Assert::AreEqual(*vector.cbegin(), frontElement);

			vector.PushBack(backElement);
			Assert::AreEqual(*vector.cbegin(), frontElement);

			Assert::IsTrue(vector.Remove(frontIterator));

			Assert::AreEqual(*vector.cbegin(), middleElement);
			Assert::IsTrue(vector.Remove(frontIterator));

			Assert::AreEqual(*vector.cbegin(), backElement);
			Assert::IsTrue(vector.Remove(frontIterator));

			Assert::AreEqual(vector.cbegin(), vector.cend());
			Assert::ExpectException<std::runtime_error>([&frontIterator]() {Foo begin = *frontIterator; UNREFERENCED_LOCAL(begin); });
		}

		TEST_METHOD(End)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Vector<Foo>::Iterator endIterator = vector.end();
			Assert::ExpectException<std::runtime_error>([&endIterator]() {auto end = *endIterator; UNREFERENCED_LOCAL(end); });

			vector.PushBack(frontElement);
			endIterator = vector.end();
			Assert::ExpectException<std::runtime_error>([&endIterator]() {auto end = *endIterator; UNREFERENCED_LOCAL(end); });

			vector.PushBack(middleElement);
			endIterator = vector.end();
			Assert::ExpectException<std::runtime_error>([&endIterator]() {auto end = *endIterator; UNREFERENCED_LOCAL(end); });

			vector.PushBack(backElement);
			endIterator = vector.end();
			Assert::ExpectException<std::runtime_error>([&endIterator]() {auto end = *endIterator; UNREFERENCED_LOCAL(end); });

			vector.PopBack();
			endIterator = vector.end();
			Assert::ExpectException<std::runtime_error>([&endIterator]() {auto end = *endIterator; UNREFERENCED_LOCAL(end); });

			vector.PopBack();
			endIterator = vector.end();
			Assert::ExpectException<std::runtime_error>([&endIterator]() {auto end = *endIterator; UNREFERENCED_LOCAL(end); });

			vector.PopBack();
			endIterator = vector.end();
			Assert::ExpectException<std::runtime_error>([&endIterator]() {auto end = *endIterator; UNREFERENCED_LOCAL(end); });
		}

		TEST_METHOD(CEnd)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Vector<Foo>::ConstIterator endIterator = vector.cend();
			Assert::ExpectException<std::runtime_error>([&endIterator]() {Foo end = *endIterator; UNREFERENCED_LOCAL(end); });

			vector.PushBack(frontElement);
			Assert::AreEqual(*endIterator, frontElement);
			endIterator = vector.cend();
			Assert::ExpectException<std::runtime_error>([&endIterator]() {Foo end = *endIterator; UNREFERENCED_LOCAL(end); });

			vector.PushBack(middleElement);
			Assert::AreEqual(*endIterator, middleElement);
			endIterator = vector.cend();
			Assert::ExpectException<std::runtime_error>([&endIterator]() {Foo end = *endIterator; UNREFERENCED_LOCAL(end); });

			vector.PushBack(backElement);
			Assert::AreEqual(*endIterator, backElement);
			endIterator = vector.cend();
			Assert::ExpectException<std::runtime_error>([&endIterator]() {Foo end = *endIterator; UNREFERENCED_LOCAL(end); });

			Assert::IsFalse(vector.Remove(endIterator));
			endIterator--;
			Assert::IsTrue(vector.Remove(endIterator));
			endIterator--;
			Assert::IsTrue(vector.Remove(endIterator));
			endIterator--;
			Assert::IsTrue(vector.Remove(endIterator));
			endIterator--;
			Assert::AreEqual(vector.cend(), endIterator);
		}

		TEST_METHOD(Front)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Assert::ExpectException<std::runtime_error>([&vector]() {auto& front = vector.Front(); UNREFERENCED_LOCAL(front); });

			vector.PushBack(frontElement);
			Assert::AreEqual(vector.Front(), frontElement);

			vector.PushBack(middleElement);
			Assert::AreEqual(vector.Front(), frontElement);

			vector.PushBack(backElement);
			Assert::AreEqual(vector.Front(), frontElement);

			vector.PopBack();
			Assert::AreEqual(vector.Front(), frontElement);

			vector.PopBack();
			Assert::AreEqual(vector.Front(), frontElement);

			vector.PopBack();
			Assert::ExpectException<std::runtime_error>([&vector]() {auto& front = vector.Front(); UNREFERENCED_LOCAL(front); });
		}

		TEST_METHOD(ConstFront)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Assert::ExpectException<std::runtime_error>([&vector]() {auto& front = vector.Front(); UNREFERENCED_LOCAL(front); });

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			const Vector<Foo> constantVector = vector;
			const Vector<Foo> emptyVector;
			Assert::AreEqual(constantVector.Front(), frontElement);
			Assert::ExpectException<std::runtime_error>([&emptyVector]() {emptyVector.Front(); });
		}

		TEST_METHOD(Back)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Assert::ExpectException<std::runtime_error>([&vector]() {auto& back = vector.Back(); UNREFERENCED_LOCAL(back); });

			vector.PushBack(frontElement);
			Assert::AreEqual(vector.Back(), frontElement);

			vector.PushBack(middleElement);
			Assert::AreEqual(vector.Back(), middleElement);

			vector.PushBack(backElement);
			Assert::AreEqual(vector.Back(), backElement);

			vector.PopBack();
			Assert::AreEqual(vector.Back(), middleElement);
			
			vector.PopBack();
			Assert::AreEqual(vector.Back(), frontElement);

			vector.PopBack();
			Assert::ExpectException<std::runtime_error>([&vector]() {auto& back = vector.Back(); UNREFERENCED_LOCAL(back); });
		}

		TEST_METHOD(ConstBack)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Assert::ExpectException<std::runtime_error>([&vector]() {auto& back = vector.Back(); UNREFERENCED_LOCAL(back); });

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			const Vector<Foo> constantVector = vector;
			const Vector<Foo> emptyVector;
			Assert::AreEqual(constantVector.Back(), backElement);
			Assert::ExpectException<std::runtime_error>([&emptyVector]() {emptyVector.Back(); });
		}

		TEST_METHOD(IsEmpty)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Assert::IsTrue(vector.IsEmpty());

			vector.PushBack(frontElement);
			Assert::IsFalse(vector.IsEmpty());

			vector.PushBack(middleElement);
			Assert::IsFalse(vector.IsEmpty());

			vector.PushBack(backElement);
			Assert::IsFalse(vector.IsEmpty());

			vector.PopBack();
			Assert::IsFalse(vector.IsEmpty());

			vector.PopBack();
			Assert::IsFalse(vector.IsEmpty());

			vector.PopBack();
			Assert::IsTrue(vector.IsEmpty());
		}

		TEST_METHOD(Capacity)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.Reserve(5);
			Assert::AreEqual(vector.Capacity(), size_t(5));
			vector.Reserve(4);
			Assert::AreEqual(vector.Capacity(), size_t(5));
			vector.Reserve(0);
			Assert::AreEqual(vector.Capacity(), size_t(5));

			vector.PushBack(frontElement);
			vector.PushBack(frontElement);
			Assert::AreEqual(vector.Capacity(), size_t(5));
			vector.PushBack(middleElement);
			vector.PushBack(middleElement);
			Assert::AreEqual(vector.Capacity(), size_t(5));
			vector.PushBack(backElement);
			vector.PushBack(backElement);
			Assert::AreEqual(vector.Capacity(), size_t(6));

			vector.PopBack();
			vector.PopBack();
			Assert::AreEqual(vector.Capacity(), size_t(6));
			Assert::AreEqual(vector.Size(), size_t(4));

			vector.ShrinkToFit();
			Assert::AreEqual(vector.Capacity(), size_t(4));

			vector.Clear();
			vector.ShrinkToFit();
			Assert::AreEqual(vector.Capacity(), size_t(0));
		}

		TEST_METHOD(Reserve)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.Reserve(5);
			Assert::AreEqual(vector.Capacity(), size_t(5));

			vector.Reserve(4);
			Assert::AreEqual(vector.Capacity(), size_t(5));

			vector.Reserve(0);
			Assert::AreEqual(vector.Capacity(), size_t(5));

			Assert::AreEqual(vector.Size(), size_t(0));

			vector.PushBack(frontElement);
			vector.PushBack(frontElement);
			Assert::AreEqual(vector.Capacity(), size_t(5));
			vector.PushBack(middleElement);
			vector.PushBack(middleElement);
			Assert::AreEqual(vector.Capacity(), size_t(5));
			vector.PushBack(backElement);
			vector.PushBack(backElement);
			Assert::AreEqual(vector.Capacity(), size_t(6));

			vector.PopBack();
			Assert::AreEqual(vector.Capacity(), size_t(6));
			Assert::AreEqual(vector.Size(), size_t(5));
			Assert::AreNotEqual(vector.Capacity(), vector.Size());

			vector.ShrinkToFit();
			Assert::AreEqual(vector.Size(), size_t(5));
			Assert::AreEqual(vector.Capacity(), size_t(5));
			//Assert::ExpectException<std::runtime_error>([&vector]() {vector.Reserve(65536); }); //Reserving a space larger than uint16_t elements has a tendency to fail. I would rather get an exception than have the program aborted.
		}

		TEST_METHOD(Find)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Vector<Foo>::Iterator traverser = vector.begin();
			traverser++;
			Assert::AreEqual(traverser, vector.Find(middleElement));
			traverser++;
			Assert::AreEqual(traverser, vector.Find(backElement));

			Assert::AreEqual(vector.begin(), vector.Find(frontElement));
			vector.Remove(frontElement);
			Assert::AreEqual(vector.Find(frontElement), vector.end()); //If not in array anymore, just returns reference to end
		}

		TEST_METHOD(RemoveIterator)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Assert::AreEqual(vector.Back(), backElement);
			Assert::AreEqual(vector.Front(), frontElement);
			Assert::AreEqual(vector.Size(), size_t(3));

			Vector<Foo>::Iterator middleIterator = vector.begin();
			Vector<Foo>::Iterator unassignedIterator;

			Assert::ExpectException<std::runtime_error>([&vector, unassignedIterator]() {vector.Remove(unassignedIterator); });//Cannot remove iterator not assigned to the Vector
			middleIterator++;


			Assert::AreEqual(*middleIterator, middleElement); //Element is successfully removed, iterator points to new element at index [1]
			Assert::IsTrue(vector.Remove(middleIterator));
			Assert::AreEqual(*middleIterator, backElement);

			Assert::AreEqual(vector.Size(), size_t(2));
			Assert::AreEqual(vector.Capacity(), size_t(3));

			Assert::IsTrue(vector.Remove(middleIterator));
			Assert::AreEqual(vector.Size(), size_t(1));
			Assert::AreEqual(vector.Capacity(), size_t(3));
			middleIterator--;
			Assert::AreEqual(vector.Front(), frontElement);

			Assert::IsTrue(vector.Remove(middleIterator));
			Assert::AreEqual(vector.Size(), size_t(0));
			Assert::AreEqual(vector.Capacity(), size_t(3));
		}

		TEST_METHOD(RemoveConstIteratorRange)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Assert::AreEqual(vector.Back(), backElement);
			Assert::AreEqual(vector.Front(), frontElement);
			Assert::AreEqual(vector.Size(), size_t(6));

			Vector<Foo>::ConstIterator startIterator = vector.cbegin();
			Vector<Foo>::ConstIterator endIterator = vector.cend();
			Vector<Foo>::ConstIterator unassignedFront;
			Vector<Foo>::ConstIterator unassignedBack;
			Assert::ExpectException<std::runtime_error>([&vector, unassignedFront, unassignedBack]() {vector.Remove(unassignedFront, unassignedBack); });//Cannot remove iterator not assigned to the Vector

			Assert::IsFalse(vector.Remove(startIterator, endIterator)); //End iterator must be an element within the vector
			endIterator-=2; //enditerator is now equal to vector[4]
			startIterator+=5;
			Assert::IsFalse(vector.Remove(startIterator, endIterator)); //Start iterator may not exceed end iterator.
			startIterator -= 3; //startiterator is now equal to vector[2]

			Assert::AreEqual(*startIterator, backElement);
			Assert::AreEqual(*endIterator, middleElement);

			Assert::IsTrue(vector.Remove(startIterator, endIterator)); //This will remove elements 2, 3, and 4;
			Assert::AreEqual(vector.Size(), size_t(3));
			Assert::AreEqual(vector.Capacity(), size_t(6));

			Assert::AreEqual(vector[0], frontElement);
			Assert::AreEqual(vector[1], middleElement);
			Assert::AreEqual(vector[2], backElement);
			vector.PushBack(backElement);

			startIterator = vector.cbegin();
			endIterator = vector.cbegin();
			endIterator++;
			Assert::IsTrue(vector.Remove(startIterator, endIterator)); //This will remove elements 0 and 1

			Assert::AreEqual(vector[0], backElement);
			Assert::AreEqual(vector[1], backElement);
			Assert::IsTrue(vector.Remove(startIterator, endIterator)); //This will remove elements 0 and 1, now the vector is empty
		}

		TEST_METHOD(RemoveIteratorRange)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Assert::AreEqual(vector.Back(), backElement);
			Assert::AreEqual(vector.Front(), frontElement);
			Assert::AreEqual(vector.Size(), size_t(6));

			Vector<Foo>::Iterator startIterator = vector.begin();
			Vector<Foo>::Iterator endIterator = vector.end();
			Vector<Foo>::Iterator unassignedFront;
			Vector<Foo>::Iterator unassignedBack;
			Assert::ExpectException<std::runtime_error>([&vector, unassignedFront, unassignedBack]() {vector.Remove(unassignedFront, unassignedBack); });//Cannot remove iterator not assigned to the Vector

			Assert::IsFalse(vector.Remove(startIterator, endIterator)); //End iterator must be an element within the vector
			endIterator -= 2; //enditerator is now equal to vector[4]
			startIterator += 5;
			Assert::IsFalse(vector.Remove(startIterator, endIterator)); //Start iterator may not exceed end iterator.
			startIterator -= 3; //startiterator is now equal to vector[2]

			Assert::AreEqual(*startIterator, backElement);
			Assert::AreEqual(*endIterator, middleElement);

			Assert::IsTrue(vector.Remove(startIterator, endIterator)); //This will remove elements 2, 3, and 4;
			Assert::AreEqual(vector.Size(), size_t(3));
			Assert::AreEqual(vector.Capacity(), size_t(6));

			Assert::AreEqual(vector[0], frontElement);
			Assert::AreEqual(vector[1], middleElement);
			Assert::AreEqual(vector[2], backElement);
			vector.PushBack(backElement);

			startIterator = vector.begin();
			endIterator = vector.begin();
			endIterator++;
			Assert::IsTrue(vector.Remove(startIterator, endIterator)); //This will remove elements 0 and 1

			Assert::AreEqual(vector[0], backElement);
			Assert::AreEqual(vector[1], backElement);
			Assert::IsTrue(vector.Remove(startIterator, endIterator)); //This will remove elements 0 and 1, now the vector is empty
		}

		TEST_METHOD(RemoveConstIterator)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Assert::AreEqual(vector.Back(), backElement);
			Assert::AreEqual(vector.Front(), frontElement);
			Assert::AreEqual(vector.Size(), size_t(3));

			Vector<Foo>::ConstIterator middleIterator = vector.cbegin();
			Vector<Foo>::ConstIterator unassignedIterator;
			Assert::ExpectException<std::runtime_error>([&vector, unassignedIterator]() {vector.Remove(unassignedIterator); });//Cannot remove ConstIterator not assigned to the Vector

			middleIterator++;

			Assert::AreEqual(*middleIterator, middleElement); //Element is successfully removed, iterator points to new element at index [1]
			Assert::IsTrue(vector.Remove(middleIterator));
			Assert::AreEqual(*middleIterator, backElement);

			Assert::AreEqual(vector.Size(), size_t(2));
			Assert::AreEqual(vector.Capacity(), size_t(3));

			Assert::IsTrue(vector.Remove(middleIterator));
			Assert::AreEqual(vector.Size(), size_t(1));
			Assert::AreEqual(vector.Capacity(), size_t(3));
			Assert::IsFalse(vector.Remove(middleIterator));
			middleIterator--;
			Assert::AreEqual(vector.Front(), frontElement);

			Assert::IsTrue(vector.Remove(middleIterator));
			Assert::AreEqual(vector.Size(), size_t(0));
			Assert::AreEqual(vector.Capacity(), size_t(3));
		}

		TEST_METHOD(RemoveValue)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Assert::AreEqual(vector.Back(), backElement);
			Assert::AreEqual(vector.Front(), frontElement);
			Assert::AreEqual(vector.Size(), size_t(3));

			Assert::AreEqual(vector[1], middleElement);
			Assert::AreEqual(vector[2], backElement);
			Assert::IsTrue(vector.Remove(middleElement));
			Assert::AreEqual(vector[1], backElement);
			Assert::IsFalse(vector.Remove(middleElement));

			Assert::AreEqual(vector.Size(), size_t(2));
			Assert::AreEqual(vector.Capacity(), size_t(3));

			Assert::IsTrue(vector.Remove(backElement));
			Assert::AreEqual(vector.Size(), size_t(1));
			Assert::AreEqual(vector.Capacity(), size_t(3));
			Assert::AreEqual(vector[0], frontElement);
			Assert::IsFalse(vector.Remove(backElement));

			Assert::IsTrue(vector.Remove(frontElement));
			Assert::AreEqual(vector.Size(), size_t(0));
			Assert::AreEqual(vector.Capacity(), size_t(3));
		}

		TEST_METHOD(PopBack)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			Assert::AreEqual(vector.Back(), frontElement);
			Assert::AreEqual(vector.Size(), size_t(1));

			vector.PushBack(middleElement);
			Assert::AreEqual(vector.Back(), middleElement);
			Assert::AreEqual(vector.Size(), size_t(2));

			vector.PushBack(backElement);
			Assert::AreEqual(vector.Back(), backElement);
			Assert::AreEqual(vector.Size(), size_t(3));

			vector.PopBack();
			Assert::AreEqual(vector.Back(), middleElement);
			Assert::AreEqual(vector.Size(), size_t(2));

			vector.PopBack();
			Assert::AreEqual(vector.Back(), frontElement);
			Assert::AreEqual(vector.Size(), size_t(1));

			vector.PopBack();
			Assert::ExpectException<std::runtime_error>([&vector]() {auto& back = vector.Back(); UNREFERENCED_LOCAL(back); });
			Assert::AreEqual(vector.Size(), size_t(0));

			Assert::AreEqual(vector.Capacity(), size_t(3));
		}

		TEST_METHOD(PushBack)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Assert::AreEqual(vector.Size(), size_t(0)); //Ensures size is always directly tied to how many elements are currently in the list, regardless of how elements are popped or pushed

			vector.PushBack(frontElement);
			Assert::AreEqual(vector.Size(), size_t(1));
			Assert::AreEqual(vector.Capacity(), size_t(1));
			Assert::AreEqual(frontElement, vector.Back());

			vector.PushBack(middleElement);
			Assert::AreEqual(vector.Size(), size_t(2));
			Assert::AreEqual(vector.Capacity(), size_t(2));
			Assert::AreEqual(middleElement, vector.Back());

			vector.PushBack(backElement);
			Assert::AreEqual(vector.Size(), size_t(3));
			Assert::AreEqual(vector.Capacity(), size_t(3));
			Assert::AreEqual(backElement, vector.Back());
		}

		TEST_METHOD(AtNonConst)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Assert::AreEqual(vector.At(0), frontElement);
			Assert::AreEqual(vector.At(1), middleElement);
			Assert::AreEqual(vector.At(2), backElement);
			Assert::AreEqual(vector.At(3), frontElement);
			Assert::AreEqual(vector.At(4), middleElement);
			Assert::AreEqual(vector.At(5), backElement);
			Assert::ExpectException<std::runtime_error>([&vector]() {vector.At(6); });
			vector.Remove(frontElement);
		}

		TEST_METHOD(AtConst)
		{
			Vector<Foo> nonConstVector;
			Foo frontElement(20), middleElement(30), backElement(40);

			nonConstVector.PushBack(frontElement);
			nonConstVector.PushBack(middleElement);
			nonConstVector.PushBack(backElement);
			nonConstVector.PushBack(frontElement);
			nonConstVector.PushBack(middleElement);
			nonConstVector.PushBack(backElement);

			const Vector<Foo> vector = nonConstVector;

			Assert::AreEqual(vector.At(0), frontElement);
			Assert::AreEqual(vector.At(1), middleElement);
			Assert::AreEqual(vector.At(2), backElement);
			Assert::AreEqual(vector.At(3), frontElement);
			Assert::AreEqual(vector.At(4), middleElement);
			Assert::AreEqual(vector.At(5), backElement);
			Assert::ExpectException<std::runtime_error>([&vector]() {vector.At(6); });
		}

		TEST_METHOD(IndexOperator)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Assert::AreEqual(vector[0], frontElement);
			Assert::AreEqual(vector[1], middleElement);
			Assert::AreEqual(vector[2], backElement);
			Assert::AreEqual(vector[3], frontElement);
			Assert::AreEqual(vector[4], middleElement);
			Assert::AreEqual(vector[5], backElement);
			Assert::ExpectException<std::runtime_error>([&vector]() {vector[6]; });
		}

		TEST_METHOD(ConstIndexOperator)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			const Vector<Foo> constVector = vector;

			Assert::AreEqual(constVector[0], frontElement);
			Assert::AreEqual(constVector[1], middleElement);
			Assert::AreEqual(constVector[2], backElement);
			Assert::AreEqual(constVector[3], frontElement);
			Assert::AreEqual(constVector[4], middleElement);
			Assert::AreEqual(constVector[5], backElement);
			Assert::ExpectException<std::runtime_error>([&constVector]() {constVector[6]; });
		}

		TEST_METHOD(MoveConstructor)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Vector<Foo> moveVector = std::move(vector);
			Assert::AreEqual(moveVector[0], frontElement);
			Assert::AreEqual(moveVector[1], middleElement);
			Assert::AreEqual(moveVector[2], backElement);
		}

		TEST_METHOD(MoveAssignment)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Vector<Foo> moveVector;
			moveVector = std::move(vector);
			Assert::AreEqual(moveVector[0], frontElement);
			Assert::AreEqual(moveVector[1], middleElement);
			Assert::AreEqual(moveVector[2], backElement);
		}

		TEST_METHOD(CopyConstructor)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Vector<Foo> copyVector = vector;
			Vector<Foo> emptyVector;
			Vector<Foo> copyOfEmptyVector = emptyVector; //No exception is thrown if an empty vector is copied
			Assert::AreEqual(copyOfEmptyVector.Size(), emptyVector.Size());
			Assert::AreEqual(copyOfEmptyVector.Capacity(), emptyVector.Capacity());

			Assert::AreEqual(copyVector[0], frontElement);
			Assert::AreEqual(copyVector[1], middleElement);
			Assert::AreEqual(copyVector[2], backElement);

			Assert::AreEqual(vector[0], frontElement);
			Assert::AreEqual(vector[1], middleElement);
			Assert::AreEqual(vector[2], backElement);
		}

		TEST_METHOD(CopyAssignment)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Vector<Foo> copyVector;
			Vector<Foo> filledCopy;

			filledCopy.Reserve(20);
			filledCopy.PushBack(backElement);
			filledCopy.PushBack(backElement);
			filledCopy.PushBack(backElement);
			filledCopy.PushBack(backElement);
			filledCopy.PushBack(backElement);
			Assert::AreEqual(filledCopy.Size(), size_t(5));
			Assert::AreEqual(filledCopy.Capacity(), size_t(20));

			copyVector = vector; //Empty vector can be set to the vector being copied.
			Assert::AreEqual(copyVector[0], frontElement);
			Assert::AreEqual(copyVector[1], middleElement);
			Assert::AreEqual(copyVector[2], backElement);

			Assert::AreEqual(vector[0], frontElement);
			Assert::AreEqual(vector[1], middleElement);
			Assert::AreEqual(vector[2], backElement);

			filledCopy = vector; //Vector with elements can also be set to the vector being copied.
			Assert::AreEqual(filledCopy[0], frontElement);
			Assert::AreEqual(filledCopy[1], middleElement);
			Assert::AreEqual(filledCopy[2], backElement);

			Assert::AreEqual(filledCopy.Size(), size_t(3));
			Assert::AreEqual(filledCopy.Capacity(), size_t(20)); //Capacity is maintained despite the copy assignment.
		}

		TEST_METHOD(Destructor)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Assert::AreEqual(vector.Size(), size_t(0));
			vector.Reserve(5);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Assert::IsFalse(vector.IsEmpty());
			Assert::AreEqual(vector[0], frontElement);
			Assert::AreEqual(vector.Size(), size_t(3));
			Assert::AreEqual(vector.Capacity(), size_t(5));

			vector.~Vector();
			Assert::ExpectException<std::runtime_error>([&vector]() {vector[0];});
			Assert::IsTrue(vector.IsEmpty());
			Assert::AreEqual(vector.Size(), size_t(0));
			Assert::AreEqual(vector.Capacity(), size_t(0));
		}

		TEST_METHOD(Clear)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Assert::AreEqual(vector[0], frontElement);
			Assert::AreEqual(vector[1], middleElement);
			Assert::AreEqual(vector[2], backElement);
			Assert::AreEqual(vector.Size(), size_t(3));
			Assert::AreEqual(vector.Capacity(), size_t(3));

			vector.Clear();

			Assert::AreEqual(vector.Size(), size_t(0));
			Assert::AreEqual(vector.Capacity(), size_t(3));
			Assert::ExpectException<std::runtime_error>([&vector]() {vector[0]; });
			Assert::ExpectException<std::runtime_error>([&vector]() {vector[1]; });
			Assert::ExpectException<std::runtime_error>([&vector]() {vector[2]; });
		}

		TEST_METHOD(ShrinkToFit)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Assert::AreEqual(vector.Size(), size_t(3));
			Assert::AreEqual(vector.Capacity(), size_t(3));

			vector.ShrinkToFit();
			Assert::AreEqual(vector.Size(), size_t(3));
			Assert::AreEqual(vector.Capacity(), size_t(3));

			vector.Reserve(5);
			Assert::AreEqual(vector.Size(), size_t(3));
			Assert::AreEqual(vector.Capacity(), size_t(5));

			vector.ShrinkToFit();
			Assert::AreEqual(vector.Size(), size_t(3));
			Assert::AreEqual(vector.Capacity(), size_t(3));

			vector.Clear();
			Assert::AreEqual(vector.Size(), size_t(0));
			Assert::AreEqual(vector.Capacity(), size_t(3));
			vector.ShrinkToFit();
			Assert::AreEqual(vector.Size(), size_t(0));
			Assert::AreEqual(vector.Capacity(), size_t(0));

		}

//ITERATOR TESTS
		
		TEST_METHOD(IteratorIsEqual)
		{
			Vector<Foo> vector;
			Vector<Foo> vectorClone;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			vectorClone = vector;

			Vector<Foo>::Iterator frontIterator = vector.begin();
			Vector<Foo>::Iterator backIterator = vector.end();
			Vector<Foo>::Iterator cloneIterator = vectorClone.begin();

			Assert::IsFalse(frontIterator == backIterator);
			backIterator--;
			Assert::IsFalse(frontIterator == backIterator);
			backIterator--;
			Assert::IsFalse(frontIterator == backIterator);
			backIterator--;
			Assert::IsTrue(frontIterator == backIterator);

			Assert::IsFalse(frontIterator == cloneIterator); //They are not equivalent if they have different owners
		}

		TEST_METHOD(ConstIteratorIsEqual)
		{
			Vector<Foo> vector;
			Vector<Foo> vectorClone;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			vectorClone = vector;

			Vector<Foo>::ConstIterator frontIterator = vector.begin();
			Vector<Foo>::ConstIterator backIterator = vector.end();
			Vector<Foo>::ConstIterator cloneIterator = vectorClone.begin();

			Assert::IsFalse(frontIterator == backIterator);
			backIterator--;
			Assert::IsFalse(frontIterator == backIterator);
			backIterator--;
			Assert::IsFalse(frontIterator == backIterator);
			backIterator--;
			Assert::IsTrue(frontIterator == backIterator);

			Assert::IsFalse(frontIterator == cloneIterator); //They are not equivalent if they have different owners
		}

		TEST_METHOD(IteratorIsNotEqual)
		{
			Vector<Foo> vector;
			Vector<Foo> vectorClone;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			vectorClone = vector;

			Vector<Foo>::Iterator frontIterator = vector.begin();
			Vector<Foo>::Iterator backIterator = vector.end();
			Vector<Foo>::Iterator cloneIterator = vectorClone.begin();

			Assert::IsTrue(frontIterator != backIterator);
			backIterator--;
			Assert::IsTrue(frontIterator != backIterator);
			backIterator--;
			Assert::IsTrue(frontIterator != backIterator);
			backIterator--;
			Assert::IsFalse(frontIterator != backIterator);

			Assert::IsTrue(frontIterator != cloneIterator); //They are not equivalent if they have different owners
		}

		TEST_METHOD(ConstIteratorIsNotEqual)
		{
			Vector<Foo> vector;
			Vector<Foo> vectorClone;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			vectorClone = vector;

			Vector<Foo>::ConstIterator frontIterator = vector.begin();
			Vector<Foo>::ConstIterator backIterator = vector.end();
			Vector<Foo>::ConstIterator cloneIterator = vectorClone.begin();

			Assert::IsTrue(frontIterator != backIterator);
			backIterator--;
			Assert::IsTrue(frontIterator != backIterator);
			backIterator--;
			Assert::IsTrue(frontIterator != backIterator);
			backIterator--;
			Assert::IsFalse(frontIterator != backIterator);

			Assert::IsTrue(frontIterator != cloneIterator); //They are not equivalent if they have different owners
		}

		TEST_METHOD(IteratorPostIncrement)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Vector<Foo>::Iterator traverser = vector.begin();

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Assert::AreEqual(*traverser, frontElement);
			Assert::AreNotEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, backElement);
			traverser++;

			Assert::AreEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, frontElement);
			Assert::AreNotEqual(*traverser, backElement);
			traverser++;

			Assert::AreEqual(*traverser, backElement);
			Assert::AreNotEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, frontElement);
			traverser++;

			Assert::AreEqual(traverser, vector.end());
		}

		TEST_METHOD(ConstIteratorPostIncrement)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Vector<Foo>::ConstIterator traverser = vector.cbegin();

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Assert::AreEqual(*traverser, frontElement);
			Assert::AreNotEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, backElement);
			traverser++;

			Assert::AreEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, frontElement);
			Assert::AreNotEqual(*traverser, backElement);
			traverser++;

			Assert::AreEqual(*traverser, backElement);
			Assert::AreNotEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, frontElement);
			traverser++;

			Assert::AreEqual(traverser, vector.cend());
		}

		TEST_METHOD(IteratorPreIncrement)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Vector<Foo>::Iterator traverser = vector.begin();

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Assert::AreEqual(*traverser, frontElement);
			Assert::AreNotEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, backElement);
			++traverser;

			Assert::AreEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, frontElement);
			Assert::AreNotEqual(*traverser, backElement);
			++traverser;

			Assert::AreEqual(*traverser, backElement);
			Assert::AreNotEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, frontElement);
			++traverser;

			Assert::AreEqual(traverser, vector.end());
		}

		TEST_METHOD(ConstIteratorPreIncrement)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);
			Vector<Foo>::ConstIterator traverser = vector.cbegin();

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Assert::AreEqual(*traverser, frontElement);
			Assert::AreNotEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, backElement);
			++traverser;

			Assert::AreEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, frontElement);
			Assert::AreNotEqual(*traverser, backElement);
			++traverser;

			Assert::AreEqual(*traverser, backElement);
			Assert::AreNotEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, frontElement);
			++traverser;

			Assert::AreEqual(traverser, vector.cend());
		}

		TEST_METHOD(IteratorPostDecrement)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::Iterator traverser = vector.end();

			traverser--;

			Assert::AreEqual(*traverser, backElement);
			Assert::AreNotEqual(*traverser, frontElement);
			Assert::AreNotEqual(*traverser, middleElement);
			traverser--;

			Assert::AreEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, backElement);
			Assert::AreNotEqual(*traverser, frontElement);
			traverser--;

			Assert::AreEqual(*traverser, frontElement);
		}

		TEST_METHOD(ConstIteratorPostDecrement)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::ConstIterator traverser = vector.cend();

			traverser--;

			Assert::AreEqual(*traverser, backElement);
			Assert::AreNotEqual(*traverser, frontElement);
			Assert::AreNotEqual(*traverser, middleElement);
			traverser--;

			Assert::AreEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, backElement);
			Assert::AreNotEqual(*traverser, frontElement);
			traverser--;

			Assert::AreEqual(*traverser, frontElement);
		}

		TEST_METHOD(IteratorPreDecrement)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::Iterator traverser = vector.end();

			--traverser;

			Assert::AreEqual(*traverser, backElement);
			Assert::AreNotEqual(*traverser, frontElement);
			Assert::AreNotEqual(*traverser, middleElement);
			--traverser;

			Assert::AreEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, backElement);
			Assert::AreNotEqual(*traverser, frontElement);
			--traverser;

			Assert::AreEqual(*traverser, frontElement);
		}

		TEST_METHOD(ConstIteratorPreDecrement)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::ConstIterator traverser = vector.cend();

			--traverser;

			Assert::AreEqual(*traverser, backElement);
			Assert::AreNotEqual(*traverser, frontElement);
			Assert::AreNotEqual(*traverser, middleElement);
			--traverser;

			Assert::AreEqual(*traverser, middleElement);
			Assert::AreNotEqual(*traverser, backElement);
			Assert::AreNotEqual(*traverser, frontElement);
			--traverser;

			Assert::AreEqual(*traverser, frontElement);
		}

		TEST_METHOD(IteratorPlusInt)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::Iterator traverser = vector.begin();

			Assert::AreEqual(*traverser, frontElement);
			Assert::AreEqual(*(traverser + 2), backElement);
			Assert::AreEqual(traverser + 4, vector.end()); //If an increment plus current index exceeds the size of the vector, the index is set to the end of the vector.
		}

		TEST_METHOD(ConstIteratorPlusInt)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::ConstIterator traverser = vector.cbegin();

			Assert::AreEqual(*traverser, frontElement);
			Assert::AreEqual(*(traverser + 2), backElement);
			Assert::AreEqual(traverser + 4, vector.cend()); //If an increment plus current index exceeds the size of the vector, the index is set to the end of the vector.
		}

		TEST_METHOD(IteratorMinusInt)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::Iterator traverser = vector.end();

			Assert::AreEqual(traverser, vector.end());
			Assert::AreEqual(*(traverser -2), middleElement);
			Assert::AreEqual(traverser - 4, vector.begin()); //If an increment minus current index goes below the start of the vector, the index is set to the beginning of the vector.
		}

		TEST_METHOD(ConstIteratorMinusInt)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::ConstIterator traverser = vector.cend();

			Assert::AreEqual(traverser, vector.cend());
			Assert::AreEqual(*(traverser - 2), middleElement);
			Assert::AreEqual(traverser - 4, vector.cbegin()); //If an increment minus current index goes below the start of the vector, the index is set to the beginning of the vector.
		}

		TEST_METHOD(IteratorPlusIterator)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::Iterator begin = vector.begin();
			Vector<Foo>::Iterator end = vector.end();
			Vector<Foo>::Iterator uninitialized;

			Assert::AreEqual(*begin, frontElement);
			Assert::AreEqual(end, vector.end());
			Assert::ExpectException<std::runtime_error>([&begin, &uninitialized]() {begin + uninitialized; }); //Two iterators with different owners may not be added.

			end -= 1;

			Assert::AreEqual(*(begin+end), vector[2]);
			Assert::AreEqual(*end, vector[2]);

			Assert::AreEqual(begin + end, vector.end()); //When begin exceeds size of array, no matter by how much, it is set equal to the end of the vector, no further
			Assert::AreEqual(*end, vector[2]);
		}

		TEST_METHOD(ConstIteratorPlusIterator)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::ConstIterator begin = vector.begin();
			Vector<Foo>::ConstIterator end = vector.end();
			Vector<Foo>::ConstIterator uninitialized;

			Assert::AreEqual(*begin, frontElement);
			Assert::AreEqual(end, vector.cend());
			Assert::ExpectException<std::runtime_error>([&begin, &uninitialized]() {begin + uninitialized; }); //Two iterators with different owners may not be added.

			end -= 1;

			Assert::AreEqual(*(begin + end), vector[2]);
			Assert::AreEqual(*end, vector[2]);

			Assert::AreEqual(begin + end, vector.cend()); //When begin exceeds size of array, no matter by how much, it is set equal to the end of the vector, no further
			Assert::AreEqual(*end, vector[2]);
		}

		TEST_METHOD(IteratorMinusIterator)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::Iterator end = vector.end();
			Vector<Foo>::Iterator begin = vector.begin();
			Vector<Foo>::Iterator uninitialized;

			Assert::AreEqual(end, vector.end());
			Assert::AreEqual(begin, vector.begin());

			//This will not affect the end iterator, the index for begin is 0.
			Assert::AreEqual(end - begin, vector.end());
			Assert::ExpectException<std::runtime_error>([&end, &uninitialized]() {end - uninitialized; }); //Two iterators with different owners may not be subtracted.

			begin += 2;

			Assert::AreEqual(*(end-begin), vector[1]);
			Assert::AreEqual(*begin, vector[2]);
			end -= 2;

			Assert::AreEqual((end-begin), vector.begin()); //If an increment minus current index goes below the start of the vector, the index is set to the beginning of the vector.
			Assert::AreEqual(*begin, vector[2]);
		}

		TEST_METHOD(ConstIteratorMinusIterator)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::ConstIterator end = vector.cend();
			Vector<Foo>::ConstIterator begin = vector.cbegin();
			Vector<Foo>::ConstIterator uninitialized;

			Assert::AreEqual(end, vector.cend());
			Assert::AreEqual(begin, vector.cbegin());

			//This will not affect the end iterator, the index for begin is 0.
			Assert::AreEqual(end - begin, vector.cend());
			Assert::ExpectException<std::runtime_error>([&end, &uninitialized]() {end - uninitialized; }); //Two iterators with different owners may not be subtracted.

			begin += 2;

			Assert::AreEqual(*(end - begin), vector[1]);
			Assert::AreEqual(*begin, vector[2]);
			end -= 2;

			Assert::AreEqual((end - begin), vector.cbegin()); //If an increment minus current index goes below the start of the vector, the index is set to the beginning of the vector.
			Assert::AreEqual(*begin, vector[2]);
		}

		TEST_METHOD(IteratorPlusEqualInt)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::Iterator traverser = vector.begin();

			Assert::AreEqual(*traverser, frontElement);
			traverser += 2;
			Assert::AreEqual(*traverser, backElement);
			traverser += 2;
			Assert::AreEqual(traverser, vector.end()); //If an increment plus current index exceeds the size of the vector, the index is set to the end of the vector.
		}

		TEST_METHOD(ConstIteratorPlusEqualInt)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::ConstIterator traverser = vector.cbegin();

			Assert::AreEqual(*traverser, frontElement);
			traverser += 2;
			Assert::AreEqual(*traverser, backElement);
			traverser += 2;
			Assert::AreEqual(traverser, vector.cend()); //If an increment plus current index exceeds the size of the vector, the index is set to the end of the vector.
		}

		TEST_METHOD(IteratorMinusEqualInt)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::Iterator traverser = vector.end();

			Assert::AreEqual(traverser, vector.end());
			traverser -= 2;
			Assert::AreEqual(*traverser, middleElement);
			traverser -= 2;
			Assert::AreEqual(traverser, vector.begin()); //If an increment minus current index goes below the start of the vector, the index is set to the beginning of the vector.
		}

		TEST_METHOD(ConstIteratorMinusEqualInt)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::ConstIterator traverser = vector.cend();

			Assert::AreEqual(traverser, vector.cend());
			traverser -= 2;
			Assert::AreEqual(*traverser, middleElement);
			traverser -= 2;
			Assert::AreEqual(traverser, vector.cbegin()); //If an increment minus current index goes below the start of the vector, the index is set to the beginning of the vector.
		}

		TEST_METHOD(IteratorPlusEqualIterator)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::Iterator begin = vector.begin();
			Vector<Foo>::Iterator end = vector.end();
			Vector<Foo>::Iterator uninitialized;

			Assert::AreEqual(*begin, frontElement);
			Assert::AreEqual(end, vector.end());
			Assert::ExpectException<std::runtime_error>([&begin, &uninitialized]() {begin += uninitialized; }); //Two iterators with different owners may not be added.

			end -= 1;
			begin += end;

			Assert::AreEqual(*begin, vector[2]);
			Assert::AreEqual(*end, vector[2]);
			begin += end; //When begin exceeds size of array, no matter by how much, it is set equal to the end of the vector, no further
			
			Assert::AreEqual(begin, vector.end());
			Assert::AreEqual(*end, vector[2]);
		}

		TEST_METHOD(ConstIteratorPlusEqualIterator)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::ConstIterator begin = vector.cbegin();
			Vector<Foo>::ConstIterator end = vector.cend();
			Vector<Foo>::ConstIterator uninitialized;

			Assert::AreEqual(*begin, frontElement);
			Assert::AreEqual(end, vector.cend());
			Assert::ExpectException<std::runtime_error>([&begin, &uninitialized]() {begin += uninitialized; }); //Two iterators with different owners may not be added.

			end -= 1;
			begin += end;
			Assert::AreEqual(*begin, vector[2]);
			Assert::AreEqual(*end, vector[2]);

			begin += end; //When begin exceeds size of array, no matter by how much, it is set equal to the end of the vector, no further
			Assert::AreEqual(begin, vector.cend());
			Assert::AreEqual(*end, vector[2]);
		}

		TEST_METHOD(IteratorMinusEqualIterator)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::Iterator end = vector.end();
			Vector<Foo>::Iterator begin = vector.begin();
			Vector<Foo>::Iterator uninitialized;

			Assert::AreEqual(end, vector.end());
			Assert::AreEqual(begin, vector.begin());

			end -= begin; //This will not affect the end iterator, the index for begin is 0.
			Assert::AreEqual(end, vector.end());
			Assert::AreEqual(begin, vector.begin());
			Assert::ExpectException<std::runtime_error>([&end, &uninitialized]() {end-=uninitialized; }); //Two iterators with different owners may not be subtracted.

			begin += 2;
			end -= begin;

			Assert::AreEqual(*end, vector[1]);
			Assert::AreEqual(*begin, vector[2]);
			end -= begin;

			Assert::AreEqual(end, vector.begin()); //If an increment minus current index goes below the start of the vector, the index is set to the beginning of the vector.
			Assert::AreEqual(*begin, vector[2]);
		}

		TEST_METHOD(ConstIteratorMinusEqualIterator)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);
			Vector<Foo>::ConstIterator end = vector.cend();
			Vector<Foo>::ConstIterator begin = vector.cbegin();
			Vector<Foo>::ConstIterator uninitialized;

			Assert::AreEqual(end, vector.cend());
			Assert::AreEqual(begin, vector.cbegin());

			end -= begin; //This will not affect the end iterator, the index for begin is 0.
			Assert::AreEqual(end, vector.cend());
			Assert::AreEqual(begin, vector.cbegin());
			Assert::ExpectException<std::runtime_error>([&end, &uninitialized]() {end -= uninitialized; }); //Two iterators with different owners may not be subtracted

			begin += 2;
			end -= begin;

			Assert::AreEqual(*end, vector[1]);
			Assert::AreEqual(*begin, vector[2]);
			end -= begin;

			Assert::AreEqual(end, vector.cbegin()); //If an increment minus current index goes below the start of the vector, the index is set to the beginning of the vector.
			Assert::AreEqual(*begin, vector[2]);
		}

		TEST_METHOD(IteratorDereference)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Vector<Foo>::Iterator traverser = vector.end();
			Assert::ExpectException<std::runtime_error>([&traverser]() {*traverser; }); //Cannot dereference nullptr

			traverser--;
			Assert::AreEqual(*traverser, backElement);
			traverser--;
			Assert::AreEqual(*traverser, middleElement);
			traverser--;
			Assert::AreEqual(*traverser, frontElement);
			traverser--;
			Assert::AreEqual(*traverser, frontElement); //Do not decrement iterator before start of vector
		}

		TEST_METHOD(ConstIteratorDereference)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Vector<Foo>::ConstIterator traverser = vector.cend();
			Assert::ExpectException<std::runtime_error>([&traverser]() {*traverser; }); //Cannot dereference nullptr

			traverser--;
			Assert::AreEqual(*traverser, backElement);
			traverser--;
			Assert::AreEqual(*traverser, middleElement);
			traverser--;
			Assert::AreEqual(*traverser, frontElement);
			traverser--;
			Assert::AreEqual(*traverser, frontElement); //Do not decrement iterator before start of vector
		}

		TEST_METHOD(IteratorCopyConstructor)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Vector<Foo>::Iterator constructedIterator = vector.end(); //Copies from vector end iterator to constructedIterator
			Vector<Foo>::Iterator anotherConstructedIterator = constructedIterator;

			Assert::AreEqual(constructedIterator, anotherConstructedIterator);
			Assert::AreEqual(vector.end(), anotherConstructedIterator);
			Assert::AreEqual(constructedIterator, vector.end());

			anotherConstructedIterator--;
			Assert::AreNotEqual(anotherConstructedIterator, constructedIterator); //When one changes, the others dont.
			Assert::AreNotEqual(vector.end(), anotherConstructedIterator);
			Assert::AreEqual(constructedIterator, vector.end());
		}

		TEST_METHOD(ConstIteratorCopyConstructor)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Vector<Foo>::ConstIterator constructedIterator = vector.cend(); //Copies from vector end constiterator to constructedIterator
			Vector<Foo>::ConstIterator anotherConstructedIterator = constructedIterator;

			Assert::AreEqual(constructedIterator, anotherConstructedIterator);
			Assert::AreEqual(vector.cend(), anotherConstructedIterator);
			Assert::AreEqual(constructedIterator, vector.cend());

			anotherConstructedIterator--;
			Assert::AreNotEqual(anotherConstructedIterator, constructedIterator); //When one changes, the others dont.
			Assert::AreNotEqual(vector.cend(), anotherConstructedIterator);
			Assert::AreEqual(constructedIterator, vector.cend());
		}

		TEST_METHOD(IteratorCopyAssignment)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Vector<Foo>::Iterator constructedIterator;
			constructedIterator = vector.end(); //Copies from vector end constiterator to constructedIterator
			Vector<Foo>::Iterator anotherConstructedIterator = vector.begin();
			anotherConstructedIterator = constructedIterator;

			Assert::AreEqual(constructedIterator, anotherConstructedIterator);
			Assert::AreEqual(vector.end(), anotherConstructedIterator);
			Assert::AreEqual(constructedIterator, vector.end());

			anotherConstructedIterator--;
			Assert::AreNotEqual(anotherConstructedIterator, constructedIterator); //When one changes, the others dont.
			Assert::AreNotEqual(vector.end(), anotherConstructedIterator);
			Assert::AreEqual(constructedIterator, vector.end());
		}

		TEST_METHOD(ConstIteratorCopyAssignment)
		{
			Vector<Foo> vector;
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Vector<Foo>::ConstIterator constructedIterator;
			constructedIterator = vector.cend(); //Copies from vector end constiterator to constructedIterator
			Vector<Foo>::ConstIterator anotherConstructedIterator = vector.cbegin(); 
			anotherConstructedIterator = constructedIterator; //Overwrites previous data via copy assignment

			Assert::AreEqual(constructedIterator, anotherConstructedIterator);
			Assert::AreEqual(vector.cend(), anotherConstructedIterator);
			Assert::AreEqual(constructedIterator, vector.cend());

			anotherConstructedIterator--;
			Assert::AreNotEqual(anotherConstructedIterator, constructedIterator); //When one changes, the others dont.
			Assert::AreNotEqual(vector.cend(), anotherConstructedIterator);
			Assert::AreEqual(constructedIterator, vector.cend());
		}

		TEST_METHOD(ConstIteratorConverter)
		{
			Vector<Foo> vector;
			vector.Reserve(4);
			Foo frontElement(20), middleElement(30), backElement(40);

			vector.PushBack(frontElement);
			vector.PushBack(middleElement);
			vector.PushBack(backElement);

			Vector<Foo> constVector = vector;
			Vector<Foo>::Iterator normalIterator = vector.begin();

			(Vector<Foo>::ConstIterator)normalIterator = constVector.cbegin();//This will force a const value return
			Assert::AreEqual(*normalIterator, frontElement); //Checks to ensure the two are equal
		}

	private: //Creates memory state screenshots to ensure no memory leaks in any test
		inline static _CrtMemState _startMemState;
	};
}