#include "JsonTestParseHelper.h"

namespace UnitTests
{
	RTTI_DEFINITIONS(JsonTestParseHelper);
	RTTI_DEFINITIONS(JsonTestParseHelper::Wrapper);

	bool JsonTestParseHelper::StartHandler(FieaGameEngine::JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray)
	{
		if (ParsingData)
		{
			throw std::runtime_error("Cannot begin parsing new element: parsing is already in progress!");
		}
		ParsingData = true;
		if (value.second["Type"] == "Integer" && coordinator.Is(JsonTestParseHelper::Wrapper().TypeIdClass()) && value.second["Value"].isInt())
		{
			StartHandlerCount++;
			isArray = false;
		//	EndHandler(coordinator, value, isArray);
			return true;
		}
		else if (value.second["Type"] == "Integer" && coordinator.Is(JsonTestParseHelper::Wrapper().TypeIdClass()) && value.second["Value"].isArray())
		{
			if (value.second["Value"].get(Json::ArrayIndex(0), -999.9f).isInt())
			{
				StartHandlerCount++;
				isArray = true;
	//			EndHandler(coordinator, value, true);
				return true;
			}
		}
		Cleanup();
		return false;
	}

	void JsonTestParseHelper::EndHandler(FieaGameEngine::JsonParseCoordinator::Wrapper& coordinator, const std::pair<const std::string, Json::Value>& value, bool& isArray)
	{
		if (reinterpret_cast<JsonTestParseHelper::Wrapper*>(dynamic_cast<FieaGameEngine::RTTI*>(&coordinator))->TotalDepth < coordinator.Depth())
		{
			reinterpret_cast<JsonTestParseHelper::Wrapper*>(dynamic_cast<FieaGameEngine::RTTI*>(&coordinator))->TotalDepth = coordinator.Depth();
		}
		if (isArray)
		{
			for (size_t i = 0; value.second["Value"].get(Json::ArrayIndex(i), -999.9f).isInt(); i++)
			{
				reinterpret_cast<JsonTestParseHelper::Wrapper*>(dynamic_cast<FieaGameEngine::RTTI*>(&coordinator))->Data.PushBack(value.second["Value"].get(Json::ArrayIndex(i), -999.9f).asInt());
			}
		}
		else
		{
			reinterpret_cast<JsonTestParseHelper::Wrapper*>(dynamic_cast<FieaGameEngine::RTTI*>(&coordinator))->Data.PushBack(value.second["Value"].asInt());
		}
		ParsingData = false;
		EndHandlerCount++;
		Cleanup();
	}

	void JsonTestParseHelper::Initialize()
	{
		InitializeCalled = true;
	}

	std::shared_ptr<FieaGameEngine::IJsonParseHelper> JsonTestParseHelper::Create() const
	{
		std::shared_ptr<FieaGameEngine::IJsonParseHelper> newHelp(new JsonTestParseHelper);
		return newHelp;
	}

	std::shared_ptr<FieaGameEngine::JsonParseCoordinator::Wrapper> JsonTestParseHelper::Wrapper::Create() const
	{
		std::shared_ptr<FieaGameEngine::JsonParseCoordinator::Wrapper> newWrapper(new Wrapper);
		return newWrapper;
	}

	void JsonTestParseHelper::Cleanup()
	{
		ParsingData = false;
		CleanupCalled = true;
	}

	JsonTestParseHelper::Wrapper::~Wrapper()
	{
		//FieaGameEngine::JsonParseCoordinator::Wrapper::~Wrapper();
		Data.~Vector();
		TotalDepth = 0;
	}
}