#pragma once

namespace UnitTests
{
	struct EventArgs
	{
	public:
		EventArgs::EventArgs(size_t bad, size_t good):
			BadGuyScore(bad), GoodGuyScore(good)
		{
		}
		size_t BadGuyScore = 0;
		size_t GoodGuyScore = 0;
	};
}