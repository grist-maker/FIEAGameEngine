#include "pch.h"
#include "EvilSubscriber.h"

using namespace FieaGameEngine;
namespace UnitTests
{
	void EvilSubscriber::Notify(const EventPublisher* eventPublisher)
	{
		assert(eventPublisher->Is(Event<float>::TypeIdClass()));
		MyFloat = static_cast<const Event<float>*>(eventPublisher)->Message();

		GameState::Queue.Update(GameState::CurrentTime);
		std::shared_ptr<EventPublisher> newEventPublisher(new Event<float>(8.5f));

		GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime());
		GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime());
		GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime());
		GameState::Queue.Enqueue(newEventPublisher, GameState::CurrentTime.CurrentTime());

	}
}