#include "pch.h"
#include "MultiEventSubscriber.h"

using namespace FieaGameEngine;
namespace UnitTests
{
	MultiEventSubscriber::MultiEventSubscriber()
	{
		Event<float>::Subscribe(this);
		Event<std::string>::Subscribe(this);
	}

	void MultiEventSubscriber::Notify(const EventPublisher* eventPublisher)
	{
		if (eventPublisher->Is(Event<std::string>::TypeIdClass()))
		{
			MyString = static_cast<const Event<std::string>*>(eventPublisher)->Message();
		}
		else if (eventPublisher->Is(Event<float>::TypeIdClass()))
		{
			MyFloat = static_cast<const Event<float>*>(eventPublisher)->Message();
		}
		else if (eventPublisher->Is(Event<EventArgs>::TypeIdClass()))
		{
			GoodGuy = static_cast<const Event<EventArgs>*>(eventPublisher)->Message().GoodGuyScore;
			BadGuy = static_cast<const Event<EventArgs>*>(eventPublisher)->Message().BadGuyScore;

			
			if (BadGuy == GoodGuy)
			{
				if (BadGuy == 13)  //Multiple dequeues shouldn't matter: the removal only happens once.
				{
					GameState::Queue.Dequeue(HatedEvent);
					GameState::Queue.Dequeue(HatedEvent);
					GameState::Queue.Dequeue(HatedEvent);
					GameState::Queue.Dequeue(HatedEvent);
				}
				else
				{
					Event<float>::UnsubscribeAll();
				}
			}
			else if (BadGuy > GoodGuy)
			{
				Event<float>::Subscribe(this);
			}
			else
			{
				Event<float>::Unsubscribe(this);
			}
		}
	}

	MultiEventSubscriber::~MultiEventSubscriber()
	{
		Event<float>::Unsubscribe(this);
		Event<std::string>::Unsubscribe(this);
	}
}