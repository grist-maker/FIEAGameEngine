#include "pch.h"
#include "CppUnitTest.h"
#include "Foo.h"
#include "ToStringSpecializations.h"
#include "Datum.h"
#include "Scope.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace UnitTests;
using namespace std;
using namespace std::string_literals;

/// <summary>
/// Tests that exercise and assure functionality of the Scope class.
/// </summary>
namespace FieaGameEngine
{
	TEST_CLASS(ScopeTests)
	{
	public:
		TEST_METHOD_INITIALIZE(Initialize) //Initial setup of memory state variables to allow memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&_startMemState);
			#endif
		}

		TEST_METHOD_CLEANUP(Cleanup) //Setup for memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &_startMemState,
				&endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
			#endif
		}

		TEST_METHOD(DefaultConstructor)
		{
			Scope default;
			Assert::AreEqual(default.Size(), size_t(0));
			Assert::IsNull(default.GetParent());
		}

		TEST_METHOD(Append)
		{
			Scope default;
			Assert::AreEqual(default.Size(), size_t(0));
			Assert::IsNull(default.GetParent());

			default.Append("Apple");
			Assert::AreEqual(default.Size(), size_t(1));
			Assert::IsNull(default.GetParent());

			default.Append("Apple");
			Assert::AreEqual(default.Size(), size_t(1));
			Assert::IsNull(default.GetParent());

			default.Append("Pear");
			Assert::AreEqual(default.Size(), size_t(2));
			Assert::IsNull(default.GetParent());

			default.Append("Orange");
			Assert::AreEqual(default.Size(), size_t(3));
			Assert::IsNull(default.GetParent());
		}

		TEST_METHOD(Size)
		{
			Scope default;
			Assert::AreEqual(default.Size(), size_t(0));

			default.Append("Apple");
			Assert::AreEqual(default.Size(), size_t(1));

			default.Append("Apple");
			Assert::AreEqual(default.Size(), size_t(1));

			default.Append("Pear");
			Assert::AreEqual(default.Size(), size_t(2));

			default.Append("Orange");
			Assert::AreEqual(default.Size(), size_t(3));

			default.Append("Banana");
			Assert::AreEqual(default.Size(), size_t(4));
		}

		TEST_METHOD(At)
		{
			Scope default;

			default.Append("Apple");
			default.Append("Apple");
			default.Append("Pear");
			default.Append("Orange");
			default.Append("Banana");
			Assert::AreEqual(default.Size(), size_t(4));

			default.At(0).PushBack(static_cast<size_t>(1));
			default.At(1).PushBack(static_cast<size_t>(2));
			default.At(2).PushBack(static_cast<size_t>(3));
			default.At(3).PushBack(static_cast<size_t>(4));

			Assert::AreEqual(default["Apple"].GetInt(), static_cast<size_t>(1));
			Assert::AreEqual(default["Pear"].GetInt(), static_cast<size_t>(2));
			Assert::AreEqual(default["Orange"].GetInt(), static_cast<size_t>(3));
			Assert::AreEqual(default["Banana"].GetInt(), static_cast<size_t>(4));

			Assert::ExpectException<std::runtime_error>([&default]() {auto value = default.At(4); });
		}

		TEST_METHOD(Find)
		{
			Scope default;

			std::string apple = "Apple";
			std::string pear = "Pear";
			std::string orange = "Orange";
			std::string banana = "Banana";

			default.Append(apple);
			default.Append(pear);
			default.Append(orange);
			default.Append(banana);
			Assert::AreEqual(default.Size(), size_t(4));

			default.At(0).PushBack(static_cast<size_t>(1));
			default.At(1).PushBack(static_cast<size_t>(2));
			default.At(2).PushBack(static_cast<size_t>(3));
			default.At(3).PushBack(static_cast<size_t>(4));

			Assert::IsTrue(default.Find("Apple") == &default.At(0));
			Assert::IsTrue(default.Find("Pear") == &default.At(1));
			Assert::IsTrue(default.Find("Orange") == &default.At(2));
			Assert::IsTrue(default.Find("Banana") == &default.At(3));
			Assert::IsTrue(default.Find("Grapes") == nullptr);
		}

		TEST_METHOD(AppendBracket)
		{
			Scope default;
			Assert::AreEqual(default.Size(), size_t(0));
			Assert::IsNull(default.GetParent());

			default["Apple"].PushBack(static_cast<size_t>(1));
			Assert::AreEqual(default.Size(), size_t(1));
			Assert::IsNull(default.GetParent());

			default["Apple"];
			Assert::AreEqual(default.Size(), size_t(1));
			Assert::IsNull(default.GetParent());

			default["Pear"].PushBack("Hello!"s);
			Assert::AreEqual(default.Size(), size_t(2));
			Assert::IsNull(default.GetParent());

			default["Orange"].PushBack(2.4f);
			Assert::AreEqual(default.Size(), size_t(3));
			Assert::IsNull(default.GetParent());

			Assert::IsTrue(default["Orange"] == 2.4f);
			Assert::IsTrue(default["Apple"] == static_cast<size_t>(1));
			Assert::IsTrue(default["Pear"] == "Hello!");
		}

		TEST_METHOD(OrderBracket)
		{
			Scope default;

			std::string apple = "Apple";
			std::string pear = "Pear";
			std::string orange = "Orange";
			std::string banana = "Banana";

			default.Append(apple);
			default.Append(apple);
			default.Append(pear);
			default.Append(orange);
			default.Append(banana);
			Assert::AreEqual(default.Size(), size_t(4));

			default.At(0).PushBack("first");
			default.At(1).PushBack("second");
			default.At(2).PushBack("third");
			default.At(3).PushBack("fourth");

			Assert::IsTrue(default[0] == *default.Find("Apple"));
			Assert::IsTrue(default[1] == *default.Find("Pear"));
			Assert::IsTrue(default[2] == *default.Find("Orange"));
			Assert::IsTrue(default[3] == *default.Find("Banana"));
		}

		TEST_METHOD(HashmapNestedScopeBracket)
		{
			Scope scopeNest;
			std::string firstBaby = "FirstBaby";
			std::string secondBaby = "SecondBaby";
			std::string thirdBaby = "ThirdBaby";
			std::string fourthBaby = "FourthBaby";

			scopeNest.AppendScope(firstBaby);
			Assert::IsTrue(scopeNest[0][0] == *scopeNest[firstBaby].GetScope());

			scopeNest.AppendScope(secondBaby);
			scopeNest[secondBaby][0].AppendScope(thirdBaby);
			scopeNest[secondBaby][0][thirdBaby][0].AppendScope(fourthBaby);

			Assert::IsTrue(scopeNest[1][0] == *(scopeNest[secondBaby].GetScope()));
			Assert::IsTrue(scopeNest[1][0][0][0] == *(scopeNest[secondBaby][0][thirdBaby].GetScope()));
			Assert::IsTrue(scopeNest[1][0][0][0][0][0] == *scopeNest[secondBaby][0][thirdBaby][0][fourthBaby].GetScope());
		}

		TEST_METHOD(CopyConstructor)
		{
			{
				Scope default;

				std::string apple = "Apple";
				std::string pear = "Pear";
				std::string orange = "Orange";
				std::string banana = "Banana";

				default.Append(apple);
				default.Append(apple);
				default.Append(pear);
				default.Append(orange);
				default.Append(banana);
				Assert::AreEqual(default.Size(), size_t(4));

				Scope copy = default;
				Assert::IsTrue(copy == default);
			}

			{
				Scope default;

				std::string intKey = "Apple";
				std::string floatKey = "Pear";
				std::string stringKey = "Orange";
				std::string vectorKey = "Banana";
				std::string matrixKey = "Strawberry";
				std::string RTTIKey = "Blueberry";
				std::string scopeKey = "Grape";

				std::string stringValue = "Fruit";
				glm::vec4 vectorValue = { 0, 1, 2, 3 };
				glm::mat4 matrixValue = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				Foo fooValue(1);
				RTTI* rttiValue = &fooValue;

				default.Append(intKey);
				default.Append(floatKey);
				default.Append(stringKey);
				default.Append(vectorKey);
				default.Append(matrixKey);
				default.Append(RTTIKey);
				default.AppendScope(scopeKey);

				default[intKey].PushBack(static_cast<size_t>(1));
				default[floatKey].PushBack(2.3f);
				default[stringKey].PushBack(stringValue);
				default[vectorKey].PushBack(vectorValue);
				default[matrixKey].PushBack(matrixValue);
				default[RTTIKey].PushBack(rttiValue);

				Scope copy = default;
				
				Assert::IsTrue(copy == default);
			}
		}

		TEST_METHOD(AssignmentOperator)
		{
			{
				Scope default;

				std::string apple = "Apple";
				std::string pear = "Pear";
				std::string orange = "Orange";
				std::string banana = "Banana";

				default.Append(apple);
				default.Append(apple);
				default.Append(pear);
				default.Append(orange);
				default.Append(banana);
				Assert::AreEqual(default.Size(), size_t(4));

				Scope copy;
				copy.Append(banana);
				Assert::IsFalse(copy == default);

				copy = default;
				Assert::IsTrue(copy == default);
			}

			{
				Scope default;

				std::string intKey = "Apple";
				std::string floatKey = "Pear";
				std::string stringKey = "Orange";
				std::string vectorKey = "Banana";
				std::string matrixKey = "Strawberry";
				std::string RTTIKey = "Blueberry";
				std::string scopeKey = "Grape";

				std::string stringValue = "Fruit";
				glm::vec4 vectorValue = { 0, 1, 2, 3 };
				glm::mat4 matrixValue = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
				Foo fooValue(1);
				RTTI* rttiValue = &fooValue;

				default.Append(intKey);
				default.Append(floatKey);
				default.Append(stringKey);
				default.Append(vectorKey);
				default.Append(matrixKey);
				default.Append(RTTIKey);
				default.AppendScope(scopeKey);

				default[intKey].PushBack(static_cast<size_t>(1));
				default[floatKey].PushBack(2.3f);
				default[stringKey].PushBack(stringValue);
				default[vectorKey].PushBack(vectorValue);
				default[matrixKey].PushBack(matrixValue);
				default[RTTIKey].PushBack(rttiValue);

				Scope copy;

				copy.Append(intKey);
				copy.Append(floatKey);
				copy.Append(stringKey);
				copy.Append(vectorKey);
				copy.Append(matrixKey);
				copy.Append(RTTIKey);
				copy.AppendScope(scopeKey);

				copy[intKey].PushBack(static_cast<size_t>(2));
				copy[floatKey].PushBack(3.3f);
				copy[stringKey].PushBack(stringValue);
				copy[vectorKey].PushBack(vectorValue);
				copy[matrixKey].PushBack(matrixValue);
				copy[RTTIKey].PushBack(rttiValue);

				Assert::IsFalse(copy == default);
				copy = default;
				Assert::IsTrue(copy == default);
			}

		}

		TEST_METHOD(EqualityOperator)
		{
			{
				Scope default;

				std::string apple = "Apple";
				std::string pear = "Pear";
				std::string orange = "Orange";
				std::string banana = "Banana";

				default.Append(apple);
				default.Append(apple);
				default.Append(pear);
				default.Append(orange);
				default.Append(banana);
				Assert::AreEqual(default.Size(), size_t(4));

				Scope copy;
				copy.Append(pear);
				copy.Append(orange);
				copy.Append(apple);
				copy.Append(banana);

				Assert::IsTrue(copy == default);

				default.At(0).PushBack("first");
				default.At(1).PushBack("second");
				default.At(2).PushBack("third");
				default.At(3).PushBack("fourth");

				Assert::IsFalse(copy == default);
				copy.At(0).PushBack("second");
				copy.At(1).PushBack("third");
				copy.At(2).PushBack("first");

				Assert::IsFalse(copy == default);
				copy.At(3).PushBack("fourth");

				Assert::IsTrue(copy == default);
			}

			{
				Scope default;

				Scope wrongScope;

				std::string intKey = "Apple";
				std::string floatKey = "Pear";
				std::string stringKey = "Orange";
				std::string vectorKey = "Banana";
				std::string matrixKey = "Strawberry";
				std::string RTTIKey = "Blueberry";
				std::string scopeKey = "Grape";

				std::string stringValue = "Fruit";
				glm::vec4 vectorValue = {0, 1, 2, 3};
				glm::mat4 matrixValue = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
				Foo fooValue(1);
				RTTI* rttiValue = &fooValue;

				std::string wrongString = "Vegetable";
				glm::vec4 wrongVector = { 0, 1, 2, 4 };
				glm::mat4 wrongMatrix = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
				Foo wrongFoo(3);
				RTTI* wrongRtti = &wrongFoo;

				default.Append(intKey);
				default.Append(floatKey);
				default.Append(stringKey);
				default.Append(vectorKey);
				default.Append(matrixKey);
				default.Append(RTTIKey);
				default.AppendScope(scopeKey);

				default[intKey].PushBack(static_cast<size_t>(1));
				default[floatKey].PushBack(2.3f);
				default[stringKey].PushBack(stringValue);
				default[vectorKey].PushBack(vectorValue);
				default[matrixKey].PushBack(matrixValue);
				default[RTTIKey].PushBack(rttiValue);

				Scope copy;
				Assert::IsFalse(copy == default);

				copy.Append(intKey);
				copy.Append(floatKey);
				copy.Append(stringKey);
				copy.Append(vectorKey);
				copy.Append(matrixKey);
				copy.Append(RTTIKey);
				copy.AppendScope(scopeKey);

				Assert::IsFalse(copy == default);

				copy[intKey].PushBack(static_cast<size_t>(1));
				copy[floatKey].PushBack(2.3f);
				copy[stringKey].PushBack(stringValue);
				copy[vectorKey].PushBack(vectorValue);
				copy[matrixKey].PushBack(matrixValue);
				copy[RTTIKey].PushBack(rttiValue);

				Assert::IsTrue(copy == default);

				copy[intKey].SetInt(2);
				Assert::IsFalse(copy == default);
				copy[intKey].SetInt(1);
				Assert::IsTrue(copy == default);

				copy[floatKey].SetFloat(2.4f);
				Assert::IsFalse(copy == default);
				copy[floatKey].SetFloat(2.3f);
				Assert::IsTrue(copy == default);

				copy[stringKey].SetString(wrongString);
				Assert::IsFalse(copy == default);
				copy[stringKey].SetString(stringValue);
				Assert::IsTrue(copy == default);

				copy[vectorKey].SetVector(wrongVector);
				Assert::IsFalse(copy == default);
				copy[vectorKey].SetVector(vectorValue);
				Assert::IsTrue(copy == default);

				copy[matrixKey].SetMatrix(wrongMatrix);
				Assert::IsFalse(copy == default);
				copy[matrixKey].SetMatrix(matrixValue);
				Assert::IsTrue(copy == default);

				copy[RTTIKey].SetRTTI(wrongRtti);
				Assert::IsFalse(copy == default);
				copy[RTTIKey].SetRTTI(rttiValue);
				Assert::IsTrue(copy == default);

				copy[scopeKey][0].Append(stringKey);
				copy[scopeKey][0][stringKey].PushBack("Love");
				copy[scopeKey][0].Append(intKey);
				copy[scopeKey][0][intKey].PushBack(static_cast<size_t>(123));
				copy[scopeKey][0].Append(floatKey);
				copy[scopeKey][0][floatKey].PushBack(22.34f);
				Assert::IsFalse(copy == default);
				default[scopeKey][0].Append(stringKey);
				default[scopeKey][0][stringKey].PushBack("Love");
				default[scopeKey][0].Append(intKey);
				default[scopeKey][0][intKey].PushBack(static_cast<size_t>(123));
				default[scopeKey][0].Append(floatKey);
				default[scopeKey][0][floatKey].PushBack(22.34f);
				Assert::IsTrue(copy == default);
			}
		}

		TEST_METHOD(InequalityOperator)
		{
			{
					Scope default;

					Scope wrongScope;

					std::string intKey = "Apple";
					std::string floatKey = "Pear";
					std::string stringKey = "Orange";
					std::string vectorKey = "Banana";
					std::string matrixKey = "Strawberry";
					std::string RTTIKey = "Blueberry";
					std::string scopeKey = "Grape";

					std::string stringValue = "Fruit";
					glm::vec4 vectorValue = { 0, 1, 2, 3 };
					glm::mat4 matrixValue = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
					Foo fooValue(1);
					RTTI* rttiValue = &fooValue;

					std::string wrongString = "Vegetable";
					glm::vec4 wrongVector = { 0, 1, 2, 4 };
					glm::mat4 wrongMatrix = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16 };
					Foo wrongFoo(3);
					RTTI* wrongRtti = &wrongFoo;

					default.Append(intKey);
					default.Append(floatKey);
					default.Append(stringKey);
					default.Append(vectorKey);
					default.Append(matrixKey);
					default.Append(RTTIKey);
					default.AppendScope(scopeKey);

					default[intKey].PushBack(static_cast<size_t>(1));
					default[floatKey].PushBack(2.3f);
					default[stringKey].PushBack(stringValue);
					default[vectorKey].PushBack(vectorValue);
					default[matrixKey].PushBack(matrixValue);
					default[RTTIKey].PushBack(rttiValue);

					Scope copy;
					Assert::IsTrue(copy != default);

					copy.Append(intKey);
					copy.Append(floatKey);
					copy.Append(stringKey);
					copy.Append(vectorKey);
					copy.Append(matrixKey);
					copy.Append(RTTIKey);
					copy.AppendScope(scopeKey);

					Assert::IsTrue(copy != default);

					copy[intKey].PushBack(static_cast<size_t>(1));
					copy[floatKey].PushBack(2.3f);
					copy[stringKey].PushBack(stringValue);
					copy[vectorKey].PushBack(vectorValue);
					copy[matrixKey].PushBack(matrixValue);
					copy[RTTIKey].PushBack(rttiValue);

					Assert::IsFalse(copy != default);

					copy[intKey].SetInt(2);
					Assert::IsTrue(copy != default);
					copy[intKey].SetInt(1);
					Assert::IsFalse(copy != default);

					copy[floatKey].SetFloat(2.4f);
					Assert::IsTrue(copy != default);
					copy[floatKey].SetFloat(2.3f);
					Assert::IsFalse(copy != default);

					copy[stringKey].SetString(wrongString);
					Assert::IsTrue(copy != default);
					copy[stringKey].SetString(stringValue);
					Assert::IsFalse(copy != default);

					copy[vectorKey].SetVector(wrongVector);
					Assert::IsTrue(copy != default);
					copy[vectorKey].SetVector(vectorValue);
					Assert::IsFalse(copy != default);

					copy[matrixKey].SetMatrix(wrongMatrix);
					Assert::IsTrue(copy != default);
					copy[matrixKey].SetMatrix(matrixValue);
					Assert::IsFalse(copy != default);

					copy[RTTIKey].SetRTTI(wrongRtti);
					Assert::IsTrue(copy != default);
					copy[RTTIKey].SetRTTI(rttiValue);
					Assert::IsFalse(copy != default);

					copy[scopeKey][0].Append(stringKey);
					copy[scopeKey][0][stringKey].PushBack("Love");
					copy[scopeKey][0].Append(intKey);
					copy[scopeKey][0][intKey].PushBack(static_cast<size_t>(123));
					copy[scopeKey][0].Append(floatKey);
					copy[scopeKey][0][floatKey].PushBack(22.34f);
					Assert::IsTrue(copy != default);
					default[scopeKey][0].Append(stringKey);
					default[scopeKey][0][stringKey].PushBack("Love");
					default[scopeKey][0].Append(intKey);
					default[scopeKey][0][intKey].PushBack(static_cast<size_t>(123));
					default[scopeKey][0].Append(floatKey);
					default[scopeKey][0][floatKey].PushBack(22.34f);
					Assert::IsFalse(copy != default);
			}
			{
				Scope default;

				std::string apple = "Apple";
				std::string pear = "Pear";
				std::string orange = "Orange";
				std::string banana = "Banana";

				default.Append(apple);
				default.Append(apple);
				default.Append(pear);
				default.Append(orange);
				default.Append(banana);
				Assert::AreEqual(default.Size(), size_t(4));

				Scope copy;
				copy.Append(pear);
				copy.Append(orange);
				copy.Append(apple);
				copy.Append(banana);

				Assert::IsFalse(copy != default);

				default.At(0).PushBack("first");
				default.At(1).PushBack("second");
				default.At(2).PushBack("third");
				default.At(3).PushBack("fourth");

				Assert::IsTrue(copy != default);
				copy.At(0).PushBack("second");
				copy.At(1).PushBack("third");
				copy.At(2).PushBack("first");

				Assert::IsTrue(copy != default);
				copy.At(3).PushBack("fourth");

				Assert::IsFalse(copy != default);
			}
	}

		TEST_METHOD(GetParent)
		{
			Scope default;
			Scope newDefault;

			Scope babyScope;
			Scope secondBabyScope;
			Scope thirdBabyScope;

			default.AppendScope("Apple");
			default.AppendScope("Apple");
			default.AppendScope("Pear");
			default.AppendScope("Orange");
			default.AppendScope("Banana");

			Assert::IsTrue(default.Find("Apple")[0][0].GetParent() == &default);
			Assert::IsTrue(default.Find("Pear")[0][0].GetParent() == &default);
			Assert::IsTrue(default.Find("Orange")[0][0].GetParent() == &default);
			Assert::IsTrue(default.Find("Banana")[0][0].GetParent() == &default);
		}

		TEST_METHOD(AppendScope)
		{
			Scope default;
			Scope newDefault;

			std::string red = "Red";
			std::string green = "Green";
			std::string orange = "Orange";
			std::string yellow = "Yellow";

			std::string A = "A";
			std::string B = "B";
			std::string C = "C";
			std::string D = "D";

			default.AppendScope("Apple");
			default.AppendScope("Apple");
			default.AppendScope("Pear");
			default.AppendScope("Orange");
			default.AppendScope("Banana");
			Assert::AreEqual(default.Size(), size_t(4));

			default["Apple"][0].Append("Color");
			default["Pear"][0].Append("Color");
			default["Orange"][0].Append("Color");
			default["Banana"][0].Append("Color");

			default["Apple"][0].Append("Flavor");
			default["Pear"][0].Append("Flavor");
			default["Orange"][0].Append("Flavor");
			default["Banana"][0].Append("Flavor");

			default["Apple"][0].Find("Color")->PushBack(red);
			default["Pear"][0].Find("Color")->PushBack(green);
			default["Orange"][0].Find("Color")->PushBack(orange);
			default["Banana"][0].Find("Color")->PushBack(yellow);

			default["Apple"][0].Find("Flavor")->PushBack(A);
			default["Pear"][0].Find("Flavor")->PushBack(B);
			default["Orange"][0].Find("Flavor")->PushBack(C);
			default["Banana"][0].Find("Flavor")->PushBack(D);

			Assert::IsTrue(default["Apple"][0].Find("Color")[0] == red);
			Assert::IsTrue(default["Pear"][0].Find("Color")[0] == green);
			Assert::IsTrue(default["Orange"][0].Find("Color")[0] == orange);
			Assert::IsTrue(default["Banana"][0].Find("Color")[0] == yellow);

			Assert::IsTrue(default["Apple"][0].Find("Flavor")[0] == A);
			Assert::IsTrue(default["Pear"][0].Find("Flavor")[0] == B);
			Assert::IsTrue(default["Orange"][0].Find("Flavor")[0] == C);
			Assert::IsTrue(default["Banana"][0].Find("Flavor")[0] == D);

			default.Append("FalseScope"s);
			default["FalseScope"s].SetType(Datum::DatumTypes::Integer);
			Assert::ExpectException<std::runtime_error>([&default]() {default.AppendScope("FalseScope"s); });
		}

		TEST_METHOD(Adopt)
		{
			const std::string a = "A"s;
			Scope root;
			Assert::AreEqual(size_t(0), root.Size());
			Scope* babyScope = new Scope();
			Assert::IsNull(babyScope->GetParent());
			root.Adopt(babyScope, a);
			Assert::AreEqual(size_t(1), root.Size());
			Assert::IsNotNull(babyScope->GetParent());

			Assert::IsTrue(&root == babyScope->GetParent());
			Datum* aDatum = root.Find(a);
			Assert::IsNotNull(aDatum);
			Assert::AreEqual(size_t(1), aDatum->Size());

			Assert::IsTrue(babyScope == aDatum->GetScope(0));
			Scope anotherScope;
			anotherScope.Adopt(babyScope, a);

			Assert::IsNotNull(babyScope->GetParent());
			Assert::IsTrue(&anotherScope == babyScope->GetParent());
			Assert::AreEqual(size_t(0), aDatum->Size());

			aDatum = anotherScope.Find(a);
			Assert::IsNotNull(aDatum);
			Assert::AreEqual(size_t(1), aDatum->Size());
			Assert::IsTrue(babyScope == aDatum->GetScope(0));
			Scope worseBabyScope;

			Datum intDatum(static_cast<size_t>(1));
			anotherScope.Append("wrongKey"s);
			anotherScope["wrongKey"s].SetType(Datum::DatumTypes::Integer);
			Assert::ExpectException<std::runtime_error>([&intDatum, &anotherScope, &a]() {anotherScope.Adopt(&anotherScope, a); });
			Assert::ExpectException<std::runtime_error>([&anotherScope, &worseBabyScope]() {anotherScope.Adopt(&worseBabyScope, "wrongKey"s); });
		}

		TEST_METHOD(SearchNoScope)
		{
			Scope default;

			std::string intKey = "Apple";
			std::string floatKey = "Pear";
			std::string stringKey = "Orange";
			std::string vectorKey = "Banana";
			std::string matrixKey = "Strawberry";
			std::string RTTIKey = "Blueberry";
			std::string scopeKey = "Grape";

			std::string stringValue = "Fruit";
			glm::vec4 vectorValue = { 0, 1, 2, 3 };
			glm::mat4 matrixValue = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
			Foo fooValue(1);
			RTTI* rttiValue = &fooValue;

			default.Append(intKey);
			default.Append(floatKey);
			default.Append(stringKey);
			default.Append(vectorKey);
			default.Append(matrixKey);
			default.Append(RTTIKey);
			default.AppendScope(scopeKey);

			default[intKey].PushBack(static_cast<size_t>(1));
			default[floatKey].PushBack(2.3f);
			default[stringKey].PushBack(stringValue);
			default[vectorKey].PushBack(vectorValue);
			default[matrixKey].PushBack(matrixValue);
			default[RTTIKey].PushBack(rttiValue);

			default[scopeKey][0].Append("FirstNewElement");
			default[scopeKey][0].Append("SecondNewElement");
			default[scopeKey][0].AppendScope("BabyScope");

			default[scopeKey][0]["FirstNewElement"].PushBack(static_cast<size_t>(1));
			default[scopeKey][0]["SecondNewElement"].PushBack(4.5f);

			Datum* searchingDatum = default[scopeKey][0].Search("Pear");
			Assert::IsTrue(*searchingDatum == 2.3f);

			searchingDatum = default[scopeKey][0].Search("Apple");
			Assert::IsTrue(*searchingDatum == static_cast<size_t>(1));

			searchingDatum = default.Search("Apple");
			Assert::IsTrue(*searchingDatum == static_cast<size_t>(1));

			searchingDatum = default.Search("BabyScope");
			Assert::IsTrue(searchingDatum == nullptr);

			searchingDatum = default[scopeKey][0]["BabyScope"][0].Search("Apple");
			Assert::IsTrue(*searchingDatum == static_cast<size_t>(1));

			searchingDatum = default[scopeKey][0]["BabyScope"][0].Search("SecondNewElement");
			Assert::IsTrue(*searchingDatum == 4.5f);
		}

		TEST_METHOD(SearchScope)
		{
			Scope default;

			std::string intKey = "Apple";
			std::string floatKey = "Pear";
			std::string stringKey = "Orange";
			std::string vectorKey = "Banana";
			std::string matrixKey = "Strawberry";
			std::string RTTIKey = "Blueberry";
			std::string scopeKey = "Grape";

			std::string stringValue = "Fruit";
			glm::vec4 vectorValue = { 0, 1, 2, 3 };
			glm::mat4 matrixValue = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
			Foo fooValue(1);
			RTTI* rttiValue = &fooValue;

			default.Append(intKey);
			default.Append(floatKey);
			default.Append(stringKey);
			default.Append(vectorKey);
			default.Append(matrixKey);
			default.Append(RTTIKey);
			default.AppendScope(scopeKey);

			default[intKey].PushBack(static_cast<size_t>(1));
			default[floatKey].PushBack(2.3f);
			default[stringKey].PushBack(stringValue);
			default[vectorKey].PushBack(vectorValue);
			default[matrixKey].PushBack(matrixValue);
			default[RTTIKey].PushBack(rttiValue);

			default[scopeKey][0].Append("FirstNewElement");
			default[scopeKey][0].Append("SecondNewElement");
			default[scopeKey][0].AppendScope("BabyScope");

			default[scopeKey][0]["FirstNewElement"].PushBack(static_cast<size_t>(1));
			default[scopeKey][0]["SecondNewElement"].PushBack(4.5f);

			Scope* searchingScope;
			Datum* searchingDatum = default[scopeKey][0].Search(floatKey, searchingScope);
			Assert::IsTrue(*searchingDatum == 2.3f);
			Assert::IsTrue(*searchingScope == default);

			searchingDatum = default[scopeKey][0].Search("Apple", searchingScope);
			Assert::IsTrue(*searchingDatum == static_cast<size_t>(1));
			Assert::IsTrue(*searchingScope == default);

			searchingDatum = default.Search("Apple", searchingScope);
			Assert::IsTrue(*searchingDatum == static_cast<size_t>(1));
			Assert::IsTrue(*searchingScope == default);

			searchingDatum = default.Search("BabyScope", searchingScope);
			Assert::IsTrue(searchingDatum == nullptr);
			Assert::IsTrue(searchingScope == nullptr);

			searchingDatum = default[scopeKey][0]["BabyScope"][0].Search("Apple", searchingScope);
			Assert::IsTrue(*searchingDatum == static_cast<size_t>(1));
			Assert::IsTrue(*searchingScope == default);

			searchingDatum = default[scopeKey][0]["BabyScope"][0].Search("SecondNewElement", searchingScope);
			Assert::IsTrue(*searchingDatum == 4.5f);
			Assert::IsTrue(*searchingScope == default[scopeKey][0]);
		}

		TEST_METHOD(Orphan)
		{
			const std::string a = "A"s;
			Scope root;
			Assert::AreEqual(size_t(0), root.Size());
			Scope* babyScope = new Scope();
			Assert::IsNull(babyScope->GetParent());
			root.Adopt(babyScope, a);
			Assert::AreEqual(size_t(1), root.Size());
			Assert::IsNotNull(babyScope->GetParent());

			Assert::IsTrue(&root == babyScope->GetParent());
			Datum* aDatum = root.Find(a);
			Assert::IsNotNull(aDatum);
			Assert::AreEqual(size_t(1), aDatum->Size());

			Assert::IsTrue(babyScope == aDatum->GetScope(0));
			Scope anotherScope;
			anotherScope.Adopt(babyScope, a);

			Assert::IsNotNull(babyScope->GetParent());
			Assert::IsTrue(&anotherScope == babyScope->GetParent());
			Assert::AreEqual(size_t(0), aDatum->Size());

			aDatum = anotherScope.Find(a);
			Assert::IsNotNull(aDatum);
			Assert::AreEqual(size_t(1), aDatum->Size());
			Assert::IsTrue(babyScope == aDatum->GetScope(0));

			Assert::AreEqual(root.Size(), size_t(1));

			auto orphanResult = root.Orphan(); //Nothing will happen, it has no parent.
			Assert::IsNull(orphanResult);

			Scope newBaby;
			newBaby.Adopt(babyScope->Orphan(), "newKey");
			Assert::AreEqual(root.Size(), size_t(1));

			root.Adopt(babyScope->Orphan(), "anotherNewKey");
			Assert::AreEqual(root.Size(), size_t(2));
		}

		TEST_METHOD(Clear)
		{
			Scope default;

			std::string intKey = "Apple";
			std::string floatKey = "Pear";
			std::string stringKey = "Orange";
			std::string vectorKey = "Banana";
			std::string matrixKey = "Strawberry";
			std::string RTTIKey = "Blueberry";
			std::string scopeKey = "Grape";

			std::string stringValue = "Fruit";
			glm::vec4 vectorValue = { 0, 1, 2, 3 };
			glm::mat4 matrixValue = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
			Foo fooValue(1);
			RTTI* rttiValue = &fooValue;

			default.Append(intKey);
			default.Append(floatKey);
			default.Append(stringKey);
			default.Append(vectorKey);
			default.Append(matrixKey);
			default.Append(RTTIKey);
			default.AppendScope(scopeKey);

			default[intKey].PushBack(static_cast<size_t>(1));
			default[floatKey].PushBack(2.3f);
			default[stringKey].PushBack(stringValue);
			default[vectorKey].PushBack(vectorValue);
			default[matrixKey].PushBack(matrixValue);
			default[RTTIKey].PushBack(rttiValue);

			Assert::AreEqual(size_t(7), default.Size());
			Assert::IsTrue(*(default.Find(intKey)) == static_cast<size_t>(1));
			Assert::IsTrue(*(default.Find(floatKey)) == 2.3f);
			Assert::IsTrue(*(default.Find(stringKey)) == stringValue);
			Assert::IsTrue(*(default.Find(vectorKey)) == vectorValue);
			Assert::IsTrue(*(default.Find(matrixKey)) == matrixValue);
			Assert::IsTrue(*(default.Find(RTTIKey)) == rttiValue);

			default.Clear();
			Assert::IsTrue(default.Find(intKey) == nullptr);
			Assert::IsTrue(default.Find(floatKey) == nullptr);
			Assert::IsTrue(default.Find(stringKey) == nullptr);
			Assert::IsTrue(default.Find(vectorKey) == nullptr);
			Assert::IsTrue(default.Find(matrixKey) == nullptr);
			Assert::IsTrue(default.Find(RTTIKey) == nullptr);
		}

		TEST_METHOD(FindContainedScope)
		{
			Scope scopeNest;
			std::string firstBaby = "FirstBaby";
			std::string secondBaby = "SecondBaby";
			std::string thirdBaby = "ThirdBaby";
			std::string fourthBaby = "FourthBaby";

			scopeNest.AppendScope(firstBaby);

			scopeNest.AppendScope(secondBaby);
			Scope* thirdBabyNest = &scopeNest[secondBaby][0].AppendScope(thirdBaby);

			std::pair<Datum*, size_t> thirdBabyPair(&scopeNest[secondBaby], 0);

			Assert::IsTrue(scopeNest.FindContainedScope(thirdBabyNest) == thirdBabyPair);
		}

		TEST_METHOD(IsDescendantOf)
		{
			Scope scopeNest;
			std::string firstBaby = "FirstBaby";
			std::string secondBaby = "SecondBaby";
			std::string thirdBaby = "ThirdBaby";
			std::string fourthBaby = "FourthBaby";

			scopeNest.AppendScope(firstBaby);

			Assert::IsTrue(scopeNest[0][0] == *scopeNest[firstBaby].GetScope());

			Scope* secondBabyNest = &scopeNest.AppendScope(secondBaby);
			Scope* thirdBabyNest = &scopeNest[secondBaby][0].AppendScope(thirdBaby);
			Scope* fourthBabyNest = &scopeNest[secondBaby][0][thirdBaby][0].AppendScope(fourthBaby);

			Assert::IsFalse(scopeNest.IsDescendantOf(scopeNest));
			Assert::IsFalse(scopeNest.IsDescendantOf(*secondBabyNest));
			Assert::IsFalse(scopeNest.IsDescendantOf(*thirdBabyNest));
			Assert::IsFalse(scopeNest.IsDescendantOf(*fourthBabyNest));

			Assert::IsFalse(secondBabyNest->IsDescendantOf(scopeNest));
			Assert::IsFalse(secondBabyNest->IsDescendantOf(*secondBabyNest));
			Assert::IsFalse(secondBabyNest->IsDescendantOf(*thirdBabyNest));
			Assert::IsFalse(secondBabyNest->IsDescendantOf(*fourthBabyNest));

			Assert::IsTrue(thirdBabyNest->IsDescendantOf(scopeNest));
			Assert::IsTrue(thirdBabyNest->IsDescendantOf(*secondBabyNest));
			Assert::IsFalse(thirdBabyNest->IsDescendantOf(*thirdBabyNest));
			Assert::IsFalse(thirdBabyNest->IsDescendantOf(*fourthBabyNest));

			Assert::IsTrue(fourthBabyNest->IsDescendantOf(scopeNest));
			Assert::IsTrue(fourthBabyNest->IsDescendantOf(*secondBabyNest));
			Assert::IsTrue(fourthBabyNest->IsDescendantOf(*thirdBabyNest));
			Assert::IsFalse(fourthBabyNest->IsDescendantOf(*fourthBabyNest));
		}

		TEST_METHOD(MoveConstructor)
		{
			Scope default;

			std::string intKey = "Apple";
			std::string floatKey = "Pear";
			std::string stringKey = "Orange";
			std::string vectorKey = "Banana";
			std::string matrixKey = "Strawberry";
			std::string RTTIKey = "Blueberry";
			std::string scopeKey = "Grape";

			std::string stringValue = "Fruit";
			glm::vec4 vectorValue = { 0, 1, 2, 3 };
			glm::mat4 matrixValue = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
			Foo fooValue(1);
			RTTI* rttiValue = &fooValue;

			default.Append(intKey);
			default.Append(floatKey);
			default.Append(stringKey);
			default.Append(vectorKey);
			default.Append(matrixKey);
			default.Append(RTTIKey);
			default.AppendScope(scopeKey);

			default[intKey].PushBack(static_cast<size_t>(1));
			default[floatKey].PushBack(2.3f);
			default[stringKey].PushBack(stringValue);
			default[vectorKey].PushBack(vectorValue);
			default[matrixKey].PushBack(matrixValue);
			default[RTTIKey].PushBack(rttiValue);

			default[scopeKey][0].Append("FirstNewElement");
			default[scopeKey][0].Append("SecondNewElement");
			default[scopeKey][0].AppendScope("BabyScope");

			default[scopeKey][0]["FirstNewElement"].PushBack(static_cast<size_t>(1));
			default[scopeKey][0]["SecondNewElement"].PushBack(4.5f);

			Scope newMovedScope = std::move(default[scopeKey][0]);
			Scope lastMovedScope = std::move(default);


			Assert::IsTrue(lastMovedScope.Find(stringKey)->GetString() == stringValue);
		}

	private: //Creates memory state screenshots to ensure no memory leaks in any test
		inline static _CrtMemState _startMemState;
	};
}