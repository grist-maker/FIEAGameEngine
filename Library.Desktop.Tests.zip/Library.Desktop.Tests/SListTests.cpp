#include "pch.h"
#include "CppUnitTest.h"
#include "SList.h"
#include "Foo.h"
#include <algorithm>
#include "ToStringSpecializations.h"
/// <summary>
/// The file specifying the SList class tests. Used to cover all possible code routes and attain full coverage of the class and its variety of methods and allowed operations.
/// </summary>
using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace UnitTests;
using namespace std;
using namespace std::string_literals;

namespace Microsoft::VisualStudio::CppUnitTestFramework
{
	template<>
	std::wstring ToString<SList<Foo>::Iterator>(const SList<Foo>::Iterator& iterator)
	{
		wstring value;
		try
		{
			value = ToString(*iterator);
		}
		catch (const std::exception&)
		{
			value = L"end()"s;
		}
		return value;
	}
	template<>
	std::wstring ToString<SList<Foo>::ConstIterator>(const SList<Foo>::ConstIterator& iterator)
	{
		wstring value;
		try
		{
			value = ToString(*iterator);
		}
		catch (const std::exception&)
		{
			value = L"end()"s;
		}
		return value;
	}
}

namespace UnitTestLibraryDesktop
{

	TEST_CLASS(LibraryDesktopTests)
	{

	public:

		TEST_METHOD_INITIALIZE(Initialize) //Initial setup of memory state variables to allow memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&_startMemState);
			#endif
		}
		TEST_METHOD_CLEANUP(Cleanup) //Setup for memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &_startMemState,
				&endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
			#endif
		}
		TEST_METHOD(Constructor)
		{
			SList<Foo> list; //Ensures size is initialized at 0, and front and back are initialized as nullptr
			Assert::AreEqual(size_t(0), list.Size());
			Assert::ExpectException<std::runtime_error>([&list]() {auto& front = list.Front(); UNREFERENCED_LOCAL(front); });
			Assert::ExpectException<std::runtime_error>([&list]() {auto& back = list.Back(); UNREFERENCED_LOCAL(back); });
		}
		TEST_METHOD(Size)
		{
			SList<Foo> list;
			Foo frontElement(20), middleElement(30), backElement(40);
			Assert::AreEqual(list.Size(), size_t(0)); //Ensures size is always directly tied to how many elements are currently in the list, regardless of how elements are popped or pushed

			list.PushFront(frontElement);
			Assert::AreEqual(list.Size(), size_t(1));

			list.PushBack(middleElement);
			Assert::AreEqual(list.Size(), size_t(2));

			list.PushBack(backElement);
			Assert::AreEqual(list.Size(), size_t(3));

			list.PopFront();
			Assert::AreEqual(list.Size(), size_t(2));

			list.PopFront();
			Assert::AreEqual(list.Size(), size_t(1));

			list.PopFront();
			Assert::AreEqual(list.Size(), size_t(0));
			Assert::ExpectException<std::runtime_error>([&list]() {list.PopFront(); UNREFERENCED_LOCAL(list.PopFront()); });
			Assert::ExpectException<std::runtime_error>([&list]() {list.PopBack(); UNREFERENCED_LOCAL(list.PopBack()); });
			Assert::AreEqual(list.Size(), size_t(0)); //Ensure the size remains 0 if pop is attempted
		}

		TEST_METHOD(IsEmpty)
		{
			SList<Foo> list;
			Foo frontElement(20), backElement(30);

			Assert::AreEqual(list.IsEmpty(), true); //Ensures list is empty when elements are not present, but not empty when they are

			list.PushFront(frontElement);
			Assert::AreEqual(list.IsEmpty(), false);

			list.PushBack(backElement);
			Assert::AreEqual(list.IsEmpty(), false);

			list.PopBack();
			Assert::AreEqual(list.IsEmpty(), false);

			list.PopFront();
			Assert::AreEqual(list.IsEmpty(), true);
		}

		TEST_METHOD(Front)
		{
			SList<Foo> list;
			Foo frontElement(20), middleElement(30), backElement(40);
			Assert::AreEqual(list.Size(), size_t(0));
			
			list.PushFront(backElement); //Ensures size and front are maintained when elements are pushed on array
			Assert::AreEqual(list.Front(), backElement);
			Assert::AreEqual(list.Size(), size_t(1));

			list.PushFront(middleElement);
			Assert::AreEqual(list.Front(), middleElement);
			Assert::AreEqual(list.Size(), size_t(2));

			list.PushFront(frontElement);
			Assert::AreEqual(list.Front(), frontElement);
			Assert::AreEqual(list.Size(), size_t(3));

			const SList<Foo>& newFullList = list; //Ensure front access is allowed for const list with at least one element
			Assert::AreEqual(newFullList.Front(), frontElement);

			list.PopFront(); //Makes sure size and front elements are updated properly when elements are popped off array front
			Assert::AreEqual(list.Front(), middleElement);
			Assert::AreEqual(list.Size(), size_t(2));

			list.PopFront();
			Assert::AreEqual(list.Front(), backElement);
			Assert::AreEqual(list.Size(), size_t(1));

			list.PopFront();
			Assert::AreEqual(list.Size(), size_t(0)); //Exception is thrown when attempt is made to access front when its empty
			Assert::ExpectException<std::runtime_error>([&list]() {auto& front = list.Front(); UNREFERENCED_LOCAL(front); });

			const SList<Foo>& newEmptyList = list;
			Assert::ExpectException<std::runtime_error>([&newEmptyList]() {auto& front = newEmptyList.Front(); UNREFERENCED_LOCAL(front); });//Ensure access isnt allowed for empty constant lists
		}

		TEST_METHOD(Back)
		{
			SList<Foo> list;
			Foo frontElement(20), middleElement(30), backElement(40);
			Assert::AreEqual(list.Size(), size_t(0));

			list.PushFront(middleElement); //Ensures size and proper back variables are maintained when new elements are added to front and back of SList
			Assert::AreEqual(list.Back(), middleElement);
			Assert::AreEqual(list.Size(), size_t(1));

			list.PushFront(frontElement);
			Assert::AreEqual(list.Back(), middleElement);
			Assert::AreEqual(list.Size(), size_t(2));

			list.PushBack(backElement);
			Assert::AreEqual(list.Back(), backElement);
			Assert::AreEqual(list.Size(), size_t(3));

			const SList<Foo>& newFullList = list; //Sets constant list and ensures its back is still accessible
			Assert::AreEqual(newFullList.Back(), backElement);

			list.PopBack(); //Makes sure size and back element positions are maintained as elements are removed from list
			Assert::AreEqual(list.Back(), middleElement);
			Assert::AreEqual(list.Size(), size_t(2));

			list.PopFront();
			Assert::AreEqual(list.Back(), middleElement);
			Assert::AreEqual(list.Size(), size_t(1));

			list.PopFront();
			Assert::ExpectException<std::runtime_error>([&list]() { auto& result = list.Back(); UNREFERENCED_LOCAL(result); }); //Ensure that access isnt allowed if uninitialized
			Assert::AreEqual(list.Size(), size_t(0));

			const SList<Foo>& newEmptyList = list;
			Assert::ExpectException<std::runtime_error>([&newEmptyList]() {auto& result = newEmptyList.Back(); UNREFERENCED_LOCAL(result); });//Ensure access isnt allowed for empty constant list
		}

		TEST_METHOD(PushFront)
		{
			SList<Foo> list;
			Foo myFirstVal(20), mySecondVal(30), myThirdVal(40);
			Assert::AreEqual(list.Size(), size_t(0));

			list.PushFront(myFirstVal); //Makes sure all 3 elements are pushed on in correct order and size is maintained
			Assert::AreEqual(list.Front(), myFirstVal);
			Assert::AreEqual(list.Back(), myFirstVal);
			Assert::AreEqual(list.Size(), size_t(1));

			list.PushFront(mySecondVal);
			Assert::AreEqual(list.Front(), mySecondVal);
			Assert::AreEqual(list.Back(), myFirstVal);
			Assert::AreEqual(list.Size(), size_t(2));

			list.PushFront(myThirdVal);
			Assert::AreEqual(list.Front(), myThirdVal);
			Assert::AreEqual(list.Back(), myFirstVal);
			Assert::AreEqual(list.Size(), size_t(3));

			list.PopFront();//Ensures next variables are set to allow elements to maintain order in list constantly
			Assert::AreEqual(list.Front(), mySecondVal);
			Assert::AreEqual(list.Back(), myFirstVal);
			Assert::AreEqual(list.Size(), size_t(2));

			list.PopBack();
			Assert::AreEqual(list.Front(), mySecondVal);
			Assert::AreEqual(list.Back(), mySecondVal);
			Assert::AreEqual(list.Size(), size_t(1));
		}

		TEST_METHOD(PushBack)
		{
			SList<Foo> list;
			Foo myFirstVal(20), mySecondVal(30), myThirdVal(40);
			Assert::AreEqual(list.Size(), size_t(0));

			list.PushBack(myFirstVal); //Makes sure that list size is properly mainained and all elements are pushed on in correct order
			Assert::AreEqual(list.Front(), myFirstVal);
			Assert::AreEqual(list.Back(), myFirstVal);
			Assert::AreEqual(list.Size(), size_t(1));

			list.PushBack(mySecondVal);
			Assert::AreEqual(list.Front(), myFirstVal);
			Assert::AreEqual(list.Back(), mySecondVal);
			Assert::AreEqual(list.Size(), size_t(2));

			list.PushBack(myThirdVal);
			Assert::AreEqual(list.Front(), myFirstVal);
			Assert::AreEqual(list.Back(), myThirdVal);
			Assert::AreEqual(list.Size(), size_t(3));

			list.PopBack(); //Makes sure next variables are set correctly to maintain position in array for when elements are popped off
			Assert::AreEqual(list.Front(), myFirstVal);
			Assert::AreEqual(list.Back(), mySecondVal);
			Assert::AreEqual(list.Size(), size_t(2));

			list.PopFront();
			Assert::AreEqual(list.Front(), mySecondVal);
			Assert::AreEqual(list.Back(), mySecondVal);
			Assert::AreEqual(list.Size(), size_t(1));
		}

		TEST_METHOD(PopFront)
		{
			SList<Foo> list;
			Foo frontElement(20), middleElement(30), backElement(40);
			Assert::AreEqual(list.Size(), size_t(0));

			list.PushBack(frontElement);
			Assert::AreEqual(list.Size(), size_t(1));
			list.PushBack(middleElement);
			Assert::AreEqual(list.Size(), size_t(2));
			list.PushBack(backElement);
			Assert::AreEqual(list.Size(), size_t(3));
			Assert::AreEqual(list.Front(), frontElement); //Assres elements are in correct order and list is proper size
			Assert::AreEqual(list.Back(), backElement);

			list.PopFront(); //Checks that when front element is popped off, it is replaced by next in line
			Assert::AreEqual(list.Front(), middleElement);
			Assert::AreEqual(list.Back(), backElement);

			list.PopFront(); //Ensures that when the second to last element is popped off, the last remaining element is considered front and back of list
			Assert::AreEqual(list.Front(), backElement);
			Assert::AreEqual(list.Back(), backElement);

			list.PopFront();
			Assert::ExpectException<std::runtime_error>([&list]() {auto& back = list.Back(); UNREFERENCED_LOCAL(back); });
			Assert::ExpectException<std::runtime_error>([&list]() {auto& front = list.Front(); UNREFERENCED_LOCAL(front); });
			Assert::ExpectException<std::runtime_error>([&list]() {list.PopFront(); UNREFERENCED_LOCAL(list.PopFront()); });//Stops user if they try to pop front off an empty list
		}

		TEST_METHOD(PopBack)
		{
			SList<Foo> list;
			Foo frontElement(20), middleElement(30), backElement(40);

			list.PushBack(middleElement);
			Assert::AreEqual(list.Size(), size_t(1));
			list.PushFront(frontElement);
			Assert::AreEqual(list.Size(), size_t(2));
			list.PushBack(backElement);
			Assert::AreEqual(list.Size(), size_t(3));
			Assert::AreEqual(list.Front(), frontElement); //Ensures front and back elements are at correct places, and list is always correct size
			Assert::AreEqual(list.Back(), backElement);

			list.PopBack(); //Ensures the backElement is removed and replaced by middleElement as the new back
			Assert::AreEqual(list.Front(), frontElement);
			Assert::AreEqual(list.Back(), middleElement);
			
			list.PopBack(); //Ensures that in single-element lists, the last remaining element is the front and back
			Assert::AreEqual(list.Front(), frontElement);
			Assert::AreEqual(list.Back(), frontElement);

			list.PopBack(); //Ensures an exception is thrown if the user attempts to pop off the back of an empty SList
			Assert::ExpectException<std::runtime_error>([&list]() {auto& back = list.Back(); UNREFERENCED_LOCAL(back); });
			Assert::ExpectException<std::runtime_error>([&list]() {auto& front = list.Front(); UNREFERENCED_LOCAL(front); });
			Assert::ExpectException<std::runtime_error>([&list]() {list.PopBack(); UNREFERENCED_LOCAL(list.PopBack()); });//Make sure it stops user if size is 0
		}

		TEST_METHOD(CopySemantics)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);
			Assert::AreEqual(list.Front(), frontElement); //Ensure back and front are correctly placed
			Assert::AreEqual(list.Back(), backElement);

			SList<Foo> copyOfList{ list }; //Invokes copy constructor to create copyOfList as a deep copy of list

			Assert::AreEqual(list.Front(), copyOfList.Front()); //Checks front and back are equal
			Assert::AreEqual(list.Back(), copyOfList.Back());
			Assert::AreEqual(list.Size(), copyOfList.Size()); //Checks sizes are equal

			list.Clear(); //Wipes initial list created via copy constructor to ensure that copy of list is a true deep and not shallow copy.
			Assert::ExpectException<std::runtime_error>([&list]() {auto& front = list.Front(); UNREFERENCED_LOCAL(front); }); //Checks that list is wiped but copy isn't
			Assert::ExpectException<std::runtime_error>([&list]() {auto& back = list.Back(); UNREFERENCED_LOCAL(back); });

			Assert::AreEqual(copyOfList.Front(), frontElement);
			Assert::AreEqual(copyOfList.Back(), backElement);

			list = copyOfList; //Tests assignment operator override function for proper functionality
			Assert::AreEqual(list.Front(), copyOfList.Front()); //Checks front, back, and size are equal
			Assert::AreEqual(list.Back(), copyOfList.Back());
			Assert::AreEqual(list.Size(), copyOfList.Size());

			list.Clear(); //Wipes a list created via assignment operator as well to ensure correct functionality

			Assert::ExpectException<std::runtime_error>([&list]() {auto& front = list.Front(); UNREFERENCED_LOCAL(front); }); //Checks that list is wiped but copy isn't
			Assert::ExpectException<std::runtime_error>([&list]() {auto& back = list.Back(); UNREFERENCED_LOCAL(back); });
			Assert::AreEqual(copyOfList.Front(), frontElement);
			Assert::AreEqual(copyOfList.Back(), backElement);

			copyOfList = list;
			Assert::ExpectException<std::runtime_error>([&list]() {auto& front = list.Front(); UNREFERENCED_LOCAL(front); }); //Checks that the empty list was properly assigned via the assignment operator
			Assert::ExpectException<std::runtime_error>([&list]() {auto& back = list.Back(); UNREFERENCED_LOCAL(back); });

			Assert::ExpectException<std::runtime_error>([&copyOfList]() {auto& front = copyOfList.Front(); UNREFERENCED_LOCAL(front); });
			Assert::ExpectException<std::runtime_error>([&copyOfList]() {auto& back = copyOfList.Back(); UNREFERENCED_LOCAL(back); });
		}

		TEST_METHOD(Clear)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);
			Assert::AreEqual(list.Front(), frontElement); //Ensure back and front elements are correct
			Assert::AreEqual(list.Back(), backElement);

			list.Clear(); //Clears a 3 element list

			Assert::AreEqual(list.Size(), size_t(0));
			Assert::ExpectException<std::runtime_error>([&list]() {auto& front = list.Front(); UNREFERENCED_LOCAL(front); }); //Checks that list is wiped and cannot be cleared again
			Assert::ExpectException<std::runtime_error>([&list]() {auto& back = list.Back(); UNREFERENCED_LOCAL(back); });
			//Assert::ExpectException<std::runtime_error>([&list]() {list.Clear(); UNREFERENCED_LOCAL(list.Clear()); });

			list.PushBack(frontElement); //Pushes and confirms that list now has one element
			Assert::AreEqual(list.Size(), size_t(1));

			list.Clear(); //Clears the one element list
			Assert::AreEqual(list.Size(), size_t(0));

			Assert::ExpectException<std::runtime_error>([&list]() {auto& front = list.Front(); UNREFERENCED_LOCAL(front); }); //Checks that list is wiped as expected
			Assert::ExpectException<std::runtime_error>([&list]() {auto& back = list.Back(); UNREFERENCED_LOCAL(back); });
		}

		TEST_METHOD(IteratorConstructor)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			SList<Foo>::Iterator defaultIterator; //Constructs default iterator using default constructor
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {Foo copyIterator = *defaultIterator; UNREFERENCED_LOCAL(copyIterator); }); //Ensures that an exception is thrown if checked since all values are nullptr

			SList<Foo>::Iterator beginIterator = list.begin(); //Initializes new iterator via the begin function
			Assert::AreEqual(*beginIterator, list.Front());

			auto endIterator = list.end(); //Initializes new iterator via the end function
			Assert::ExpectException<std::runtime_error>([&endIterator]() {Foo copyIterator = *endIterator; UNREFERENCED_LOCAL(copyIterator); }); //Ensures that an exception is thrown if checked since end iterators point PAST the end of the list
		}

		TEST_METHOD(ConstIteratorConstructor)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			const SList<Foo> constList = list;

			SList<Foo>::ConstIterator defaultIterator; //Constructs default constiterator using default constructor
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {Foo copyIterator = *defaultIterator; UNREFERENCED_LOCAL(copyIterator); }); //Ensures that an exception is thrown if checked since all values are nullptr

			SList<Foo>::ConstIterator beginIterator = constList.begin(); //Initializes new iterator via the begin function
			Assert::AreEqual(*beginIterator, constList.Front());

			SList<Foo>::ConstIterator endIterator = constList.end(); //Initializes new iterator via the end function
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {Foo copyIterator = *defaultIterator; UNREFERENCED_LOCAL(copyIterator); }); //Ensures that an exception is thrown if checked since end iterators point PAST the end of the list
		}

		TEST_METHOD(IteratorDereference)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			auto beginIterator = list.begin();
			Assert::AreEqual(*beginIterator, list.Front());
			Assert::AreEqual(*beginIterator, frontElement);

		}

		TEST_METHOD(ConstIteratorDereference)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			const SList<Foo> constList = list;
			SList<Foo>::ConstIterator beginIterator = constList.begin();

			Assert::AreEqual(*beginIterator, list.Front());
			Assert::AreEqual(*beginIterator, frontElement);
		}

		TEST_METHOD(IteratorPostfixIncrement)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			auto beginIterator = list.begin();

			beginIterator++;
			Assert::AreEqual(*beginIterator, middleElement);

			beginIterator++;
			Assert::AreEqual(*beginIterator, list.Back());

			beginIterator++;
			Assert::ExpectException<std::runtime_error>([&beginIterator]() {Foo copyIterator = *beginIterator; UNREFERENCED_LOCAL(copyIterator); });
		}

		TEST_METHOD(ConstIteratorPostfixIncrement)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			const SList<Foo> constList = list;

			SList<Foo>::ConstIterator beginIterator = constList.begin();

			beginIterator++;
			Assert::AreEqual(*beginIterator, middleElement);

			beginIterator++;
			Assert::AreEqual(*beginIterator, list.Back());

			beginIterator++;
			Assert::ExpectException<std::runtime_error>([&beginIterator]() {Foo copyIterator = *beginIterator; UNREFERENCED_LOCAL(copyIterator); });
		}

		TEST_METHOD(IteratorPrefixIncrement)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			auto beginIterator = list.begin(); //The iterator is initialized at the start of the list.

			++beginIterator;
			Assert::AreEqual(*beginIterator, middleElement); //Iterator traverses the list with each increment

			++beginIterator;
			Assert::AreEqual(*beginIterator, list.Back());//Back of list and the iterator are now equivalent since it has been incremented to the end

			++beginIterator;
			Assert::ExpectException<std::runtime_error>([&beginIterator]() {Foo copyIterator = *beginIterator; UNREFERENCED_LOCAL(copyIterator); });//Dereferencing null is illlegal behavior and should throw an exception
		}

		TEST_METHOD(ConstIteratorPrefixIncrement)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			const SList<Foo> constList = list;

			SList<Foo>::ConstIterator beginIterator = constList.begin(); //The iterator is initialized at the start of the list.

			++beginIterator;
			Assert::AreEqual(*beginIterator, middleElement); //Iterator traverses the list with each increment

			++beginIterator;
			Assert::AreEqual(*beginIterator, backElement); //Back of list and the iterator are now equivalent since it has been incremented to the end

			++beginIterator; //Now, the iterator should point to nullptr
			Assert::ExpectException<std::runtime_error>([&beginIterator]() {Foo copyIterator = *beginIterator; UNREFERENCED_LOCAL(copyIterator); }); //Dereferencing null is illlegal behavior and should throw an exception
		}

		TEST_METHOD(IteratorNotEqual)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			auto beginIterator = list.begin();
			auto endIterator = list.end();

			Assert::IsTrue(beginIterator != endIterator); //Ensures they are not equal

			beginIterator++;
			beginIterator++;
			beginIterator++;

			Assert::IsFalse(beginIterator != endIterator);
		}

		TEST_METHOD(ConstIteratorNotEqual)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			const SList<Foo> constList = list;

			SList<Foo>::ConstIterator beginIterator = constList.begin();
			SList<Foo>::ConstIterator endIterator = constList.end();

			Assert::IsTrue(beginIterator != endIterator); //Ensures they are not equal

			beginIterator++;
			beginIterator++;
			beginIterator++;

			Assert::IsFalse(beginIterator != endIterator); //Ensures they are now equal
		}

		TEST_METHOD(IteratorAreEqual)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			auto beginIterator = list.begin();
			auto endIterator = list.end();

			Assert::IsFalse(beginIterator == endIterator); //Ensures they are not equal

			beginIterator++;
			beginIterator++;
			beginIterator++;

			Assert::IsTrue(beginIterator == endIterator);
		}

		TEST_METHOD(ConstIteratorAreEqual)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			const SList<Foo> constList = list;

			SList<Foo>::ConstIterator beginIterator = constList.begin();
			SList<Foo>::ConstIterator endIterator = constList.end();

			Assert::IsFalse(beginIterator == endIterator); //Ensures they are not equal

			beginIterator++;
			beginIterator++;
			beginIterator++;

			Assert::IsTrue(beginIterator == endIterator); //Ensures they are now equal
		}

		TEST_METHOD(IteratorBegin)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			SList<Foo>::Iterator defaultIterator; //Constructs default iterator using default constructor

			list.PushFront(backElement);
			auto backIterator = list.begin();

			list.PushFront(middleElement);
			auto middleIterator = list.begin();

			list.PushFront(frontElement);
			auto frontIterator = list.begin();
			defaultIterator = list.begin();

			Assert::AreEqual(*backIterator, backElement);
			Assert::AreEqual(*middleIterator, middleElement);
			Assert::AreEqual(*frontIterator, frontElement);
			Assert::AreEqual(*defaultIterator, frontElement);
		}

		TEST_METHOD(ConstIteratorBegin)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			SList<Foo>::ConstIterator defaultIterator; //Constructs default iterator using default constructor
			
			SList<Foo>::ConstIterator backIterator;
			SList<Foo>::ConstIterator middleIterator;
			SList<Foo>::ConstIterator frontIterator;

			list.PushFront(backElement);
			const SList<Foo> backConstList = list;
			backIterator = backConstList.begin();

			list.PushFront(middleElement);
			const SList<Foo> middleConstList = list;
			middleIterator = middleConstList.begin();

			list.PushFront(frontElement);
			const SList<Foo> frontConstList = list;
			frontIterator = frontConstList.begin();

			defaultIterator = frontConstList.begin();

			Assert::AreEqual(*backIterator, backElement);
			Assert::AreEqual(*middleIterator, middleElement);
			Assert::AreEqual(*frontIterator, frontElement);
			Assert::AreEqual(*defaultIterator, frontElement);
		}

		TEST_METHOD(IteratorEnd)
		{
			const Foo frontElement(10);

			SList<Foo> list;
			SList<Foo>::Iterator defaultIterator; //Constructs default iterator using default constructor
			defaultIterator = list.end();

			list.PushBack(frontElement);
			auto endIterator = list.end();

			Assert::ExpectException<std::runtime_error>([&endIterator]() {Foo copyIterator = *endIterator; UNREFERENCED_LOCAL(copyIterator); }); //Ensures that an exception is thrown if checked since all values are nullptr
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {Foo copyIterator = *defaultIterator; UNREFERENCED_LOCAL(copyIterator); });
		}

		TEST_METHOD(ConstIteratorEnd)
		{
			const Foo frontElement(10);

			SList<Foo> list;
			const SList<Foo> emptyConstList = list;
			SList<Foo>::ConstIterator beginIterator = emptyConstList.end();

			list.PushBack(frontElement);
			const SList<Foo> fullConstList = list;
			SList<Foo>::ConstIterator endIterator = fullConstList.end();

			Assert::ExpectException<std::runtime_error>([&endIterator]() {Foo copyIterator = *endIterator; UNREFERENCED_LOCAL(copyIterator); }); //Ensures that an exception is thrown if checked since all values are nullptr
			Assert::ExpectException<std::runtime_error>([&beginIterator]() {Foo copyIterator = *beginIterator; UNREFERENCED_LOCAL(copyIterator); });

			Assert::AreNotEqual(endIterator, beginIterator);//Since they have different owner lists, it is false
		}

		TEST_METHOD(ConstantBegin)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);
			
			SList<Foo>::ConstIterator beginIterator = list.CBegin(); //This will force a const value return
			Assert::AreEqual(*beginIterator, frontElement);  //The assignment was successful!
		}

		TEST_METHOD(ConstantEnd)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			SList<Foo>::ConstIterator endIterator = list.CEnd(); //This will force a const value return
			Assert::ExpectException<std::runtime_error>([&endIterator]() {Foo copyIterator = *endIterator; UNREFERENCED_LOCAL(copyIterator); }); //Ensures that an exception is thrown if checked since all values are nullptr
		}

		TEST_METHOD(ConstIteratorTypeCast)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			const SList<Foo> constList = list;
			SList<Foo>::Iterator normalIterator = list.begin();

			(SList<Foo>::ConstIterator)normalIterator = constList.CBegin();//This will force a const value return
			Assert::AreEqual(*normalIterator, frontElement);
		}

		TEST_METHOD(IteratorInsertAfter)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;

			SList<Foo>::Iterator nullIterator;
			SList<Foo>::Iterator basicIterator = list.begin();

			Assert::ExpectException<std::runtime_error>([&nullIterator, &list, &frontElement]() {list.InsertAfter(frontElement, nullIterator); }); //Exception is thrown if the iterator is NOT part of the calling list

			list.InsertAfter(frontElement, basicIterator);
			basicIterator = list.begin();
			Assert::AreEqual(*basicIterator, list.Front()); //Front element and basiciterator are equal
			list.InsertAfter(backElement, basicIterator); //Back gets added after iterator
			list.InsertAfter(middleElement, basicIterator); //Middle gets added between back and iterator

			Assert::AreEqual(frontElement, list.Front());
			Assert::AreEqual(backElement, list.Back());
		}

		TEST_METHOD(IteratorToString)
		{

		}
		TEST_METHOD(ConstIteratorToString)
		{

		}

		TEST_METHOD(IteratorFind)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			SList<Foo>::Iterator beginIterator = list.begin();
			Assert::AreEqual(beginIterator, list.Find(frontElement));

			SList<Foo>::Iterator middleIterator = list.begin();
			middleIterator++;

			SList<Foo>::Iterator endIterator = list.begin();
			endIterator++;
			endIterator++;

			Assert::AreEqual(beginIterator, list.Find(frontElement)); //Element is properly found and matching iterator is returned
			Assert::AreEqual(middleIterator, list.Find(middleElement));
			Assert::AreEqual(endIterator, list.Find(backElement));
		}

		TEST_METHOD(ConstIteratorFind)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);
			const Foo nonexistentElement(40);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);

			const SList<Foo> constantList = list;

			SList<Foo>::ConstIterator beginIterator = constantList.begin();
			Assert::AreEqual(beginIterator, constantList.Find(frontElement));

			SList<Foo>::ConstIterator middleIterator = constantList.begin();
			middleIterator++;

			SList<Foo>::ConstIterator endIterator = constantList.begin();
			endIterator++;
			endIterator++;

			Assert::AreEqual(beginIterator,constantList.Find(frontElement)); //Element is properly found and matching iterator is returned
			Assert::AreEqual(middleIterator, constantList.Find(middleElement));
			Assert::AreEqual(endIterator, constantList.Find(backElement));

			Assert::AreEqual(constantList.end(), constantList.Find(nonexistentElement)); //Nullptr is returned if element isnt found on list
		}

		TEST_METHOD(IteratorRemove)
		{
			const Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);
			const Foo finalElement(40);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);
			list.PushBack(finalElement);

			SList<Foo>::Iterator beginIterator = list.begin();

			SList<Foo>::Iterator middleIterator = list.begin();
			middleIterator++;

			SList<Foo>::Iterator endIterator = list.begin();
			endIterator++;
			endIterator++;

			SList<Foo>::Iterator finalIterator = list.begin();
			finalIterator++;
			finalIterator++;
			finalIterator++;

			const SList<Foo>::Iterator backOfListIterator = list.end();

			SList<Foo>::Iterator nullIterator;

			Assert::ExpectException<std::runtime_error>([&nullIterator, &list]() {list.Remove(nullIterator); }); //Exception is thrown if the iterator is NOT part of the calling list

			Assert::IsTrue(list.Remove(beginIterator)); //Removes beginning iterator
			Assert::AreEqual(middleIterator, list.begin()); //MiddleIterator is new front of list
			Assert::AreEqual(*endIterator, backElement); //BackIterator is not affected
			Assert::AreEqual(*finalIterator,finalElement); //BackIterator is not affected

			Assert::IsFalse(list.Remove(backOfListIterator)); //Does not destroy the back of list, since it has no node value

			Assert::IsTrue(list.Size() == 3);

			Assert::IsTrue(list.Remove(endIterator)); //Removes end (new middle) iterator
			Assert::AreEqual(middleIterator, list.begin()); //MiddleIterator is new front of list
			Assert::AreEqual(*finalIterator, finalElement); //BackIterator is not affected

			Assert::IsTrue(list.Remove(finalIterator));
			Assert::AreEqual(middleIterator, list.begin()); //MiddleIterator is still front of list

			Assert::IsTrue(list.Remove(middleIterator)); //Removes end (new middle) iterator
			Assert::IsTrue(list.Size() == 0);

			#ifdef NDEBUG
				
			#else
				Assert::IsFalse(list.Remove(middleIterator)); //Does not remove nonexistent elements, but throws exception when trying to remove elements from empty SList in release
			#endif
		}

		TEST_METHOD(TRemove)
		{
			Foo frontElement(10);
			const Foo middleElement(20);
			const Foo backElement(30);
			const Foo finalElement(40);

			SList<Foo> list;
			list.PushBack(frontElement);
			list.PushBack(middleElement);
			list.PushBack(backElement);
			list.PushBack(finalElement);

			SList<Foo>::Iterator beginIterator = list.begin();

			SList<Foo>::Iterator middleIterator = list.begin();
			middleIterator++;

			SList<Foo>::Iterator endIterator = list.begin();
			endIterator++;
			endIterator++;

			SList<Foo>::Iterator finalIterator = list.begin();
			finalIterator++;
			finalIterator++;
			finalIterator++;

			Assert::IsTrue(list.Remove(&list.Front())); //Removes beginning node
			Assert::AreEqual(middleIterator, list.begin()); //MiddleIterator is new front of list
			Assert::AreEqual(*endIterator, backElement); //BackIterator is not affected
			Assert::AreEqual(*finalIterator, finalElement); //BackIterator is not affected

			Assert::IsTrue(list.Remove(&list.Back())); //Removes backmost node, which is finalIterator
			Assert::AreEqual(middleIterator, list.begin()); //MiddleIterator is new front of list
			Assert::AreEqual(*endIterator, backElement); //BackIterator is not affected

			Assert::IsTrue(list.Remove(&list.Back()));
			Assert::AreEqual(middleIterator, list.begin()); //MiddleIterator is still front of list

			Assert::IsFalse(list.Remove(&frontElement)); //Unsuccessful remove of nonexistent element

			Assert::IsTrue(list.Remove(&list.Back())); //Removes end (new middle) iterator
			Assert::IsTrue(list.Size() == 0);

			Assert::IsFalse(list.Remove(&middleElement)); //Can't remove nonexistent element
		}


	private: //Creates memory state screenshots to ensure no memory leaks in any test
		inline static _CrtMemState _startMemState;
	};
}