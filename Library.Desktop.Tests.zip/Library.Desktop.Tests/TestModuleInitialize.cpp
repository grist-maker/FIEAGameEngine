#include "pch.h"
#include "TypeManager.h"
#include "AttributedFoo.h"
#include "Monster.h"
#include "GameObject.h"
#include "Pancake.h"
#include "CppUnitTest.h"
#include "ActionList.h"
#include "ActionIncrement.h"
#include "ActionDecrement.h"
#include "ActionMultiply.h"
#include "ActionDivide.h"
#include "ActionListIf.h"
#include "ActionListWhile.h"
#include "EventMessageAttributed.h"
#include "ReactionAttributed.h"
#include "ActionEvent.h"
#include "OperateReactionAttributed.h"
#include "BigReactionAttributed.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace UnitTests;
using namespace std;

namespace UnitTestsLibraryDesktop
{
	TEST_MODULE_INITIALIZE(TestModuleInitialize)
	{
		TypeManager::Instance()->CreateInstance();

		size_t fooId = AttributedFoo::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> attributedFooSign(fooId, AttributedFoo::Signatures());
		TypeManager::Instance()->AddSignatures(attributedFooSign);

		size_t gameObjectId = GameObject::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> GameObjectSignatures(gameObjectId, GameObject::Signatures());
		TypeManager::Instance()->AddSignatures(GameObjectSignatures);

		size_t monsterId = Monster::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> MonsterSign(monsterId, Monster::Signatures());
		TypeManager::Instance()->AddSignatures(MonsterSign);

		size_t pancakeId = Pancake::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> PancakeSignatures(pancakeId, Pancake::Signatures());
		TypeManager::Instance()->AddSignatures(PancakeSignatures);

		size_t listId = ActionList::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> ActionListSignatures(listId, ActionList::Signatures());
		TypeManager::Instance()->AddSignatures(ActionListSignatures);

		size_t actionIncrementId = ActionIncrement::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> ActionIncrementSignatures(actionIncrementId, ActionIncrement::Signatures());
		TypeManager::Instance()->AddSignatures(ActionIncrementSignatures);

		size_t actionDecrementId = ActionDecrement::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> ActionDecrementSignatures(actionDecrementId, ActionDecrement::Signatures());
		TypeManager::Instance()->AddSignatures(ActionDecrementSignatures);

		size_t actionMultiplyId = ActionMultiply::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> ActionMultiplySignatures(actionMultiplyId, ActionMultiply::Signatures());
		TypeManager::Instance()->AddSignatures(ActionMultiplySignatures);

		size_t actionDivideId = ActionDivide::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> ActionDivideSignatures(actionDivideId, ActionDivide::Signatures());
		TypeManager::Instance()->AddSignatures(ActionDivideSignatures);

		size_t actionListIfId = ActionListIf::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> ActionListIfSignatures(actionListIfId, ActionListIf::Signatures());
		TypeManager::Instance()->AddSignatures(ActionListIfSignatures);

		size_t actionListWhileId = ActionListWhile::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> ActionListWhileSignatures(actionListWhileId, ActionListWhile::Signatures());
		TypeManager::Instance()->AddSignatures(ActionListWhileSignatures);

		size_t eventMessage = EventMessageAttributed::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> EventMessageSignatures(eventMessage, EventMessageAttributed::Signatures());
		TypeManager::Instance()->AddSignatures(EventMessageSignatures);

		size_t reactionAttributedMessage = ReactionAttributed::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> reactionAttributedSignatures(reactionAttributedMessage, ReactionAttributed::Signatures());
		TypeManager::Instance()->AddSignatures(reactionAttributedSignatures);

		size_t ActionEventMessage = ActionEvent::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> ActionEventSignatures(ActionEventMessage, ActionEvent::Signatures());
		TypeManager::Instance()->AddSignatures(ActionEventSignatures);

		size_t OperateReactionAttributedMessage = OperateReactionAttributed::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> OperateReactionAttributedSignatures(OperateReactionAttributedMessage, OperateReactionAttributed::Signatures());
		TypeManager::Instance()->AddSignatures(OperateReactionAttributedSignatures);

		size_t BigReactionAttributedMessage = BigReactionAttributed::TypeIdClass();
		const std::pair<size_t, Vector<Signature>> BigReactionAttributedSignatures(BigReactionAttributedMessage, BigReactionAttributed::Signatures());
		TypeManager::Instance()->AddSignatures(BigReactionAttributedSignatures);
	}

	TEST_MODULE_CLEANUP(TestModuleCleanup)
	{
		size_t fooId = AttributedFoo::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(fooId);

		size_t monsterId = Monster::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(monsterId);

		size_t gameId = GameObject::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(gameId);

		size_t pancakeId = Pancake::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(pancakeId);

		size_t actionListId = ActionList::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(actionListId);

		size_t actionIncrementId = ActionIncrement::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(actionIncrementId);

		size_t actionDecrementId = ActionDecrement::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(actionDecrementId);

		size_t actionMultiplyId = ActionMultiply::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(actionMultiplyId);

		size_t actionDivideId = ActionDivide::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(actionDivideId);

		size_t actionListIfId = ActionListIf::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(actionListIfId);

		size_t actionListWhileId = ActionListWhile::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(actionListWhileId);

		size_t eventMessageId = EventMessageAttributed::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(eventMessageId);

		size_t reactionAttributedId = ReactionAttributed::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(reactionAttributedId);

		size_t actionEventId = ActionEvent::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(actionEventId);

		size_t incrementReactionId = OperateReactionAttributed::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(incrementReactionId);

		size_t bigReactionId = BigReactionAttributed::TypeIdClass();
		TypeManager::Instance()->RemoveSignatures(bigReactionId);

		TypeManager::Instance()->DestroyInstance();
	}
}