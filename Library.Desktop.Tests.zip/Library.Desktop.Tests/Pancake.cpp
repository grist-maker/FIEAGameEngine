#include "pch.h"
#include "Pancake.h"

using namespace std;
using namespace std::string_literals;
using namespace FieaGameEngine;

namespace UnitTests
{
	RTTI_DEFINITIONS(Pancake);

	Pancake::Pancake() :
		GameObject(TypeIdClass())
	{
	}

	FieaGameEngine::Vector<FieaGameEngine::Signature> Pancake::Signatures()
	{
		auto signatureArray = GameObject::Signatures();
		signatureArray.PushBack(Signature{ "Berry", Datum::DatumTypes::String, 1, offsetof(Pancake, Berry) });
		return signatureArray;
	}

	void Pancake::Update(const FieaGameEngine::GameTime& currentTime)
	{
		GameObject::Update(currentTime);
		Stack += currentTime.ElapsedGameTimeSeconds().count();
	}
}