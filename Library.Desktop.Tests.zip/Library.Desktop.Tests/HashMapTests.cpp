#include "pch.h"
#include "CppUnitTest.h"
#include "HashMap.h"
#include "Foo.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace UnitTests;
using namespace std;
using namespace std::string_literals;

/// <summary>
/// Define tests to fully cover the HashMap and its potential behaviors. Tests T, Foo, Char*, and String type keys for HashMaps.
/// </summary>
namespace FieaGameEngine
{
	template <>
	struct HashFunctor<Foo> final
	{
		size_t operator()(const Foo& key) const
		{
			size_t hashValue = 0;
			const auto hashPrime = 31;

			for (std::size_t index = 0; index < 4; ++index)
			{
				hashValue += static_cast<size_t>(key.Data() + index); //Value is grabbed from Foo. Value is stored in 4 byte data type, so we add together 4 bytes in order.
			}
			return hashValue * hashPrime;
		}
	};

}
namespace UnitTestLibraryDesktop
{
	TEST_CLASS(HashMapTests)
	{
	public:

		TEST_METHOD_INITIALIZE(Initialize) //Initial setup of memory state variables to allow memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&_startMemState);
			#endif
		}

		TEST_METHOD_CLEANUP(Cleanup) //Setup for memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &_startMemState,
				&endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
			#endif
		}
		TEST_METHOD(Constructor)
		{
			Assert::ExpectException<std::runtime_error>([]() {HashMap<uint16_t, size_t> newMap(0);  });
			Assert::ExpectException<std::runtime_error>([]() {HashMap<uint16_t, size_t> newMap(1);  }); //The HashMap should at least have 2 sections

			HashMap<uint16_t, size_t> newMap; //You can call constructor with or without size argument
			HashMap<uint16_t, size_t> specifiedMap(15);
		}

		TEST_METHOD(Insert)
		{
			HashMap<uint16_t, size_t> newMap;
			
			HashMap<uint16_t, size_t>::Iterator newIterator;
			std::pair <uint16_t, size_t> keyValues(uint16_t(25), size_t(25));
			auto result = newMap.Insert(keyValues);

			Assert::AreEqual(result.second, true); //An insert did occur!
			Assert::AreEqual((* result.first).second, size_t(25)); //The correct element is returned.

			auto newResult = newMap.Insert(keyValues);
			Assert::AreEqual(newResult.second, false); //An insert did not occur!
			Assert::AreEqual((*result.first).second, size_t(25)); //The correct element is returned.

			keyValues.first = uint16_t(26);
			keyValues.second = size_t(26);
			auto successfulInsertResult = newMap.Insert(keyValues);
			Assert::AreEqual(successfulInsertResult.second, true); //An insert did occur!
			Assert::AreEqual((*successfulInsertResult.first).second, size_t(26)); //The correct element is returned.

			Assert::AreEqual((* successfulInsertResult.first).second, (* newMap.begin()).second);

			++successfulInsertResult.first;
			Assert::AreEqual((* successfulInsertResult.first).second, (*result.first).second); //The increment was successful, showing that the insertion did occur in the right order!
		}

		TEST_METHOD(Find)
		{
			HashMap<uint16_t, size_t> newMap;

			HashMap<uint16_t, size_t>::Iterator newIterator;
			std::pair <uint16_t, size_t> keyValues(uint16_t(25), size_t(26));
			std::pair <uint16_t, size_t> alternateValues(uint16_t(26), size_t(25));

			auto result = newMap.Insert(keyValues);

			Assert::AreEqual((* (newMap.Find(keyValues.first))).second, (* (result.first)).second); //The element was properly found.
			HashMap<uint16_t, size_t>::Iterator failedIterator = newMap.Find(uint16_t(26));

			Assert::ExpectException<std::runtime_error>([&failedIterator]() {(* failedIterator).second;  }); //An iterator is returned, but it is associated to null value. The element was not found since it hasn't been added.
			
			result = newMap.Insert(alternateValues);
			Assert::AreEqual((* (newMap.Find(alternateValues.first))).second, (*(result.first)).second); //The element was properly found.

			failedIterator = newMap.Find(uint16_t(26)); //Now, this find will work!
			Assert::AreEqual((* failedIterator).second, size_t(25));
		}

		TEST_METHOD(HashmapIndex)
		{
			HashMap<uint16_t, size_t> newMap;
			auto dataReference = newMap[0]; //This will insert a default value of size_t with the uint16_t key 0.

			Assert::AreEqual(dataReference, newMap[0]); //Now, it will find the value with that key
			auto newDataReference = newMap[1];

			Assert::AreEqual(newDataReference, dataReference); //Both were default constructed, so the values are the same.
			Assert::AreEqual((* (newMap.Find(0))).second, (* (newMap.Find(1))).second);

			std::pair<uint16_t, size_t> value0(uint16_t{ 0 }, size_t{ 0 });
			std::pair<uint16_t, size_t> value1(uint16_t{ 1 }, size_t{ 0 });

			HashMap<uint16_t, size_t>::Iterator value0Iterator = newMap.Insert(value0).first;
			HashMap<uint16_t, size_t>::Iterator value1Iterator = newMap.Insert(value1).first;

			Assert::AreEqual((* value0Iterator).second, (* value1Iterator).second); //They are always considered equal by data value
		}

		TEST_METHOD(Size)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			auto dataReference = newMap[0]; //This will insert a default value of size_t with the uint16_t key 0.
			dataReference = newMap[1];
			Assert::AreEqual(newMap.Size(), size_t{ 2 });

			newMap.Remove(2);
			Assert::AreEqual(newMap.Size(), size_t{ 2 });

			newMap.Remove(1);
			Assert::AreEqual(newMap.Size(), size_t{ 1 });

			newMap.Remove(1);
			Assert::AreEqual(newMap.Size(), size_t{ 1 }); //The same element cannot be removed again, it is already absent from the HashMap

			newMap.Clear();
			Assert::AreEqual(newMap.Size(), size_t{ 0 });

		//	Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.begin();  });
		}

		TEST_METHOD(Begin)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(0));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(1), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(2), static_cast<size_t>(2));;

			auto frontReference = newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			Assert::AreEqual((* (newMap.begin())).second, size_t(0));
			newMap.Remove(0);
			Assert::AreEqual((* (newMap.begin())).second, size_t(1));
			newMap.Remove(1);
			Assert::AreEqual((* (newMap.begin())).second, size_t(2));
			newMap.Remove(2);
		}

		TEST_METHOD(End)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(0));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(1), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(2), static_cast<size_t>(2));;

			auto frontReference = newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			++backReference.first;

			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.end();  });
			Assert::ExpectException<std::runtime_error>([&backReference]() {*backReference.first;  }); //Back will send an exception when dereferenced. It returns a pointer past the ending element of the final SList.
		}

		TEST_METHOD(CBegin)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.cbegin();  });

			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(0));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(1), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(2), static_cast<size_t>(2));;

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			Assert::AreEqual((* (newMap.cbegin())).second, size_t(0));
			newMap.Remove(0);
			Assert::AreEqual((* (newMap.cbegin())).second, size_t(1));
			newMap.Remove(1);
			Assert::AreEqual((* (newMap.cbegin())).second, size_t(2));
			newMap.Remove(2);
		}

		TEST_METHOD(CEnd)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(0));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(1), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(2), static_cast<size_t>(2));;

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			const HashMap<uint16_t, size_t> copiedMap = newMap;
			auto backElement = copiedMap.cbegin();
			backElement++;
			backElement++;
			backElement++;

			Assert::ExpectException<std::runtime_error>([&copiedMap]() {*copiedMap.cend();  });
			Assert::ExpectException<std::runtime_error>([&backElement]() {*backElement;  });
		}

		TEST_METHOD(At)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			Assert::AreEqual(newMap.At(static_cast<uint16_t>(0)), static_cast<size_t>(1));
			Assert::AreEqual(newMap.At(static_cast<uint16_t>(2)), static_cast<size_t>(3));
			Assert::AreEqual(newMap.At(static_cast<uint16_t>(4)), static_cast<size_t>(5));

			Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.At(1);});
			Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.At(3);});
			Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.At(5);});
		}

		TEST_METHOD(AtConst)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			const HashMap<uint16_t, size_t> copiedMap = newMap;

			Assert::AreEqual(copiedMap.At(static_cast<uint16_t>(0)), static_cast<size_t>(1));
			Assert::AreEqual(copiedMap.At(static_cast<uint16_t>(2)), static_cast<size_t>(3));
			Assert::AreEqual(copiedMap.At(static_cast<uint16_t>(4)), static_cast<size_t>(5));

			Assert::ExpectException<std::runtime_error>([&copiedMap]() {copiedMap.At(1); });
			Assert::ExpectException<std::runtime_error>([&copiedMap]() {copiedMap.At(3); });
			Assert::ExpectException<std::runtime_error>([&copiedMap]() {copiedMap.At(5); });
		}

		TEST_METHOD(Destructor)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);
			Assert::AreEqual(newMap.Size(), size_t(3));

			Assert::IsFalse(newMap.Insert(frontPair).second);
			Assert::IsFalse(newMap.Insert(middlePair).second);
			Assert::IsFalse(newMap.Insert(endPair).second);

			newMap.~HashMap<uint16_t, size_t>();
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
		}

		TEST_METHOD(ContainsKey)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::IsFalse(newMap.ContainsKey(static_cast<uint16_t>(0)));

			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			newMap.Insert(frontPair);
			Assert::IsTrue(newMap.ContainsKey(static_cast<uint16_t>(0)));
			Assert::IsFalse(newMap.ContainsKey(static_cast<uint16_t>(2)));

			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			newMap.Insert(middlePair);
			Assert::IsTrue(newMap.ContainsKey(static_cast<uint16_t>(2)));
			Assert::IsFalse(newMap.ContainsKey(static_cast<uint16_t>(4)));

			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));;
			newMap.Insert(endPair);
			Assert::IsTrue(newMap.ContainsKey(static_cast<uint16_t>(4)));
		}

		TEST_METHOD(Remove)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(0));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(1), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(2), static_cast<size_t>(2));;

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);
			Assert::AreEqual(newMap.Size(), size_t(3));

			Assert::AreEqual((* newMap.Find(static_cast<uint16_t>(1))).second, size_t(1));
			newMap.Remove(1);
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find(uint16_t(1));  });

			Assert::AreEqual((* (newMap.begin())).second, size_t(0));
			newMap.Remove(0);
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find(uint16_t(0));  });

			Assert::AreEqual((* (newMap.begin())).second, size_t(2));
			newMap.Remove(2);
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find(uint16_t(2));  });

			//Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.begin(); });
		}

		TEST_METHOD(Clear)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);
			Assert::AreEqual(newMap.Size(), size_t(3));

			Assert::IsFalse(newMap.Insert(frontPair).second);
			Assert::IsFalse(newMap.Insert(middlePair).second);
			Assert::IsFalse(newMap.Insert(endPair).second);

			newMap.Clear();
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
//			Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.begin(); });//Begin is empty

			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find(uint16_t(0));  }); //Previous elements can't be found.
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find(uint16_t(2));  });
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find(uint16_t(4));  });
		}

		//Iterator and ConstIterator tests
		TEST_METHOD(IteratorConstructor)
		{
			HashMap<uint16_t, size_t> newHashmap(5);

			newHashmap[0]; //Create new default constructed element with key uint16_t(0)
			newHashmap[1]; //Create new default constructed element with key uint16_t(1)
			newHashmap[2]; //Create new default constructed element with key uint16_t(2)

			HashMap<uint16_t, size_t>::Iterator defaultIterator;

			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {*defaultIterator;  });
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {defaultIterator++;  });
		}

		TEST_METHOD(ConstIteratorConstructor)
		{
			HashMap<uint16_t, size_t> newHashmap(5);

			newHashmap.Insert(std::pair<uint16_t, size_t>(static_cast<uint16_t>(0), static_cast<size_t>(1)));
			newHashmap.Insert(std::pair<uint16_t, size_t>(static_cast<uint16_t>(2), static_cast<size_t>(3)));
			newHashmap.Insert(std::pair<uint16_t, size_t>(static_cast<uint16_t>(4), static_cast<size_t>(5)));

			HashMap<uint16_t, size_t>::ConstIterator defaultIterator;

			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {*defaultIterator;  }); //Default constructed has null value, defined has start of hashmap
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {defaultIterator++;  });
		}

		TEST_METHOD(IteratorCopyConstructor)
		{
			HashMap<uint16_t, size_t> newHashmap(5);

			newHashmap[0]; //Create new default constructed element with key uint16_t(0)
			newHashmap[1]; //Create new default constructed element with key uint16_t(1)
			newHashmap[2]; //Create new default constructed element with key uint16_t(2)

			HashMap<uint16_t, size_t>::Iterator definedIterator = newHashmap.begin();
			Assert::AreEqual((* definedIterator).second, newHashmap[0]);
		}
		TEST_METHOD(ConstIteratorCopyConstructor)
		{
			HashMap<uint16_t, size_t> newHashmap(5);

			newHashmap[0]; //Create new default constructed element with key uint16_t(0)
			newHashmap[1]; //Create new default constructed element with key uint16_t(1)
			newHashmap[2]; //Create new default constructed element with key uint16_t(2)

			HashMap<uint16_t, size_t>::ConstIterator definedIterator = newHashmap.cbegin();
			Assert::AreEqual((* definedIterator).second, newHashmap[0]);
		}

		TEST_METHOD(IteratorDestructor)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			Assert::AreEqual((* frontReference.first).second, static_cast<size_t>(1));
			frontReference.first.~Iterator();
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference.first;  });

			Assert::AreEqual((* middleReference.first).second, static_cast<size_t>(3));
			middleReference.first.~Iterator();
			Assert::ExpectException<std::runtime_error>([&middleReference]() {*middleReference.first;  });

			Assert::AreEqual((* backReference.first).second, static_cast<size_t>(5));
			backReference.first.~Iterator();
			Assert::ExpectException<std::runtime_error>([&backReference]() {*backReference.first;  });
		}

		TEST_METHOD(ConstIteratorDestructor)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));;

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto frontReference = newMap.cbegin();
			auto middleReference = newMap.cbegin();
			middleReference++;
			auto backReference = newMap.cbegin();
			backReference++;
			backReference++;

			Assert::AreEqual((* frontReference).second, static_cast<size_t>(1));
			frontReference.~ConstIterator();
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });

			Assert::AreEqual((* middleReference).second, static_cast<size_t>(5));
			middleReference.~ConstIterator();
			Assert::ExpectException<std::runtime_error>([&middleReference]() {*middleReference;  });

			Assert::AreEqual((* backReference).second, static_cast<size_t>(3));
			backReference.~ConstIterator();
			Assert::ExpectException<std::runtime_error>([&backReference]() {*backReference;  });
		}

		TEST_METHOD(IteratorPreIncrement)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));;

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto frontReference = newMap.begin();
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(1));

			++frontReference;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(5));

			++frontReference;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(3));

			++frontReference;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });
		//	++frontReference;
		}

		TEST_METHOD(ConstIteratorPreIncrement)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));;

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto frontReference = newMap.cbegin();
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(1));

			++frontReference;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(5));

			++frontReference;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(3));

			++frontReference;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });

			++frontReference;
		}

		TEST_METHOD(IteratorPostIncrement)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));;

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto frontReference = newMap.begin();
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(1));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(5));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(3));

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });

			frontReference++;
		}

		TEST_METHOD(ConstIteratorPostIncrement)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto frontReference = newMap.cbegin();
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(1));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(5));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(3));

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });

			frontReference++;
		}

		TEST_METHOD(IteratorDereference)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			HashMap<uint16_t, size_t>::Iterator defaultReference;
			Assert::ExpectException<std::runtime_error>([&defaultReference]() {*defaultReference;  });

			auto frontReference = newMap.begin();
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(1));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(5));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(3));

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });
		}

		TEST_METHOD(ConstIteratorDereference)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			HashMap<uint16_t, size_t>::ConstIterator defaultReference;
			Assert::ExpectException<std::runtime_error>([&defaultReference]() {*defaultReference;  });

			HashMap<uint16_t, size_t>::ConstIterator frontReference = newMap.cbegin();
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(1));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(5));

			frontReference++;
			Assert::AreEqual((*frontReference).second, static_cast<size_t>(3));

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });
		}

		TEST_METHOD(IteratorArrowDereference)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));

			auto traverser = newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			Assert::AreEqual((* (&traverser)->first).second, static_cast<size_t>(1));
			
			*(&traverser)->first++;
			Assert::AreEqual((* (&traverser)->first).second, size_t(5));

			*(&traverser)->first++;
			Assert::AreEqual((* (&traverser)->first).second, size_t(3));

			*(&traverser)->first++;
			Assert::ExpectException<std::runtime_error>([&traverser]() {*(&traverser)->first;  });
		}

		TEST_METHOD(ConstIteratorArrowDereference)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			std::pair<HashMap<uint16_t, size_t>::ConstIterator, bool> traverser(newMap.cbegin(), true);

			Assert::AreEqual((* (&traverser)->first).second, size_t(1));

			*(&traverser)->first++;
			Assert::AreEqual((* (&traverser)->first).second, size_t(5));

			traverser.first++;
			Assert::AreEqual((* (&traverser)->first).second, size_t(3));

			traverser.first++;
			Assert::ExpectException<std::runtime_error>([&traverser]() {*(& traverser)->first;  });
		}

		TEST_METHOD(IteratorEquality)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));

			auto firstInsert = newMap.Insert(frontPair).first; //This will insert a default value of size_t with the uint16_t key 0.
			auto secondInsert = newMap.Insert(middlePair).first;
			auto thirdInsert = newMap.Insert(endPair).first;

			Assert::IsFalse(firstInsert == secondInsert);
			Assert::IsFalse(firstInsert == thirdInsert);
			Assert::IsFalse(thirdInsert == secondInsert);

			firstInsert++;

			Assert::IsFalse(firstInsert == secondInsert);
			Assert::IsTrue(firstInsert == thirdInsert);
			Assert::IsFalse(thirdInsert == secondInsert);

			firstInsert++;
			thirdInsert++;
			Assert::IsTrue(firstInsert == secondInsert);
			Assert::IsTrue(firstInsert == thirdInsert);
			Assert::IsTrue(thirdInsert == secondInsert);

			HashMap<uint16_t, size_t>::Iterator defaultIterator;
			Assert::IsFalse(defaultIterator == secondInsert);
			Assert::IsFalse(defaultIterator == thirdInsert);
			Assert::IsFalse(defaultIterator == firstInsert);
		}

		TEST_METHOD(ConstIteratorEquality)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto first = newMap.cbegin();
			auto second = newMap.cbegin();
			auto third = newMap.cbegin();

			second++;
			third++;
			third++;

			Assert::IsFalse(first == second);
			Assert::IsFalse(first == third);
			Assert::IsFalse(third == second);

			first++;

			Assert::IsTrue(first == second);
			Assert::IsFalse(first == third);
			Assert::IsFalse(third == second);

			first++;
			second++;
			Assert::IsTrue(first == second);
			Assert::IsTrue(first == third);
			Assert::IsTrue(third == second);

			HashMap<uint16_t, size_t>::ConstIterator defaultIterator;
			Assert::IsFalse(defaultIterator == second);
			Assert::IsFalse(defaultIterator == third);
			Assert::IsFalse(defaultIterator == first);
		}

		TEST_METHOD(IteratorInEquality)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));

			auto firstInsert = newMap.Insert(frontPair).first; //This will insert a default value of size_t with the uint16_t key 0.
			auto secondInsert = newMap.Insert(middlePair).first;
			auto thirdInsert = newMap.Insert(endPair).first;

			Assert::IsTrue(firstInsert != secondInsert);
			Assert::IsTrue(firstInsert != thirdInsert);
			Assert::IsTrue(thirdInsert != secondInsert);

			firstInsert++;

			Assert::IsTrue(firstInsert != secondInsert);
			Assert::IsFalse(firstInsert != thirdInsert);
			Assert::IsTrue(thirdInsert != secondInsert);

			firstInsert++;
			thirdInsert++;
			Assert::IsFalse(firstInsert != secondInsert);
			Assert::IsFalse(firstInsert != thirdInsert);
			Assert::IsFalse(thirdInsert != secondInsert);

			HashMap<uint16_t, size_t>::Iterator defaultIterator;
			Assert::IsTrue(defaultIterator != secondInsert);
			Assert::IsTrue(defaultIterator != thirdInsert);
			Assert::IsTrue(defaultIterator != firstInsert);
		}

		TEST_METHOD(ConstIteratorInEquality)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));
			std::pair<uint16_t, size_t> middlePair(static_cast<uint16_t>(2), static_cast<size_t>(3));
			std::pair<uint16_t, size_t> endPair(static_cast<uint16_t>(4), static_cast<size_t>(5));

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto first = newMap.cbegin();
			auto second = newMap.cbegin();
			auto third = newMap.cbegin();

			second++;
			third++;
			third++;
			Assert::IsTrue(first != second);
			Assert::IsTrue(first != third);
			Assert::IsTrue(third != second);

			first++;
			Assert::IsFalse(first != second);
			Assert::IsTrue(first != third);
			Assert::IsTrue(third != second);

			first++;
			second++;
			Assert::IsFalse(first != second);
			Assert::IsFalse(first != third);
			Assert::IsFalse(third != second);

			HashMap<uint16_t, size_t>::ConstIterator defaultIterator;
			Assert::IsTrue(defaultIterator != second);
			Assert::IsTrue(defaultIterator != third);
			Assert::IsTrue(defaultIterator != first);
		}

		TEST_METHOD(IteratorAssignment)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.

			HashMap<uint16_t, size_t>::Iterator definedIterator = newMap.begin();
			HashMap<uint16_t, size_t>::Iterator defaultIterator;

			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {*defaultIterator;  });
			Assert::IsFalse(defaultIterator == definedIterator);

			defaultIterator = definedIterator;
			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::AreEqual((* defaultIterator).second, static_cast<size_t>(1));
			Assert::IsTrue(defaultIterator == definedIterator);
		}

		TEST_METHOD(ConstIteratorAssignment)
		{
			HashMap<uint16_t, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<uint16_t, size_t> frontPair(static_cast<uint16_t>(0), static_cast<size_t>(1));

			newMap.Insert(frontPair); //This will insert a default value of size_t with the uint16_t key 0.

			HashMap<uint16_t, size_t>::ConstIterator definedIterator = newMap.cbegin();
			HashMap<uint16_t, size_t>::ConstIterator defaultIterator;

			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {*defaultIterator;  });
			Assert::IsFalse(defaultIterator == definedIterator);

			defaultIterator = definedIterator;
			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::AreEqual((* defaultIterator).second, static_cast<size_t>(1));
			Assert::IsTrue(defaultIterator == definedIterator);
		}
		//Foo tests
		TEST_METHOD(FooConstructor)
		{
			Assert::ExpectException<std::runtime_error>([]() {HashMap<Foo, size_t, HashFunctor<Foo>> newMap(0);  });
			Assert::ExpectException<std::runtime_error>([]() {HashMap<Foo, size_t, HashFunctor<Foo>> newMap(1);  }); //The HashMap should at least have 2 sections

			HashMap<Foo, size_t, HashFunctor<Foo>> newMap; //You can call constructor with or without size argument
			HashMap<Foo, size_t, HashFunctor<Foo>> specifiedMap(15);
		}

		TEST_METHOD(FooInsert)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;

			HashMap<Foo, size_t, HashFunctor<Foo>>::Iterator newIterator;
			std::pair <Foo, size_t> keyValues(Foo(25), size_t(25));
			auto result = newMap.Insert(keyValues);

			Assert::AreEqual(result.second, true); //An insert did occur!
			Assert::AreEqual((* result.first).second, size_t(25)); //The correct element is returned.

			auto newResult = newMap.Insert(keyValues);
			Assert::AreEqual(newResult.second, false); //An insert did not occur!
			Assert::AreEqual((* newResult.first).second, size_t(25)); //The correct element is returned.

			keyValues.first = Foo(26);
			keyValues.second = size_t(26);
			auto successfulInsertResult = newMap.Insert(keyValues);
			Assert::AreEqual(successfulInsertResult.second, true); //An insert did occur!
			Assert::AreEqual((* successfulInsertResult.first).second, size_t(26)); //The correct element is returned.

			Assert::AreEqual((* successfulInsertResult.first).second, (* newMap.begin()).second);

			++successfulInsertResult.first;
			Assert::AreEqual((* successfulInsertResult.first).second, (* result.first).second); //The increment was successful, showing that the insertion did occur in the right order!
		}

		TEST_METHOD(FooFind)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;

			HashMap<Foo, size_t, HashFunctor<Foo>>::Iterator newIterator;
			std::pair <Foo, size_t> keyValues(Foo(25), size_t(26));
			std::pair <Foo, size_t> alternateValues(Foo(26), size_t(25));

			auto result = newMap.Insert(keyValues);

			Assert::AreEqual((* (newMap.Find(keyValues.first))).second, (* result.first).second); //The element was properly found.
			HashMap<Foo, size_t>::Iterator failedIterator = newMap.Find(Foo(26));

			Assert::ExpectException<std::runtime_error>([&failedIterator]() {(* failedIterator).second;  }); //An iterator is returned, but it is associated to null value. The element was not found since it hasn't been added.

			result = newMap.Insert(alternateValues);
			Assert::AreEqual((* (newMap.Find(alternateValues.first))).second, (* result.first).second); //The element was properly found.

			failedIterator = newMap.Find(Foo(26)); //Now, this find will work!
			Assert::AreEqual((* failedIterator).second, size_t(25));
		}

		TEST_METHOD(FooHashmapIndex)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			auto dataReference = newMap[Foo(0)];

			Assert::AreEqual(dataReference, newMap[Foo(0)]); //Now, it will find the value with that key
			auto newDataReference = newMap[Foo(1)];

			Assert::AreEqual(newDataReference, dataReference); //Both were default constructed, so the values are the same.
			Assert::AreEqual((* (newMap.Find(Foo(0)))).second, (* (newMap.Find(Foo(1)))).second);

			std::pair<Foo, size_t> value0(Foo{ Foo(0) }, size_t{ 0 });
			std::pair<Foo, size_t> value1(Foo{ Foo(1) }, size_t{ 0 });

			HashMap<Foo, size_t>::Iterator value0Iterator = newMap.Insert(value0).first;
			HashMap<Foo, size_t>::Iterator value1Iterator = newMap.Insert(value1).first;

			Assert::AreEqual((* value0Iterator).second, (* value1Iterator).second); //They are always considered equal by data value
		}

		TEST_METHOD(FooSize)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			auto dataReference = newMap[Foo(0)];
			dataReference = newMap[Foo(1)];
			Assert::AreEqual(newMap.Size(), size_t{ 2 });

			newMap.Remove(Foo(2));
			Assert::AreEqual(newMap.Size(), size_t{ 2 });

			newMap.Remove(Foo(1));
			Assert::AreEqual(newMap.Size(), size_t{ 1 });

			newMap.Remove(Foo(1));
			Assert::AreEqual(newMap.Size(), size_t{ 1 }); //The same element cannot be removed again, it is already absent from the HashMap

			newMap.Clear();
			Assert::AreEqual(newMap.Size(), size_t{ 0 });

	//		Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.begin();  });
		}

		TEST_METHOD(FooBegin)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(0));
			std::pair<Foo, size_t> middlePair(Foo(1), static_cast<size_t>(1));
			std::pair<Foo, size_t> endPair(Foo(2), static_cast<size_t>(2));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			Assert::AreEqual((* (newMap.begin())).second, size_t(0));
			newMap.Remove(Foo(0));
			Assert::AreEqual((* (newMap.begin())).second, size_t(2));
			newMap.Remove(Foo(1));
			Assert::AreEqual((* (newMap.begin())).second, size_t(2));
			newMap.Remove(Foo(2));
		}

		TEST_METHOD(FooEnd)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(0));
			std::pair<Foo, size_t> middlePair(Foo(2), static_cast<size_t>(1));
			std::pair<Foo, size_t> endPair(Foo(1), static_cast<size_t>(2));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			++backReference.first;

			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.end();  });
			Assert::ExpectException<std::runtime_error>([&backReference]() {*backReference.first;  }); //Back will send an exception when dereferenced. It returns a pointer past the ending element of the final SList.
		}

		TEST_METHOD(FooCBegin)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.cbegin();  });

			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(0));
			std::pair<Foo, size_t> middlePair(Foo(2), static_cast<size_t>(1));
			std::pair<Foo, size_t> endPair(Foo(1), static_cast<size_t>(2));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			Assert::AreEqual((* (newMap.cbegin())).second, size_t(0));
			newMap.Remove(Foo(0));
			Assert::AreEqual((* (newMap.cbegin())).second, size_t(1));
			newMap.Remove(Foo(2));
			Assert::AreEqual((* (newMap.cbegin())).second, size_t(2));
			newMap.Remove(Foo(1));
		}

		TEST_METHOD(FooCEnd)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(0));
			std::pair<Foo, size_t> middlePair(Foo(2), static_cast<size_t>(1));
			std::pair<Foo, size_t> endPair(Foo(1), static_cast<size_t>(2));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			const HashMap<Foo, size_t> copiedMap = newMap;
			auto backElement = copiedMap.cbegin();
			backElement++;
			backElement++;
			backElement++;

			Assert::ExpectException<std::runtime_error>([&copiedMap]() {*copiedMap.cend();  });
			Assert::ExpectException<std::runtime_error>([&backElement]() {*backElement;  });
		}

		TEST_METHOD(FooAt)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(2), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(1), static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			Assert::AreEqual(newMap.At(Foo(0)), static_cast<size_t>(1));
			Assert::AreEqual(newMap.At(Foo(2)), static_cast<size_t>(3));
			Assert::AreEqual(newMap.At(Foo(1)), static_cast<size_t>(5));
		}

		TEST_METHOD(FooAtConst)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(2), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(1), static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			const HashMap<Foo, size_t> copiedMap = newMap;

			Assert::AreEqual(copiedMap.At(Foo(0)), static_cast<size_t>(1));
			Assert::AreEqual(copiedMap.At(Foo(2)), static_cast<size_t>(3));
			Assert::AreEqual(copiedMap.At(Foo(1)), static_cast<size_t>(5));
		}

		TEST_METHOD(FooDestructor)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(2), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(1), static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);
			Assert::AreEqual(newMap.Size(), size_t(3));

			Assert::IsFalse(newMap.Insert(frontPair).second);
			Assert::IsFalse(newMap.Insert(middlePair).second);
			Assert::IsFalse(newMap.Insert(endPair).second);

			newMap.~HashMap<Foo, size_t>();
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
		}

		TEST_METHOD(FooContainsKey)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::IsFalse(newMap.ContainsKey(Foo(0)));

			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			newMap.Insert(frontPair);
			Assert::IsTrue(newMap.ContainsKey(Foo(0)));
			Assert::IsFalse(newMap.ContainsKey(Foo(2)));

			std::pair<Foo, size_t> middlePair(Foo(2), static_cast<size_t>(3));
			newMap.Insert(middlePair);
			Assert::IsTrue(newMap.ContainsKey(Foo(2)));
			Assert::IsFalse(newMap.ContainsKey(Foo(4)));

			std::pair<Foo, size_t> endPair(Foo(4), static_cast<size_t>(5));;
			newMap.Insert(endPair);
			Assert::IsTrue(newMap.ContainsKey(Foo(4)));
		}

		TEST_METHOD(FooRemove)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(0));
			std::pair<Foo, size_t> middlePair(Foo(2), static_cast<size_t>(1));
			std::pair<Foo, size_t> endPair(Foo(1), static_cast<size_t>(2));;

			newMap.Insert(frontPair); 
			newMap.Insert(middlePair);
			newMap.Insert(endPair);
			Assert::AreEqual(newMap.Size(), size_t(3));

			Assert::AreEqual((* newMap.Find(Foo(2))).second, size_t(1));
			newMap.Remove(Foo(2));
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find(Foo(2));  });

			Assert::AreEqual((*(newMap.begin())).second, size_t(0));
			newMap.Remove(Foo(0));
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find(Foo(0));  });

			Assert::AreEqual((*(newMap.begin())).second, size_t(2));
			newMap.Remove(Foo(1));
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find(Foo(1));  });

			//Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.begin(); });
		}

		TEST_METHOD(FooClear)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(2), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(4), static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);
			Assert::AreEqual(newMap.Size(), size_t(3));

			Assert::IsFalse(newMap.Insert(frontPair).second);
			Assert::IsFalse(newMap.Insert(middlePair).second);
			Assert::IsFalse(newMap.Insert(endPair).second);

			newMap.Clear();
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
//			Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.begin(); });//Begin is empty

			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find(Foo(0));  }); //Previous elements can't be found.
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find(Foo(2));  });
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find(Foo(4));  });
		}

		//Iterator and ConstIterator tests
		TEST_METHOD(FooIteratorConstructor)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newHashmap(5);

			newHashmap.Insert(std::pair<Foo, size_t>(Foo(0), static_cast<size_t>(1)));
			newHashmap.Insert(std::pair<Foo, size_t>(Foo(2), static_cast<size_t>(3)));
			newHashmap.Insert(std::pair<Foo, size_t>(Foo(4), static_cast<size_t>(5)));

			HashMap<Foo, size_t>::Iterator defaultIterator;
			HashMap<Foo, size_t>::Iterator definedIterator = newHashmap.begin();
			Assert::AreEqual((*newHashmap.Find(Foo(0))).second, static_cast<size_t>(1));

			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {*defaultIterator;  });
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {defaultIterator++;  });
		}

		TEST_METHOD(FooConstIteratorConstructor)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newHashmap(5);

			newHashmap.Insert(std::pair<Foo, size_t>(Foo(0), static_cast<size_t>(1)));
			newHashmap.Insert(std::pair<Foo, size_t>(Foo(2), static_cast<size_t>(3)));
			newHashmap.Insert(std::pair<Foo, size_t>(Foo(4), static_cast<size_t>(5)));

			HashMap<Foo, size_t>::ConstIterator defaultIterator;
			HashMap<Foo, size_t>::ConstIterator definedIterator = newHashmap.cbegin();
			Assert::AreEqual((*newHashmap.Find(Foo(0))).second, static_cast<size_t>(1));

			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {*defaultIterator;  }); //Default constructed has null value, defined has start of hashmap
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {defaultIterator++;  });
		}

		TEST_METHOD(FooIteratorCopyConstructor)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newHashmap(5);

			newHashmap[Foo(0)]; //Create new default constructed element with key Foo(0)
			newHashmap[Foo(1)]; //Create new default constructed element with key Foo(1)
			newHashmap[Foo(2)]; //Create new default constructed element with key Foo(2)

			HashMap<Foo, size_t>::Iterator definedIterator = newHashmap.begin();
			Assert::AreEqual((*definedIterator).second, newHashmap[Foo(0)]);
		}
		TEST_METHOD(FooConstIteratorCopyConstructor)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newHashmap(5);

			newHashmap[Foo(0)];
			newHashmap[Foo(1)];
			newHashmap[Foo(2)];

			HashMap<Foo, size_t>::ConstIterator definedIterator = newHashmap.cbegin();
			Assert::AreEqual((*definedIterator).second, newHashmap[Foo(0)]);
		}

		TEST_METHOD(FooIteratorDestructor)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(2), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(1), static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			Assert::AreEqual((*(frontReference.first)).second, static_cast<size_t>(1));
			frontReference.first.~Iterator();
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference.first;  });

			Assert::AreEqual((*(middleReference.first)).second, static_cast<size_t>(3));
			middleReference.first.~Iterator();
			Assert::ExpectException<std::runtime_error>([&middleReference]() {*middleReference.first;  });

			Assert::AreEqual((*(backReference.first)).second, static_cast<size_t>(5));
			backReference.first.~Iterator();
			Assert::ExpectException<std::runtime_error>([&backReference]() {*backReference.first;  });
		}

		TEST_METHOD(FooConstIteratorDestructor)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(2), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(1), static_cast<size_t>(5));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto frontReference = newMap.cbegin();
			auto middleReference = newMap.cbegin();
			middleReference++;
			auto backReference = newMap.cbegin();
			backReference++;
			backReference++;

			Assert::AreEqual((* frontReference).second, static_cast<size_t>(1));
			frontReference.~ConstIterator();
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });

			Assert::AreEqual((*middleReference).second, static_cast<size_t>(3));
			middleReference.~ConstIterator();
			Assert::ExpectException<std::runtime_error>([&middleReference]() {*middleReference;  });

			Assert::AreEqual((* backReference).second, static_cast<size_t>(5));
			backReference.~ConstIterator();
			Assert::ExpectException<std::runtime_error>([&backReference]() {*backReference;  });
		}

		TEST_METHOD(FooIteratorPreIncrement)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(1), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(2), static_cast<size_t>(5));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto frontReference = newMap.begin();
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(1));

			++frontReference;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(5));

			++frontReference;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(3));

			++frontReference;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {(* frontReference).second;  });
			++frontReference;
		}

		TEST_METHOD(FooConstIteratorPreIncrement)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(1), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(2), static_cast<size_t>(5));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto frontReference = newMap.cbegin();
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(1));

			++frontReference;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(5));

			++frontReference;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(3));

			++frontReference;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });

			++frontReference;
		}

		TEST_METHOD(FooIteratorPostIncrement)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(1), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(2), static_cast<size_t>(5));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto frontReference = newMap.begin();
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(1));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(5));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(3));

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });

			frontReference++;
		}

		TEST_METHOD(FooConstIteratorPostIncrement)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(4), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(2), static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto frontReference = newMap.cbegin();
			Assert::AreEqual((*frontReference).second, static_cast<size_t>(1));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(5));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(3));

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });

			frontReference++;
		}

		TEST_METHOD(FooIteratorDereference)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(4), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(2), static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			HashMap<Foo, size_t>::Iterator defaultReference;
			Assert::ExpectException<std::runtime_error>([&defaultReference]() {*defaultReference;  });

			auto frontReference = newMap.begin();
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(1));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(5));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(3));

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });
		}

		TEST_METHOD(FooConstIteratorDereference)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(4), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(2), static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			HashMap<Foo, size_t>::ConstIterator defaultReference;
			Assert::ExpectException<std::runtime_error>([&defaultReference]() {*defaultReference;  });

			HashMap<Foo, size_t>::ConstIterator frontReference = newMap.cbegin();
			Assert::AreEqual((*frontReference).second, static_cast<size_t>(1));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(5));

			frontReference++;
			Assert::AreEqual((* frontReference).second, static_cast<size_t>(3));

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });
		}

		TEST_METHOD(FooIteratorArrowDereference)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(4), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(2), static_cast<size_t>(5));

			auto traverser = newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto firstPair = *(&traverser)->first;
			Assert::AreEqual(firstPair.second, static_cast<size_t>(1));

			*(&traverser)->first++;
			auto secondPair = *(&traverser)->first;
			Assert::AreEqual(secondPair.second, size_t(5));

			*(&traverser)->first++;
			auto thirdPair = *(&traverser)->first;
			Assert::AreEqual(thirdPair.second, size_t(3));

			*(&traverser)->first++;
			Assert::ExpectException<std::runtime_error>([&traverser]() {*(&traverser)->first;  });
		}

		TEST_METHOD(FooConstIteratorArrowDereference)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(4), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(2), static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			std::pair<HashMap<Foo, size_t>::ConstIterator, bool> traverser(newMap.cbegin(), true);

			auto pair = *(&traverser)->first;

			Assert::AreEqual(pair.second, size_t(1));

			traverser.first++;
			auto secondPair = *(&traverser)->first;
			Assert::AreEqual(secondPair.second, size_t(5));

			traverser.first++;
			auto thirdPair = *(&traverser)->first;
			Assert::AreEqual(thirdPair.second, size_t(3));

			traverser.first++;
			Assert::ExpectException<std::runtime_error>([&traverser]() {*(&traverser)->first;  });
		}

		TEST_METHOD(FooIteratorEquality)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(4), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(2), static_cast<size_t>(5));

			auto firstInsert = newMap.Insert(frontPair).first;
			auto secondInsert = newMap.Insert(middlePair).first;
			auto thirdInsert = newMap.Insert(endPair).first;

			Assert::IsFalse(firstInsert == secondInsert);
			Assert::IsFalse(firstInsert == thirdInsert);
			Assert::IsFalse(thirdInsert == secondInsert);

			firstInsert++;

			Assert::IsFalse(firstInsert == secondInsert);
			Assert::IsTrue(firstInsert == thirdInsert);
			Assert::IsFalse(thirdInsert == secondInsert);

			firstInsert++;
			thirdInsert++;
			Assert::IsTrue(firstInsert == secondInsert);
			Assert::IsTrue(firstInsert == thirdInsert);
			Assert::IsTrue(thirdInsert == secondInsert);

			HashMap<Foo, size_t>::Iterator defaultIterator;
			Assert::IsFalse(defaultIterator == secondInsert);
			Assert::IsFalse(defaultIterator == thirdInsert);
			Assert::IsFalse(defaultIterator == firstInsert);
		}

		TEST_METHOD(FooConstIteratorEquality)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(4), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(2), static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto first = newMap.cbegin();
			auto second = newMap.cbegin();
			auto third = newMap.cbegin();

			second++;
			third++;
			third++;

			Assert::IsFalse(first == second);
			Assert::IsFalse(first == third);
			Assert::IsFalse(third == second);

			first++;

			Assert::IsTrue(first == second);
			Assert::IsFalse(first == third);
			Assert::IsFalse(third == second);

			first++;
			second++;
			Assert::IsTrue(first == second);
			Assert::IsTrue(first == third);
			Assert::IsTrue(third == second);

			HashMap<Foo, size_t>::ConstIterator defaultIterator;
			Assert::IsFalse(defaultIterator == second);
			Assert::IsFalse(defaultIterator == third);
			Assert::IsFalse(defaultIterator == first);
		}

		TEST_METHOD(FooIteratorInEquality)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(4), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(2), static_cast<size_t>(5));

			auto firstInsert = newMap.Insert(frontPair).first;
			auto secondInsert = newMap.Insert(middlePair).first;
			auto thirdInsert = newMap.Insert(endPair).first;

			Assert::IsTrue(firstInsert != secondInsert);
			Assert::IsTrue(firstInsert != thirdInsert);
			Assert::IsTrue(thirdInsert != secondInsert);

			firstInsert++;

			Assert::IsTrue(firstInsert != secondInsert);
			Assert::IsFalse(firstInsert != thirdInsert);
			Assert::IsTrue(thirdInsert != secondInsert);

			firstInsert++;
			thirdInsert++;
			Assert::IsFalse(firstInsert != secondInsert);
			Assert::IsFalse(firstInsert != thirdInsert);
			Assert::IsFalse(thirdInsert != secondInsert);

			HashMap<Foo, size_t>::Iterator defaultIterator;
			Assert::IsTrue(defaultIterator != secondInsert);
			Assert::IsTrue(defaultIterator != thirdInsert);
			Assert::IsTrue(defaultIterator != firstInsert);
		}

		TEST_METHOD(FooConstIteratorInEquality)
		{
			HashMap<Foo, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));
			std::pair<Foo, size_t> middlePair(Foo(4), static_cast<size_t>(3));
			std::pair<Foo, size_t> endPair(Foo(2), static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto first = newMap.cbegin();
			auto second = newMap.cbegin();
			auto third = newMap.cbegin();

			second++;
			third++;
			third++;
			Assert::IsTrue(first != second);
			Assert::IsTrue(first != third);
			Assert::IsTrue(third != second);

			first++;
			Assert::IsFalse(first != second);
			Assert::IsTrue(first != third);
			Assert::IsTrue(third != second);

			first++;
			second++;
			Assert::IsFalse(first != second);
			Assert::IsFalse(first != third);
			Assert::IsFalse(third != second);

			HashMap<Foo, size_t>::ConstIterator defaultIterator;
			Assert::IsTrue(defaultIterator != second);
			Assert::IsTrue(defaultIterator != third);
			Assert::IsTrue(defaultIterator != first);
		}

		TEST_METHOD(FooIteratorAssignment)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));

			newMap.Insert(frontPair);

			HashMap<Foo, size_t>::Iterator definedIterator = newMap.begin();
			HashMap<Foo, size_t>::Iterator defaultIterator;

			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {*defaultIterator;  });
			Assert::IsFalse(defaultIterator == definedIterator);

			defaultIterator = definedIterator;
			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::AreEqual((* defaultIterator).second, static_cast<size_t>(1));
			Assert::IsTrue(defaultIterator == definedIterator);
		}

		TEST_METHOD(FooConstIteratorAssignment)
		{
			HashMap<Foo, size_t, HashFunctor<Foo>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<Foo, size_t> frontPair(Foo(0), static_cast<size_t>(1));

			newMap.Insert(frontPair);

			HashMap<Foo, size_t>::ConstIterator definedIterator = newMap.cbegin();
			HashMap<Foo, size_t>::ConstIterator defaultIterator;

			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {*defaultIterator;  });
			Assert::IsFalse(defaultIterator == definedIterator);

			defaultIterator = definedIterator;
			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::AreEqual((* defaultIterator).second, static_cast<size_t>(1));
			Assert::IsTrue(defaultIterator == definedIterator);
		}
		//String tests
		TEST_METHOD(StringConstructor)
		{
			Assert::ExpectException<std::runtime_error>([]() {HashMap<std::string, size_t, HashFunctor<std::string>> newMap(0);  });
			Assert::ExpectException<std::runtime_error>([]() {HashMap<std::string, size_t, HashFunctor<std::string>> newMap(1);  }); //The HashMap should at least have 2 sections

			HashMap<std::string, size_t> newMap; //You can call constructor with or without size argument
			HashMap<std::string, size_t> specifiedMap(15);
		}

		TEST_METHOD(StringInsert)
		{
			HashMap<std::string, size_t> newMap;

			HashMap<std::string, size_t, HashFunctor<std::string>>::Iterator newIterator;
			std::pair <std::string, size_t> keyValues("CPP", size_t(25));
			auto result = newMap.Insert(keyValues);

			Assert::AreEqual(result.second, true); //An insert did occur!
			Assert::AreEqual((* result.first).second, size_t(25)); //The correct element is returned.

			auto newResult = newMap.Insert(keyValues);
			Assert::AreEqual(newResult.second, false); //An insert did not occur!
			Assert::AreEqual((* newResult.first).second, size_t(25)); //The correct element is returned.

			keyValues.first = "CPlusPlus";
			keyValues.second = size_t(26);
			auto successfulInsertResult = newMap.Insert(keyValues);
			Assert::AreEqual(successfulInsertResult.second, true); //An insert did occur!
			Assert::AreEqual((* successfulInsertResult.first).second, size_t(26)); //The correct element is returned.

			Assert::AreEqual((* result.first).second, (* newMap.begin()).second);

			++result.first;
			Assert::AreEqual((* successfulInsertResult.first).second, (* result.first).second); //The increment was successful, showing that the insertion did occur in the right order!
		}

		TEST_METHOD(StringFind)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;

			HashMap<std::string, size_t, HashFunctor<std::string>>::Iterator newIterator;
			std::pair <std::string, size_t> keyValues("Apples", size_t(26));
			std::pair <std::string, size_t> alternateValues("Oranges", size_t(25));

			auto result = newMap.Insert(keyValues);

			Assert::AreEqual((* (newMap.Find(keyValues.first))).second, (*result.first).second); //The element was properly found.
			HashMap<std::string, size_t>::Iterator failedIterator = newMap.Find("Oranges");

			Assert::ExpectException<std::runtime_error>([&failedIterator]() {* failedIterator;  }); //An iterator is returned, but it is associated to null value. The element was not found since it hasn't been added.

			result = newMap.Insert(alternateValues);
			Assert::AreEqual((* (newMap.Find(alternateValues.first))).second, (*result.first).second); //The element was properly found.

			failedIterator = newMap.Find("Oranges"); //Now, this find will work!
			Assert::AreEqual((* failedIterator).second, size_t(25));
		}

		TEST_METHOD(StringIndex)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			auto dataReference = newMap["Apples"];

			Assert::AreEqual(dataReference, newMap["Apples"]); //Now, it will find the value with that key
			auto newDataReference = newMap["Oranges"];

			Assert::AreEqual(newDataReference, dataReference); //Both were default constructed, so the values are the same.
			Assert::AreEqual((* (newMap.Find("Apples"))).second, (* (newMap.Find("Oranges"))).second);

			std::pair<std::string, size_t> value0("Apples", size_t{0});
			std::pair<std::string, size_t> value1("Oranges", size_t{0});

			HashMap<std::string, size_t>::Iterator value0Iterator = newMap.Insert(value0).first;
			HashMap<std::string, size_t>::Iterator value1Iterator = newMap.Insert(value1).first;

			Assert::AreEqual((* value0Iterator).second, (* value1Iterator).second); //They are always considered equal by data value
		}

		TEST_METHOD(StringSize)
		{
			HashMap<std::string, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			auto dataReference = newMap["Apples"];
			dataReference = newMap["Oranges"];
			Assert::AreEqual(newMap.Size(), size_t{ 2 });

			newMap.Remove("Pears");
			Assert::AreEqual(newMap.Size(), size_t{ 2 });

			newMap.Remove("Oranges");
			Assert::AreEqual(newMap.Size(), size_t{ 1 });

			newMap.Remove("Oranges");
			Assert::AreEqual(newMap.Size(), size_t{ 1 }); //The same element cannot be removed again, it is already absent from the HashMap

			newMap.Clear();
			Assert::AreEqual(newMap.Size(), size_t{ 0 });

//			Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.begin();  });
		}

		TEST_METHOD(StringBegin)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(0));
			std::pair<std::string, size_t> middlePair("Apples", static_cast<size_t>(1));
			std::pair<std::string, size_t> endPair("Pears", static_cast<size_t>(2));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			Assert::AreEqual((*newMap.Find("Oranges")).second, size_t(0));
			newMap.Remove("Oranges");
			Assert::AreEqual((*newMap.Find("Apples")).second, size_t(1));
			newMap.Remove("Apples");
			Assert::AreEqual((*newMap.Find("Pears")).second, size_t(2));
			newMap.Remove("Pears");
		}

		TEST_METHOD(StringEnd)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(0));
			std::pair<std::string, size_t> middlePair("Apples", static_cast<size_t>(1));
			std::pair<std::string, size_t> endPair("Pears", static_cast<size_t>(2));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			++backReference.first;

			Assert::ExpectException<std::runtime_error>([&newMap]() {(* newMap.end()).second;  });
			Assert::ExpectException<std::runtime_error>([&backReference]() {(* backReference.first).second;  }); //Back will send an exception when dereferenced. It returns a pointer past the ending element of the final SList.
		}

		TEST_METHOD(StringCBegin)
		{
			HashMap<std::string, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.cbegin();  });

			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(0));
			std::pair<std::string, size_t> middlePair("Apples", static_cast<size_t>(1));
			std::pair<std::string, size_t> endPair("Pears", static_cast<size_t>(2));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			Assert::AreEqual((*newMap.Find("Oranges")).second, size_t(0));
			newMap.Remove("Oranges");
			Assert::AreEqual((*newMap.Find("Apples")).second, size_t(1));
			newMap.Remove("Apples");
			Assert::AreEqual((*newMap.Find("Pears")).second, size_t(2));
			newMap.Remove("Pears");
		}

		TEST_METHOD(StringCEnd)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(0));
			std::pair<std::string, size_t> middlePair("Pears", static_cast<size_t>(1));
			std::pair<std::string, size_t> endPair("Apples", static_cast<size_t>(2));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			const HashMap<std::string, size_t> copiedMap = newMap;
			auto backElement = copiedMap.cbegin();
			backElement++;
			backElement++;
			backElement++;

			Assert::ExpectException<std::runtime_error>([&copiedMap]() {*copiedMap.cend();  });
			Assert::ExpectException<std::runtime_error>([&backElement]() {*backElement;  });
		}

		TEST_METHOD(StringAt)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Apples", static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			Assert::AreEqual(newMap.At("Oranges"), static_cast<size_t>(1));
			Assert::AreEqual(newMap.At("Pears"), static_cast<size_t>(3));
			Assert::AreEqual(newMap.At("Apples"), static_cast<size_t>(5));

			Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.At("Bananas"); });
			Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.At("Cherries"); });
			Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.At("Peaches"); });
		}

		TEST_METHOD(StringAtConst)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Apples", static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			const HashMap<std::string, size_t> copiedMap = newMap;

			Assert::AreEqual(copiedMap.At("Oranges"), static_cast<size_t>(1));
			Assert::AreEqual(copiedMap.At("Pears"), static_cast<size_t>(3));
			Assert::AreEqual(copiedMap.At("Apples"), static_cast<size_t>(5));

			Assert::ExpectException<std::runtime_error>([&copiedMap]() {copiedMap.At("Bananas"); });
			Assert::ExpectException<std::runtime_error>([&copiedMap]() {copiedMap.At("Cherries"); });
			Assert::ExpectException<std::runtime_error>([&copiedMap]() {copiedMap.At("Peaches"); });
		}

		TEST_METHOD(StringDestructor)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Apples", static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);
			Assert::AreEqual(newMap.Size(), size_t(3));

			Assert::IsFalse(newMap.Insert(frontPair).second);
			Assert::IsFalse(newMap.Insert(middlePair).second);
			Assert::IsFalse(newMap.Insert(endPair).second);
		}

		TEST_METHOD(StringContainsKey)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::IsFalse(newMap.ContainsKey("Oranges"));

			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			newMap.Insert(frontPair);
			Assert::IsTrue(newMap.ContainsKey("Oranges"));
			Assert::IsFalse(newMap.ContainsKey("Pears"));

			std::pair<std::string, size_t> middlePair("Pears", static_cast<size_t>(3));
			newMap.Insert(middlePair);
			Assert::IsTrue(newMap.ContainsKey("Pears"));
			Assert::IsFalse(newMap.ContainsKey("Apples"));

			std::pair<std::string, size_t> endPair("Apples", static_cast<size_t>(5));
			newMap.Insert(endPair);
			Assert::IsTrue(newMap.ContainsKey("Apples"));
		}

		TEST_METHOD(StringRemove)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(0));
			std::pair<std::string, size_t> middlePair("Pears", static_cast<size_t>(1));
			std::pair<std::string, size_t> endPair("Apples", static_cast<size_t>(2));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);
			Assert::AreEqual(newMap.Size(), size_t(3));

			auto first = newMap.cbegin();
			auto second = newMap.cbegin();
			auto third = newMap.cbegin();

			second++;
			third++;
			third++;

			Assert::AreEqual((* newMap.Find("Pears")).second, size_t(1));
			newMap.Remove("Pears");
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find("Pears");  });

			Assert::AreEqual((*newMap.Find("Oranges")).second, size_t(0));
			newMap.Remove("Oranges");
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find("Oranges");  });

			Assert::AreEqual((*newMap.Find("Apples")).second, size_t(2));
			newMap.Remove("Apples");
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find("Apples");  });

		//	Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.begin(); });
		}

		TEST_METHOD(StringClear)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Apples", static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);
			Assert::AreEqual(newMap.Size(), size_t(3));

			Assert::IsFalse(newMap.Insert(frontPair).second);
			Assert::IsFalse(newMap.Insert(middlePair).second);
			Assert::IsFalse(newMap.Insert(endPair).second);

			newMap.Clear();
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			//Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.begin(); });//Begin is empty

			Assert::ExpectException<std::runtime_error>([&newMap]() {(* newMap.Find("Oranges")).second;  }); //Previous elements can't be found.
			Assert::ExpectException<std::runtime_error>([&newMap]() {(* newMap.Find("Pears")).second;  });
			Assert::ExpectException<std::runtime_error>([&newMap]() {(* newMap.Find("Apples")).second;  });
		}

		//Iterator and ConstIterator tests
		TEST_METHOD(StringIteratorConstructor)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newHashmap(5);

			newHashmap["Oranges"];
			newHashmap["Pears"];
			newHashmap["Apples"];

			HashMap<std::string, size_t>::Iterator defaultIterator;

			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {*defaultIterator;  });
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {defaultIterator++;  });
		}

		TEST_METHOD(StringConstIteratorConstructor)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newHashmap(5);

			newHashmap.Insert(std::pair<std::string, size_t>("Oranges", static_cast<size_t>(1)));
			newHashmap.Insert(std::pair<std::string, size_t>("Pears", static_cast<size_t>(3)));
			newHashmap.Insert(std::pair<std::string, size_t>("Apples", static_cast<size_t>(5)));

			HashMap<std::string, size_t>::ConstIterator defaultIterator;

			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {*defaultIterator;  }); //Default constructed has null value, defined has start of hashmap
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {defaultIterator++;  });
		}

		TEST_METHOD(StringIteratorCopyConstructor)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newHashmap(5);

			newHashmap["Oranges"];
			newHashmap["Pears"];
			newHashmap["Apples"];

			HashMap<std::string, size_t>::Iterator definedIterator = newHashmap.begin();
			Assert::AreEqual((* definedIterator).second, newHashmap["Oranges"]);
		}
		TEST_METHOD(StringConstIteratorCopyConstructor)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newHashmap(5);

			newHashmap["Oranges"];
			newHashmap["Pears"];
			newHashmap["Apples"];

			HashMap<std::string, size_t>::ConstIterator definedIterator = newHashmap.cbegin();
			Assert::AreEqual((* definedIterator).second, newHashmap["Oranges"]);
		}

		TEST_METHOD(StringIteratorDestructor)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Apples", static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			Assert::AreEqual((* frontReference.first).second, static_cast<size_t>(1));
			frontReference.first.~Iterator();
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference.first;  });

			Assert::AreEqual((* middleReference.first).second, static_cast<size_t>(3));
			middleReference.first.~Iterator();
			Assert::ExpectException<std::runtime_error>([&middleReference]() {*middleReference.first;  });

			Assert::AreEqual((* backReference.first).second, static_cast<size_t>(5));
			backReference.first.~Iterator();
			Assert::ExpectException<std::runtime_error>([&backReference]() {*backReference.first;  });
		}

		TEST_METHOD(StringConstIteratorDestructor)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Pears", static_cast<size_t>(5));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto frontReference = newMap.cbegin();
			auto middleReference = newMap.cbegin();
			middleReference++;
			auto backReference = newMap.cbegin();
			backReference++;
			backReference++;

			auto movingIterator = newMap.cbegin();

			Assert::AreEqual((* frontReference).second, (*movingIterator).second);
			frontReference.~ConstIterator();
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });
			movingIterator++;

			Assert::AreEqual((* middleReference).second, (*movingIterator).second);
			middleReference.~ConstIterator();
			Assert::ExpectException<std::runtime_error>([&middleReference]() {*middleReference;  });

			movingIterator++;
			Assert::AreEqual((* backReference).second, (*movingIterator).second);
			backReference.~ConstIterator();
			Assert::ExpectException<std::runtime_error>([&backReference]() {*backReference;  });
		}

		TEST_METHOD(StringIteratorPreIncrement)
		{
			HashMap<std::string, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Pears", static_cast<size_t>(5));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto firstPair = newMap.begin();
			auto secondPair = newMap.begin();
			auto thirdPair = newMap.begin();

			secondPair++;
			thirdPair++;
			thirdPair++;

			auto frontReference = newMap.begin();
			Assert::AreEqual((*frontReference).second, (*firstPair).second);

			++frontReference;
			Assert::AreEqual((*frontReference).second, (*secondPair).second);

			++frontReference;
			Assert::AreEqual((*frontReference).second, (*thirdPair).second);

			++frontReference;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });
			++frontReference;
		}

		TEST_METHOD(StringConstIteratorPreIncrement)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Pears", static_cast<size_t>(5));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto firstPair = newMap.begin();
			auto secondPair = newMap.begin();
			auto thirdPair = newMap.begin();

			secondPair++;
			thirdPair++;
			thirdPair++;

			auto frontReference = newMap.cbegin();
			Assert::AreEqual((* frontReference).second, (*firstPair).second);

			++frontReference;
			Assert::AreEqual((* frontReference).second, (*secondPair).second);

			++frontReference;
			Assert::AreEqual((*frontReference).second, (*thirdPair).second);

			++frontReference;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });
			++frontReference;
		}

		TEST_METHOD(StringIteratorPostIncrement)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Pears", static_cast<size_t>(5));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto first = newMap.begin();
			auto second = newMap.begin();
			auto third = newMap.begin();

			second++;
			third++;
			third++;

			auto frontReference = newMap.begin();
			Assert::AreEqual((* frontReference).second, (*first).second);

			frontReference++;
			Assert::AreEqual((* frontReference).second, (*second).second);

			frontReference++;
			Assert::AreEqual((* frontReference).second, (*third).second);

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {(* frontReference).second;  });
			frontReference++;
		}

		TEST_METHOD(StringConstIteratorPostIncrement)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Pears", static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto firstPair = newMap.begin();
			auto secondPair = newMap.begin();
			auto thirdPair = newMap.begin();

			secondPair++;
			thirdPair++;
			thirdPair++;

			auto frontReference = newMap.cbegin();
			Assert::AreEqual((*frontReference).second, (*firstPair).second);

			frontReference++;
			Assert::AreEqual((* frontReference).second, (*secondPair).second);

			frontReference++;
			Assert::AreEqual((* frontReference).second, (*thirdPair).second);

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });
			frontReference++;
		}

		TEST_METHOD(StringIteratorDereference)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t > middlePair("Apples", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Pears", static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto firstPair = newMap.begin();
			auto secondPair = newMap.begin();
			auto thirdPair = newMap.begin();

			secondPair++;
			thirdPair++;
			thirdPair++;

			HashMap<std::string, size_t>::Iterator defaultReference;
			Assert::ExpectException<std::runtime_error>([&defaultReference]() {*defaultReference;  });

			auto frontReference = newMap.begin();
			Assert::AreEqual((* frontReference).second, (*firstPair).second);

			frontReference++;
			Assert::AreEqual((*frontReference).second, (*secondPair).second);

			frontReference++;
			Assert::AreEqual((* frontReference).second, (*thirdPair).second);

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference;  });
		}

		TEST_METHOD(StringConstIteratorDereference)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Pears", static_cast<size_t>(5));
			std::pair<std::string, size_t> endPair("Apples", static_cast<size_t>(3));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			HashMap<std::string, size_t>::ConstIterator defaultReference;
			Assert::ExpectException<std::runtime_error>([&defaultReference]() {*defaultReference;  });

			HashMap<std::string, size_t>::ConstIterator frontReference = newMap.cbegin();
			Assert::AreEqual((*newMap.Find("Oranges")).second, static_cast<size_t>(1));

			frontReference++;
			Assert::AreEqual((*newMap.Find("Apples")).second, static_cast<size_t>(3));

			frontReference++;
			Assert::AreEqual((*newMap.Find("Pears")).second, static_cast<size_t>(5));

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {(* frontReference).second;  });
		}

		TEST_METHOD(StringIteratorArrowDereference)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Pears", static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto firstPair = newMap.begin();
			auto secondPair = newMap.begin();
			auto thirdPair = newMap.begin();
			auto traverser = newMap.begin();

			secondPair++;
			thirdPair++;
			thirdPair++;

			Assert::AreEqual((*traverser).second, (*firstPair).second);

			traverser++;
			Assert::AreEqual((*traverser).second, (*secondPair).second);

			traverser++;
			Assert::AreEqual((*traverser).second, (*thirdPair).second);

			traverser++;
			Assert::ExpectException<std::runtime_error>([&traverser]() {*traverser;  });
		}

		TEST_METHOD(StringConstIteratorArrowDereference)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Pears", static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			std::pair<HashMap<std::string, size_t>::ConstIterator, bool> traverser(newMap.cbegin(), true);

			Assert::AreEqual((*newMap.Find("Oranges")).second, size_t(1));

			*(&traverser)->first++;
			Assert::AreEqual((*newMap.Find("Apples")).second, size_t(3));

			traverser.first++;
			Assert::AreEqual((*newMap.Find("Pears")).second, size_t(5));

			traverser.first++;
			Assert::ExpectException<std::runtime_error>([&traverser]() {*(&traverser)->first;  });
		}

		TEST_METHOD(StringIteratorEquality)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Pears", static_cast<size_t>(5));

			auto firstInsert = newMap.Insert(frontPair).first;
			auto secondInsert = newMap.Insert(middlePair).first;
			auto thirdInsert = newMap.Insert(endPair).first;


			auto firstPair = newMap.begin();
			auto secondPair = newMap.begin();
			auto thirdPair = newMap.begin();

			secondPair++;
			thirdPair++;
			thirdPair++;

			Assert::IsFalse(firstPair == secondPair);
			Assert::IsFalse(firstPair == thirdPair);
			Assert::IsFalse(thirdPair == secondPair);

			firstPair++;

			Assert::IsTrue(firstPair == secondPair);
			Assert::IsFalse(firstPair == thirdPair);
			Assert::IsFalse(thirdPair == secondPair);

			firstPair++;
			secondPair++;
			Assert::IsTrue(firstPair == secondPair);
			Assert::IsTrue(firstPair == thirdPair);
			Assert::IsTrue(thirdPair == secondPair);

			HashMap<std::string, size_t>::Iterator defaultIterator;
			Assert::IsFalse(defaultIterator == secondInsert);
			Assert::IsFalse(defaultIterator == thirdInsert);
			Assert::IsFalse(defaultIterator == firstInsert);
		}

		TEST_METHOD(StringConstIteratorEquality)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Apples", static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto first = newMap.cbegin();
			auto second = newMap.cbegin();
			auto third = newMap.cbegin();

			second++;
			third++;
			third++;

			Assert::IsFalse(first == second);
			Assert::IsFalse(first == third);
			Assert::IsFalse(third == second);

			first++;

			Assert::IsTrue(first == second);
			Assert::IsFalse(first == third);
			Assert::IsFalse(third == second);

			first++;
			second++;
			Assert::IsTrue(first == second);
			Assert::IsTrue(first == third);
			Assert::IsTrue(third == second);

			HashMap<std::string, size_t>::ConstIterator defaultIterator;
			Assert::IsFalse(defaultIterator == second);
			Assert::IsFalse(defaultIterator == third);
			Assert::IsFalse(defaultIterator == first);
		}

		TEST_METHOD(StringIteratorInEquality)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Pears", static_cast<size_t>(5));

			auto firstInsert = newMap.Insert(frontPair).first;
			auto secondInsert = newMap.Insert(middlePair).first;
			auto thirdInsert = newMap.Insert(endPair).first;


			auto firstPair = newMap.begin();
			auto secondPair = newMap.begin();
			auto thirdPair = newMap.begin();

			secondPair++;
			thirdPair++;
			thirdPair++;

			Assert::IsTrue(firstPair != secondPair);
			Assert::IsTrue(firstPair != thirdPair);
			Assert::IsTrue(thirdPair != secondPair);

			firstPair++;

			Assert::IsFalse(firstPair != secondPair);
			Assert::IsTrue(firstPair != thirdPair);
			Assert::IsTrue(thirdPair != secondPair);

			firstPair++;
			secondPair++;
			Assert::IsFalse(firstPair != secondPair);
			Assert::IsFalse(firstPair != thirdPair);
			Assert::IsFalse(thirdPair != secondPair);

			HashMap<std::string, size_t>::Iterator defaultIterator;
			Assert::IsTrue(defaultIterator != secondInsert);
			Assert::IsTrue(defaultIterator != thirdInsert);
			Assert::IsTrue(defaultIterator != firstInsert);
		}

		TEST_METHOD(StringConstIteratorInEquality)
		{
			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<std::string, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<std::string, size_t> endPair("Apples", static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto first = newMap.cbegin();
			auto second = newMap.cbegin();
			auto third = newMap.cbegin();

			second++;
			third++;
			third++;
			Assert::IsTrue(first != second);
			Assert::IsTrue(first != third);
			Assert::IsTrue(third != second);

			first++;
			Assert::IsFalse(first != second);
			Assert::IsTrue(first != third);
			Assert::IsTrue(third != second);

			first++;
			second++;
			Assert::IsFalse(first != second);
			Assert::IsFalse(first != third);
			Assert::IsFalse(third != second);

			HashMap<std::string, size_t>::ConstIterator defaultIterator;
			Assert::IsTrue(defaultIterator != second);
			Assert::IsTrue(defaultIterator != third);
			Assert::IsTrue(defaultIterator != first);
		}

		TEST_METHOD(StringIteratorAssignment)
		{
			HashMap<std::string, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));

			newMap.Insert(frontPair);

			HashMap<std::string, size_t>::Iterator definedIterator = newMap.begin();
			HashMap<std::string, size_t>::Iterator defaultIterator;

			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {(* defaultIterator).second;  });
			Assert::IsFalse(defaultIterator == definedIterator);

			defaultIterator = definedIterator;
			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::AreEqual((* defaultIterator).second, static_cast<size_t>(1));
			Assert::IsTrue(defaultIterator == definedIterator);
		}

		TEST_METHOD(StringConstIteratorAssignment)
		{
			HashMap<std::string, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<std::string, size_t> frontPair("Oranges", static_cast<size_t>(1));

			newMap.Insert(frontPair);

			HashMap<std::string, size_t>::ConstIterator definedIterator = newMap.cbegin();
			HashMap<std::string, size_t>::ConstIterator defaultIterator;

			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {*defaultIterator;  });
			Assert::IsFalse(defaultIterator == definedIterator);

			defaultIterator = definedIterator;
			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::AreEqual((* defaultIterator).second, static_cast<size_t>(1));
			Assert::IsTrue(defaultIterator == definedIterator);
		}

		//Char* Tests
		TEST_METHOD(CharConstructor)
		{
			Assert::ExpectException<std::runtime_error>([]() {HashMap<char*, size_t, HashFunctor<char*>> newMap(0);  });
			Assert::ExpectException<std::runtime_error>([]() {HashMap<char*, size_t, HashFunctor<char*>> newMap(1);  }); //The HashMap should at least have 2 sections

			HashMap<char*, size_t> newMap; //You can call constructor with or without size argument
			HashMap<char*, size_t> specifiedMap(15);
		}

		TEST_METHOD(CharInsert)
		{
			HashMap<char*, size_t> newMap;

			HashMap<char*, size_t, HashFunctor<char*>>::Iterator newIterator;
			std::pair <char*, size_t> keyValues("CPP", size_t(25));
			auto result = newMap.Insert(keyValues);

			Assert::AreEqual(result.second, true); //An insert did occur!
			Assert::AreEqual((* result.first).second, size_t(25)); //The correct element is returned.

			auto newResult = newMap.Insert(keyValues);
			Assert::AreEqual(newResult.second, false); //An insert did not occur!
			Assert::AreEqual((* newResult.first).second, size_t(25)); //The correct element is returned.

			keyValues.first = "CPlusPlus";
			keyValues.second = size_t(26);
			auto successfulInsertResult = newMap.Insert(keyValues);
			Assert::AreEqual(successfulInsertResult.second, true); //An insert did occur!
			Assert::AreEqual((* successfulInsertResult.first).second, size_t(26)); //The correct element is returned.

			Assert::AreEqual((* result.first).second, (* newMap.begin()).second);

			++result.first;
			Assert::AreEqual((* successfulInsertResult.first).second, (* result.first).second); //The increment was successful, showing that the insertion did occur in the right order!
		}

		TEST_METHOD(CharFind)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;

			HashMap<char*, size_t, HashFunctor<char*>>::Iterator newIterator;
			std::pair <char*, size_t> keyValues("Apples", size_t(26));
			std::pair <char*, size_t> alternateValues("Oranges", size_t(25));

			auto result = newMap.Insert(keyValues);

			Assert::AreEqual((* (newMap.Find(keyValues.first))).second, (* result.first).second); //The element was properly found.
			HashMap<char*, size_t>::Iterator failedIterator = newMap.Find("Oranges");

			Assert::ExpectException<std::runtime_error>([&failedIterator]() {*failedIterator;  }); //An iterator is returned, but it is associated to null value. The element was not found since it hasn't been added.

			result = newMap.Insert(alternateValues);
			Assert::AreEqual((* (newMap.Find(alternateValues.first))).second, (* result.first).second); //The element was properly found.

			failedIterator = newMap.Find("Oranges"); //Now, this find will work!
			Assert::AreEqual((* failedIterator).second, size_t(25));
		}

		TEST_METHOD(CharIndex)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			auto dataReference = newMap["Apples"];

			Assert::AreEqual(dataReference, newMap["Apples"]); //Now, it will find the value with that key
			auto newDataReference = newMap["Oranges"];

			Assert::AreEqual(newDataReference, dataReference); //Both were default constructed, so the values are the same.
			Assert::AreEqual((* (newMap.Find("Apples"))).second, (* (newMap.Find("Oranges"))).second);

			std::pair<char*, size_t> value0("Apples", size_t{ 0 });
			std::pair<char*, size_t> value1("Oranges", size_t{ 0 });

			HashMap<char*, size_t>::Iterator value0Iterator = newMap.Insert(value0).first;
			HashMap<char*, size_t>::Iterator value1Iterator = newMap.Insert(value1).first;

			Assert::AreEqual((* value0Iterator).second, (* value1Iterator).second); //They are always considered equal by data value
		}

		TEST_METHOD(CharSize)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			auto dataReference = newMap["Apples"];
			dataReference = newMap["Oranges"];
			Assert::AreEqual(newMap.Size(), size_t{ 2 });

			newMap.Remove("Pears");
			Assert::AreEqual(newMap.Size(), size_t{ 2 });

			newMap.Remove("Oranges");
			Assert::AreEqual(newMap.Size(), size_t{ 1 });

			newMap.Remove("Oranges");
			Assert::AreEqual(newMap.Size(), size_t{ 1 }); //The same element cannot be removed again, it is already absent from the HashMap

			newMap.Clear();
			Assert::AreEqual(newMap.Size(), size_t{ 0 });

//			Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.begin();  });
		}

		TEST_METHOD(CharBegin)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(0));
			std::pair<char*, size_t> middlePair("Apples", static_cast<size_t>(1));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(2));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			Assert::AreEqual((*frontReference.first).second, size_t(0));
			newMap.Remove("Oranges");
			Assert::AreEqual((* (newMap.begin())).second, size_t(1));
			newMap.Remove("Apples");
			Assert::AreEqual((* (newMap.begin())).second, size_t(2));
			newMap.Remove("Pears");
		}

		TEST_METHOD(CharEnd)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(0));
			std::pair<char*, size_t> middlePair("Apples", static_cast<size_t>(1));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(2));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			++backReference.first;

			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.end();  });
			Assert::ExpectException<std::runtime_error>([&backReference]() {*backReference.first;  }); //Back will send an exception when dereferenced. It returns a pointer past the ending element of the final SList.
		}

		TEST_METHOD(CharCBegin)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.cbegin();  });

			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(0));
			std::pair<char*, size_t> middlePair("Apples", static_cast<size_t>(1));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(2));;

			auto frontReference = newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			Assert::AreEqual((*frontReference.first).second, size_t(0));
			newMap.Remove("Oranges");
			Assert::AreEqual((* (newMap.cbegin())).second, size_t(1));
			newMap.Remove("Apples");
			Assert::AreEqual((* (newMap.cbegin())).second, size_t(2));
			newMap.Remove("Pears");
		}

		TEST_METHOD(CharCEnd)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(0));
			std::pair<char*, size_t> middlePair("Pears", static_cast<size_t>(1));
			std::pair<char*, size_t> endPair("Apples", static_cast<size_t>(2));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			const HashMap<char*, size_t> copiedMap = newMap;
			auto backElement = copiedMap.cbegin();
			backElement++;
			backElement++;
			backElement++;

			Assert::ExpectException<std::runtime_error>([&copiedMap]() {*copiedMap.cend();  });
			Assert::ExpectException<std::runtime_error>([&backElement]() {*backElement;  });
		}

		TEST_METHOD(CharAt)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Apples", static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			Assert::AreEqual(newMap.At("Oranges"), static_cast<size_t>(1));
			Assert::AreEqual(newMap.At("Pears"), static_cast<size_t>(3));
			Assert::AreEqual(newMap.At("Apples"), static_cast<size_t>(5));

			Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.At("Bananas"); });
			Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.At("Cherries"); });
			Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.At("Peaches"); });
		}

		TEST_METHOD(CharAtConst)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Apples", static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			const HashMap<char*, size_t> copiedMap = newMap;

			Assert::AreEqual(copiedMap.At("Oranges"), static_cast<size_t>(1));
			Assert::AreEqual(copiedMap.At("Pears"), static_cast<size_t>(3));
			Assert::AreEqual(copiedMap.At("Apples"), static_cast<size_t>(5));

			Assert::ExpectException<std::runtime_error>([&copiedMap]() {copiedMap.At("Bananas"); });
			Assert::ExpectException<std::runtime_error>([&copiedMap]() {copiedMap.At("Cherries"); });
			Assert::ExpectException<std::runtime_error>([&copiedMap]() {copiedMap.At("Peaches"); });
		}

		TEST_METHOD(CharDestructor)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Apples", static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);
			Assert::AreEqual(newMap.Size(), size_t(3));

			Assert::IsFalse(newMap.Insert(frontPair).second);
			Assert::IsFalse(newMap.Insert(middlePair).second);
			Assert::IsFalse(newMap.Insert(endPair).second);

			newMap.~HashMap<char*, size_t>();
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
		}

		TEST_METHOD(CharContainsKey)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::IsFalse(newMap.ContainsKey("Oranges"));

			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			newMap.Insert(frontPair);
			Assert::IsTrue(newMap.ContainsKey("Oranges"));
			Assert::IsFalse(newMap.ContainsKey("Pears"));

			std::pair<char*, size_t> middlePair("Pears", static_cast<size_t>(3));
			newMap.Insert(middlePair);
			Assert::IsTrue(newMap.ContainsKey("Pears"));
			Assert::IsFalse(newMap.ContainsKey("Apples"));

			std::pair<char*, size_t> endPair("Apples", static_cast<size_t>(5));
			newMap.Insert(endPair);
			Assert::IsTrue(newMap.ContainsKey("Apples"));
		}

		TEST_METHOD(CharRemove)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(0));
			std::pair<char*, size_t> middlePair("Pears", static_cast<size_t>(1));
			std::pair<char*, size_t> endPair("Apples", static_cast<size_t>(2));;

			auto first = newMap.Insert(frontPair);
			auto second = newMap.Insert(middlePair);
			auto third = newMap.Insert(endPair);
			Assert::AreEqual(newMap.Size(), size_t(3));

			Assert::AreEqual((* newMap.Find("Pears")).second, (*second.first).second);
			newMap.Remove("Pears");
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find("Pears");  });

			Assert::AreEqual((*newMap.Find("Oranges")).second, (*first.first).second);
			newMap.Remove("Oranges");
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find("Oranges");  });

			Assert::AreEqual((*newMap.Find("Apples")).second, (*third.first).second);
			newMap.Remove("Apples");
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find("Apples");  });
		}

		TEST_METHOD(CharClear)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Apples", static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);
			Assert::AreEqual(newMap.Size(), size_t(3));

			Assert::IsFalse(newMap.Insert(frontPair).second);
			Assert::IsFalse(newMap.Insert(middlePair).second);
			Assert::IsFalse(newMap.Insert(endPair).second);

			newMap.Clear();
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			//Assert::ExpectException<std::runtime_error>([&newMap]() {newMap.begin(); });//Begin is empty

			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find("Oranges");  }); //Previous elements can't be found.
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find("Pears");  });
			Assert::ExpectException<std::runtime_error>([&newMap]() {*newMap.Find("Apples");  });
		}

		//Iterator and ConstIterator tests
		TEST_METHOD(CharIteratorConstructor)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newHashmap(5);

			newHashmap["Oranges"];
			newHashmap["Pears"];
			newHashmap["Apples"];

			HashMap<char*, size_t>::Iterator defaultIterator;

			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {*defaultIterator;  });
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {defaultIterator++;  });
		}

		TEST_METHOD(CharConstIteratorConstructor)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newHashmap(5);

			newHashmap.Insert(std::pair<char*, size_t>("Oranges", static_cast<size_t>(1)));
			newHashmap.Insert(std::pair<char*, size_t>("Pears", static_cast<size_t>(3)));
			newHashmap.Insert(std::pair<char*, size_t>("Apples", static_cast<size_t>(5)));

			HashMap<char*, size_t>::ConstIterator defaultIterator;

			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {*defaultIterator;  }); //Default constructed has null value, defined has start of hashmap
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {defaultIterator++;  });
		}

		TEST_METHOD(CharIteratorCopyConstructor)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newHashmap(5);

			newHashmap["Oranges"];
			newHashmap["Pears"];
			newHashmap["Apples"];

			HashMap<char*, size_t>::Iterator definedIterator = newHashmap.begin();
			Assert::AreEqual((* definedIterator).second, newHashmap["Oranges"]);
		}
		TEST_METHOD(CharConstIteratorCopyConstructor)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newHashmap(5);

			newHashmap["Oranges"];
			newHashmap["Pears"];
			newHashmap["Apples"];

			HashMap<char*, size_t>::ConstIterator definedIterator = newHashmap.cbegin();
			Assert::AreEqual((* definedIterator).second, newHashmap["Oranges"]);
		}

		TEST_METHOD(CharIteratorDestructor)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Apples", static_cast<size_t>(5));;

			auto frontReference = newMap.Insert(frontPair);
			auto middleReference = newMap.Insert(middlePair);
			auto backReference = newMap.Insert(endPair);

			Assert::AreEqual((* frontReference.first).second, static_cast<size_t>(1));
			frontReference.first.~Iterator();
			Assert::ExpectException<std::runtime_error>([&frontReference]() {*frontReference.first;  });

			Assert::AreEqual((* middleReference.first).second, static_cast<size_t>(3));
			middleReference.first.~Iterator();
			Assert::ExpectException<std::runtime_error>([&middleReference]() {*middleReference.first;  });

			Assert::AreEqual((* backReference.first).second, static_cast<size_t>(5));
			backReference.first.~Iterator();
			Assert::ExpectException<std::runtime_error>([&backReference]() {*backReference.first;  });
		}

		TEST_METHOD(CharConstIteratorDestructor)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(5));;

			auto firstReference = newMap.Insert(frontPair);
			auto secondReference = newMap.Insert(middlePair);
			auto thirdReference = newMap.Insert(endPair);

			auto frontReference = newMap.cbegin();
			auto middleReference = newMap.cbegin();
			middleReference++;
			auto backReference = newMap.cbegin();
			backReference++;
			backReference++;

			Assert::AreEqual((*firstReference.first).second, static_cast<size_t>(1));
			frontReference.~ConstIterator();
			Assert::ExpectException<std::runtime_error>([&frontReference]() {(* frontReference).second;  });

			Assert::AreEqual((*secondReference.first).second, static_cast<size_t>(3));
			middleReference.~ConstIterator();
			Assert::ExpectException<std::runtime_error>([&middleReference]() {(* middleReference).second;  });

			Assert::AreEqual((*thirdReference.first).second, static_cast<size_t>(5));
			backReference.~ConstIterator();
			Assert::ExpectException<std::runtime_error>([&backReference]() {(* backReference).second;  });
		}

		TEST_METHOD(CharIteratorPreIncrement)
		{
			HashMap<char*, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(5));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto firstPair = newMap.begin();
			auto secondPair = newMap.begin();
			auto thirdPair = newMap.begin();

			secondPair++;
			thirdPair++;
			thirdPair++;

			auto frontReference = newMap.begin();
			Assert::AreEqual((* frontReference).second, (*firstPair).second);

			++frontReference;
			Assert::AreEqual((* frontReference).second, (*secondPair).second);

			++frontReference;
			Assert::AreEqual((* frontReference).second, (*thirdPair).second);

			++frontReference;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {(* frontReference).second;  });
			++frontReference;
		}

		TEST_METHOD(CharConstIteratorPreIncrement)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(5));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto frontReference = newMap.cbegin();
			Assert::AreEqual((*frontReference).second, newMap.At((*frontReference).first));
			//Assert::AreEqual((* frontReference).second, static_cast<size_t>(1));

			++frontReference;
			Assert::AreEqual((*frontReference).second, newMap.At((*frontReference).first));
			//Assert::AreEqual((* frontReference).second, static_cast<size_t>(3));

			++frontReference;
			Assert::AreEqual((*frontReference).second, newMap.At((*frontReference).first));
			//Assert::AreEqual((* frontReference).second, static_cast<size_t>(5));

			++frontReference;
//			Assert::ExpectException<std::runtime_error>([&frontReference]() {(* frontReference).second;  });
			++frontReference;
		}

		TEST_METHOD(CharIteratorPostIncrement)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(5));;

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto firstInsert = newMap.begin();
			auto secondInsert = newMap.begin();
			auto thirdInsert = newMap.begin();

			secondInsert++;
			thirdInsert++;
			thirdInsert++;

			auto frontReference = newMap.begin();
			Assert::AreEqual((* frontReference).second, (*firstInsert).second);

			frontReference++;
			Assert::AreEqual((* frontReference).second, (*secondInsert).second);

			frontReference++;
			Assert::AreEqual((* frontReference).second, (*thirdInsert).second);

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {(* frontReference).second;  });
			frontReference++;
		}

		TEST_METHOD(CharConstIteratorPostIncrement)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(5));

			auto firstReference = newMap.Insert(frontPair);
			auto secondReference = newMap.Insert(middlePair);
			auto thirdReference = newMap.Insert(endPair);

			auto frontReference = newMap.cbegin();
			Assert::AreEqual((*frontReference).second, newMap.At((*frontReference).first));

			frontReference++;
			Assert::AreEqual((*frontReference).second, newMap.At((*frontReference).first));

			frontReference++;
			Assert::AreEqual((*frontReference).second, newMap.At((*frontReference).first));

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {(* frontReference).second;  });
		}

		TEST_METHOD(CharIteratorDereference)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t > middlePair("Apples", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			HashMap<char*, size_t>::Iterator defaultReference;
			Assert::ExpectException<std::runtime_error>([&defaultReference]() {*defaultReference;  });

			auto frontReference = newMap.begin();
			Assert::AreEqual((*frontReference).second, newMap.At((*frontReference).first));

			frontReference++;
			Assert::AreEqual((*frontReference).second, newMap.At((*frontReference).first));
			//Assert::AreEqual((* frontReference).second, static_cast<size_t>(3));

			frontReference++;
			Assert::AreEqual((*frontReference).second, newMap.At((*frontReference).first)); 
			//frontReference).second, static_cast<size_t>(5));

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {(* frontReference).second;  });
		}

		TEST_METHOD(CharConstIteratorDereference)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(5));

			auto firstPair = newMap.Insert(frontPair);
			auto secondPair = newMap.Insert(middlePair);
			auto thirdPair = newMap.Insert(endPair);

			HashMap<char*, size_t>::ConstIterator defaultReference;
			Assert::ExpectException<std::runtime_error>([&defaultReference]() {*defaultReference;  });

			HashMap<char*, size_t>::ConstIterator frontReference = newMap.cbegin();
			Assert::AreEqual((*firstPair.first).second, static_cast<size_t>(1));

			frontReference++;
			Assert::AreEqual((*secondPair.first).second, static_cast<size_t>(3));

			frontReference++;
			Assert::AreEqual((*thirdPair.first).second, static_cast<size_t>(5));

			frontReference++;
			Assert::ExpectException<std::runtime_error>([&frontReference]() {(* frontReference).second;  });
		}

		TEST_METHOD(CharIteratorArrowDereference)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto traverser = newMap.begin();

			Assert::AreEqual((*traverser).second, newMap.At((*traverser).first));

			traverser++;
			Assert::AreEqual((*traverser).second, newMap.At((*traverser).first));
			//Assert::AreEqual((* (&traverser)->first).second, size_t(3));

			traverser++;
			Assert::AreEqual((*traverser).second, newMap.At((*traverser).first));
//			Assert::AreEqual((* (&traverser)->first).second, size_t(5));

			traverser++;
			Assert::ExpectException<std::runtime_error>([&traverser]() {(*traverser).second;;  });
		}

		TEST_METHOD(CharConstIteratorArrowDereference)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(5));

			auto firstPair = newMap.Insert(frontPair);
			auto secondPair = newMap.Insert(middlePair);
			auto thirdPair = newMap.Insert(endPair);

			std::pair<HashMap<char*, size_t>::ConstIterator, bool> traverser(newMap.cbegin(), true);

			Assert::AreEqual((*firstPair.first).second, size_t(1));

			*(&traverser)->first++;
			Assert::AreEqual((*secondPair.first).second, size_t(3));

			traverser.first++;
			Assert::AreEqual((*thirdPair.first).second, size_t(5));

			traverser.first++;
			Assert::ExpectException<std::runtime_error>([&traverser]() {(* (&traverser)->first).second;  });
		}

		TEST_METHOD(CharIteratorEquality)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(5));

			auto first = newMap.Insert(frontPair).first;
			auto second = newMap.Insert(middlePair).first;
			auto third = newMap.Insert(endPair).first;

			auto firstInsert = newMap.begin();
			auto secondInsert = newMap.begin();
			auto thirdInsert = newMap.begin();
			
			secondInsert++;
			thirdInsert++;
			thirdInsert++;

			Assert::IsFalse(firstInsert == secondInsert);
			Assert::IsFalse(firstInsert == thirdInsert);
			Assert::IsFalse(thirdInsert == secondInsert);

			firstInsert++;

			Assert::IsTrue(firstInsert == secondInsert);
			Assert::IsFalse(firstInsert == thirdInsert);
			Assert::IsFalse(thirdInsert == secondInsert);

			firstInsert++;
			secondInsert++;
			Assert::IsTrue(firstInsert == secondInsert);
			Assert::IsTrue(firstInsert == thirdInsert);
			Assert::IsTrue(thirdInsert == secondInsert);

			HashMap<char*, size_t>::Iterator defaultIterator;
			Assert::IsFalse(defaultIterator == secondInsert);
			Assert::IsFalse(defaultIterator == thirdInsert);
			Assert::IsFalse(defaultIterator == firstInsert);
		}

		TEST_METHOD(CharConstIteratorEquality)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Apples", static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto first = newMap.cbegin();
			auto second = newMap.cbegin();
			auto third = newMap.cbegin();

			second++;
			third++;
			third++;

			Assert::IsFalse(first == second);
			Assert::IsFalse(first == third);
			Assert::IsFalse(third == second);

			first++;

			Assert::IsTrue(first == second);
			Assert::IsFalse(first == third);
			Assert::IsFalse(third == second);

			first++;
			second++;
			Assert::IsTrue(first == second);
			Assert::IsTrue(first == third);
			Assert::IsTrue(third == second);

			HashMap<char*, size_t>::ConstIterator defaultIterator;
			Assert::IsFalse(defaultIterator == second);
			Assert::IsFalse(defaultIterator == third);
			Assert::IsFalse(defaultIterator == first);
		}

		TEST_METHOD(CharIteratorInEquality)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Apples", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Pears", static_cast<size_t>(5));

			newMap.Insert(frontPair).first;
			newMap.Insert(middlePair).first;
			newMap.Insert(endPair).first;

			auto firstInsert = newMap.begin();
			auto secondInsert = newMap.begin();
			auto thirdInsert = newMap.begin();

			secondInsert++;
			thirdInsert++;
			thirdInsert++;

			Assert::IsTrue(firstInsert != secondInsert);
			Assert::IsTrue(firstInsert != thirdInsert);
			Assert::IsTrue(thirdInsert != secondInsert);

			firstInsert++;

			Assert::IsFalse(firstInsert != secondInsert);
			Assert::IsTrue(firstInsert != thirdInsert);
			Assert::IsTrue(thirdInsert != secondInsert);

			firstInsert++;
			secondInsert++;
			Assert::IsFalse(firstInsert != secondInsert);
			Assert::IsFalse(firstInsert != thirdInsert);
			Assert::IsFalse(thirdInsert != secondInsert);

			HashMap<char*, size_t>::Iterator defaultIterator;
			Assert::IsTrue(defaultIterator != secondInsert);
			Assert::IsTrue(defaultIterator != thirdInsert);
			Assert::IsTrue(defaultIterator != firstInsert);
		}

		TEST_METHOD(CharConstIteratorInEquality)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));
			std::pair<char*, size_t> middlePair("Pears", static_cast<size_t>(3));
			std::pair<char*, size_t> endPair("Apples", static_cast<size_t>(5));

			newMap.Insert(frontPair);
			newMap.Insert(middlePair);
			newMap.Insert(endPair);

			auto first = newMap.cbegin();
			auto second = newMap.cbegin();
			auto third = newMap.cbegin();

			second++;
			third++;
			third++;
			Assert::IsTrue(first != second);
			Assert::IsTrue(first != third);
			Assert::IsTrue(third != second);

			first++;
			Assert::IsFalse(first != second);
			Assert::IsTrue(first != third);
			Assert::IsTrue(third != second);

			first++;
			second++;
			Assert::IsFalse(first != second);
			Assert::IsFalse(first != third);
			Assert::IsFalse(third != second);

			HashMap<char*, size_t>::ConstIterator defaultIterator;
			Assert::IsTrue(defaultIterator != second);
			Assert::IsTrue(defaultIterator != third);
			Assert::IsTrue(defaultIterator != first);
		}

		TEST_METHOD(CharIteratorAssignment)
		{
			HashMap<char*, size_t, HashFunctor<char*>> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));

			newMap.Insert(frontPair);

			HashMap<char*, size_t>::Iterator definedIterator = newMap.begin();
			HashMap<char*, size_t>::Iterator defaultIterator;

			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {(* defaultIterator).second;  });
			Assert::IsFalse(defaultIterator == definedIterator);

			defaultIterator = definedIterator;
			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::AreEqual((* defaultIterator).second, static_cast<size_t>(1));
			Assert::IsTrue(defaultIterator == definedIterator);
		}

		TEST_METHOD(CharConstIteratorAssignment)
		{
			HashMap<char*, size_t> newMap;
			Assert::AreEqual(newMap.Size(), size_t{ 0 });
			std::pair<char*, size_t> frontPair("Oranges", static_cast<size_t>(1));

			newMap.Insert(frontPair);

			HashMap<char*, size_t>::ConstIterator definedIterator = newMap.cbegin();
			HashMap<char*, size_t>::ConstIterator defaultIterator;

			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::ExpectException<std::runtime_error>([&defaultIterator]() {(* defaultIterator).second;  });
			Assert::IsFalse(defaultIterator == definedIterator);

			defaultIterator = definedIterator;
			Assert::AreEqual((* definedIterator).second, static_cast<size_t>(1));
			Assert::AreEqual((* defaultIterator).second, static_cast<size_t>(1));
			Assert::IsTrue(defaultIterator == definedIterator);
		}
		//Hash function tests
		TEST_METHOD(HashDefault)
		{
			const size_t first = 1;
			const size_t second = 2;
			size_t third;

			third = first;

			HashFunctor<size_t> hashFunctor;
			Assert::AreEqual(hashFunctor(first), hashFunctor(first));
			Assert::AreNotEqual(hashFunctor(first), hashFunctor(second));
			Assert::AreNotEqual(hashFunctor(second), hashFunctor(third));
			Assert::AreEqual(hashFunctor(first), hashFunctor(third));

			HashFunctor<const size_t> constHashFunctor;
			Assert::AreEqual(constHashFunctor(first), constHashFunctor(first));
			Assert::AreNotEqual(constHashFunctor(first), constHashFunctor(second));
			Assert::AreNotEqual(constHashFunctor(second), constHashFunctor(third));
			Assert::AreEqual(constHashFunctor(first), constHashFunctor(third));
		}

		TEST_METHOD(HashFoo)
		{
			HashFunctor<Foo> hashFunctor{};
			Foo firstFoo(1);
			Foo secondFoo(2);
			Foo thirdFoo(33);
			Foo fourthFoo(3);
			Foo fifthFoo(33);
			Foo sixthFoo(10);

			Assert::AreNotEqual(hashFunctor(firstFoo), hashFunctor(secondFoo));
			Assert::AreNotEqual(hashFunctor(firstFoo), hashFunctor(sixthFoo));
			Assert::AreEqual(hashFunctor(firstFoo), size_t(310));
			Assert::AreEqual(hashFunctor(secondFoo), size_t(434));
			Assert::AreNotEqual(hashFunctor(thirdFoo), hashFunctor(fourthFoo));
			Assert::AreEqual(hashFunctor(thirdFoo), hashFunctor(fifthFoo));
		}

		TEST_METHOD(HashCharStar)
		{
			const char* greeting = "Hello";
			const char* goodbye = "Goodbye";
			char hello[6];
			strcpy_s(hello, greeting);

			HashFunctor<char*> hashFunctor;
			Assert::AreEqual(hashFunctor(greeting), hashFunctor(greeting));
			Assert::AreNotEqual(hashFunctor(greeting), hashFunctor(goodbye));
			Assert::AreNotEqual(hashFunctor(goodbye), hashFunctor(hello));
			Assert::AreEqual(hashFunctor(greeting), hashFunctor(hello));

			HashFunctor<const char*> constHashFunctor;
			Assert::AreEqual(constHashFunctor(greeting), constHashFunctor(greeting));
			Assert::AreNotEqual(constHashFunctor(greeting), constHashFunctor(goodbye));
			Assert::AreNotEqual(constHashFunctor(goodbye), constHashFunctor(hello));
			Assert::AreEqual(constHashFunctor(greeting), constHashFunctor(hello));
		}


		TEST_METHOD(HashString)
		{
			const std::string greeting = "Hello";
			const std::string goodbye = "Goodbye";
			std::string hello;

			hello = greeting;

			HashFunctor<std::string> hashFunctor; 
			Assert::AreEqual(hashFunctor(greeting), hashFunctor(greeting));
			Assert::AreNotEqual(hashFunctor(greeting), hashFunctor(goodbye));
			Assert::AreNotEqual(hashFunctor(goodbye), hashFunctor(hello));
			Assert::AreEqual(hashFunctor(greeting), hashFunctor(hello));

			HashFunctor<const std::string> constHashFunctor;
			Assert::AreEqual(constHashFunctor(greeting), constHashFunctor(greeting));
			Assert::AreNotEqual(constHashFunctor(greeting), constHashFunctor(goodbye));
			Assert::AreNotEqual(constHashFunctor(goodbye), constHashFunctor(hello));
			Assert::AreEqual(constHashFunctor(greeting), constHashFunctor(hello));
		}
		
		TEST_METHOD(BasicTest)
		{
			std::pair <std::string, size_t> basicPair("Apple", size_t(25));
			std::pair <std::string, size_t> altPair("Pear", size_t(25));

			HashMap<std::string, size_t, HashFunctor<std::string>> newMap;

			newMap.Insert(basicPair);
			Assert::AreEqual(newMap.Size(), size_t(1));

			newMap.Insert(altPair);
			//default.Append("Orange");
			Assert::AreEqual(newMap.Size(), size_t(2));
		}

	private: //Creates memory state screenshots to ensure no memory leaks in any test
		inline static _CrtMemState _startMemState;
	};
}