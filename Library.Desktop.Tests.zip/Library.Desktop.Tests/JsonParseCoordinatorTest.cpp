#pragma once
#include "pch.h"
#include "json\json.h"
#include <CppUnitTest.h>
#include <fstream>
#include "JsonIntegerParseHelper.h"
#include "JsonTestParseHelper.h"
#include "JsonTableParseHelper.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace glm;
using namespace std;
using namespace std::string_literals;

namespace Microsoft::VisualStudio::CppUnitTestFramework
{
}

namespace UnitTests
{
	TEST_CLASS(JsonParseCoordinatorTests)
	{
		TEST_METHOD_INITIALIZE(Initialize) //Initial setup of memory state variables to allow memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&_startMemState);
			#endif
		}

		TEST_METHOD_CLEANUP(Cleanup) //Setup for memory leak testing
		{
			#if defined(DEBUG) || defined(_DEBUG)
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);

			if (_CrtMemDifference(&diffMemState, &_startMemState,
				&endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
			#endif
		}
		
		TEST_METHOD(Constructor)
		{
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTestParseHelper::Wrapper);
			JsonParseCoordinator parseCoordinator(wrapper);
			Assert::AreEqual(size_t(0), parseCoordinator.HelperSize());
			Assert::IsTrue(wrapper == parseCoordinator.GetWrapper());

			parseCoordinator.AddHelper(make_shared<JsonTestParseHelper>());
			Assert::AreEqual(size_t(1), parseCoordinator.HelperSize());

			shared_ptr<JsonParseCoordinator::Wrapper> anotherWrapper(new JsonTestParseHelper::Wrapper);
			parseCoordinator.SetWrapper(anotherWrapper);
			Assert::IsTrue(anotherWrapper == parseCoordinator.GetWrapper());

		}

		TEST_METHOD(MoveConstructor)
		{
			stringstream inputStream;
			inputStream << R"(
			{
				"Health":
				{
					"Type": "Integer",
					"Value": 100
				}
			})"s;
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTestParseHelper::Wrapper);
			JsonParseCoordinator parseCoordinator(wrapper);
			parseCoordinator.AddHelper(make_shared<JsonTestParseHelper>());

			shared_ptr<JsonParseCoordinator::Wrapper> otherWrapper(new JsonTestParseHelper::Wrapper);

			parseCoordinator.DeserializeObject(inputStream);

			Assert::AreEqual(size_t(0), wrapper->Depth());
			JsonTestParseHelper::Wrapper* rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
			Assert::IsTrue(rawWrapper->Data[0] == 100);

			JsonParseCoordinator otherParseCoordinator = std::move(parseCoordinator);
			Assert::AreEqual(size_t(1), otherParseCoordinator.HelperSize());
			Assert::IsTrue(wrapper == otherParseCoordinator.GetWrapper());
			rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
			Assert::IsTrue(rawWrapper->Data[0] == 100);
		}

		TEST_METHOD(ParseFromString)
		{
			const string inputString = R"(
			{
				"IntegerValue":
				{
					"Type": "Integer",
					"Value": 100
				}
			})"s;

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTestParseHelper::Wrapper);
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTestParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			Assert::IsFalse(testParseHelper->InitializeCalled);
			parseCoordinator.Initialize();
			Assert::IsTrue(testParseHelper->InitializeCalled);

			Assert::AreEqual(size_t(0), testParseHelper->StartHandlerCount);
			Assert::AreEqual(size_t(0), testParseHelper->EndHandlerCount);
			JsonTestParseHelper::Wrapper* rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
			Assert::AreEqual(size_t(0), rawWrapper->TotalDepth);

			parseCoordinator.DeserializeObject(inputString);
			
			Assert::AreEqual(size_t(1), testParseHelper->StartHandlerCount);
			Assert::AreEqual(size_t(1), testParseHelper->EndHandlerCount);
			rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
			Assert::IsTrue(rawWrapper->Data[0] == 100);
			Assert::AreEqual(size_t(2), rawWrapper->TotalDepth);
		}

		TEST_METHOD(DeserializeObjectFromFile)
		{
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTestParseHelper::Wrapper);
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTestParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			Assert::IsFalse(testParseHelper->InitializeCalled);
			parseCoordinator.Initialize();
			Assert::IsTrue(testParseHelper->InitializeCalled);

			Assert::AreEqual(size_t(0), testParseHelper->StartHandlerCount);
			Assert::AreEqual(size_t(0), testParseHelper->EndHandlerCount);
			JsonTestParseHelper::Wrapper* rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
			Assert::AreEqual(size_t(0), rawWrapper->TotalDepth);

			std::string wrongPath = R"(InvalidPath\WrongData.json)";
			Assert::ExpectException<exception>([&parseCoordinator, &wrongPath] {parseCoordinator.DeserializeObjectFromFile(wrongPath); });

			std::string fullPath =  R"(Content\IntegerTest.json)";
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			Assert::AreEqual(size_t(1), testParseHelper->StartHandlerCount);
			Assert::AreEqual(size_t(1), testParseHelper->EndHandlerCount);
			rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
			Assert::IsTrue(rawWrapper->Data[0] == 8);
			Assert::AreEqual(size_t(2), rawWrapper->TotalDepth);
		}

		TEST_METHOD(ParseFromStream)
		{
			stringstream inputStream;
			inputStream << R"(
			{
				"Health":
				{
					"Type": "Integer",
					"Value": 100
				}
			})"s;

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTestParseHelper::Wrapper);
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTestParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			Assert::IsFalse(testParseHelper->InitializeCalled);
			testParseHelper->Initialize();
			Assert::IsTrue(testParseHelper->InitializeCalled);
			Assert::IsFalse(testParseHelper->CleanupCalled);

			parseCoordinator.DeserializeObject(inputStream);

			Assert::AreEqual(size_t(1), testParseHelper->StartHandlerCount);
			Assert::AreEqual(size_t(1), testParseHelper->EndHandlerCount);
			Assert::AreEqual(size_t(0), wrapper->Depth());
			Assert::IsTrue(testParseHelper->CleanupCalled);
			JsonTestParseHelper::Wrapper* rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
			Assert::IsTrue(rawWrapper->Data[0] == 100);
			Assert::AreEqual(size_t(2), rawWrapper->TotalDepth);
		}

		TEST_METHOD(MoveAssignment)
		{
			stringstream inputStream;
			inputStream << R"(
			{
				"Health":
				{
					"Type": "Integer",
					"Value": 100
				}
			})"s;
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTestParseHelper::Wrapper);
			JsonParseCoordinator parseCoordinator(wrapper);
			parseCoordinator.AddHelper(make_shared<JsonTestParseHelper>());
				
			shared_ptr<JsonParseCoordinator::Wrapper> otherWrapper(new JsonTestParseHelper::Wrapper);
			JsonParseCoordinator otherParseCoordinator(otherWrapper);

			parseCoordinator.DeserializeObject(inputStream);

			Assert::AreEqual(size_t(0), wrapper->Depth());
			JsonTestParseHelper::Wrapper* rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
			Assert::IsTrue(rawWrapper->Data[0] == 100);

			otherParseCoordinator = std::move(parseCoordinator);
			Assert::AreEqual(size_t(1), otherParseCoordinator.HelperSize());
			Assert::IsTrue(wrapper == otherParseCoordinator.GetWrapper());
			rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
			Assert::IsTrue(rawWrapper->Data[0] == 100);
		}

		TEST_METHOD(Destructor)
		{
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTestParseHelper::Wrapper);
			JsonParseCoordinator parseCoordinator(wrapper);
			parseCoordinator.SetWrapper(nullptr);
			Assert::IsTrue(wrapper->GetJsonParseCoordinator() == nullptr);
			Assert::IsTrue(parseCoordinator.GetWrapper() == nullptr);
			//No memory leak comes from them becoming unassociated. All memory is freed with no overrun at the end of the program.
		}

		TEST_METHOD(Create)
		{
			{
				stringstream inputStream;
				inputStream << R"(
				{
					"Health":
					{
						"Type": "Integer",
						"Value": 100
					}
				})"s;
				shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTestParseHelper::Wrapper);
				JsonParseCoordinator parseCoordinator(wrapper);
				parseCoordinator.AddHelper(make_shared<JsonTestParseHelper>());

				parseCoordinator.DeserializeObject(inputStream);
					
				Assert::AreEqual(size_t(0), wrapper->Depth());
				JsonTestParseHelper::Wrapper* rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
				Assert::IsTrue(rawWrapper->Data[0] == 100);

				unique_ptr<JsonParseCoordinator>otherParseCoordinator = parseCoordinator.Clone();
				Assert::AreEqual(size_t(1), otherParseCoordinator->HelperSize());
				Assert::IsFalse(wrapper == otherParseCoordinator->GetWrapper());
				Assert::AreEqual(size_t(0), rawWrapper->Depth());
				rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(otherParseCoordinator->GetWrapper().get());
				Assert::IsTrue(rawWrapper->Data.Size() == 0);

				stringstream newInputStream;
				newInputStream << R"(
				{
					"Health":
					{
						"Type": "Integer",
						"Value": 100
					}
				})"s;

				otherParseCoordinator->DeserializeObject(newInputStream);
				Assert::AreEqual(size_t(1), otherParseCoordinator->HelperSize());
				Assert::IsFalse(wrapper == otherParseCoordinator->GetWrapper());
				Assert::AreEqual(size_t(0), rawWrapper->Depth());
				rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(otherParseCoordinator->GetWrapper().get());
				Assert::IsTrue(rawWrapper->Data.Size() == 1);
				Assert::IsTrue(rawWrapper->Data[0] == 100);
			}

			{
				stringstream inputStream;
				inputStream << R"(
				{
					"Health":
					{
						"Type": "Integer",
						"Value": 100
					}
				})"s;

				stringstream wrongInputStream;
				wrongInputStream << R"(
				{
					"Health":
					{
						"Type": "Integer",
						"Value": "NotanInt"
					}
				})"s;

				shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonIntegerParseHelper::Wrapper);
				JsonParseCoordinator parseCoordinator(wrapper);
				parseCoordinator.AddHelper(make_shared<JsonIntegerParseHelper>());

				parseCoordinator.DeserializeObject(wrongInputStream);
				JsonIntegerParseHelper::Wrapper* rawWrapper = static_cast<JsonIntegerParseHelper::Wrapper*>(wrapper.get());
				Assert::IsTrue(rawWrapper->Data.Size() == 0);

				parseCoordinator.DeserializeObject(inputStream);

				Assert::AreEqual(size_t(0), wrapper->Depth());
				rawWrapper = static_cast<JsonIntegerParseHelper::Wrapper*>(wrapper.get());
				Assert::IsTrue(rawWrapper->Data[0] == 100);

				unique_ptr<JsonParseCoordinator>otherParseCoordinator = parseCoordinator.Clone();
				Assert::AreEqual(size_t(1), otherParseCoordinator->HelperSize());
				Assert::IsFalse(wrapper == otherParseCoordinator->GetWrapper());
				Assert::AreEqual(size_t(0), rawWrapper->Depth());
				rawWrapper = static_cast<JsonIntegerParseHelper::Wrapper*>(otherParseCoordinator->GetWrapper().get());
				Assert::IsTrue(rawWrapper->Data.Size() == 0);

				stringstream newInputStream;
				newInputStream << R"(
				{
					"Health":
					{
						"Type": "Integer",
						"Value": 100
					}
				})"s;

				otherParseCoordinator->DeserializeObject(newInputStream);
				Assert::AreEqual(size_t(1), otherParseCoordinator->HelperSize());
				Assert::IsFalse(wrapper == otherParseCoordinator->GetWrapper());
				Assert::AreEqual(size_t(0), rawWrapper->Depth());
				rawWrapper = static_cast<JsonIntegerParseHelper::Wrapper*>(otherParseCoordinator->GetWrapper().get());
				Assert::IsTrue(rawWrapper->Data.Size() == 1);
				Assert::IsTrue(rawWrapper->Data[0] == 100);
			}
		}

		TEST_METHOD(SetJsonParseCoordinator)
		{
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTestParseHelper::Wrapper);
			JsonParseCoordinator parseCoordinator(wrapper);

			Assert::IsTrue(parseCoordinator.GetWrapper()->GetJsonParseCoordinator() == &parseCoordinator); //Set is done by default.
			
			JsonParseCoordinator newParseCoordinator(wrapper);
			Assert::IsTrue(parseCoordinator.GetWrapper()->GetJsonParseCoordinator() == &newParseCoordinator);
		}

		TEST_METHOD(GetJsonParseCoordinator)
		{
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTestParseHelper::Wrapper);
			JsonParseCoordinator parseCoordinator(wrapper);

			Assert::IsTrue(parseCoordinator.GetWrapper()->GetJsonParseCoordinator() == &parseCoordinator);

			JsonParseCoordinator newParseCoordinator(wrapper);
			Assert::IsTrue(parseCoordinator.GetWrapper()->GetJsonParseCoordinator() == &newParseCoordinator);
		}

		TEST_METHOD(IncrementAndDecrementDepth)
		{
			string inputString = R"(
			{
				"Health":
				{
					"Type": "Integer",
					"Value": 100
				}
			})"s;

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTestParseHelper::Wrapper);
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTestParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			JsonTestParseHelper::Wrapper* rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
			Assert::AreEqual(size_t(0), rawWrapper->TotalDepth);

			parseCoordinator.DeserializeObject(inputString);
			Assert::AreEqual(size_t(2), rawWrapper->TotalDepth);
		}

		TEST_METHOD(ParseMembers)
		{
			const string inputString = R"(
			{
				"FirstInt":
				{
					"Type": "Integer",
					"Value": 100
				}, 
				"NextInt":
				{
					"Type": "Integer",
					"Value": 200
				}
			})"s;

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTestParseHelper::Wrapper);
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTestParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			Assert::IsFalse(testParseHelper->InitializeCalled);
			parseCoordinator.Initialize();
			Assert::IsTrue(testParseHelper->InitializeCalled);

			Assert::AreEqual(size_t(0), testParseHelper->StartHandlerCount);
			Assert::AreEqual(size_t(0), testParseHelper->EndHandlerCount);
			JsonTestParseHelper::Wrapper* rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
			Assert::AreEqual(size_t(0), rawWrapper->TotalDepth);

			parseCoordinator.DeserializeObject(inputString);

			Assert::AreEqual(size_t(2), testParseHelper->StartHandlerCount);
			Assert::AreEqual(size_t(2), testParseHelper->EndHandlerCount);
			rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
			Assert::IsTrue(rawWrapper->Data[0] == 100);
			Assert::IsTrue(rawWrapper->Data[1] == 200);
			Assert::AreEqual(size_t(2), rawWrapper->TotalDepth);
		}

		TEST_METHOD(IntegerArrayParsing)
		{
			string inputString = R"(
									{
										"IntegerData":
										{
											"Type": "Integer",
											"Value": [10, 20, 30, 40]
										}
									})";

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper = make_shared<JsonIntegerParseHelper::Wrapper>();
			JsonParseCoordinator parseCoordinator(wrapper);
			parseCoordinator.AddHelper(make_shared<JsonIntegerParseHelper>());

			std::shared_ptr<JsonIntegerParseHelper> newHelper{ new JsonIntegerParseHelper() };

			parseCoordinator.DeserializeObject(inputString);

			JsonIntegerParseHelper::Wrapper* rawWrapper = static_cast<JsonIntegerParseHelper::Wrapper*>(wrapper.get());
			Assert::AreEqual(size_t(4), rawWrapper->Data.Size());
			Assert::AreEqual(size_t(10), rawWrapper->Data[0]);
			Assert::AreEqual(size_t(20), rawWrapper->Data[1]);
			Assert::AreEqual(size_t(30), rawWrapper->Data[2]);
			Assert::AreEqual(size_t(40), rawWrapper->Data[3]);

			shared_ptr<JsonParseCoordinator::Wrapper> newWrapper = make_shared<JsonTestParseHelper::Wrapper>();
			JsonParseCoordinator newParseCoordinator(newWrapper);
			newParseCoordinator.AddHelper(make_shared<JsonTestParseHelper>());
			std::shared_ptr<JsonTestParseHelper> newTestHelper{ new JsonTestParseHelper() };

			newParseCoordinator.DeserializeObject(inputString);

			JsonTestParseHelper::Wrapper* newRawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(newWrapper.get());
			Assert::AreEqual(size_t(4), newRawWrapper->Data.Size());
			Assert::AreEqual(size_t(10), newRawWrapper->Data[0]);
			Assert::AreEqual(size_t(20), newRawWrapper->Data[1]);
			Assert::AreEqual(size_t(30), newRawWrapper->Data[2]);
			Assert::AreEqual(size_t(40), newRawWrapper->Data[3]);
		}

		TEST_METHOD(AddRemoveHelpers)
		{
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper = make_shared<JsonTestParseHelper::Wrapper>();
			JsonParseCoordinator parseCoordinator(wrapper);

			auto parsingHelper = make_shared<JsonTestParseHelper>();
			Assert::AreEqual(size_t(0), parseCoordinator.HelperSize());
			parseCoordinator.AddHelper(parsingHelper);
			Assert::AreEqual(size_t(1), parseCoordinator.HelperSize());

			Assert::ExpectException<exception>([&parseCoordinator, &parsingHelper] {parseCoordinator.AddHelper(parsingHelper); });

			parseCoordinator.AddHelper(make_shared<JsonIntegerParseHelper>());
			Assert::AreEqual(size_t(2), parseCoordinator.HelperSize());

			parseCoordinator.RemoveHelper(parseCoordinator.HelperList()[0]);
			Assert::AreEqual(size_t(1), parseCoordinator.HelperSize());

			parseCoordinator.RemoveHelper(parseCoordinator.HelperList()[0]);
			Assert::AreEqual(size_t(0), parseCoordinator.HelperSize());
		}

		TEST_METHOD(WrapperDestroy)
		{
			{
				string inputString = R"(
									{
										"IntegerData":
										{
											"Type": "Integer",
											"Value": [10, 20, 30, 40]
										}
									})";

				shared_ptr<JsonParseCoordinator::Wrapper> wrapper = make_shared<JsonIntegerParseHelper::Wrapper>();
				JsonParseCoordinator parseCoordinator(wrapper);
				parseCoordinator.AddHelper(make_shared<JsonIntegerParseHelper>());

				std::shared_ptr<JsonIntegerParseHelper> newHelper{ new JsonIntegerParseHelper() };

				parseCoordinator.DeserializeObject(inputString);

				JsonIntegerParseHelper::Wrapper* rawWrapper = static_cast<JsonIntegerParseHelper::Wrapper*>(wrapper.get());
				Assert::AreEqual(size_t(2), rawWrapper->TotalDepth);
				Assert::AreEqual(size_t(4), rawWrapper->Data.Size());
				Assert::AreEqual(size_t(10), rawWrapper->Data[0]);
				Assert::AreEqual(size_t(20), rawWrapper->Data[1]);
				Assert::AreEqual(size_t(30), rawWrapper->Data[2]);
				Assert::AreEqual(size_t(40), rawWrapper->Data[3]);

				//wrapper->~Wrapper();
				//Assert::AreEqual(size_t(0), rawWrapper->Data.Size());
				//Assert::AreEqual(size_t(0), rawWrapper->TotalDepth);
			}

			{
				string inputString = R"(
									{
										"IntegerData":
										{
											"Type": "Integer",
											"Value": [10, 20, 30, 40]
										}
									})";

				shared_ptr<JsonParseCoordinator::Wrapper> wrapper = make_shared<JsonTestParseHelper::Wrapper>();
				JsonParseCoordinator parseCoordinator(wrapper);
				parseCoordinator.AddHelper(make_shared<JsonTestParseHelper>());

				std::shared_ptr<JsonTestParseHelper> newHelper{ new JsonTestParseHelper() };

				parseCoordinator.DeserializeObject(inputString);

				JsonTestParseHelper::Wrapper* rawWrapper = static_cast<JsonTestParseHelper::Wrapper*>(wrapper.get());
				Assert::AreEqual(size_t(2), rawWrapper->TotalDepth);
				Assert::AreEqual(size_t(4), rawWrapper->Data.Size());
				Assert::AreEqual(size_t(10), rawWrapper->Data[0]);
				Assert::AreEqual(size_t(20), rawWrapper->Data[1]);
				Assert::AreEqual(size_t(30), rawWrapper->Data[2]);
				Assert::AreEqual(size_t(40), rawWrapper->Data[3]);

			//	wrapper->~Wrapper();
			//	Assert::AreEqual(size_t(0), rawWrapper->Data.Size());
			//	Assert::AreEqual(size_t(0), rawWrapper->TotalDepth);
			}
		}

		TEST_METHOD(JsonTableConstructor)
		{
			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			Assert::AreEqual(size_t(0), parseCoordinator.HelperSize());
			Assert::IsTrue(wrapper == parseCoordinator.GetWrapper());

			shared_ptr<FieaGameEngine::IJsonParseHelper> newHelper(new JsonTableParseHelper);

			parseCoordinator.AddHelper(newHelper);
			Assert::AreEqual(size_t(1), parseCoordinator.HelperSize());

			shared_ptr<JsonParseCoordinator::Wrapper> anotherWrapper(new JsonTestParseHelper::Wrapper);
			parseCoordinator.SetWrapper(anotherWrapper);
			Assert::IsTrue(anotherWrapper == parseCoordinator.GetWrapper());
		}

		TEST_METHOD(JsonTableSingleParser)
		{
			std::string fullPath = R"(Content\JSONPrimitiveTest.json)";

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());

			Assert::IsTrue(rawWrapper->Data->Size() == 6);

			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(0) == 100);

			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(0) == 100.2f);

			Assert::IsTrue(rawWrapper->Data->Find("StringValue")->GetString(0) == "Hi");

			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(0) == glm::vec4(1, 2, 3, 4));

			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope()->Size() == 1);
			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope(0)->Find("Cake")->GetString(0) == "red velvet");

			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Cake Recipe")->GetScope()->Find("Cake")->GetString() == "red velvet");
			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Cake Recipe")->GetScope()->Find("Frosting")->GetString() == "cream cheese");

			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Tea Recipe")->GetScope()->Find("Tea")->GetString() == "black");
			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Tea Recipe")->GetScope()->Find("Sweetener")->GetString() == "honey");
		}

		TEST_METHOD(JsonTableAlternateSingleParser)
		{
			std::string fullPath = R"(Content\JSONAlternatePrimitiveTest.json)";

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());

			Assert::IsTrue(rawWrapper->Data->Size() == 6);

			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(0) == 100);

			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(0) == 100.2f);

			Assert::IsTrue(rawWrapper->Data->Find("MatrixValue")->GetMatrix(0) == glm::mat4(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1));

			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(0) == glm::vec4(1, 2, 3, 4));

			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope()->Size() == 1);
			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope(0)->Find("Cake")->GetString(0) == "red velvet");

			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Cake Recipe")->GetScope()->Find("Cake")->GetString() == "red velvet");
			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Cake Recipe")->GetScope()->Find("Frosting")->GetString() == "cream cheese");

			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Tea Recipe")->GetScope()->Find("Tea")->GetString() == "black");
			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Tea Recipe")->GetScope()->Find("Sweetener")->GetString() == "honey");
		}

		TEST_METHOD(JsonTableArray)
		{
			std::string fullPath = R"(Content\JSONMiniTest.json)";

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());

			Assert::IsTrue(rawWrapper->Data->Size() == 6);

			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(0) == 100);
			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(1) == 200);
			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(2) == 300);

			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(0) == 100.2f);
			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(1) == 100.3f);
			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(2) == 100.4f);

			Assert::IsTrue(rawWrapper->Data->Find("StringValue")->GetString(0) == "Hi");
			Assert::IsTrue(rawWrapper->Data->Find("StringValue")->GetString(1) == "Hello");
			Assert::IsTrue(rawWrapper->Data->Find("StringValue")->GetString(2) == "Howdy");

			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(0) == glm::vec4(1, 2, 3, 4));
			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(1) == glm::vec4(4, 3, 2, 1));
			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(2) == glm::vec4(2, 4, 6, 8));

			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope()->Size() == 3);
			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope(0)->Find("Cake")->GetString(0) == "red velvet");
			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope(0)->Find("Frosting")->GetString(0) == "cream cheese");
			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope(0)->Find("Slices")->GetInt() == 8);

			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Cake Recipe")->GetScope()->Find("Cake")->GetString() == "red velvet");
			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Cake Recipe")->GetScope()->Find("Frosting")->GetString() == "cream cheese");

			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Tea Recipe")->GetScope()->Find("Tea")->GetString() == "black");
			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Tea Recipe")->GetScope()->Find("Sweetener")->GetString() == "honey");

		}

		TEST_METHOD(JsonTableAlternateArray)
		{
			std::string fullPath = R"(Content\AlternateJSONMiniTest.json)";

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());

			Assert::IsTrue(rawWrapper->Data->Size() == 6);

			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(0) == 100);
			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(1) == 200);
			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(2) == 300);

			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(0) == 100.2f);
			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(1) == 100.3f);
			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(2) == 100.4f);

			Assert::IsTrue(rawWrapper->Data->Find("MatrixValue")->GetMatrix(0) == glm::mat4(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 ,1, 1, 1, 1, 1));
			Assert::IsTrue(rawWrapper->Data->Find("MatrixValue")->GetMatrix(1) == glm::mat4(2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2));
			Assert::IsTrue(rawWrapper->Data->Find("MatrixValue")->GetMatrix(2) == glm::mat4(3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3));

			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(0) == glm::vec4(1, 2, 3, 4));
			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(1) == glm::vec4(4, 3, 2, 1));
			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(2) == glm::vec4(2, 4, 6, 8));

			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope()->Size() == 3);
			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope(0)->Find("Cake")->GetString(0) == "red velvet");
			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope(0)->Find("Frosting")->GetString(0) == "cream cheese");
			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope(0)->Find("Slices")->GetInt() == 8);

			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Cake Recipe")->GetScope()->Find("Cake")->GetString() == "red velvet");
			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Cake Recipe")->GetScope()->Find("Frosting")->GetString() == "cream cheese");

			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Tea Recipe")->GetScope()->Find("Tea")->GetString() == "black");
			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Tea Recipe")->GetScope()->Find("Sweetener")->GetString() == "honey");

		}

		TEST_METHOD(JsonExternalSingleValues)
		{
			std::string fullPath = R"(Content\JSONPrimitiveTest.json)";

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			size_t IntArray[] = { 200 };
			float FloatArray[] = { 200.2f };
			std::string StringArray[] = { "Hey" };
			glm::vec4 VectorArray[] = { glm::vec4(4, 2, 0, 6) };

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());

			rawWrapper->Initialize();
			rawWrapper->Data->Append("IntegerValue");
			rawWrapper->Data->Find("IntegerValue")->SetStorage(IntArray, 1);
			rawWrapper->Data->Append("FloatValue");
			rawWrapper->Data->Find("FloatValue")->SetStorage(FloatArray, 1);
			rawWrapper->Data->Append("StringValue");
			rawWrapper->Data->Find("StringValue")->SetStorage(StringArray, 1);
			rawWrapper->Data->Append("VectorValue");
			rawWrapper->Data->Find("VectorValue")->SetStorage(VectorArray, 1);
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(0) == 100);
			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(0) == 100.2f);
			Assert::IsTrue(rawWrapper->Data->Find("StringValue")->GetString(0) == "Hi");
			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(0) == glm::vec4(1, 2, 3, 4));
		}

		TEST_METHOD(JsonAlternateExternalSingleValues)
		{
			std::string fullPath = R"(Content\JSONAlternatePrimitiveTest.json)";

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			size_t IntArray[] = { 200 };
			float FloatArray[] = { 200.2f };
			glm::mat4 MatrixArray[] = { glm::mat4(2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)};
			glm::vec4 VectorArray[] = { glm::vec4(4, 2, 0, 6) };

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());

			rawWrapper->Initialize();
			rawWrapper->Data->Append("IntegerValue");
			rawWrapper->Data->Find("IntegerValue")->SetStorage(IntArray, 1);
			rawWrapper->Data->Append("FloatValue");
			rawWrapper->Data->Find("FloatValue")->SetStorage(FloatArray, 1);
			rawWrapper->Data->Append("MatrixValue");
			rawWrapper->Data->Find("MatrixValue")->SetStorage(MatrixArray, 1);
			rawWrapper->Data->Append("VectorValue");
			rawWrapper->Data->Find("VectorValue")->SetStorage(VectorArray, 1);
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(0) == 100);
			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(0) == 100.2f);
			Assert::IsTrue(rawWrapper->Data->Find("MatrixValue")->GetMatrix(0) == glm::mat4(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1));
			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(0) == glm::vec4(1, 2, 3, 4));
		}

		TEST_METHOD(JsonTableExternalArrayValues)
		{
			std::string fullPath = R"(Content\JSONMiniTest.json)";

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			size_t IntArray[] = { 200, 300, 400 };
			float FloatArray[] = { 200.2f, 300.3f, 400.4f };
			std::string StringArray[] = {"Hey", "Greetings", "Mornin"};
			glm::vec4 VectorArray[] = { glm::vec4(4, 2, 0, 6), glm::vec4(9, 9, 9, 9), glm::vec4(1, 1, 1, 1) };

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			
			rawWrapper->Initialize();
			rawWrapper->Data->Append("IntegerValue");
			rawWrapper->Data->Find("IntegerValue")->SetStorage(IntArray, 3);
			rawWrapper->Data->Append("FloatValue");
			rawWrapper->Data->Find("FloatValue")->SetStorage(FloatArray, 3);
			rawWrapper->Data->Append("StringValue");
			rawWrapper->Data->Find("StringValue")->SetStorage(StringArray, 3);
			rawWrapper->Data->Append("VectorValue");
			rawWrapper->Data->Find("VectorValue")->SetStorage(VectorArray, 3);
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(0) == 100);
			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(1) == 200);
			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(2) == 300);

			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(0) == 100.2f);
			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(1) == 100.3f);
			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(2) == 100.4f);

			Assert::IsTrue(rawWrapper->Data->Find("StringValue")->GetString(0) == "Hi");
			Assert::IsTrue(rawWrapper->Data->Find("StringValue")->GetString(1) == "Hello");
			Assert::IsTrue(rawWrapper->Data->Find("StringValue")->GetString(2) == "Howdy");

			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(0) == glm::vec4(1, 2, 3, 4));
			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(1) == glm::vec4(4, 3, 2, 1));
			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(2) == glm::vec4(2, 4, 6, 8));
		}

		TEST_METHOD(JsonTableAlternateExternalArrayValues)
		{
			std::string fullPath = R"(Content\AlternateJSONMiniTest.json)";

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			size_t IntArray[] = { 200, 300, 400 };
			float FloatArray[] = { 200.2f, 300.3f, 400.4f };
			glm::mat4 MatrixArray[] = { glm::mat4(2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1), glm::mat4(2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1), glm::mat4(2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1) };
			glm::vec4 VectorArray[] = { glm::vec4(4, 2, 0, 6), glm::vec4(9, 9, 9, 9), glm::vec4(1, 1, 1, 1) };

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());

			rawWrapper->Initialize();
			rawWrapper->Data->Append("IntegerValue");
			rawWrapper->Data->Find("IntegerValue")->SetStorage(IntArray, 3);
			rawWrapper->Data->Append("FloatValue");
			rawWrapper->Data->Find("FloatValue")->SetStorage(FloatArray, 3);
			rawWrapper->Data->Append("MatrixValue");
			rawWrapper->Data->Find("MatrixValue")->SetStorage(MatrixArray, 3);
			rawWrapper->Data->Append("VectorValue");
			rawWrapper->Data->Find("VectorValue")->SetStorage(VectorArray, 3);
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(0) == 100);
			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(1) == 200);
			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(2) == 300);

			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(0) == 100.2f);
			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(1) == 100.3f);
			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(2) == 100.4f);

			Assert::IsTrue(rawWrapper->Data->Find("MatrixValue")->GetMatrix(0) == glm::mat4(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1));
			Assert::IsTrue(rawWrapper->Data->Find("MatrixValue")->GetMatrix(1) == glm::mat4(2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2));
			Assert::IsTrue(rawWrapper->Data->Find("MatrixValue")->GetMatrix(2) == glm::mat4(3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3));

			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(0) == glm::vec4(1, 2, 3, 4));
			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(1) == glm::vec4(4, 3, 2, 1));
			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(2) == glm::vec4(2, 4, 6, 8));
		}

		TEST_METHOD(JSONTableWrapperDestroy)
		{
			std::string fullPath = R"(Content\JSONMiniTest.json)";

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			parseCoordinator.Initialize();

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());

			parseCoordinator.DeserializeObjectFromFile(fullPath);

			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(0) == 100);
			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(1) == 200);
			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(2) == 300);

			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(0) == 100.2f);
			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(1) == 100.3f);
			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(2) == 100.4f);

			Assert::IsTrue(rawWrapper->Data->Find("StringValue")->GetString(0) == "Hi");
			Assert::IsTrue(rawWrapper->Data->Find("StringValue")->GetString(1) == "Hello");
			Assert::IsTrue(rawWrapper->Data->Find("StringValue")->GetString(2) == "Howdy");

			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(0) == glm::vec4(1, 2, 3, 4));
			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(1) == glm::vec4(4, 3, 2, 1));
			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(2) == glm::vec4(2, 4, 6, 8));

			//rawWrapper->~Wrapper();
		//	Assert::IsTrue(rawWrapper->Data->Size() == 0);
		//	Assert::IsTrue(rawWrapper->Data->Find("IntegerValue") == nullptr);
		//	Assert::IsTrue(rawWrapper->Data->Find("FloatValue") == nullptr);
		//	Assert::IsTrue(rawWrapper->Data->Find("StringValue") == nullptr);
		//	Assert::IsTrue(rawWrapper->Data->Find("VectorValue") == nullptr);

		}

		TEST_METHOD(JSONTableClone)
		{
			std::string fullPath = R"(Content\JSONPrimitiveTest.json)";

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());

			Assert::IsTrue(rawWrapper->Data->Size() == 6);

			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(0) == 100);

			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(0) == 100.2f);

			Assert::IsTrue(rawWrapper->Data->Find("StringValue")->GetString(0) == "Hi");

			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(0) == glm::vec4(1, 2, 3, 4));

			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope()->Size() == 1);
			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope(0)->Find("Cake")->GetString(0) == "red velvet");

			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Cake Recipe")->GetScope()->Find("Cake")->GetString() == "red velvet");
			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Cake Recipe")->GetScope()->Find("Frosting")->GetString() == "cream cheese");

			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Tea Recipe")->GetScope()->Find("Tea")->GetString() == "black");
			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Tea Recipe")->GetScope()->Find("Sweetener")->GetString() == "honey");

			unique_ptr<JsonParseCoordinator>otherParseCoordinator = parseCoordinator.Clone();
			rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(otherParseCoordinator->GetWrapper().get());
			Assert::IsTrue(rawWrapper->Data->Size()  == 0);

			otherParseCoordinator->DeserializeObjectFromFile(fullPath);
			Assert::IsTrue(rawWrapper->Data->Size() == 6);

			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue")->GetInt(0) == 100);

			Assert::IsTrue(rawWrapper->Data->Find("FloatValue")->GetFloat(0) == 100.2f);

			Assert::IsTrue(rawWrapper->Data->Find("StringValue")->GetString(0) == "Hi");

			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->GetVector(0) == glm::vec4(1, 2, 3, 4));

			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope()->Size() == 1);
			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue")->GetScope(0)->Find("Cake")->GetString(0) == "red velvet");

			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Cake Recipe")->GetScope()->Find("Cake")->GetString() == "red velvet");
			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Cake Recipe")->GetScope()->Find("Frosting")->GetString() == "cream cheese");

			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Tea Recipe")->GetScope()->Find("Tea")->GetString() == "black");
			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray")->GetScope(0)->Find("Tea Recipe")->GetScope()->Find("Sweetener")->GetString() == "honey");
		}

		TEST_METHOD(JsonTableFailedParse)
		{
			std::string fullPath = R"(Content\JSONInvalidData.json)";

			shared_ptr<JsonParseCoordinator::Wrapper> wrapper(new JsonTableParseHelper::Wrapper(std::make_shared<Scope>()));
			JsonParseCoordinator parseCoordinator(wrapper);
			auto testParseHelper = make_shared<JsonTableParseHelper>();
			parseCoordinator.AddHelper(testParseHelper);

			JsonTableParseHelper::Wrapper* rawWrapper = static_cast<JsonTableParseHelper::Wrapper*>(wrapper.get());
			parseCoordinator.DeserializeObjectFromFile(fullPath);

			Assert::IsTrue(rawWrapper->Data->Size() == 4);
			Assert::IsTrue(rawWrapper->Data->Find("IntegerValue") == nullptr);
			Assert::IsTrue(rawWrapper->Data->Find("FloatValue") == nullptr);
			Assert::IsTrue(rawWrapper->Data->Find("StringValue") == nullptr);
			Assert::IsTrue(rawWrapper->Data->Find("MatrixValue")->Size() == 0); //After setfromstring failure, the datum is wiped.
			Assert::IsTrue(rawWrapper->Data->Find("VectorValue")->Size() == 0);
			Assert::IsTrue(rawWrapper->Data->Find("ScopeValue") == nullptr);
			Assert::IsTrue(rawWrapper->Data->Find("NestedScopeArray") == nullptr);
			Assert::IsTrue(rawWrapper->Data->Find("SingleMatrixValue")->Size() == 0); //After setfromstring failure, the datum is wiped.
			Assert::IsTrue(rawWrapper->Data->Find("SingleVectorValue")->Size() == 0);
		}

		private: //Creates memory state screenshots to ensure no memory leaks in any test
		inline static _CrtMemState _startMemState;
	};
}